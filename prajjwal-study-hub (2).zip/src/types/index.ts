export type UserRole = 'student' | 'admin';
export type AcademicLevel = 'Foundation' | 'Diploma' | 'Degree' | 'BS Degree';
export type AcademicSubLevel = 'Foundation' | 'Diploma in Programming' | 'Diploma in Data Science' | 'Degree' | 'Degree Level' | 'BSc Degree Level' | 'BS Degree Level' | 'Degree / BS Level';
export type QuestionType = 'MCQ' | 'MSQ' | 'NAT' | 'CODE_OUTPUT' | 'OPPE_CODE';
export type ExamCategory = 'Quiz 1' | 'Quiz 2' | 'End Term' | 'OPPE 1' | 'OPPE 2' | 'Qualifier Mock' | 'Subject Practice' | string;

export interface TestCase {
  id: string;
  input: string;
  expectedOutput: string;
  isHidden?: boolean;
  explanation?: string;
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  role: UserRole;
  programEnrolled?: string;
  currentTerm?: string;
  academicLevel?: AcademicLevel;
  createdAt: string;
  updatedAt: string;
  bio?: string;
  targetExam?: string;
  studyGoal?: string;
  dailyGoalMinutes?: number;
}

export interface Program {
  id: string;
  title: string;
  code: string;
  description: string;
  level: 'Foundation' | 'Diploma' | 'Degree' | 'General';
  published: boolean;
  coursesCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Course {
  id: string;
  programId: string;
  title: string;
  code: string;
  description: string;
  term?: string;
  credit?: number;
  category: 'Mathematics' | 'Statistics' | 'Programming' | 'Data Science' | 'Humanities' | 'Core CS' | string;
  color?: string;
  iconName?: string;
  published: boolean;
  order?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Module {
  id: string;
  courseId: string;
  title: string;
  weekNumber?: number;
  order?: number;
  description: string;
  published?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Topic {
  id: string;
  moduleId: string;
  courseId: string;
  title: string;
  order: number;
  description?: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PracticeProblem {
  id: string;
  questionText: string;
  options?: string[];
  correctOptionIndex?: number;
  correctOptionIndices?: number[];
  correctAnswer?: string;
  numericAnswer?: number;
  solution: string;
  hints?: string[];
  type?: 'MCQ' | 'MSQ' | 'NAT' | 'CODE_OUTPUT';
}

export interface FormulaItem {
  name: string;
  formula: string; // LaTeX expression
  description: string;
  variables?: { symbol: string; meaning: string }[];
  keyPoints?: string[];
}

export interface WeeklyStudyMaterial {
  id: string;
  courseId: string;
  courseTitle: string;
  courseCode: string;
  level: AcademicLevel;
  subLevel?: AcademicSubLevel;
  weekNumber: number;
  title: string;
  detailedNotes?: string; // comprehensive conceptual explanations, derivations, examples & solved problems
  quickRevisionNotes?: string[]; // bulleted high-yield summary points and key takeaways
  formulaSheets?: FormulaItem[]; // mathematical formulas, theorems, definitions & syntax cheat-sheets
  practiceQuestions?: PracticeProblem[]; // minimum 3-5 standard practice problems with step-by-step solutions/hints
  // Compatibility fields
  keyTakeaways?: string[]; // alias/fallback to quickRevisionNotes
  markdownContent?: string; // alias/fallback to detailedNotes
  definitions?: Array<{ term: string; explanation: string; formula?: string }>;
  codeSnippets?: Array<{ language: string; title: string; code: string }>;
  examTips?: string[];
  handwrittenMnemonic?: string;
  practiceRecommendation?: string;
}

export type WeeklyChapterNote = WeeklyStudyMaterial;

export interface Note {
  id: string;
  title: string;
  description: string;
  programId?: string;
  courseId: string;
  moduleId?: string;
  topicId?: string;
  weekNumber?: number;
  fileUrl?: string;
  fileName?: string;
  contentMarkdown?: string;
  detailedNotes?: string;
  quickRevisionNotes?: string[];
  revisionNotes?: string[];
  formulaSheets?: FormulaItem[];
  formulaSheet?: string | FormulaItem[];
  practiceQuestions?: PracticeProblem[];
  authorName: string;
  uploadedBy?: string;
  tags: string[];
  readingTimeMinutes: number;
  fileSize?: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FormulaSheet {
  id: string;
  title: string;
  courseId: string;
  topicId?: string;
  formula: string;
  latex?: string;
  explanation: string;
  keyPoints?: string[];
  variables?: { symbol: string; meaning: string }[];
  fileUrl?: string;
  tags: string[];
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Question {
  id: string;
  courseId: string;
  courseTitle?: string;
  level?: AcademicLevel;
  subLevel?: AcademicSubLevel;
  subject?: string;
  type?: QuestionType;
  questionText: string;
  codeSnippet?: string;
  starterCode?: string;
  options: string[];
  correctOptionIndex?: number;
  correctOptionIndices?: number[]; // for MSQ
  correctNumericAnswer?: number; // for NAT
  numericTolerance?: number; // for NAT
  toleranceRange?: [number, number]; // e.g. [3.12, 3.16]
  hints?: string[];
  formulaRef?: string;
  testCases?: TestCase[];
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  marks: number;
  negativeMarks?: number;
  tags?: string[];
  term?: string;
  pyqYear?: string; // e.g. "Qualifier 2023", "Quiz 1 2024", "End Term 2023", "Jan 2025"
  moduleId?: string;
  topicId?: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface MockTest {
  id: string;
  title: string;
  description?: string;
  courseId: string;
  courseTitle?: string;
  programId?: string;
  level?: AcademicLevel;
  subLevel?: AcademicSubLevel;
  subject?: string;
  type: 'Quiz 1' | 'Quiz 2' | 'End Term' | 'OPPE 1' | 'OPPE 2' | 'Qualifier Mock' | 'Subject Practice' | 'Full Syllabus' | string;
  examCategory?: ExamCategory;
  examType?: ExamCategory;
  academicTerm?: string; // e.g. "Jan 2026", "Sept 2025", "May 2025", "Jan 2025", "Sept 2024", "May 2024", "Jan 2024", "Sept 2023", "May 2023", "2022", "2021"
  termYear?: string;
  durationMinutes: number;
  totalMarks: number;
  passingMarks: number;
  totalQuestions: number;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Standard' | 'Challenging' | 'Comprehensive' | 'Exam Standard' | string;
  instructions: string[];
  questionIds?: string[];
  questions?: Question[];
  isOppe?: boolean;
  availableFrom?: string;
  availableUntil?: string;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface QuestionResponse {
  questionId: string;
  selectedOptionIndex?: number;
  selectedOptionIndices?: number[];
  numericAnswer?: string;
  codeAnswer?: string;
  testCasesPassed?: number;
  totalTestCases?: number;
  isMarkedForReview: boolean;
  isAnswered: boolean;
  isCorrect?: boolean;
  marksAwarded?: number;
  timeSpentSeconds?: number;
}

export interface TestAttempt {
  id: string;
  userId: string;
  testId: string;
  mockTestId?: string;
  testTitle: string;
  level?: AcademicLevel;
  subLevel?: AcademicSubLevel;
  examCategory?: ExamCategory;
  courseId: string;
  courseTitle: string;
  score: number;
  totalMarks: number;
  percentage: number;
  accuracy: number;
  timeSpentSeconds: number;
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  unattempted: number;
  responses?: Record<string, QuestionResponse>;
  completedAt: string;
}

export interface StudyPlanTask {
  id: string;
  userId: string;
  title: string;
  description?: string;
  date: string;
  startTime?: string;
  endTime?: string;
  courseId?: string;
  courseTitle?: string;
  topicTitle?: string;
  topic?: string;
  priority: 'low' | 'medium' | 'high';
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type StudyTask = StudyPlanTask;

export interface BookmarkItem {
  id: string;
  userId: string;
  itemType: 'note' | 'formula' | 'question' | 'course' | string;
  itemId: string;
  title?: string;
  itemTitle?: string;
  courseTitle?: string;
  courseName?: string;
  notes?: string;
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  category: 'feedback' | 'resource_request' | 'correction' | 'general' | string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'replied';
}

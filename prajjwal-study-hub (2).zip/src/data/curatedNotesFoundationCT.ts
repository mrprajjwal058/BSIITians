import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_CT_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-ct-w1',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Computational Thinking Pillars: Decomposition, Abstraction & Pattern Recognition',
    detailedNotes: `### Week 1: Foundational Pillars of Computational Thinking

#### 1. The Four Pillars of Computational Thinking
1. **Decomposition:** Breaking a complex, unstructured problem into smaller, manageable, and independently solvable sub-problems.
2. **Pattern Recognition:** Identifying similarities, recurring trends, invariants, and structural regularities across problem instances.
3. **Abstraction:** Isolating essential, high-level features while stripping away unnecessary implementation noise and superficial details.
4. **Algorithm Design:** Devising a finite, deterministic, step-by-step sequence of instructions to solve any instance of the generalized problem.

#### 2. Variables, States & Pseudocode Primitives
- **State:** The snapshot of all variable values in memory at a given execution step.
- **Assignment Operator ($\leftarrow$):** Mutates state by evaluating the right-hand side expression and storing the result in the left-hand variable.
- **Sequence:** Step-by-step sequential execution order from top to bottom.`,
    quickRevisionNotes: [
      'Four pillars: Decomposition (Breakdown), Pattern Recognition (Trends), Abstraction (Filtering noise), Algorithm Design (Step-by-step logic).',
      'Abstraction removes irrelevant details to build generalized models.',
      'State represents the memory snapshot of all variables at a specific execution timestamp.',
      'Assignment operator mutates the variable on the left with the evaluated result on the right.'
    ],
    formulaSheets: [
      {
        name: 'Computational Problem Solving Model',
        formula: '\\text{Problem} \\xrightarrow{\\text{Decompose}} \\text{Sub-problems} \\xrightarrow{\\text{Abstract}} \\text{Algorithm} \\xrightarrow{\\text{Execute}} \\text{Solution}',
        description: 'Standard CT workflow pipeline.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w1-p1',
        questionText: 'When designing a transit navigation app, ignoring street tree positions and only modeling road intersections and distances is an example of which CT pillar?',
        options: ['Abstraction', 'Decomposition', 'Pattern Recognition', 'Recursion'],
        correctOptionIndex: 0,
        solution: 'Filtering out non-essential environmental visual features and retaining only topological network nodes and edge weights is Abstraction.',
        hints: ['Consider which pillar filters out irrelevant real-world details.']
      },
      {
        id: 'ct-w1-p2',
        questionText: 'Breaking an e-commerce platform into user authentication, cart management, payment gateway, and order fulfillment is an example of:',
        options: ['Decomposition', 'Abstraction', 'Algorithm Design', 'Pattern Matching'],
        correctOptionIndex: 0,
        solution: 'Dividing a monolithic system into discrete, smaller modular subsystems is Decomposition.',
        hints: ['Breaking a large problem into parts.']
      },
      {
        id: 'ct-w1-p3',
        questionText: 'If variable $A = 5$ and $B = 10$, what are their values after executing: $A \\leftarrow A + B$; $B \\leftarrow A - B$; $A \\leftarrow A - B$?',
        options: ['A = 10, B = 5', 'A = 5, B = 10', 'A = 15, B = 15', 'A = 0, B = 0'],
        correctOptionIndex: 0,
        solution: 'Step 1: $A = 5 + 10 = 15$. Step 2: $B = 15 - 10 = 5$. Step 3: $A = 15 - 5 = 10$. This is the classic arithmetic variable swap algorithm without temporary variables.',
        hints: ['Trace the variable values step-by-step.']
      }
    ],
    keyTakeaways: [
      'Computational thinking is a universal problem-solving methodology independent of specific coding syntax.',
      'Abstraction enables scalable architectural design in complex software systems.'
    ],
    markdownContent: `### Week 1: Pillars of Computational Thinking\nDecomposition, pattern recognition, abstraction, and state transitions.`,
    examTips: ['Always trace state step-by-step using a table with columns for each variable!']
  },
  {
    id: 'note-ct-w2',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Algorithms, Flowcharts, State Tables, Invariants & Dry Runs',
    detailedNotes: `### Week 2: Algorithmic Traces, State Tables & Control Flow

#### 1. Flowchart Geometry & Standard Symbols
- **Terminal (Oval / Pill):** Start and End of execution.
- **Process (Rectangle):** Computational statement or state assignment (e.g. $X \\leftarrow X + 1$).
- **Decision (Diamond):** Conditional branch evaluating a boolean predicate (True / False).
- **Input/Output (Parallelogram):** Reading data or outputting values.

#### 2. State Table (Dry Run Table)
A structured matrix tracking variable values after each discrete execution step. Indispensable for debugging logic and proving termination.

#### 3. Loop Invariants
A mathematical condition or predicate that is:
1. **Initialization:** True before the first iteration of the loop.
2. **Maintenance:** If true before an iteration, remains true after the iteration.
3. **Termination:** Upon loop exit, provides a guarantee of algorithmic correctness.`,
    quickRevisionNotes: [
      'Flowchart symbols: Oval (Start/End), Rectangle (Process/Assignment), Diamond (Decision), Parallelogram (I/O).',
      'State tables track execution line-by-line across iteration steps.',
      'Loop invariants must hold at initialization, maintenance, and termination.',
      'Dry runs identify off-by-one boundary errors.'
    ],
    formulaSheets: [
      {
        name: 'Loop Invariant Principle',
        formula: 'P(\\text{Initial}) \\land [P(k) \\implies P(k+1)] \\implies P(\\text{Final Correctness})',
        description: 'Inductive proof template for algorithmic iteration correctness.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w2-p1',
        questionText: 'What standard flowchart shape represents a conditional boolean branch ($X > 0$)?',
        options: ['Diamond', 'Rectangle', 'Parallelogram', 'Oval'],
        correctOptionIndex: 0,
        solution: 'Diamonds represent decision points with two branching paths (True / False).',
        hints: ['Recall standard flowchart symbols.']
      },
      {
        id: 'ct-w2-p2',
        questionText: 'Consider pseudocode: $S \\leftarrow 0; i \\leftarrow 1$; while ($i \\le 4$) do: $S \\leftarrow S + i$; $i \\leftarrow i + 1$; end. What is final $S$?',
        options: ['10', '15', '4', '6'],
        correctOptionIndex: 0,
        solution: 'Iteration 1: $S = 1, i = 2$. Iteration 2: $S = 1+2=3, i = 3$. Iteration 3: $S = 3+3=6, i = 4$. Iteration 4: $S = 6+4=10, i = 5$. Loop terminates since $5 > 4$. Final $S = 10$.',
        hints: ['Compute $1 + 2 + 3 + 4$.']
      },
      {
        id: 'ct-w2-p3',
        questionText: 'What three stages must be verified to prove a loop invariant?',
        options: ['Initialization, Maintenance, Termination', 'Input, Processing, Output', 'Declaration, Assignment, Return', 'Start, Branch, End'],
        correctOptionIndex: 0,
        solution: 'A loop invariant is proven inductively via Initialization (base case), Maintenance (inductive step), and Termination (correctness).',
        hints: ['Similar to mathematical induction steps.']
      }
    ],
    keyTakeaways: [
      'Dry running with state tables prevents subtle off-by-one errors.',
      'Loop invariants formally prove termination and algorithmic correctness.'
    ],
    markdownContent: `### Week 2: Flowcharts & State Tables\nDiagrammatic logic, dry runs, and invariant induction proofs.`,
    examTips: ['Always note down the final value of the loop counter variable upon loop termination!']
  },
  {
    id: 'note-ct-w3',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Iteration Patterns: Nested Loops, Counters & Accumulators',
    detailedNotes: `### Week 3: Iteration Mechanics & Accumulation Patterns

#### 1. Counters vs Accumulators
- **Counter Pattern:** $C \\leftarrow C + 1$ (Tracks frequency, occurrences, or step iterations).
- **Accumulator Pattern:** $S \\leftarrow S + X$ (Maintains running sum, aggregate score, or concatenated result).
- **Extreme Tracker Pattern:**
  - $\\text{MaxVal} \\leftarrow -\\infty$; if ($X > \\text{MaxVal}$) then $\\text{MaxVal} \\leftarrow X$.

#### 2. Nested Loops & Coordinate Grids
When an inner loop executes completely for every single step of an outer loop:
- Outer loop ($i$ from $1$ to $N$): executes $N$ times.
- Inner loop ($j$ from $1$ to $M$): executes $M$ times per outer step.
- **Total Operations:** $N \\times M$.
- **Triangular Loops ($j$ from $1$ to $i$):** Total operations $= \\frac{N(N+1)}{2} = O(N^2)$.`,
    quickRevisionNotes: [
      'Counter: $C \\leftarrow C + 1$; Accumulator: $S \\leftarrow S + X$.',
      'For nested rectangular loops ($N \\times M$), total iterations equal $N \\cdot M$.',
      'For triangular loops ($j$ from $1$ to $i$), total iterations equal $\\frac{N(N+1)}{2}$.',
      'Initialize min-trackers to $+\\infty$ and max-trackers to $-\\infty$.'
    ],
    formulaSheets: [
      {
        name: 'Triangular Loop Iteration Sum',
        formula: '\\sum_{i=1}^n i = \\frac{n(n + 1)}{2}',
        description: 'Total step count in triangular nested loop execution.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w3-p1',
        questionText: 'How many times does the inner print statement execute in: for $i = 1$ to 5 do: for $j = 1$ to $i$ do: print("*")?',
        options: ['15', '25', '10', '20'],
        correctOptionIndex: 0,
        solution: 'Total iterations $= 1 + 2 + 3 + 4 + 5 = \\frac{5(6)}{2} = 15$.',
        hints: ['Sum integers from 1 to 5.']
      },
      {
        id: 'ct-w3-p2',
        questionText: 'What is the correct initialization for finding the maximum value in a list of negative temperatures?',
        options: ['MaxVal = -\\infty', 'MaxVal = 0', 'MaxVal = 100', 'MaxVal = \\infty'],
        correctOptionIndex: 0,
        solution: 'Initializing to 0 would fail if all temperatures are negative (e.g. -5, -10), as 0 would incorrectly remain the maximum. Hence $-\\infty$ or the first list element must be used.',
        hints: ['What happens if all dataset values are negative?']
      },
      {
        id: 'ct-w3-p3',
        questionText: 'How many total iterations occur in a 3-level nested loop where each loop runs from 1 to 4?',
        options: ['64', '12', '16', '256'],
        correctOptionIndex: 0,
        solution: 'Total iterations $= 4 \\times 4 \\times 4 = 4^3 = 64$.',
        hints: ['Multiply individual loop bounds: $4 \\times 4 \\times 4$.']
      }
    ],
    keyTakeaways: [
      'Nested loops traverse matrices, grids, and pairwise entity relationships.',
      'Improper sentinel initialization leads to silent edge-case logic failures.'
    ],
    markdownContent: `### Week 3: Iteration & Nested Loops\nCounters, accumulators, triangular matrices, and sentinel values.`,
    examTips: ['Always trace triangular loop bounds: check if $j$ goes up to $i$ or $i - 1$!']
  },
  {
    id: 'note-ct-w4',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Filtering, Conditional Logic & Searching Fundamentals',
    detailedNotes: `### Week 4: Filtering Patterns & Search Strategies

#### 1. Filter / Selection Pattern
Traverse a sequence and append elements that satisfy a boolean predicate $P(x)$ into an output collection.
- **Short-Circuit Evaluation:**
  - $A \\land B$: If $A$ is False, $B$ is NOT evaluated.
  - $A \\lor B$: If $A$ is True, $B$ is NOT evaluated.

#### 2. Linear Search Algorithm
Iterate sequentially through an array of $n$ elements:
- **Best Case:** Target at first index $\\implies 1$ comparison ($O(1)$).
- **Worst Case:** Target at end or absent $\\implies n$ comparisons ($O(n)$).
- **Average Case:** $\\approx \\frac{n+1}{2}$ comparisons.

#### 3. Binary Search Algorithm (Pre-sorted Arrays ONLY)
Repeatedly halve the search window:
$$\\text{mid} = \\left\\lfloor \\frac{\\text{low} + \\text{high}}{2} \\right\\rfloor$$
- **Comparisons:** At most $\\lceil \\log_2(n) \\rceil + 1$ comparisons ($O(\\log n)$).`,
    quickRevisionNotes: [
      'Linear search works on ANY unordered array in $O(n)$ time.',
      'Binary search REQUIRES a sorted array and runs in $O(\\log n)$ time.',
      'Short-circuit boolean logic prevents null-pointer or division-by-zero crashes.',
      'Binary search mid calculation: $\\text{mid} = \\lfloor (\\text{low} + \\text{high})/2 \\rfloor$.'
    ],
    formulaSheets: [
      {
        name: 'Binary Search Maximum Comparisons',
        formula: 'k = \\lfloor \\log_2(n) \\rfloor + 1',
        description: 'Maximum comparison upper bound for binary search over n elements.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w4-p1',
        questionText: 'What is the maximum number of comparisons required to search for a key in a sorted array of 1000 elements using Binary Search?',
        options: ['10', '1000', '500', '14'],
        correctOptionIndex: 0,
        solution: '$\\lceil \\log_2(1000) \\rceil = 10$ because $2^9 = 512 < 1000 \\le 2^{10} = 1024$. At most 10 comparisons are needed.',
        hints: ['Find the power of 2 that exceeds 1000: $2^k \\ge 1000$.']
      },
      {
        id: 'ct-w4-p2',
        questionText: 'Why can Binary Search NOT be applied directly on an unsorted linked list?',
        options: ['Linked lists lack random O(1) access to middle elements, and elements are unsorted', 'Linked lists only store integers', 'Linked lists cannot be searched', 'Binary search requires fixed-size 32-bit words'],
        correctOptionIndex: 0,
        solution: 'Binary search requires both sorted order and $O(1)$ random indexing to jump directly to the middle element, which standard singly-linked lists do not support.',
        hints: ['Consider indexing efficiency in linked lists.']
      },
      {
        id: 'ct-w4-p3',
        questionText: 'In short-circuit evaluation of `(x != 0) && (10 / x > 2)`, what happens when `x == 0`?',
        options: ['First condition evaluates to False, second condition is skipped, avoiding division by zero', 'Program crashes with division by zero', 'Expression returns True', 'Second condition is evaluated first'],
        correctOptionIndex: 0,
        solution: 'Because the left side evaluates to False in an AND operation, the runtime immediately short-circuits to False without evaluating the right operand, safely avoiding division by zero.',
        hints: ['Recall short-circuit behavior of `&&`.']
      }
    ],
    keyTakeaways: [
      'Binary search logarithmic scaling is the foundation of database B-tree lookups.',
      'Short-circuit boolean guards prevent runtime exceptions.'
    ],
    markdownContent: `### Week 4: Filtering & Searching\nLinear search, binary search, and boolean short-circuit evaluation.`,
    examTips: ['Remember that Binary Search ONLY works when the dataset is strictly sorted!']
  },
  {
    id: 'note-ct-w5',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Datasets, Tabular Records, Grouping, Aggregations & Pivot Logic',
    detailedNotes: `### Week 5: Structured Data Processing & Relational Aggregation

#### 1. Tabular Representation (Records & Fields)
- **Table / Relation:** Collection of records (rows).
- **Field / Attribute:** Column representing a specific characteristic.
- **Primary Key:** An attribute uniquely identifying every record in the table.

#### 2. Group By & Aggregation Patterns
To compute statistics partitioned by category (e.g. Total sales per department):
1. **Partitioning:** Group records sharing identical category keys.
2. **Aggregation:** Apply accumulator functions ($(\\text{COUNT}, \\text{SUM}, \\text{AVG}, \\text{MIN}, \\text{MAX})$) within each grouped partition.

#### 3. Pivot Tables & Cross-Tabulation
Transforming row-level transactional records into a multi-dimensional summary matrix where distinct values of one attribute become column headers.`,
    quickRevisionNotes: [
      'Primary key uniquely identifies each record in a dataset.',
      'Group-By operations partition rows by key and apply independent aggregations.',
      'Pivot tables rotate unique attribute values into distinct summary columns.',
      'Aggregation functions include COUNT, SUM, AVG, MIN, MAX.'
    ],
    formulaSheets: [
      {
        name: 'Grouped Average Relation',
        formula: '\\text{AVG}_{\\text{group}} = \\frac{\\sum_{i \\in \\text{group}} X_i}{\\text{COUNT}_{\\text{group}}}',
        description: 'Partitioned arithmetic average aggregation.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w5-p1',
        questionText: 'In a database table of 500 employee records across 5 distinct departments, how many rows will the result of `GROUP BY Department` contain?',
        options: ['5', '500', '100', '25'],
        correctOptionIndex: 0,
        solution: 'Grouping by department collapses the 500 rows into 1 summary row per distinct department, producing exactly 5 rows in the output.',
        hints: ['Number of output rows equals the number of distinct groups.']
      },
      {
        id: 'ct-w5-p2',
        questionText: 'Which property must a primary key field satisfy in a tabular dataset?',
        options: ['Unique and Non-Null for every record', 'Must be a positive floating-point number', 'Must be sorted in ascending order', 'Must contain duplicate values'],
        correctOptionIndex: 0,
        solution: 'A primary key must be unique across all rows and cannot contain null values.',
        hints: ['Uniqueness and non-null constraint.']
      },
      {
        id: 'ct-w5-p3',
        questionText: 'What is the effect of pivoting a dataset on a column with 10 distinct values?',
        options: ['Creates 10 new summary columns in the resulting matrix', 'Creates 10 new tables', 'Deletes 10 rows', 'Multiplies record count by 10'],
        correctOptionIndex: 0,
        solution: 'Pivoting rotates the distinct values of the target column into individual column headers in the cross-tabulated result.',
        hints: ['Pivoting turns distinct values into column headers.']
      }
    ],
    keyTakeaways: [
      'Relational aggregations form the core of SQL and Pandas DataFrame manipulations.',
      'Pivoting reshapes transactional logs into analytical feature matrices.'
    ],
    markdownContent: `### Week 5: Datasets & Group By Aggregations\nRelational records, primary keys, grouping logic, and pivot matrices.`,
    examTips: ['Remember: `COUNT` counts rows, whereas `SUM` aggregates the numerical values inside the specified column!']
  },
  {
    id: 'note-ct-w6',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Two-Way Tables, Cross-Tabulations & Joint Cardinality Relations',
    detailedNotes: `### Week 6: Two-Way Tables & Cardinality Ratios

#### 1. Two-Way Contingency Tables in Computational Thinking
A grid representation mapping two categorical attributes $(A, B)$ with counts $N_{ij}$:
- **Row Totals ($R_i$):** Marginal counts for attribute $A$.
- **Column Totals ($C_j$):** Marginal counts for attribute $B$.
- **Grand Total ($N$):** $\\sum R_i = \\sum C_j = N$.

#### 2. Cardinality Ratios & Relations
- **One-to-One (1:1):** Each element of $A$ maps to at most one element of $B$, and vice versa (e.g. Citizen to Passport Number).
- **One-to-Many (1:N):** One entity in $A$ associates with multiple entities in $B$ (e.g. Department to Employees).
- **Many-to-Many (M:N):** Entities in both sets relate to multiple entities in the other (e.g. Students to Courses).`,
    quickRevisionNotes: [
      'Two-way tables cross-tabulate frequencies across two categorical attributes.',
      'Row totals and column totals both sum to the Grand Total $N$.',
      'Cardinality types: 1:1, 1:N, M:N.',
      'Many-to-Many relationships require junction/bridge tables in relational schemas.'
    ],
    formulaSheets: [
      {
        name: 'Grand Total Matrix Invariant',
        formula: 'N = \\sum_{i=1}^r \\sum_{j=1}^c N_{ij} = \\sum_{i=1}^r R_i = \\sum_{j=1}^c C_j',
        description: 'Conservation of total counts in cross-tabulation tables.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w6-p1',
        questionText: 'What type of cardinality relationship exists between Students and Courses in a university?',
        options: ['Many-to-Many (M:N)', 'One-to-One (1:1)', 'One-to-Many (1:N)', 'None of the above'],
        correctOptionIndex: 0,
        solution: 'Each student can enroll in multiple courses, and each course contains multiple students, which is a Many-to-Many (M:N) relationship.',
        hints: ['Can a student take multiple courses? Can a course have multiple students?']
      },
      {
        id: 'ct-w6-p2',
        questionText: 'In a 2-way table of 200 surveyed users, Row 1 has total 120 and Row 2 has total 80. Column 1 has total 90. What is the total of Column 2?',
        options: ['110', '120', '90', '100'],
        correctOptionIndex: 0,
        solution: 'Grand total $N = 120 + 80 = 200$. Sum of column totals must equal $N$: $C_1 + C_2 = 200 \\implies 90 + C_2 = 200 \\implies C_2 = 110$.',
        hints: ['Column totals sum to the Grand Total $N = 200$.']
      },
      {
        id: 'ct-w6-p3',
        questionText: 'How is a Many-to-Many relationship represented in a normalized relational database?',
        options: ['Using an associative / junction table with two foreign keys', 'Using a single column with comma-separated values', 'It cannot be represented in SQL', 'By duplicating the entire database'],
        correctOptionIndex: 0,
        solution: 'A junction/bridge table containing foreign keys referencing both primary entities resolves M:N relationships into two 1:N links.',
        hints: ['Recall junction table design.']
      }
    ],
    keyTakeaways: [
      'Two-way tables allow fast computation of joint and conditional probability distributions.',
      'Cardinality defines foreign key constraints and schema relationships.'
    ],
    markdownContent: `### Week 6: Two-Way Tables & Cardinality\nContingency grids, marginal sums, and relational entity cardinalities.`,
    examTips: ['Check that the sum of row sums equals the sum of column sums!']
  },
  {
    id: 'note-ct-w7',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Sorting Algorithms: Bubble Sort, Selection Sort & Insertion Sort',
    detailedNotes: `### Week 7: Comparison-Based Sorting Algorithms & Invariants

#### 1. Bubble Sort
Repeatedly steps through the list, compares adjacent elements and swaps them if out of order:
- **Pass $k$:** Places the $k$-th largest element in its correct final position at the end.
- **Comparisons:** $\\frac{n(n-1)}{2} = O(n^2)$.
- **Best Case (with swapped flag):** $O(n)$ if already sorted.

#### 2. Selection Sort
Finds the minimum element from the unsorted subarray and swaps it with the first unsorted element:
- **Pass $k$:** Places the $k$-th smallest element in its final sorted position.
- **Comparisons:** Always $\\frac{n(n-1)}{2} = O(n^2)$ regardless of initial order.
- **Swaps:** At most $n - 1$ swaps ($O(n)$ writes).

#### 3. Insertion Sort
Builds the sorted array one element at a time by shifting larger elements to the right:
- **Best Case (Already sorted):** $O(n)$ comparisons, $0$ shifts.
- **Worst Case (Reverse sorted):** $O(n^2)$ comparisons and shifts.
- **Online & Adaptive:** Extremely fast for nearly-sorted arrays.`,
    quickRevisionNotes: [
      'Bubble Sort: Swaps adjacent elements; bubbles largest to the end in each pass.',
      'Selection Sort: Finds minimum and swaps with front; makes minimum number of swaps ($O(n)$).',
      'Insertion Sort: Inserts into sorted prefix; runs in $O(n)$ time for nearly-sorted data.',
      'All three have worst-case time complexity $O(n^2)$ and auxiliary space $O(1)$.'
    ],
    formulaSheets: [
      {
        name: 'Comparison Bound in Quadratic Sorts',
        formula: 'C(n) = \\sum_{i=1}^{n-1} (n - i) = \\frac{n(n - 1)}{2} = O(n^2)',
        description: 'Total comparisons in standard nested-loop sorting passes.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w7-p1',
        questionText: 'Which sorting algorithm performs the fewest number of element swaps ($O(n)$ worst-case)?',
        options: ['Selection Sort', 'Bubble Sort', 'Insertion Sort', 'Quick Sort'],
        correctOptionIndex: 0,
        solution: 'Selection sort makes at most 1 swap per outer loop pass, giving at most $n - 1$ swaps in total ($O(n)$ swaps).',
        hints: ['Selection sort only swaps once per pass after finding the minimum.']
      },
      {
        id: 'ct-w7-p2',
        questionText: 'What is the time complexity of Insertion Sort on an array that is ALREADY sorted in ascending order?',
        options: ['O(n)', 'O(n^2)', 'O(n \\log n)', 'O(1)'],
        correctOptionIndex: 0,
        solution: 'In an already-sorted array, each element is compared once with its predecessor and requires 0 shifts, completing in linear $O(n)$ time.',
        hints: ['Each element is already greater than its left neighbor.']
      },
      {
        id: 'ct-w7-p3',
        questionText: 'What is the array state after 1 pass of Bubble Sort on $[5, 1, 4, 2, 8]$?',
        options: ['[1, 4, 2, 5, 8]', '[1, 5, 4, 2, 8]', '[1, 2, 4, 5, 8]', '[5, 1, 2, 4, 8]'],
        correctOptionIndex: 0,
        solution: 'Compare (5,1)->swap [1,5,4,2,8]; Compare (5,4)->swap [1,4,5,2,8]; Compare (5,2)->swap [1,4,2,5,8]; Compare (5,8)->no swap [1,4,2,5,8]. Largest element 8 is now at the end.',
        hints: ['Trace adjacent pairwise comparisons and swaps.']
      }
    ],
    keyTakeaways: [
      'Insertion sort is the algorithm of choice for small partitions ($n \\le 16$) in hybrid algorithms like Timsort.',
      'Selection sort minimizes flash memory writes due to its $O(n)$ swap bound.'
    ],
    markdownContent: `### Week 7: Sorting Algorithms\nBubble, Selection, and Insertion sorts, comparison counts, and invariant proofs.`,
    examTips: ['Remember that Selection Sort makes $O(n^2)$ comparisons even if the array is already sorted!']
  },
  {
    id: 'note-ct-w8',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Algorithm Complexity, Asymptotic Analysis & Big-O Notation',
    detailedNotes: `### Week 8: Asymptotic Analysis & Big-O Complexity

#### 1. Big-O Formal Definition (Asymptotic Upper Bound)
$$f(n) = O(g(n)) \\iff \\exists c > 0, n_0 > 0 \\text{ such that } f(n) \\le c \\cdot g(n) \\quad \\forall n \\ge n_0$$

#### 2. Standard Hierarchy of Time Complexities
$$O(1) < O(\\log n) < O(\\sqrt{n}) < O(n) < O(n \\log n) < O(n^2) < O(n^3) < O(2^n) < O(n!)$$
- $O(1)$: Constant time (array indexing, hash lookup).
- $O(\\log n)$: Logarithmic time (binary search, balanced BST operations).
- $O(n)$: Linear time (single loop scan, counting).
- $O(n \\log n)$: Linearithmic (Merge Sort, Heap Sort, optimal comparison sorting).
- $O(n^2)$: Quadratic (nested loops, Bubble/Selection sort).
- $O(2^n)$: Exponential (generating all subsets, brute-force TSP).

#### 3. Space Complexity
Measures auxiliary memory allocated by an algorithm as a function of input size $n$.`,
    quickRevisionNotes: [
      'Big-O represents asymptotic upper bound on growth rate as $n \\to \\infty$.',
      'Complexity hierarchy: $O(1) < O(\\log n) < O(n) < O(n\\log n) < O(n^2) < O(2^n) < O(n!)$.',
      'Drop lower-order terms and multiplicative constants ($3n^2 + 50n + 1000 = O(n^2)$).',
      'Space complexity accounts for stack depth in recursive calls.'
    ],
    formulaSheets: [
      {
        name: 'Big-O Formal Bound',
        formula: 'f(n) \\le c \\cdot g(n) \\quad \\forall n \\ge n_0',
        description: 'Mathematical definition of asymptotic upper bounding.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w8-p1',
        questionText: 'What is the Big-O time complexity of $f(n) = 5n^3 + 100n^2 + 5000n + 2^n$?',
        options: ['O(2^n)', 'O(n^3)', 'O(n^2)', 'O(n!)'],
        correctOptionIndex: 0,
        solution: 'As $n \\to \\infty$, the exponential term $2^n$ grows strictly faster than any polynomial term $n^3$. Hence the dominant term is $O(2^n)$.',
        hints: ['Exponential growth dominates polynomial growth.']
      },
      {
        id: 'ct-w8-p2',
        questionText: 'An algorithm takes 1 millisecond for $n = 1000$. If its time complexity is $O(n^2)$, how long will it take for $n = 10,000$?',
        options: ['100 ms (0.1 s)', '10 ms', '1000 ms', '10,000 ms'],
        correctOptionIndex: 0,
        solution: 'Input size increased by factor of $10,000 / 1000 = 10$. For $O(n^2)$, execution time scales by $10^2 = 100$. New time $= 1\\text{ ms} \\times 100 = 100\\text{ ms}$.',
        hints: ['Time scales as $(n_2 / n_1)^2$.']
      },
      {
        id: 'ct-w8-p3',
        questionText: 'What is the auxiliary space complexity of an in-place Bubble Sort algorithm?',
        options: ['O(1)', 'O(n)', 'O(n^2)', 'O(\\log n)'],
        correctOptionIndex: 0,
        solution: 'In-place Bubble Sort only uses a single temporary variable for swapping, requiring $O(1)$ constant extra space.',
        hints: ['Does in-place sorting create new arrays?']
      }
    ],
    keyTakeaways: [
      'Big-O enables hardware-independent evaluation of algorithmic scalability.',
      'Polynomial time $O(n^k)$ is tractable; exponential time $O(2^n)$ is intractable for large $n$.'
    ],
    markdownContent: `### Week 8: Asymptotic Complexity & Big-O\nFormal limits, growth hierarchy, and time-space analysis.`,
    examTips: ['Always identify the dominant term and discard constant multiplicative factors!']
  },
  {
    id: 'note-ct-w9',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Divide & Conquer Paradigm, Merge Sort & Recurrence Relations',
    detailedNotes: `### Week 9: Divide-and-Conquer & Master Theorem

#### 1. The Divide-and-Conquer Paradigm
1. **Divide:** Partition the problem into smaller disjoint sub-problems of the same type.
2. **Conquer:** Solve sub-problems recursively; when small enough, solve base cases directly.
3. **Combine:** Merge the solutions of sub-problems to form the solution to the original problem.

#### 2. Merge Sort
- **Divide:** Split array into two halves at $\\text{mid} = \\lfloor (L + R)/2 \\rfloor$.
- **Conquer:** Recursively sort left and right subarrays.
- **Combine:** Merge two sorted subarrays in $O(n)$ time using two pointers.
- **Recurrence Relation:**
  $$T(n) = 2T(n/2) + O(n) \\implies T(n) = O(n \\log n)$$
- **Space Complexity:** $O(n)$ auxiliary memory for merging buffers.
- **Stability:** Merge Sort is a **stable** sorting algorithm.

#### 3. Master Theorem for Divide-and-Conquer Recurrences
For $T(n) = a T(n/b) + O(n^d)$:
1. If $d < \\log_b a \\implies T(n) = O(n^{\\log_b a})$
2. If $d = \\log_b a \\implies T(n) = O(n^d \\log n)$
3. If $d > \\log_b a \\implies T(n) = O(n^d)$`,
    quickRevisionNotes: [
      'Merge Sort recurrence: $T(n) = 2T(n/2) + O(n) = O(n \\log n)$ in Best, Average, and Worst cases.',
      'Merge Sort is stable but requires $O(n)$ auxiliary space.',
      'Master Theorem solves $T(n) = a T(n/b) + O(n^d)$ by comparing $d$ to $\\log_b a$.',
      'Merging two sorted arrays of size $n$ and $m$ takes $O(n + m)$ time.'
    ],
    formulaSheets: [
      {
        name: 'Master Theorem Recurrence Solver',
        formula: 'T(n) = a T(n/b) + O(n^d) \\implies T(n) = O(n^{\\log_b a}) \\text{ if } d < \\log_b a, \\; O(n^d \\log n) \\text{ if } d = \\log_b a',
        description: 'Closed-form asymptotic solver for divide-and-conquer recurrences.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w9-p1',
        questionText: 'Using the Master Theorem, solve $T(n) = 4T(n/2) + O(n)$.',
        options: ['O(n^2)', 'O(n \\log n)', 'O(n)', 'O(n^3)'],
        correctOptionIndex: 0,
        solution: '$a = 4, b = 2, d = 1$. $\\log_b a = \\log_2 4 = 2$. Since $d = 1 < \\log_b a = 2$, case 1 applies: $T(n) = O(n^{\\log_2 4}) = O(n^2)$.',
        hints: ['Compare $d=1$ with $\\log_2(4) = 2$.']
      },
      {
        id: 'ct-w9-p2',
        questionText: 'What is the maximum number of comparisons needed to merge two sorted arrays of size 5 and 7?',
        options: ['11', '12', '35', '7'],
        correctOptionIndex: 0,
        solution: 'To merge two sorted lists of sizes $n$ and $m$, the worst-case number of comparisons is $n + m - 1 = 5 + 7 - 1 = 11$.',
        hints: ['Worst-case merge comparisons formula is $n + m - 1$.']
      },
      {
        id: 'ct-w9-p3',
        questionText: 'What is the primary disadvantage of Merge Sort compared to Quick Sort or Heap Sort?',
        options: ['Requires O(n) additional auxiliary memory buffer', 'Has worst-case O(n^2) time complexity', 'Is not a stable sort', 'Cannot sort strings'],
        correctOptionIndex: 0,
        solution: 'Standard Merge Sort requires $O(n)$ auxiliary space to allocate temporary arrays during the merge phase, whereas Quick Sort and Heap Sort are in-place.',
        hints: ['Consider memory consumption.']
      }
    ],
    keyTakeaways: [
      'Divide-and-conquer optimal sub-structure breaks exponential search spaces into logarithmic recursions.',
      'Merge Sort provides guaranteed $O(n \\log n)$ worst-case performance.'
    ],
    markdownContent: `### Week 9: Divide & Conquer and Merge Sort\nRecursive decomposition, Master Theorem, and two-pointer merging.`,
    examTips: ['Remember the worst-case comparison bound for merging two sorted lists: $n + m - 1$!']
  },
  {
    id: 'note-ct-w10',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Graph Theory, Trees, Adjacency Matrices & BFS/DFS Traversal',
    detailedNotes: `### Week 10: Graph Data Structures & Systematic Traversals

#### 1. Graphs & Representations: $G = (V, E)$
- **Vertices ($V$):** Set of nodes.
- **Edges ($E$):** Connections between nodes (directed or undirected).
- **Adjacency Matrix ($A \\in \\{0, 1\\}^{|V| \\times |V|}$):** $A_{ij} = 1$ if edge $(i, j) \\in E$. Symmetric for undirected graphs. Space: $O(V^2)$.
- **Adjacency List:** Array of lists storing neighbors for each node. Space: $O(V + E)$ (ideal for sparse graphs).

#### 2. Breadth-First Search (BFS)
Traverses level-by-level using a **Queue (FIFO)**:
- Finds the **shortest path** in unweighted graphs.
- Time Complexity: $O(V + E)$.

#### 3. Depth-First Search (DFS)
Explores as deep as possible along each branch before backtracking using a **Stack (LIFO)** or **Recursion**:
- Used for cycle detection, topological sorting, and connected components.
- Time Complexity: $O(V + E)$.

#### 4. Trees
A connected, acyclic undirected graph:
- A tree with $n$ vertices always has exactly $n - 1$ edges.`,
    quickRevisionNotes: [
      'Adjacency list is memory efficient ($O(V+E)$) for sparse graphs; matrix takes $O(V^2)$.',
      'BFS uses a FIFO Queue and computes shortest paths in unweighted graphs.',
      'DFS uses a LIFO Stack / Recursion and detects cycles.',
      'A tree with $V$ vertices has exactly $V - 1$ edges and no cycles.'
    ],
    formulaSheets: [
      {
        name: 'Handshaking Lemma',
        formula: '\\sum_{v \\in V} \\text{deg}(v) = 2 |E|',
        description: 'Sum of vertex degrees equals twice the total number of edges.'
      },
      {
        name: 'Tree Edge-Vertex Identity',
        formula: '|E| = |V| - 1',
        description: 'Fundamental structural property of connected acyclic trees.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w10-p1',
        questionText: 'An undirected graph has 6 vertices with degrees 2, 3, 3, 4, 1, 1. How many edges does the graph have?',
        options: ['7', '14', '6', '12'],
        correctOptionIndex: 0,
        solution: 'By Handshaking Lemma: $\\sum \\text{deg}(v) = 2|E| \\implies 2 + 3 + 3 + 4 + 1 + 1 = 14 \\implies 2|E| = 14 \\implies |E| = 7$.',
        hints: ['Sum degrees and divide by 2.']
      },
      {
        id: 'ct-w10-p2',
        questionText: 'Which data structure is fundamentally used to implement Breadth-First Search (BFS)?',
        options: ['Queue (FIFO)', 'Stack (LIFO)', 'Heap / Priority Queue', 'Binary Search Tree'],
        correctOptionIndex: 0,
        solution: 'BFS requires visiting nodes in first-in first-out level order, which is managed via a Queue.',
        hints: ['Level-by-level traversal uses FIFO order.']
      },
      {
        id: 'ct-w10-p3',
        questionText: 'How many edges does a connected tree with 50 nodes have?',
        options: ['49', '50', '25', '100'],
        correctOptionIndex: 0,
        solution: 'Every connected tree with $V$ nodes has exactly $|E| = V - 1 = 50 - 1 = 49$ edges.',
        hints: ['Use $|E| = V - 1$.']
      }
    ],
    keyTakeaways: [
      'Graphs model social networks, transportation webs, and recommendation engines.',
      'Handshaking lemma dictates that the number of odd-degree vertices is always even.'
    ],
    markdownContent: `### Week 10: Graphs & Traversals\nAdjacency structures, BFS queues, DFS recursion, and tree invariants.`,
    examTips: ['Always use a `visited` boolean array in BFS/DFS to prevent infinite loops from graph cycles!']
  },
  {
    id: 'note-ct-w11',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Dynamic Programming, Memoization & Recurrence Relations',
    detailedNotes: `### Week 11: Dynamic Programming & Optimal Substructure

#### 1. Core Principles of Dynamic Programming (DP)
Dynamic Programming applies when a problem exhibits:
1. **Optimal Substructure:** An optimal solution to the overall problem incorporates optimal solutions to its sub-problems.
2. **Overlapping Sub-problems:** The same sub-problems are computed repeatedly across different recursive call branches.

#### 2. Approaches to DP
- **Top-Down with Memoization:** Recursive function augmented with a lookup table (cache) that checks if a sub-problem has already been evaluated.
- **Bottom-Up with Tabulation:** Iterative state table population starting from the base cases up to the target state $N$.

#### 3. Canonical Examples
- **Fibonacci Sequence:** $F(n) = F(n-1) + F(n-2)$ with $F(0)=0, F(1)=1$.
  - Naive Recursion: $O(2^n)$ time.
  - DP (Memoized / Tabulated): $O(n)$ time, $O(1)$ space.
- **0/1 Knapsack Problem:**
  $$\\text{DP}[i][w] = \\max(\\text{DP}[i-1][w], \\text{val}[i] + \\text{DP}[i-1][w - \\text{wt}[i]])$$`,
    quickRevisionNotes: [
      'DP requires: Optimal Substructure and Overlapping Sub-problems.',
      'Top-Down = Recursion + Memoization; Bottom-Up = Iteration + Tabulation.',
      'Fibonacci naive recursion $O(2^n)$ is reduced to $O(n)$ via DP.',
      'Tabulation avoids call stack overflow on deep recursions.'
    ],
    formulaSheets: [
      {
        name: '0/1 Knapsack Bellman Equation',
        formula: 'DP[i, w] = \\max(DP[i-1, w], \\; \\text{val}_i + DP[i-1, w - \\text{wt}_i])',
        description: 'Fundamental state transition equation for 0/1 knapsack dynamic programming.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w11-p1',
        questionText: 'What two properties must a problem satisfy to be solvable via Dynamic Programming?',
        options: ['Optimal Substructure and Overlapping Sub-problems', 'Greedy Choice and Constant Time', 'Linear Independence and Orthogonality', 'Disjoint sets and Divide-and-Conquer'],
        correctOptionIndex: 0,
        solution: 'Dynamic Programming requires that optimal sub-solutions compose the global optimum (Optimal Substructure) and that sub-problems recur repeatedly (Overlapping Sub-problems).',
        hints: ['Recall the two prerequisites for DP.']
      },
      {
        id: 'ct-w11-p2',
        questionText: 'What is the time complexity of computing the $n$-th Fibonacci number using bottom-up DP tabulation?',
        options: ['O(n)', 'O(2^n)', 'O(n^2)', 'O(\\log n)'],
        correctOptionIndex: 0,
        solution: 'Bottom-up tabulation computes each value $F(2), F(3), \\dots, F(n)$ once in a single loop of length $n$, giving $O(n)$ time complexity.',
        hints: ['Single loop from 2 to $n$.']
      },
      {
        id: 'ct-w11-p3',
        questionText: 'In Memoization, what does the algorithm do before computing a recursive call?',
        options: ['Checks the lookup table/cache to see if the sub-problem was already solved', 'Deletes the cache', 'Runs a sorting algorithm', 'Restarts execution from main'],
        correctOptionIndex: 0,
        solution: 'Memoization intercepts recursive calls by first querying the memory cache; if present, it returns the cached answer in $O(1)$ time.',
        hints: ['Check cache first.']
      }
    ],
    keyTakeaways: [
      'Dynamic programming turns exponential brute-force searches into polynomial-time matrix tabulations.',
      'Viterbi decoding, Bellman-Ford routing, and sequence alignments (BLAST) all rely on DP.'
    ],
    markdownContent: `### Week 11: Dynamic Programming\nOptimal substructure, memoization caches, and tabulation mechanics.`,
    examTips: ['Always identify the base cases first before formulating the recursive state transition equation!']
  },
  {
    id: 'note-ct-w12',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    courseCode: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Algorithmic Verification, Correctness Proofs & System Design Principles',
    detailedNotes: `### Week 12: Algorithmic Verification & Robust System Design

#### 1. Program Correctness & Hoare Triples
$$\\{P\\} \\; C \\; \\{Q\\}$$
- $P$: **Precondition** (Assertion guaranteed true before command $C$ executes).
- $C$: **Program Command / Code Block**.
- $Q$: **Postcondition** (Assertion guaranteed true after termination of $C$).
- **Total Correctness:** Partial Correctness (if it terminates, output is correct) $+$ Termination Proof (guaranteed to halt in finite steps).

#### 2. Robust System Design Principles
- **Modularity & High Cohesion:** Components do one clear logical task.
- **Low Coupling:** Subsystems interact through minimal, well-defined API contracts without relying on internal implementation details.
- **Defensive Programming:** Validating all input bounds, asserting invariants, and graceful error recovery.`,
    quickRevisionNotes: [
      'Hoare Triple: $\\{P\\} C \\{Q\\}$ (Precondition, Code, Postcondition).',
      'Total Correctness = Partial Correctness + Termination Proof.',
      'High Cohesion and Low Coupling define robust modular system architecture.',
      'Defensive programming prevents silent data corruption.'
    ],
    formulaSheets: [
      {
        name: 'Hoare Triple Logic',
        formula: '\\{P\\} \\; \\text{Code} \\; \\{Q\\}',
        description: 'Formal axiomatic verification of software state transformations.'
      }
    ],
    practiceQuestions: [
      {
        id: 'ct-w12-p1',
        questionText: 'What is the difference between Partial Correctness and Total Correctness?',
        options: ['Total Correctness requires a formal proof of termination in finite steps, whereas Partial Correctness assumes termination', 'Partial Correctness is for floating-point numbers only', 'Total Correctness only applies to recursive functions', 'There is no difference'],
        correctOptionIndex: 0,
        solution: 'Partial correctness asserts that IF the program terminates, the postcondition holds. Total correctness additionally proves that the program is guaranteed to terminate.',
        hints: ['Consider infinite loop possibilities.']
      },
      {
        id: 'ct-w12-p2',
        questionText: 'In software engineering, what is the goal of designing with "High Cohesion and Low Coupling"?',
        options: ['Make modules focused on a single task and minimize dependencies between different modules', 'Make all functions share global variables', 'Maximize code line count', 'Merge all classes into one large file'],
        correctOptionIndex: 0,
        solution: 'High cohesion ensures a module has a clear, focused purpose; low coupling minimizes inter-module dependencies for maintainability.',
        hints: ['Focused modules with minimal mutual dependencies.']
      },
      {
        id: 'ct-w12-p3',
        questionText: 'Given precondition $P: x > 0$, code $C: y \\leftarrow x + 2$, what is a valid postcondition $Q$?',
        options: ['y > 2', 'y < 0', 'y == 2', 'y < x'],
        correctOptionIndex: 0,
        solution: 'If $x > 0$, then adding 2 yields $y = x + 2 > 0 + 2 = 2$. Hence $Q: y > 2$.',
        hints: ['Add 2 to both sides of the precondition inequality.']
      }
    ],
    keyTakeaways: [
      'Formal verification proves the absence of runtime flaws in safety-critical systems.',
      'Modular architecture enables seamless continuous integration and scalable codebases.'
    ],
    markdownContent: `### Week 12: Algorithmic Verification\nHoare triples, termination invariants, and modular software engineering.`,
    examTips: ['Verify both partial correctness AND loop termination when evaluating algorithmic proofs!']
  }
];

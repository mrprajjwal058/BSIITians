import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_BA_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-ba-w1',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 1,
    title: 'Business Analytics Taxonomy: Descriptive, Diagnostic, Predictive & Prescriptive Frameworks',
    detailedNotes: `### Week 1: Foundations of Business Analytics & Decision Frameworks

#### 1. The Four Pillars of Business Analytics
1. **Descriptive Analytics ("What happened?"):**
   - Summarizes historical data via aggregations, KPIs, and executive BI dashboards.
   - Tools: SQL, Tableau, Power BI, Excel Pivot Tables.
2. **Diagnostic Analytics ("Why did it happen?"):**
   - Root-cause analysis, variance analysis, drill-down slicing, and anomaly correlation.
   - Tools: Multivariate regression, cohort decomposition, Pareto analysis (80/20 rule).
3. **Predictive Analytics ("What will happen?"):**
   - Statistical forecasting, machine learning models, churn prediction, credit risk scoring.
   - Tools: Time Series (ARIMA), GBDTs (XGBoost), Logistic Regression.
4. **Prescriptive Analytics ("What should we do?"):**
   - Recommending optimal actionable decisions under resource constraints and uncertainty.
   - Tools: Linear Programming (Simplex), Monte Carlo Simulation, Reinforcement Learning.

#### 2. The CRISP-DM Framework for Business Analytics
- **Business Understanding:** Define business objective, success criteria (e.g. reduce churn by $5\\%$), and conversion value.
- **Data Understanding $\\to$ Data Preparation $\\to$ Modeling $\\to$ Evaluation $\\to$ Deployment.**`,
    quickRevisionNotes: [
      'Descriptive = What happened? (Dashboards, KPIs).',
      'Diagnostic = Why did it happen? (Root-cause, ANOVA).',
      'Predictive = What will happen? (Forecasting, ML).',
      'Prescriptive = What should we do? (Optimization, Linear Programming).',
      'CRISP-DM standardizes analytics projects from business objective to deployment.'
    ],
    formulaSheets: [
      {
        name: 'Return on Investment (ROI)',
        formula: '\\text{ROI} = \\frac{\\text{Net Profit}}{\\text{Cost of Investment}} \\times 100\\% = \\frac{\\text{Gain} - \\text{Cost}}{\\text{Cost}} \\times 100\\%',
        description: 'Universal financial metric evaluating the economic return of business initiatives.'
      }
    ],
    definitions: [
      {
        term: 'Prescriptive Analytics',
        explanation: 'The branch of business analytics dedicated to finding the best course of action for a given situation through mathematical optimization and decision simulation models.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Executive KPI Summary and Cohort Decomposition in Python',
        code: `import pandas as pd
import numpy as np

def compute_executive_kpis(sales_df):
    total_revenue = sales_df['revenue'].sum()
    total_orders = sales_df['order_id'].nunique()
    total_customers = sales_df['customer_id'].nunique()
    
    aov = total_revenue / total_orders # Average Order Value
    arpu = total_revenue / total_customers # Average Revenue Per User
    
    return {
        "Total Revenue": f"\${total_revenue:,.2f}",
        "Total Orders": total_orders,
        "Unique Customers": total_customers,
        "AOV": f"\${aov:.2f}",
        "ARPU": f"\${arpu:.2f}"
    }`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w1-q1',
        questionText: 'An e-commerce airline company uses mathematical optimization to dynamically adjust seat prices across flights to maximize total revenue subject to seat capacity constraints. Which level of analytics does this represent?',
        options: ['Prescriptive Analytics', 'Descriptive Analytics', 'Diagnostic Analytics', 'Predictive Analytics'],
        correctOptionIndex: 0,
        solution: 'Prescriptive Analytics focuses on decision optimization (prescribing the optimal action/price to maximize an objective function under constraints).',
        hints: ['Optimizing actions subject to constraints.']
      }
    ],
    examTips: [
      'In business analytics exam cases, always start by defining the business metric (KPI) before proposing mathematical models.',
      'Remember: Predictive models output probabilities; Prescriptive models optimize decisions based on those probabilities.'
    ],
    handwrittenMnemonic: 'Descriptive (What) -> Diagnostic (Why) -> Predictive (Future) -> Prescriptive (Optimal Action)!'
  },
  {
    id: 'note-ba-w2',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 2,
    title: 'Business Metrics & Unit Economics: CAC, LTV, Churn Rate, MRR & Executive Dashboards',
    detailedNotes: `### Week 2: Unit Economics & Subscription Financial Metrics

#### 1. Core SaaS & Subscription Unit Economics
- **Customer Acquisition Cost (CAC):**
  $$\\text{CAC} = \\frac{\\text{Total Marketing \\& Sales Spend in Period } t}{\\text{Total New Customers Acquired in Period } t}$$
- **Customer Lifetime Value (LTV / CLV):**
  $$\\text{LTV} = \\frac{\\text{Average Revenue Per User (ARPU)} \\times \\text{Gross Margin (\\%)}}{\\text{Customer Churn Rate}}$$
- **The Golden Ratio of Unit Economics:**
  $$\\frac{\\text{LTV}}{\\text{CAC}} \\ge 3.0 \\quad (\\text{Healthy SaaS Business})$$
  - If $\\frac{\\text{LTV}}{\\text{CAC}} < 1.0$: Company loses money on every acquired customer.
  - If $\\frac{\\text{LTV}}{\\text{CAC}} > 5.0$: Company is under-investing in marketing growth.
- **CAC Payback Period:**
  $$\\text{Payback Months} = \\frac{\\text{CAC}}{\\text{Monthly ARPU} \\times \\text{Gross Margin (\\%)}} \\quad (\\text{Healthy if } \\le 12\\text{ months})$$

#### 2. Revenue & Churn Metrics
- **Monthly Recurring Revenue (MRR):** Predictable monthly revenue from active subscriptions.
- **Customer Churn Rate ($CR$):**
  $$CR = \\frac{\\text{Customers Lost during Period}}{\\text{Customers at Start of Period}}$$
- **Net Revenue Retention (NRR):** Measures revenue retained from existing customers including expansion/upsells ($> 100\\%$ indicates net negative revenue churn!).`,
    quickRevisionNotes: [
      'CAC = Total Sales & Marketing Spend / New Customers Acquired.',
      'LTV = (ARPU * Gross Margin) / Churn Rate.',
      'Healthy SaaS benchmarks: LTV/CAC >= 3.0 and CAC Payback <= 12 months.',
      'Net Revenue Retention (NRR) > 100% means expansion revenue exceeds churn losses.'
    ],
    formulaSheets: [
      {
        name: 'LTV to CAC Ratio & Payback Period',
        formula: '\\frac{\\text{LTV}}{\\text{CAC}} = \\frac{\\text{ARPU} \\times \\text{Margin}}{\\text{CAC} \\times \\text{Churn Rate}} \\quad | \\quad \\text{Payback} = \\frac{\\text{CAC}}{\\text{Monthly Gross Profit}}',
        description: 'Key health indicators of subscription unit economics.'
      }
    ],
    definitions: [
      {
        term: 'Customer Lifetime Value (LTV)',
        explanation: 'The total net monetary value a customer is expected to generate for a business over the entire duration of their commercial relationship.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'SaaS Unit Economics and LTV/CAC Dashboard Calculator',
        code: `def calculate_unit_economics(marketing_spend, new_customers, arpu_monthly, gross_margin_pct, monthly_churn_rate):
    cac = marketing_spend / new_customers
    ltv = (arpu_monthly * gross_margin_pct) / monthly_churn_rate
    ltv_cac_ratio = ltv / cac
    payback_months = cac / (arpu_monthly * gross_margin_pct)
    
    return {
        "CAC": f"\${cac:.2f}",
        "LTV": f"\${ltv:.2f}",
        "LTV/CAC Ratio": f"{ltv_cac_ratio:.2f}x",
        "Payback Period (Months)": f"{payback_months:.1f} months",
        "Health Status": "EXCELLENT" if ltv_cac_ratio >= 3.0 and payback_months <= 12 else "WARNING"
    }

# Example Evaluation
print(calculate_unit_economics(
    marketing_spend=50000, new_customers=250, arpu_monthly=120, gross_margin_pct=0.80, monthly_churn_rate=0.03
))`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w2-q1',
        questionText: 'If an enterprise SaaS company has a monthly ARPU of $200, a gross margin of 75%, and a monthly customer churn rate of 2.5%, what is the expected Customer Lifetime Value (LTV)?',
        options: ['$6,000', '$8,000', '$2,400', '$10,000'],
        correctOptionIndex: 0,
        solution: 'LTV = (ARPU * Gross Margin) / Churn Rate = ($200 * 0.75) / 0.025 = $150 / 0.025 = $6,000.',
        hints: ['LTV = (200 * 0.75) / 0.025']
      }
    ],
    examTips: [
      'Be careful with time units: Ensure ARPU and Churn Rate share identical time bases (both monthly or both annual).',
      'Net Churn can be negative when expansion revenue from existing customers exceeds lost revenue from churned customers.'
    ],
    handwrittenMnemonic: 'LTV/CAC >= 3x; Payback <= 12 months; LTV = Margin * ARPU / Churn!'
  },
  {
    id: 'note-ba-w3',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 3,
    title: 'Controlled Business Experimentation: A/B Testing, Sample Size Estimation & Z-Tests',
    detailedNotes: `### Week 3: A/B Testing & Rigorous Hypothesis Testing

#### 1. The Anatomy of an A/B Test
- **Control Group ($A$):** Current baseline version (existing website checkout).
- **Treatment Group ($B$):** Modified version with proposed feature (new 1-click checkout).
- **Randomized Assignment:** Hash user ID (e.g. \`hash(user_id) % 100 < 50\`) to guarantee unbiased, independent splits.

#### 2. Sample Size Estimation (Evan Miller Formulation)
Before launching a test, calculate minimum required sample size $n$ per variant to ensure statistical validity:
$$n = \\frac{2 \\left( Z_{1-\\alpha/2} + Z_{1-\\beta} \\right)^2 \\cdot \\bar{p}(1 - \\bar{p})}{(\\text{MDE})^2}$$
- $\\alpha$ (**Significance Level / Type I Error**): Probability of false positive (typically $0.05 \\implies Z_{0.975} = 1.96$).
- $1 - \\beta$ (**Statistical Power**): Probability of detecting real effect (typically $0.80 \\implies Z_{0.80} = 0.84$).
- **MDE (Minimum Detectable Effect):** Smallest percentage lift of practical business interest.

#### 3. Two-Proportion Z-Test for Conversion Rate
$$Z = \\frac{\\hat{p}_B - \\hat{p}_A}{\\sqrt{\\hat{p}(1 - \\hat{p}) \\left( \\frac{1}{n_A} + \\frac{1}{n_B} \\right)}}, \\quad \\hat{p} = \\frac{x_A + x_B}{n_A + n_B}$$
- If $|Z| > 1.96$ ($p < 0.05$), reject $H_0$ $\\implies$ Statistically significant conversion lift!`,
    quickRevisionNotes: [
      'A/B testing uses randomized splits to isolate causal treatment effects.',
      'Type I error (alpha = 0.05) is False Positive; Type II error (beta = 0.20) is False Negative.',
      'Statistical Power (1 - beta = 0.80) ensures 80% probability of detecting true lift.',
      'Two-proportion Z-test evaluates whether conversion rate differences are statistically significant.'
    ],
    formulaSheets: [
      {
        name: 'Two-Proportion Pooled Z-Test',
        formula: 'Z = \\frac{\\hat{p}_B - \\hat{p}_A}{\\sqrt{\\hat{p}(1-\\hat{p})\\left(\\frac{1}{n_A} + \\frac{1}{n_B}\\right)}} \\quad (\\text{Significant if } |Z| > 1.96)',
        description: 'Test statistic for comparing binomial conversion rates in A/B experiments.'
      }
    ],
    definitions: [
      {
        term: 'Minimum Detectable Effect (MDE)',
        explanation: 'The smallest relative or absolute lift in a target metric that an experiment is powered to detect with specified statistical confidence and power.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Complete A/B Test Statistical Significance Analyzer',
        code: `import numpy as np
from scipy import stats

def analyze_ab_test(conversions_a, visitors_a, conversions_b, visitors_b, alpha=0.05):
    p_a = conversions_a / visitors_a
    p_b = conversions_b / visitors_b
    relative_lift = ((p_b - p_a) / p_a) * 100
    
    # Pooled conversion rate
    p_pooled = (conversions_a + conversions_b) / (visitors_a + visitors_b)
    se_pooled = np.sqrt(p_pooled * (1 - p_pooled) * (1/visitors_a + 1/visitors_b))
    
    z_score = (p_b - p_a) / se_pooled
    p_value = 2 * (1 - stats.norm.cdf(abs(z_score)))
    
    is_significant = p_value < alpha
    return {
        "Control CR": f"{p_a * 100:.2f}%",
        "Treatment CR": f"{p_b * 100:.2f}%",
        "Relative Lift": f"{relative_lift:+.2f}%",
        "Z-Score": round(z_score, 4),
        "P-Value": round(p_value, 5),
        "Statistically Significant": is_significant
    }`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w3-q1',
        questionText: 'What common statistical trap occurs when product managers repeatedly inspect A/B test results daily and stop the test early as soon as p < 0.05 is reached?',
        options: ['Peeking Problem (Repeated Significance Testing), which drastically inflates the False Positive (Type I error) rate far beyond the nominal 5%', 'It causes sample size to decrease', 'It turns Z-tests into T-tests', 'It deletes test data'],
        correctOptionIndex: 0,
        solution: 'Continuously checking p-values and stopping early capitalizes on temporary random fluctuations, inflating the true Type I error rate from 5% to over 30%.',
        hints: ['Peeking problem inflates Type I false positive rate.']
      }
    ],
    examTips: [
      'Never stop an A/B test early upon first seeing $p < 0.05$; always run for the predetermined sample size and full weekly business cycles (to capture weekend behavior).',
      'Check for Sample Ratio Mismatch (SRM) using a Chi-Square goodness-of-fit test to ensure visitor allocation was truly 50/50.'
    ],
    handwrittenMnemonic: 'Calculate sample size first; Avoid peeking; Reject H0 when |Z| > 1.96 (p < 0.05)!'
  },
  {
    id: 'note-ba-w4',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 4,
    title: 'Advanced Experimentation: Multi-Armed Bandits (MAB), Thompson Sampling & UCB',
    detailedNotes: `### Week 4: Multi-Armed Bandits & Adaptive Experimentation

#### 1. The Exploration-Exploitation Dilemma in Business
- **Standard A/B Testing:** Allocates $50\\%$ of traffic to inferior variant for the entire duration of the test (**High Regret / Opportunity Cost**).
- **Multi-Armed Bandits (MAB):** Dynamically shifts traffic towards winning variants in real time, minimizing cumulative regret while maintaining continuous learning.
- Ideal for short-lived campaigns (Black Friday sales, news headline optimization, flash promotions).

#### 2. Upper Confidence Bound (UCB1) Algorithm
Balances empirical mean reward $\\hat{\\mu}_i$ with an uncertainty exploration bonus based on how rarely arm $i$ was pulled:
$$\\text{Score}_i = \\hat{\\mu}_i + \\sqrt{\\frac{2 \\ln N}{n_i}}$$
- Select arm with maximum $\\text{Score}_i$ at each step.

#### 3. Thompson Sampling (Bayesian Bandits)
Maintains Beta posterior distribution $\\text{Beta}(\\alpha_i, \\beta_i)$ over each arm's conversion probability:
1. For each arm $i$, sample random draw: $\\theta_i \\sim \\text{Beta}(\\alpha_i, \\beta_i)$.
2. Serve arm with highest sampled $\\theta_i$.
3. If conversion occurs: $\\alpha_i \\leftarrow \\alpha_i + 1$; else $\\beta_i \\leftarrow \\beta_i + 1$.`,
    quickRevisionNotes: [
      'Multi-Armed Bandits balance Exploration (learning) and Exploitation (earning).',
      'MAB minimizes cumulative regret compared to fixed-sample A/B tests.',
      'UCB1 adds an uncertainty confidence bound $\\sqrt{2\\ln N / n_i}$ to empirical mean.',
      'Thompson Sampling draws random samples from Beta posterior distributions $\\text{Beta}(\\alpha, \\beta)$.'
    ],
    formulaSheets: [
      {
        name: 'UCB1 Decision Rule',
        formula: 'A_t = \\arg\\max_{i} \\left( \\hat{\\mu}_i + c \\sqrt{\\frac{\\ln t}{N_i(t)}} \\right)',
        description: 'Upper Confidence Bound arm selection balancing reward and exploration.'
      }
    ],
    definitions: [
      {
        term: 'Cumulative Regret',
        explanation: 'The expected total revenue/reward lost by playing sub-optimal bandit arms compared to always playing the single best arm in hindsight.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Thompson Sampling Bayesian Multi-Armed Bandit Implementation',
        code: `import numpy as np

class ThompsonSamplingBandit:
    def __init__(self, num_variants):
        self.k = num_variants
        self.alpha = np.ones(self.k) # Success prior (Beta(1,1))
        self.beta = np.ones(self.k)  # Failure prior

    def select_variant(self):
        # Sample conversion rate from Beta posterior for each arm
        samples = [np.random.beta(self.alpha[i], self.beta[i]) for i in range(self.k)]
        return np.argmax(samples)

    def update_reward(self, chosen_variant, converted: bool):
        if converted:
            self.alpha[chosen_variant] += 1
        else:
            self.beta[chosen_variant] += 1

# Simulation Example
bandit = ThompsonSamplingBandit(num_variants=3)
for _ in range(1000):
    arm = bandit.select_variant()
    # Simulating ground truth reward (Arm 2 is best with 15% CR)
    reward = np.random.rand() < [0.08, 0.10, 0.15][arm]
    bandit.update_reward(arm, reward)`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w4-q1',
        questionText: 'When is a Multi-Armed Bandit algorithm preferred over a standard classical hypothesis-testing A/B test?',
        options: ['When the cost of serving a sub-optimal variant is high or the campaign lifecycle is very short (e.g. 24-hour flash sales, ad banner optimization)', 'When proving academic statistical theorems', 'When analyzing quarterly financial statements', 'When sorting lists of names'],
        correctOptionIndex: 0,
        solution: 'Bandits minimize regret in real time by routing traffic to the best variant dynamically, making them optimal for short time-horizons where maximizing conversions outweighs strict hypothesis testing.',
        hints: ['Minimizes lost revenue during short-duration promotions.']
      }
    ],
    examTips: [
      'Standard A/B tests are preferred when you need unbiased statistical effect size estimates; Bandits are preferred when you want to maximize revenue during the experiment.',
      'Thompson Sampling asymptotically achieves logarithmic cumulative regret $O(\\ln T)$.'
    ],
    handwrittenMnemonic: 'A/B Tests for Science; Multi-Armed Bandits for Maximizing Revenue!'
  },
  {
    id: 'note-ba-w5',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 5,
    title: 'Customer Segmentation: RFM (Recency, Frequency, Monetary) Analysis & K-Means',
    detailedNotes: `### Week 5: Customer Segmentation & Behavioral Clustering

#### 1. RFM (Recency, Frequency, Monetary) Segmentation
A powerful behavioral scoring framework based on transaction history:
- **Recency ($R$):** Days since customer's last purchase (Lower is better $\\implies$ higher score).
- **Frequency ($F$):** Total count of distinct orders (Higher is better).
- **Monetary Value ($M$):** Total spend across customer lifetime (Higher is better).
- Customers are binned into quintiles ($1-5$), creating composite RFM scores ($111$ to $555$):
  - **Champions ($555, 554$):** Bought recently, buy often, spend the most.
  - **Loyal Customers ($X5X$):** Buy frequently; responsive to promotions.
  - **At Risk ($155, 154$):** Spent big and bought often in past, but haven't purchased recently.
  - **Lost ($111$):** Lowest recency, frequency, and spend.

#### 2. K-Means Clustering on Customer Data
- Standardize features using Z-score or Min-Max scaling (prevents Monetary value in thousands from dominating Recency in tens!).
- **Optimal $k$ Selection:**
  - **Elbow Method:** Inertia (Within-Cluster Sum of Squares - WCSS) elbow inflection point.
  - **Silhouette Coefficient ($s \\in [-1, 1]$):** Measures cluster cohesion vs separation ($s > 0.5$ indicates strong clustering).`,
    quickRevisionNotes: [
      'RFM scores Recency (low days), Frequency (high orders), and Monetary (high spend) from 1 to 5.',
      'RFM segments: Champions (555), At Risk (155), Loyal (X5X), Lost (111).',
      'Always scale features before K-Means clustering to prevent dollar values dominating days.',
      'Evaluate cluster quality using Elbow Method (WCSS) and Silhouette Score.'
    ],
    formulaSheets: [
      {
        name: 'Within-Cluster Sum of Squares (Inertia)',
        formula: '\\text{WCSS} = \\sum_{k=1}^{K} \\sum_{x_i \\in C_k} \\|x_i - \\mu_k\\|^2',
        description: 'Objective function minimized by K-Means clustering algorithm.'
      }
    ],
    definitions: [
      {
        term: 'RFM Analysis',
        explanation: 'A quantitative marketing technique that ranks and groups customers based on the recency, frequency, and monetary value of their recent transactions to identify distinct behavioral segments.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'End-to-End RFM Feature Extraction and Quantile Scoring in Pandas',
        code: `import pandas as pd
import datetime as dt

def compute_rfm_segments(orders_df, snapshot_date):
    rfm = orders_df.groupby('customer_id').agg({
        'order_date': lambda d: (snapshot_date - d.max()).days, # Recency
        'order_id': 'count',                                    # Frequency
        'order_amount': 'sum'                                   # Monetary
    }).rename(columns={'order_date': 'Recency', 'order_id': 'Frequency', 'order_amount': 'Monetary'})

    # Score quintiles 1 to 5
    rfm['R_Score'] = pd.qcut(rfm['Recency'], 5, labels=[5, 4, 3, 2, 1]) # Inverted: recent = 5
    rfm['F_Score'] = pd.qcut(rfm['Frequency'].rank(method='first'), 5, labels=[1, 2, 3, 4, 5])
    rfm['M_Score'] = pd.qcut(rfm['Monetary'], 5, labels=[1, 2, 3, 4, 5])

    rfm['RFM_Segment'] = rfm['R_Score'].astype(str) + rfm['F_Score'].astype(str) + rfm['M_Score'].astype(str)
    return rfm`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w5-q1',
        questionText: 'In an RFM analysis, a customer with an RFM score of "155" represents which marketing segment, and what is the recommended business action?',
        options: ['"At-Risk" high-value customer who spent heavily and bought often but has not purchased recently; target with win-back discount campaigns and personalized re-engagement', '"New Customer" who just signed up', '"Lost Customer" with zero commercial value', '"Champion" who bought yesterday'],
        correctOptionIndex: 0,
        solution: 'R=1 means low recency (long time since last purchase), while F=5 and M=5 represent top frequency and monetary value. This signifies an at-risk valuable customer needing urgent re-engagement.',
        hints: ['R=1 (not recent), F=5 (frequent), M=5 (high spend).']
      }
    ],
    examTips: [
      'In RFM scoring, remember that Recency is scored inversely (lowest days gets highest score of 5).',
      'Use log transformations (`np.log1p`) on skewed Monetary and Frequency distributions before applying K-Means.'
    ],
    handwrittenMnemonic: 'Recency (Low days = 5), Frequency (High = 5), Monetary (High = 5); 155 is At-Risk!'
  },
  {
    id: 'note-ba-w6',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 6,
    title: 'Market Basket Analysis: Association Rules, Apriori Algorithm, Support, Confidence & Lift',
    detailedNotes: `### Week 6: Market Basket Analysis & Association Rule Mining

#### 1. Core Association Rule Metrics: $X \\implies Y$
- **Support (Frequency of Co-occurrence):**
  $$\\text{Support}(X \\implies Y) = P(X \\cap Y) = \\frac{\\text{Transactions containing both } X \\text{ and } Y}{\\text{Total Transactions } N}$$
- **Confidence (Conditional Probability / Reliability):**
  $$\\text{Confidence}(X \\implies Y) = P(Y | X) = \\frac{\\text{Support}(X \\cap Y)}{\\text{Support}(X)}$$
- **Lift (Strength / Independence Ratio):**
  $$\\text{Lift}(X \\implies Y) = \\frac{P(X \\cap Y)}{P(X) \\cdot P(Y)} = \\frac{\\text{Confidence}(X \\implies Y)}{\\text{Support}(Y)}$$
  - $\\text{Lift} = 1$: $X$ and $Y$ are statistically independent.
  - $\\text{Lift} > 1$: Positive association (Purchasing $X$ significantly increases probability of purchasing $Y$).
  - $\\text{Lift} < 1$: Negative association / substitutes.

#### 2. The Apriori Principle & Pruning
- **Apriori Property:** All non-empty subsets of a frequent itemset must also be frequent.
- **Pruning Rule:** If an itemset $S$ is infrequent ($\\text{Support}(S) < \\text{min\\_sup}$), all its supersets are immediately pruned without scanning transactions, dramatically shrinking the combinatorial search space.`,
    quickRevisionNotes: [
      'Support = P(X and Y): Fraction of baskets containing both items.',
      'Confidence = P(Y | X): Probability of buying Y given X was purchased.',
      'Lift = P(X and Y) / (P(X) * P(Y)): Lift > 1 indicates positive association.',
      'Apriori property: If itemset S is infrequent, all its supersets must also be infrequent.'
    ],
    formulaSheets: [
      {
        name: 'Association Rule Lift Formula',
        formula: '\\text{Lift}(X \\implies Y) = \\frac{\\text{Confidence}(X \\implies Y)}{\\text{Support}(Y)} = \\frac{P(X \\cap Y)}{P(X) \\times P(Y)}',
        description: 'Measures how much more often X and Y occur together than expected by chance.'
      }
    ],
    definitions: [
      {
        term: 'Association Rule Lift',
        explanation: 'The ratio of the observed co-occurrence frequency of items X and Y to the expected frequency under the assumption of statistical independence.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Mining Association Rules with MLxtend in Python',
        code: `import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules

# Transaction one-hot encoded matrix
basket_df = pd.DataFrame([
    {'Bread': 1, 'Butter': 1, 'Milk': 1, 'Beer': 0},
    {'Bread': 1, 'Butter': 1, 'Milk': 0, 'Beer': 0},
    {'Bread': 0, 'Butter': 0, 'Milk': 1, 'Beer': 1},
    {'Bread': 1, 'Butter': 1, 'Milk': 1, 'Beer': 0},
    {'Bread': 0, 'Butter': 1, 'Milk': 1, 'Beer': 1},
])

# Step 1: Find frequent itemsets with min_support = 0.40
frequent_itemsets = apriori(basket_df, min_support=0.40, use_colnames=True)

# Step 2: Generate association rules with min_threshold for Lift = 1.2
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1.2)
print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w6-q1',
        questionText: 'If Support(Beer) = 20%, Support(Diapers) = 10%, and Support(Beer and Diapers) = 6%, what is the Lift of the rule `Beer => Diapers`?',
        options: ['3.0', '1.5', '0.6', '2.0'],
        correctOptionIndex: 0,
        solution: 'Lift = P(Beer and Diapers) / (P(Beer) * P(Diapers)) = 0.06 / (0.20 * 0.10) = 0.06 / 0.02 = 3.0. A customer buying beer is 3 times more likely to buy diapers than average.',
        hints: ['Lift = 0.06 / (0.20 * 0.10)']
      }
    ],
    examTips: [
      'High confidence alone is misleading if the consequent item has very high baseline popularity; always verify that Lift > 1.0.',
      'Use FP-Growth (Frequent Pattern Tree) for large transaction databases, as it scans the database only twice compared to Apriori\'s multiple passes.'
    ],
    handwrittenMnemonic: 'Support = Joint prob; Confidence = Conditional prob; Lift > 1 means true cross-sell opportunity!'
  },
  {
    id: 'note-ba-w7',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 7,
    title: 'Pricing Analytics: Price Elasticity of Demand, Revenue Optimization & Dynamic Pricing',
    detailedNotes: `### Week 7: Price Elasticity & Revenue Maximization

#### 1. Price Elasticity of Demand (PED / $\\epsilon$)
Measures the percentage change in quantity demanded in response to a percentage change in price:
$$\\epsilon = \\frac{\\% \\Delta Q}{\\% \\Delta P} = \\frac{dQ}{dP} \\times \\frac{P}{Q}$$
- **$|\\epsilon| > 1$ (Elastic Demand):** Customers are price sensitive. Lowering price increases total revenue.
- **$|\\epsilon| = 1$ (Unitary Elasticity):** Total revenue is maximized!
- **$|\\epsilon| < 1$ (Inelastic Demand):** Essential goods (e.g. insulin, electricity). Raising price increases total revenue.

#### 2. Estimating Elasticity: The Log-Log Regression Model
$$\\ln(Q) = \\beta_0 + \\beta_1 \\ln(P) + \\sum \\gamma_i X_i + \\epsilon$$
- **Interpretation:** The regression slope coefficient $\\beta_1$ directly equals the constant price elasticity $\\epsilon$!

#### 3. Optimal Revenue & Profit Maximization
$$\\text{Revenue}(P) = P \\times Q(P) \\implies \\frac{d\\text{Revenue}}{dP} = 0 \\implies P^* = \\text{Optimal Price}$$
- **Optimal Markup Rule with Marginal Cost ($MC$):**
  $$P^* = MC \\times \\left( \\frac{\\epsilon}{1 + \\epsilon} \\right)$$`,
    quickRevisionNotes: [
      'Price Elasticity = (% Change in Quantity) / (% Change in Price).',
      '|Elasticity| > 1 is Elastic (cut price to increase revenue); < 1 is Inelastic (raise price).',
      'In Log-Log regression `ln(Q) = a + b*ln(P)`, the slope b is the price elasticity.',
      'Revenue is mathematically maximized at the unitary elasticity point (|epsilon| = 1).'
    ],
    formulaSheets: [
      {
        name: 'Optimal Price Markup Rule',
        formula: 'P^* = \\text{Marginal Cost} \\times \\left( \\frac{\\epsilon}{1 + \\epsilon} \\right) \\quad (\\text{where } \\epsilon < -1)',
        description: 'Microeconomic pricing rule maximizing gross profit.'
      }
    ],
    definitions: [
      {
        term: 'Price Elasticity of Demand',
        explanation: 'A quantitative metric measuring the degree of responsiveness of the quantity demanded of a product to a change in its unit selling price.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Estimating Price Elasticity and Optimal Price via Log-Log OLS Regression',
        code: `import numpy as np
import statsmodels.api as sm

def estimate_elasticity_and_optimal_price(prices, quantities, marginal_cost):
    log_p = np.log(prices)
    log_q = np.log(quantities)
    
    X = sm.add_constant(log_p)
    model = sm.OLS(log_q, X).fit()
    
    elasticity = model.params[1] # beta_1 is elasticity
    
    # Calculate profit-maximizing price
    if elasticity < -1.0:
        optimal_price = marginal_cost * (elasticity / (1 + elasticity))
    else:
        optimal_price = "Inelastic demand: Increase price subject to capacity constraints"
        
    return {
        "Price Elasticity (beta)": round(elasticity, 4),
        "R-Squared": round(model.rsquared, 4),
        "P-Value": round(model.pvalues[1], 5),
        "Optimal Price": optimal_price
    }`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w7-q1',
        questionText: 'A streaming service estimates its subscription price elasticity to be -0.60 (inelastic). If the company raises its subscription price by 10%, what will happen to total revenue?',
        options: ['Total revenue will increase, because quantity demanded will drop by only 6%, more than offset by the 10% price increase', 'Total revenue will drop to zero', 'Total revenue will decrease by 6%', 'Total revenue remains unchanged'],
        correctOptionIndex: 0,
        solution: 'For inelastic demand (|e| < 1), the percentage gain from higher price exceeds the percentage loss in volume (% delta Q = -0.6 * 10% = -6%), resulting in higher total revenue.',
        hints: ['Inelastic demand: price increase increases total revenue.']
      }
    ],
    examTips: [
      'In Log-Log regression equations, elasticity is constant across all price points; in linear demand ($Q = a - bP$), elasticity varies continuously depending on $P/Q$.',
      'Remember that price elasticity is typically negative (downward sloping demand curve).'
    ],
    handwrittenMnemonic: 'Log-Log slope is Elasticity; |e| > 1 cut price; |e| < 1 raise price; |e| = 1 max revenue!'
  },
  {
    id: 'note-ba-w8',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 8,
    title: 'Customer Lifetime Value (CLV) & Survival Analysis: Kaplan-Meier & Cox Proportional Hazards',
    detailedNotes: `### Week 8: Customer Survival Analysis & Lifetime Modeling

#### 1. Why Standard Regression Fails for Customer Tenure
- **Right-Censoring:** Many customers are still active at the time of study; their true lifetime is unknown and truncated in the dataset. Dropping them causes severe selection bias.
- **Survival Analysis:** Handles right-censored data mathematically.

#### 2. The Survival and Hazard Functions
- **Survival Function $S(t) = P(T > t)$:** Probability that customer tenure exceeds time $t$.
- **Hazard Function $\\lambda(t)$:** Instantaneous churn rate at time $t$ given survival up to $t$:
  $$\\lambda(t) = \\lim_{\\Delta t \\to 0} \\frac{P(t \\le T < t + \\Delta t \\mid T \\ge t)}{\\Delta t}$$

#### 3. Kaplan-Meier Non-Parametric Estimator
$$\\hat{S}(t) = \\prod_{t_i \\le t} \\left( 1 - \\frac{d_i}{n_i} \\right)$$
- $d_i$: Number of churn events at timestamp $t_i$.
- $n_i$: Number of customers at risk immediately prior to $t_i$.

#### 4. Cox Proportional Hazards Semi-Parametric Model
Models hazard rate as a function of customer covariates $X$:
$$\\lambda(t \\mid X) = \\lambda_0(t) \\exp(\\beta_1 X_1 + \\dots + \\beta_p X_p)$$
- **Hazard Ratio ($HR = e^{\\beta_i}$):** $HR > 1$ implies feature increases risk of churn; $HR < 1$ implies protective factor (increases retention).`,
    quickRevisionNotes: [
      'Survival analysis properly accounts for right-censored active customers.',
      'Kaplan-Meier estimates non-parametric survival curves $S(t) = \\prod (1 - d_i/n_i)$.',
      'Cox Proportional Hazards models covariate effects via Hazard Ratios ($HR = e^{\\beta}$).',
      'Hazard Ratio HR > 1 increases churn risk; HR < 1 improves customer retention.'
    ],
    formulaSheets: [
      {
        name: 'Cox Proportional Hazards Model',
        formula: '\\lambda(t \\mid X) = \\lambda_0(t) \\exp(\\boldsymbol{\\beta}^T \\mathbf{X}) \\implies \\text{Hazard Ratio} = \\frac{\\lambda(t \\mid X_i = 1)}{\\lambda(t \\mid X_i = 0)} = e^{\\beta_i}',
        description: 'Semi-parametric survival model quantifying risk factors in customer churn.'
      }
    ],
    definitions: [
      {
        term: 'Right-Censored Data',
        explanation: 'Data where the event of interest (customer churn) has not yet occurred for some subjects by the end of the observation window.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Fitting Kaplan-Meier Survival Curve and Cox Proportional Hazards in Python',
        code: `from lifelines import KaplanMeierFitter, CoxPHFitter
import pandas as pd

# Sample customer tenure dataframe (tenure in months, churned: 1=churn, 0=censored)
df = pd.DataFrame({
    'tenure_months': [5, 12, 24, 8, 36, 18, 48],
    'churned': [1, 1, 0, 1, 0, 1, 0], # 0 represents right-censored active user
    'has_support_plan': [0, 0, 1, 0, 1, 0, 1],
    'monthly_charges': [75.0, 90.0, 45.0, 85.0, 50.0, 70.0, 40.0]
})

# Kaplan-Meier Curve
kmf = KaplanMeierFitter()
kmf.fit(df['tenure_months'], event_observed=df['churned'])
print("Median Customer Lifetime (Months):", kmf.median_survival_time_)

# Cox Proportional Hazards Regression
cph = CoxPHFitter()
cph.fit(df, duration_col='tenure_months', event_col='churned')
cph.print_summary()`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w8-q1',
        questionText: 'In a Cox Proportional Hazards churn model, a feature `has_annual_contract` has a coefficient of beta = -0.693, resulting in a Hazard Ratio of exp(-0.693) = 0.50. How is this interpreted?',
        options: ['Customers with an annual contract have a 50% lower instantaneous hazard (risk) of churning at any point in time compared to month-to-month customers', 'Customers churn 50 times faster', 'Half the customers are deleted', 'Annual contracts double churn rate'],
        correctOptionIndex: 0,
        solution: 'Hazard Ratio HR = 0.50 means the rate of churn for annual contract holders is exactly half (50% reduction in churn risk) that of the reference baseline group.',
        hints: ['HR = 0.50 indicates 50% reduced risk of churn.']
      }
    ],
    examTips: [
      'Never use standard Linear OLS Regression on customer lifetime datasets because right-censoring violates normality and unbiasedness assumptions.',
      'Verify the proportional hazards assumption in Cox regression using scaled Schoenfeld residuals test.'
    ],
    handwrittenMnemonic: 'Kaplan-Meier handles right-censoring; Cox Hazard Ratio e^beta > 1 increases churn risk!'
  },
  {
    id: 'note-ba-w9',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 9,
    title: 'Financial Analytics & Credit Scoring: Weight of Evidence (WoE), Information Value (IV) & Scorecards',
    detailedNotes: `### Week 9: Credit Risk Analytics & Regulatory Scorecards

#### 1. Credit Scoring & Probability of Default (PD)
Financial institutions build regulatory-compliant Logistic Regression Scorecards (Basel II/III framework) to predict the Probability of Default (PD) for loan applicants.

#### 2. Weight of Evidence (WoE) & Information Value (IV)
Continuous variables are binned into coarse buckets to handle non-linearities and missing values:
- **Weight of Evidence (WoE):**
  $$\\text{WoE}_i = \\ln\\left( \\frac{\\% \\text{ Goods}_i}{\\% \\text{ Bads}_i} \\right) = \\ln\\left( \\frac{\\text{Good}_i / \\text{Total Good}}{\\text{Bad}_i / \\text{Total Bad}} \\right)$$
- **Information Value (IV) - Feature Selection Metric:**
  $$\\text{IV} = \\sum_{i=1}^{k} \\left( \\% \\text{ Goods}_i - \\% \\text{ Bads}_i \\right) \\times \\text{WoE}_i$$
  - $\\text{IV} < 0.02$: Useless for prediction.
  - $0.02 \\le \\text{IV} < 0.1$: Weak predictive power.
  - $0.1 \\le \\text{IV} < 0.3$: Medium predictive power.
  - $0.3 \\le \\text{IV} < 0.5$: **Strong predictor** (optimal for scorecard).
  - $\\text{IV} > 0.5$: Suspicious / data leakage.

#### 3. Transforming Log-Odds to Standard Credit Scores
$$\\text{Score} = \\text{Offset} + \\text{Factor} \\times \\ln\\left( \\frac{1 - PD}{PD} \\right)$$
- Scaled using Points to Double the Odds (PDO): $\\text{Factor} = \\frac{\\text{PDO}}{\\ln(2)}$.`,
    quickRevisionNotes: [
      'Credit scorecards map borrower features to Probability of Default (PD).',
      'Weight of Evidence (WoE) linearizes non-linear relationships with log-odds.',
      'Information Value (IV between 0.3 and 0.5) identifies strong predictive features.',
      'Score scaling: Score = Offset + Factor * ln(Odds), calibrated via Points to Double the Odds (PDO).'
    ],
    formulaSheets: [
      {
        name: 'Information Value (IV) Formula',
        formula: '\\text{IV} = \\sum_{i=1}^{k} \\left( \\frac{\\text{Good}_i}{\\text{Total Good}} - \\frac{\\text{Bad}_i}{\\text{Total Bad}} \\right) \\times \\ln\\left( \\frac{\\text{Good}_i / \\text{Total Good}}{\\text{Bad}_i / \\text{Total Bad}} \\right)',
        description: 'Quantitative metric for feature selection in credit risk modeling.'
      }
    ],
    definitions: [
      {
        term: 'Weight of Evidence (WoE)',
        explanation: 'A measure of the predictive strength of a specific binned category of an independent variable in separating good credit borrowers from bad defaults.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Calculating WoE and IV for Financial Risk Bins in Pandas',
        code: `import pandas as pd
import numpy as np

def calculate_woe_iv(df, feature_col, target_col):
    # target: 1 = Bad (Default), 0 = Good (Non-Default)
    total_good = (df[target_col] == 0).sum()
    total_bad = (df[target_col] == 1).sum()
    
    grouped = df.groupby(feature_col).agg(
        good=(target_col, lambda x: (x == 0).sum()),
        bad=(target_col, lambda x: (x == 1).sum())
    ).reset_index()
    
    grouped['dist_good'] = grouped['good'] / total_good
    grouped['dist_bad'] = grouped['bad'] / total_bad
    
    # Avoid log(0) using small epsilon
    grouped['dist_good'] = grouped['dist_good'].replace(0, 0.0001)
    grouped['dist_bad'] = grouped['dist_bad'].replace(0, 0.0001)
    
    grouped['WoE'] = np.log(grouped['dist_good'] / grouped['dist_bad'])
    grouped['IV'] = (grouped['dist_good'] - grouped['dist_bad']) * grouped['WoE']
    
    total_iv = grouped['IV'].sum()
    return grouped, total_iv`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w9-q1',
        questionText: 'An applicant category has an Information Value (IV) of 0.38 for predicting loan default. How should a credit risk modeler treat this feature?',
        options: ['Keep the feature; an IV between 0.3 and 0.5 indicates strong, high-quality predictive power for regulatory credit scorecards', 'Drop the feature as useless', 'Drop the feature as severe data leakage', 'Replace it with random noise'],
        correctOptionIndex: 0,
        solution: 'In credit risk analytics, features with Information Value between 0.3 and 0.5 are considered strong, robust predictive drivers.',
        hints: ['0.3 <= IV < 0.5 is strong predictive power.']
      }
    ],
    examTips: [
      'WoE values must be monotonic across ordinal numerical bins (e.g. higher income bins should show strictly increasing WoE).',
      'Logistic regression with WoE-transformed variables produces easily explainable additive credit scorecard points for loan officers.'
    ],
    handwrittenMnemonic: 'WoE = ln(%Good / %Bad); IV between 0.3 - 0.5 is strong credit feature!'
  },
  {
    id: 'note-ba-w10',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 10,
    title: 'Demand Forecasting & Inventory Optimization: Time Series (ARIMA/SARIMA) & Economic Order Quantity (EOQ)',
    detailedNotes: `### Week 10: Demand Forecasting & Supply Chain Optimization

#### 1. Classical Time Series Decomposition
$$Y_t = \\text{Trend}(T_t) + \\text{Seasonal}(S_t) + \\text{Cyclical}(C_t) + \\text{Residual}(\\epsilon_t)$$
- **Additive Model ($Y_t = T_t + S_t + \\epsilon_t$):** Seasonal fluctuations remain constant in magnitude over time.
- **Multiplicative Model ($Y_t = T_t \\times S_t \\times \\epsilon_t$):** Seasonal swings grow proportionally with trend.

#### 2. ARIMA($p, d, q$) Modeling (Box-Jenkins Methodology)
- **$p$ (Autoregressive - AR):** Lags in PACF (Partial Autocorrelation Function) plot.
- **$d$ (Differencing Order):** Number of differences needed to achieve stationary mean (Augmented Dickey-Fuller test $p < 0.05$).
- **$q$ (Moving Average - MA):** Lags in ACF (Autocorrelation Function) plot.

#### 3. Inventory Optimization: Economic Order Quantity (EOQ)
Balances **Ordering Costs** ($S$) with **Holding Costs** ($H$):
$$\\text{Total Cost} = \\underbrace{\\frac{D}{Q} S}_{\\text{Annual Ordering Cost}} + \\underbrace{\\frac{Q}{2} H}_{\\text{Annual Holding Cost}}$$
Taking derivative $\\frac{d\\text{TC}}{dQ} = 0$ yields the celebrated **EOQ Formula**:
$$Q^* = \\sqrt{\\frac{2 D S}{H}}$$
- **Reorder Point (ROP):** $\\text{ROP} = (d \\times L) + \\text{Safety Stock} = (d \\times L) + Z \\cdot \\sigma_L$.`,
    quickRevisionNotes: [
      'Time series components: Trend, Seasonality, Cyclical, and Irregular residuals.',
      'ARIMA(p,d,q): p from PACF lags, d from differencing stationarity, q from ACF lags.',
      'EOQ formula $Q^* = \\sqrt{2DS / H}$ minimizes total ordering and inventory holding costs.',
      'Reorder Point ROP = Lead Time Demand + Safety Stock.'
    ],
    formulaSheets: [
      {
        name: 'Economic Order Quantity (EOQ) & Reorder Point',
        formula: 'Q^* = \\sqrt{\\frac{2 D S}{H}} \\quad | \\quad \\text{ROP} = \\bar{d} \\times L + Z_{\\alpha} \\cdot \\sigma_d \\sqrt{L}',
        description: 'Optimal replenishment batch size and threshold in supply chain inventory control.'
      }
    ],
    definitions: [
      {
        term: 'Economic Order Quantity (EOQ)',
        explanation: 'The ideal order quantity a company should purchase for its inventory to minimize total inventory holding, shortage, and order setup costs.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Calculating EOQ, Safety Stock and Total Annual Cost in Python',
        code: `import numpy as np

def calculate_inventory_policy(annual_demand, order_cost, holding_cost_per_unit, daily_demand_mean, daily_demand_std, lead_time_days, service_level=0.95):
    # Step 1: Economic Order Quantity
    eoq = np.sqrt((2 * annual_demand * order_cost) / holding_cost_per_unit)
    
    # Step 2: Safety Stock for desired service level (e.g. 95% -> Z = 1.645)
    z_value = 1.645 if service_level == 0.95 else 2.33
    safety_stock = z_value * daily_demand_std * np.sqrt(lead_time_days)
    
    # Step 3: Reorder Point
    reorder_point = (daily_demand_mean * lead_time_days) + safety_stock
    total_cost = (annual_demand / eoq) * order_cost + (eoq / 2) * holding_cost_per_unit
    
    return {
        "EOQ (Units per Order)": round(eoq, 1),
        "Safety Stock": round(safety_stock, 1),
        "Reorder Point (ROP)": round(reorder_point, 1),
        "Min Total Inventory Cost": f"\${total_cost:,.2f}"
    }`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w10-q1',
        questionText: 'A warehouse has an annual demand of 10,000 units, an order placement cost of $50 per order, and an annual holding cost of $4 per unit. What is the Economic Order Quantity (EOQ)?',
        options: ['500 units', '1,000 units', '250 units', '2,500 units'],
        correctOptionIndex: 0,
        solution: 'EOQ = sqrt((2 * 10,000 * 50) / 4) = sqrt(1,000,000 / 4) = sqrt(250,000) = 500 units.',
        hints: ['EOQ = sqrt((2 * D * S) / H)']
      }
    ],
    examTips: [
      'At the optimal EOQ point, Annual Ordering Costs exactly equal Annual Holding Costs!',
      'Before fitting ARIMA, verify time series stationarity using the ADF (Augmented Dickey-Fuller) unit root test.'
    ],
    handwrittenMnemonic: 'EOQ = sqrt(2DS/H); At EOQ, Ordering Cost equals Holding Cost!'
  },
  {
    id: 'note-ba-w11',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 11,
    title: 'Linear Programming & Resource Optimization: Simplex Method, PuLP Solver & Sensitivity Analysis',
    detailedNotes: `### Week 11: Mathematical Optimization with Linear Programming

#### 1. Linear Programming (LP) Formulation
An LP model consists of:
1. **Decision Variables:** Quantities to determine ($x_1, x_2, \\dots, x_n \\ge 0$).
2. **Objective Function:** Maximize profit or minimize cost:
   $$\\max \\ Z = c_1 x_1 + c_2 x_2 + \\dots + c_n x_n$$
3. **Constraints:** Resource limits (labor hours, machine time, raw materials):
   $$\\sum a_{ij} x_j \\le b_i, \\quad \\forall i$$

#### 2. The Simplex Algorithm & Duality
- The feasible region formed by linear inequality constraints is a **Convex Polytope**.
- **Fundamental Theorem of LP:** The optimal solution is guaranteed to lie on one of the **Extreme Corner Points (Vertices)** of the convex polytope!
- **Simplex Method:** Efficiently traverses adjacent vertices along polytope edges until objective value stops increasing.
- **Shadow Price (Dual Variable $y_i$):** Marginal increase in optimal objective $Z$ per unit increase in the $i$-th constraint's capacity $b_i$.`,
    quickRevisionNotes: [
      'Linear Programming maximizes or minimizes a linear objective subject to linear constraints.',
      'Optimal solutions always lie on corner vertices of the convex feasible region.',
      'Shadow Price is the marginal gain in profit obtained from acquiring one additional unit of constrained resource.',
      'PuLP and SciPy optimize LP problems programmatically in Python.'
    ],
    formulaSheets: [
      {
        name: 'Linear Program Standard Form',
        formula: '\\max_{\\mathbf{x}} \\ \\mathbf{c}^T \\mathbf{x} \\quad \\text{subject to} \\quad \\mathbf{A}\\mathbf{x} \\le \\mathbf{b}, \\quad \\mathbf{x} \\ge \\mathbf{0}',
        description: 'Canonical matrix formulation of linear resource optimization.'
      }
    ],
    definitions: [
      {
        term: 'Shadow Price',
        explanation: 'The instantaneous change in the optimal objective function value resulting from a one-unit relaxation in a given constraint bound.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Production Mix Optimization using PuLP Linear Programming Solver',
        code: `import pulp

# Initialize LP Maximization Problem
model = pulp.LpProblem("Factory_Production_Optimization", pulp.LpMaximize)

# Decision Variables: Units of Product A and Product B to produce
x1 = pulp.LpVariable('Product_A', lowBound=0, cat='Continuous')
x2 = pulp.LpVariable('Product_B', lowBound=0, cat='Continuous')

# Objective Function: Profit = 40*A + 50*B
model += 40 * x1 + 50 * x2, "Total_Profit"

# Constraints
model += 2 * x1 + 3 * x2 <= 120, "Labor_Hours_Limit"
model += 4 * x1 + 2 * x2 <= 160, "Raw_Material_Limit"

# Solve using default CBC Solver
model.solve(pulp.PULP_CBC_CMD(msg=False))

print("Status:", pulp.LpStatus[model.status])
print(f"Optimal Product A: {x1.varValue} units")
print(f"Optimal Product B: {x2.varValue} units")
print(f"Maximum Profit: \${pulp.value(model.objective):,.2f}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w11-q1',
        questionText: 'If the shadow price of a machine capacity constraint is $25.00/hour, and an additional hour of machine time can be rented for $15.00/hour, should the business rent the additional capacity?',
        options: ['Yes, because the marginal profit gain ($25.00) exceeds the rental cost ($15.00), generating a net profit increase of $10.00 per hour', 'No, shadow prices are costs not gains', 'No, renting violates LP constraints', 'It makes no difference'],
        correctOptionIndex: 0,
        solution: 'Shadow price represents the marginal profit generated by one additional unit of constraint. Since shadow price ($25) > marginal cost ($15), acquiring the extra capacity is profitable.',
        hints: ['Rent if shadow price > rental cost.']
      }
    ],
    examTips: [
      'A constraint is Binding (active) if its slack variable is 0 at the optimal solution (shadow price > 0).',
      'For integer quantities (e.g. aircraft or staff count), specify `cat="Integer"` in PuLP to enforce Integer Linear Programming (ILP).'
    ],
    handwrittenMnemonic: 'Optimal solution sits on a Corner Vertex; Shadow price = Marginal profit of +1 resource!'
  },
  {
    id: 'note-ba-w12',
    courseId: 'course-ba',
    courseTitle: 'Business Analytics',
    courseCode: 'DS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 12,
    title: 'Decision Analysis, Multi-Criteria Decision Making (AHP) & Executive Storytelling',
    detailedNotes: `### Week 12: Decision Analysis & Executive Communication

#### 1. Decision Trees & Expected Monetary Value (EMV)
- **Decision Nodes (Squares):** Points of direct managerial choice.
- **Chance Nodes (Circles):** Uncertain probabilistic states of nature.
- **Expected Monetary Value (EMV):**
  $$\\text{EMV} = \\sum_{i} P(s_i) \\times \\text{Payoff}(s_i)$$
- **Expected Value of Perfect Information (EVPI):**
  $$\\text{EVPI} = \\text{Expected Value with Perfect Info (EVwPI)} - \\text{Max EMV without Info}$$
  - Sets the absolute maximum budget a company should pay for market research or data intelligence!

#### 2. Analytic Hierarchy Process (AHP - Thomas Saaty)
Multi-criteria prioritization framework:
1. Construct Pairwise Comparison Matrix $A$ using Saaty's 1-9 scale.
2. Compute Principal Eigenvector to determine normalized priority weights.
3. Check Consistency Ratio ($CR = \\frac{CI}{RI} < 0.10$ for acceptable consistency).

#### 3. Executive Storytelling & Data Visualization Best Practices
- **Minto Pyramid Principle:** State the executive conclusion / recommendation first, followed by supporting grouped arguments, and lastly raw data drill-downs.
- **Cognitive Load Reduction:** Remove chart junk; use high contrast for key takeaways; label lines directly instead of distant legends.`,
    quickRevisionNotes: [
      'Decision trees calculate Expected Monetary Value (EMV = sum(P_i * Payoff_i)).',
      'EVPI defines the theoretical maximum financial value of market research data.',
      'Analytic Hierarchy Process (AHP) weights qualitative multi-criteria decisions via pairwise matrices.',
      'Minto Pyramid Principle: Lead with the recommendation first, followed by supporting data.'
    ],
    formulaSheets: [
      {
        name: 'Expected Value of Perfect Information (EVPI)',
        formula: '\\text{EVPI} = \\text{EVwPI} - \\text{EMV}^* = \\sum P(s_i) \\max_{a} \\text{Payoff}(a, s_i) - \\max_{a} \\sum P(s_i) \\text{Payoff}(a, s_i)',
        description: 'Maximum financial value of acquiring complete certainty prior to decision.'
      }
    ],
    definitions: [
      {
        term: 'Expected Value of Perfect Information (EVPI)',
        explanation: 'The price a decision-maker would be willing to pay to gain access to perfect certainty regarding future states of nature before making a commitment.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Decision Tree EMV and EVPI Valuation Script in Python',
        code: `import numpy as np

def calculate_decision_emv_and_evpi(payoff_matrix, state_probabilities):
    # payoff_matrix: rows = actions, cols = states of nature
    payoff_matrix = np.array(payoff_matrix)
    probs = np.array(state_probabilities)
    
    # Step 1: EMV for each decision alternative
    emv_per_action = payoff_matrix.dot(probs)
    max_emv = np.max(emv_per_action)
    best_action_idx = np.argmax(emv_per_action)
    
    # Step 2: Expected Value with Perfect Information (EVwPI)
    max_payoffs_per_state = np.max(payoff_matrix, axis=0)
    ev_with_perfect_info = np.dot(max_payoffs_per_state, probs)
    
    # Step 3: EVPI
    evpi = ev_with_perfect_info - max_emv
    
    return {
        "Best Action Index": int(best_action_idx),
        "Max EMV": f"\${max_emv:,.2f}",
        "EV with Perfect Info": f"\${ev_with_perfect_info:,.2f}",
        "EVPI (Max Research Budget)": f"\${evpi:,.2f}"
    }`
      }
    ],
    practiceQuestions: [
      {
        id: 'ba-w12-q1',
        questionText: 'If a company\'s maximum EMV under uncertainty is $100,000, and the Expected Value with Perfect Information (EVwPI) is $135,000, what is the maximum amount the firm should pay a research consultancy for perfect predictive data?',
        options: ['$35,000', '$135,000', '$100,000', '$235,000'],
        correctOptionIndex: 0,
        solution: 'EVPI = EVwPI - Max EMV = $135,000 - $100,000 = $35,000. The firm should never pay more than $35,000 for perfect information.',
        hints: ['EVPI = EVwPI - Max EMV']
      }
    ],
    examTips: [
      'In executive presentations, always present the actionable recommendation in the very first slide (Minto Pyramid Principle).',
      'EVPI can never be negative; perfect information always has non-negative expected utility.'
    ],
    handwrittenMnemonic: 'EMV = sum(P * Payoff); EVPI = EVwPI - Max EMV (Max research budget); Lead with conclusions!'
  }
];

import { Question } from '../types';

export const DIPLOMA_QUESTIONS: Question[] = [
  // ==========================================
  // DIPLOMA IN PROGRAMMING: JAVA
  // ==========================================
  {
    id: 'pyq-java-generics-msq',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Programming in Java',
    type: 'MSQ',
    questionText: 'Which of the following statements regarding Java Generics, Wildcards, and Type Erasure are TRUE?',
    options: [
      'Type erasure replaces all type parameters in generic types with their bounds or \`Object\` if the type parameters are unbounded.',
      '\`List<? extends Number>\` is a covariant wildcard that allows reading elements as \`Number\`, but disallows adding non-null elements (PECS principle: Producer Extends).',
      '\`List<Object>\` is a supertype of \`List<String>\` in Java.',
      'You cannot instantiate a generic array directly using \`new E[size]\` due to type erasure at runtime.'
    ],
    correctOptionIndices: [0, 1, 3],
    explanation: `Java Generics Core Semantics:
1. Statement A is TRUE: The compiler applies type erasure for backward compatibility, substituting type bounds or Object.
2. Statement B is TRUE: PECS (Producer Extends, Consumer Super) guarantees that \`? extends Number\` can be safely read from as Number, but prevents inserting subtypes because the exact concrete parameter type is unknown.
3. Statement C is FALSE: In Java, generic types are invariant (\`List<String>\` is NOT a subtype of \`List<Object>\`).
4. Statement D is TRUE: Generic array creation is prohibited because array types must retain component type info at runtime.`,
    hints: [
      'Recall invariance of generic types in Java (unlike arrays which are covariant).',
      'Remember PECS: Producer Extends, Consumer Super.'
    ],
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 3',
    pyqYear: 'Jan 2024 (Quiz 2)',
    tags: ['Java', 'Generics', 'Wildcards', 'Type Erasure', 'PECS'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN PROGRAMMING: DBMS
  // ==========================================
  {
    id: 'pyq-dbms-bcnf-lossless-mcq',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Database Management Systems',
    type: 'MCQ',
    questionText: 'A relational schema $R(A, B, C)$ is decomposed into $R_1(A, B)$ and $R_2(B, C)$ under functional dependencies $F = \\{ A \\to B,\\; B \\to C \\}$. Which statement correctly characterizes this decomposition?',
    options: [
      'It is a Lossless Join decomposition and Dependency Preserving.',
      'It is Lossy (Loss of information upon natural join).',
      'It is Lossless Join but NOT Dependency Preserving.',
      'Neither $R_1$ nor $R_2$ is in 3NF.'
    ],
    correctOptionIndex: 0,
    explanation: `Decomposition Property Verification:
1. Lossless Join Test:
   $$R_1 \\cap R_2 = \\{B\\}$$
   Check if $R_1 \\cap R_2 \\to R_1$ or $R_1 \\cap R_2 \\to R_2$:
   Since $B \\to C$ holds in $F$, $(B)^+ = \\{B, C\\} = R_2$.
   Because the common attribute $B$ is a superkey of $R_2$, the decomposition is guaranteed Lossless Join.
2. Dependency Preservation:
   - $A \\to B$ is in $R_1(A, B)$.
   - $B \\to C$ is in $R_2(B, C)$.
   All original functional dependencies in $F$ are directly testable on single relations without joins, so it is Dependency Preserving.`,
    hints: [
      'Check if $(R_1 \\cap R_2) \\to R_1$ or $(R_1 \\cap R_2) \\to R_2$ using attribute closures.',
      'Confirm all FDs can be checked within $R_1$ or $R_2$.'
    ],
    formulaRef: 'R_1 \\cap R_2 \\to R_1 \\quad \\text{or} \\quad R_1 \\cap R_2 \\to R_2',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0.5,
    term: 'Term 3',
    pyqYear: 'May 2024 (End Term)',
    tags: ['DBMS', 'Normalization', 'Lossless Join', 'Dependency Preservation', 'BCNF'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN PROGRAMMING: PDSA
  // ==========================================
  {
    id: 'pyq-pdsa-dijkstra-heap-nat',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Programming, Data Structures & Algorithms (PDSA)',
    type: 'NAT',
    questionText: 'In a directed graph with $V = 100$ vertices and $E = 500$ non-negative weighted edges, what is the maximum number of `decrease_key` / priority updates performed in the worst case by Dijkstra\'s algorithm using a Min-Heap (enter the exact number)?',
    options: [],
    correctNumericAnswer: 500,
    numericTolerance: 0,
    toleranceRange: [500, 500],
    explanation: `Dijkstra Edge Relaxation Invariant:
- Each directed edge $(u, v) \\in E$ is examined and relaxed at most once when vertex $u$ is extracted from the priority queue.
- Therefore, at most $|E| = 500$ decrease-key priority updates can occur in the worst case.
- Overall complexity is $O((V + E) \\log V)$.`,
    hints: [
      'Each directed edge in the graph can trigger at most one edge relaxation.',
      'Count the number of edges $E$.'
    ],
    formulaRef: 'O((V + E) \\log V)',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 4',
    pyqYear: 'Sept 2024 (Quiz 1)',
    tags: ['PDSA', 'Graphs', 'Dijkstra', 'Heaps', 'Algorithms'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN DATA SCIENCE: MLF & MLP
  // ==========================================
  {
    id: 'pyq-mlf-logistic-loss-nat',
    courseId: 'course-mlf-mlt',
    courseTitle: 'Machine Learning Foundations & Techniques (MLF / MLT)',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    subject: 'Machine Learning Foundations & Techniques (MLF / MLT)',
    type: 'NAT',
    questionText: 'For a binary classification sample with true ground truth label $y = 1$, a logistic regression model predicts the probability $\\hat{y} = P(y = 1 | \\mathbf{x}) = 0.50$. Using natural logarithm base $e$, compute the Binary Cross-Entropy loss $\\mathcal{L} = -\\ln(0.50)$ (given $\\ln(2) \\approx 0.693$. Enter answer rounded to 3 decimal places).',
    options: [],
    correctNumericAnswer: 0.693,
    numericTolerance: 0.005,
    toleranceRange: [0.688, 0.698],
    explanation: `Binary Cross-Entropy Loss:
$$\\mathcal{L} = -[y \\ln(\\hat{y}) + (1 - y)\\ln(1 - \\hat{y})]$$
1. With $y = 1$ and $\\hat{y} = 0.50$:
   $$\\mathcal{L} = -[1 \\times \\ln(0.50) + 0] = -\\ln(1/2) = \\ln(2) \\approx 0.69315$$
2. The loss is $0.693$.`,
    hints: [
      'When $y = 1$, the loss formula reduces to $-\\ln(\\hat{y})$.',
      '$-\\ln(0.5) = \\ln(2) \\approx 0.693$.'
    ],
    formulaRef: '\\mathcal{L} = -[y \\ln(\\hat{y}) + (1 - y)\\ln(1 - \\hat{y})]',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 4',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['ML Foundations', 'Cross-Entropy', 'Logistic Regression', 'Loss Functions'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-mlp-roc-auc-msq',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice (MLP)',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    subject: 'Machine Learning Practice (MLP)',
    type: 'MSQ',
    questionText: 'Which of the following statements regarding the ROC (Receiver Operating Characteristic) curve and AUC are TRUE?',
    options: [
      'The ROC curve plots the True Positive Rate (Sensitivity) on the Y-axis against the False Positive Rate ($1 - \\text{Specificity}$) on the X-axis across all decision thresholds.',
      'An ROC-AUC score of $0.50$ corresponds to a completely random classifier with no discriminative capability.',
      'ROC curves are invariant to monotonic transformations of predicted probabilities (they depend purely on relative ranking).',
      'For severe class-imbalanced datasets where the positive class is extremely rare, the Precision-Recall (PR) AUC curve is often more informative than the ROC curve.'
    ],
    correctOptionIndices: [0, 1, 2, 3],
    explanation: `ROC-AUC Evaluation Principles:
- Statement A is TRUE: Standard definition of ROC axis coordinates ($TPR = TP/(TP+FN)$, $FPR = FP/(FP+TN)$).
- Statement B is TRUE: Diagonal line from $(0,0)$ to $(1,1)$ has area $0.50$.
- Statement C is TRUE: Threshold sweeps sort scores ordinally, so monotonic scaling does not alter curve rank ordering.
- Statement D is TRUE: When negatives massively outnumber positives, large increases in FP cause tiny changes in FPR ($FP / TN$), making ROC look overly optimistic; PR curve isolates precision directly.
All 4 statements are correct!`,
    hints: [
      'Recall that FPR = FP / (FP + TN) and TPR = TP / (TP + FN).',
      'Consider why PR curve is preferred over ROC under severe class imbalance.'
    ],
    formulaRef: '\\text{TPR} = \\frac{TP}{TP+FN}, \\quad \\text{FPR} = \\frac{FP}{FP+TN}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 5',
    pyqYear: 'Jan 2025 (Quiz 2)',
    tags: ['ML Practice', 'ROC-AUC', 'Model Evaluation', 'Class Imbalance'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

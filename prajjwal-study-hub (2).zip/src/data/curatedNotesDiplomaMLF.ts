import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_DS_MLF_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-mlf-w1',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 1,
    title: 'Linear Algebra for ML: Vector Spaces, Norms, Dot Products & Hyperplanes',
    detailedNotes: `### Week 1: Geometric Foundations of Machine Learning

#### 1. Vector Spaces, Linear Combinations & Span
A set of vectors $\\{\\mathbf{v}_1, \\dots, \\mathbf{v}_k\\} \\subset \\mathbb{R}^d$ is **linearly independent** if:
$$c_1 \\mathbf{v}_1 + c_2 \\mathbf{v}_2 + \\dots + c_k \\mathbf{v}_k = \\mathbf{0} \\implies c_1 = c_2 = \\dots = c_k = 0$$
- The **Span** of the vectors is the subspace formed by all their linear combinations.
- The **Rank** of matrix $A \\in \\mathbb{R}^{m \\times n}$ is the dimension of the column space $\\text{col}(A)$.

#### 2. Vector Norms & Distance Metrics
- **$L_1$ Norm (Manhattan):** $\\|\\mathbf{x}\\|_1 = \\sum_{i=1}^d |x_i|$ (promotes sparsity in Lasso).
- **$L_2$ Norm (Euclidean):** $\\|\\mathbf{x}\\|_2 = \\sqrt{\\sum_{i=1}^d x_i^2} = \\sqrt{\\mathbf{x}^T \\mathbf{x}}$.
- **$L_\\infty$ Norm (Max Norm):** $\\|\\mathbf{x}\\|_\\infty = \\max_i |x_i|$.
- **Cosine Similarity:** $\\cos(\\theta) = \\frac{\\mathbf{x}^T \\mathbf{y}}{\\|\\mathbf{x}\\|_2 \\|\\mathbf{y}\\|_2}$.

#### 3. Hyperplanes & Decision Boundaries
A hyperplane in $\\mathbb{R}^d$ is parameterized by a normal vector $\\mathbf{w} \\in \\mathbb{R}^d$ and bias $b \\in \\mathbb{R}$:
$$\\mathcal{H} = \\{\\mathbf{x} \\in \\mathbb{R}^d \\mid \\mathbf{w}^T \\mathbf{x} + b = 0\\}$$
- Signed orthogonal distance from point $\\mathbf{x}_0$ to hyperplane $\\mathcal{H}$:
$$d(\\mathbf{x}_0, \\mathcal{H}) = \\frac{\\mathbf{w}^T \\mathbf{x}_0 + b}{\\|\\mathbf{w}\\|_2}$$`,
    quickRevisionNotes: [
      'Normal vector $\\mathbf{w}$ is strictly orthogonal to any vector lying inside the hyperplane $\\mathbf{w}^T \\mathbf{x} + b = 0$.',
      'Signed distance to hyperplane is $d = \\frac{\\mathbf{w}^T \\mathbf{x} + b}{\\|\\mathbf{w}\\|_2}$.',
      '$L_1$ ball is a diamond/polytope with vertices on axes; $L_2$ ball is a smooth hypersphere.'
    ],
    formulaSheets: [
      {
        name: 'Signed Distance to Hyperplane',
        formula: 'd(\\mathbf{x}, \\mathcal{H}) = \\frac{\\mathbf{w}^T \\mathbf{x} + b}{\\|\\mathbf{w}\\|_2}',
        description: 'Orthogonal distance of point $\\mathbf{x}$ to decision boundary $\\mathbf{w}^T \\mathbf{x} + b = 0$.'
      }
    ],
    definitions: [
      {
        term: 'Hyperplane',
        explanation: 'An affine subspace of dimension $d-1$ in $\\mathbb{R}^d$ dividing space into two half-spaces.',
        formula: '\\mathbf{w}^T \\mathbf{x} + b = 0'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Vector Norms & Distance Computation with NumPy',
        code: `import numpy as np

def compute_distances(x, w, b):
    # Orthogonal distance from point x to hyperplane w^T x + b = 0
    w_norm = np.linalg.norm(w, ord=2)
    signed_dist = (np.dot(w, x) + b) / w_norm
    return abs(signed_dist)`
      }
    ],
    examTips: [
      'Scaling $\\mathbf{w}$ and $b$ by positive constant $c$ gives the exact same hyperplane geometrically, but changes the raw score $\\mathbf{w}^T \\mathbf{x} + b$. You MUST normalize by $\\|\\mathbf{w}\\|_2$ to find true geometric distance!',
      'Two non-zero vectors $\\mathbf{u}, \\mathbf{v}$ are orthogonal $\\iff \\mathbf{u}^T \\mathbf{v} = 0$.'
    ],
    handwrittenMnemonic: 'Normal vector $\\mathbf{w}$ points in direction of increasing positive score!'
  },
  {
    id: 'note-mlf-w2',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 2,
    title: 'Matrix Factorization: Eigenvalues, Spectral Theorem & SVD (Singular Value Decomposition)',
    detailedNotes: `### Week 2: Eigendecomposition & Singular Value Decomposition

#### 1. Eigenvalues and Eigenvectors
For square matrix $A \\in \\mathbb{R}^{d \\times d}$, a non-zero vector $\\mathbf{v}$ and scalar $\\lambda$ satisfy:
$$A \\mathbf{v} = \\lambda \\mathbf{v} \\iff (A - \\lambda I) \\mathbf{v} = \\mathbf{0} \\implies \\det(A - \\lambda I) = 0$$
- **Trace & Determinant Properties:** $\\text{Tr}(A) = \\sum \\lambda_i$ and $\\det(A) = \\prod \\lambda_i$.
- **Spectral Theorem for Symmetric Matrices:** If $A = A^T$, all eigenvalues are real, and eigenvectors can be chosen orthonormal: $A = Q \\Lambda Q^T$.

#### 2. Singular Value Decomposition (SVD)
For ANY matrix $A \\in \\mathbb{R}^{m \\times n}$ of rank $r$:
$$A = U \\Sigma V^T = \\sum_{i=1}^r \\sigma_i \\mathbf{u}_i \\mathbf{v}_i^T$$
- $U \\in \\mathbb{R}^{m \\times m}$: Orthonormal eigenvectors of $A A^T$ (Left singular vectors).
- $V \\in \\mathbb{R}^{n \\times n}$: Orthonormal eigenvectors of $A^T A$ (Right singular vectors).
- $\\Sigma \\in \\mathbb{R}^{m \\times n}$: Diagonal matrix of singular values $\\sigma_1 \\ge \\sigma_2 \\ge \\dots \\ge \\sigma_r > 0$ where $\\sigma_i = \\sqrt{\\lambda_i(A^T A)}$.

#### 3. Low-Rank Matrix Approximation (Eckart-Young-Mirsky Theorem)
The best rank-$k$ approximation ($k < r$) minimizing Frobenius norm error $\\|A - A_k\\|_F$ is obtained by truncating SVD to the top $k$ singular components:
$$A_k = \\sum_{i=1}^k \\sigma_i \\mathbf{u}_i \\mathbf{v}_i^T, \\quad \\|A - A_k\\|_F^2 = \\sum_{i=k+1}^r \\sigma_i^2$$`,
    quickRevisionNotes: [
      'Singular values $\\sigma_i$ are always non-negative real numbers, even if matrix $A$ is non-square or has negative entries.',
      'Eckart-Young theorem guarantees truncated SVD is the globally optimal low-rank matrix approximation.',
      'Frobenius norm squared equals sum of squares of all singular values: $\\|A\\|_F^2 = \\sum \\sigma_i^2$.'
    ],
    formulaSheets: [
      {
        name: 'Singular Value Decomposition (SVD)',
        formula: 'A = U \\Sigma V^T = \\sum_{i=1}^r \\sigma_i \\mathbf{u}_i \\mathbf{v}_i^T',
        description: 'Full factorization into orthonormal bases and scaling singular values.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'SVD & Rank-K Approximation in Python',
        code: `import numpy as np

def rank_k_approx(A, k):
    U, s, Vt = np.linalg.svd(A, full_matrices=False)
    # Truncate to top k singular components
    Ak = np.dot(U[:, :k] * s[:k], Vt[:k, :])
    reconstruction_loss = np.sum(s[k:]**2)
    return Ak, reconstruction_loss`
      }
    ],
    examTips: [
      'Singular values are square roots of eigenvalues of $A^T A$ or $A A^T$, so $\\sigma_i \\ge 0$ always!',
      'Columns of $U$ with $\\sigma_i = 0$ span the nullspace of $A^T$.'
    ],
    handwrittenMnemonic: '$A = U \\Sigma V^T$: Left vectors from $AA^T$, Right vectors from $A^T A$!'
  },
  {
    id: 'note-mlf-w3',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 3,
    title: 'Principal Component Analysis (PCA) & Dimensionality Reduction',
    detailedNotes: `### Week 3: Principal Component Analysis & Variance Maximization

#### 1. PCA Objective: Maximum Variance Projection
Given centered data matrix $X \\in \\mathbb{R}^{n \\times d}$ (where $\\sum_{i=1}^n \\mathbf{x}_i = \\mathbf{0}$):
- Covariance matrix: $S = \\frac{1}{n} X^T X \\in \\mathbb{R}^{d \\times d}$.
- Finding unit projection vector $\\mathbf{u}_1$ (with $\\|\\mathbf{u}_1\\|_2 = 1$) maximizing projected variance:
$$\\max_{\\mathbf{u}_1} \\mathbf{u}_1^T S \\mathbf{u}_1 \\quad \\text{s.t.} \\quad \\mathbf{u}_1^T \\mathbf{u}_1 = 1$$
- Using Lagrange Multiplier $\\mathcal{L}(\\mathbf{u}_1, \\lambda) = \\mathbf{u}_1^T S \\mathbf{u}_1 - \\lambda (\\mathbf{u}_1^T \\mathbf{u}_1 - 1)$:
$$\\nabla_{\\mathbf{u}_1} \\mathcal{L} = 2 S \\mathbf{u}_1 - 2 \\lambda \\mathbf{u}_1 = \\mathbf{0} \\implies S \\mathbf{u}_1 = \\lambda \\mathbf{u}_1$$
- Hence, the principal component directions are the **eigenvectors of sample covariance matrix $S$** sorted in descending order of eigenvalues $\\lambda_1 \\ge \\lambda_2 \\ge \\dots \\ge \\lambda_d \\ge 0$.

#### 2. Explained Variance Ratio
- Total variance in dataset: $\\text{Tr}(S) = \\sum_{i=1}^d \\lambda_i$.
- Explained variance proportion by top $k$ principal components:
$$\\text{EVR}_k = \\frac{\\sum_{j=1}^k \\lambda_j}{\\sum_{i=1}^d \\lambda_i}$$`,
    quickRevisionNotes: [
      'Data MUST be zero-mean centered before computing covariance matrix and PCA!',
      'PCA minimizes mean squared reconstruction error $\\iff$ PCA maximizes projected variance.',
      'Principal directions are mutually orthogonal eigenvectors of $X^T X$.'
    ],
    formulaSheets: [
      {
        name: 'Explained Variance Ratio',
        formula: '\\text{EVR}_k = \\frac{\\sum_{j=1}^k \\lambda_j}{\\sum_{i=1}^d \\lambda_i}',
        description: 'Proportion of total dataset variance retained by first $k$ principal components.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Full PCA Implementation from Scratch',
        code: `import numpy as np

def custom_pca(X, n_components):
    # 1. Zero-center data
    X_centered = X - np.mean(X, axis=0)
    # 2. Compute sample covariance matrix
    cov_matrix = np.cov(X_centered, rowvar=False)
    # 3. Eigendecomposition
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    # 4. Sort in descending order
    sorted_indices = np.argsort(eigenvalues)[::-1]
    top_components = eigenvectors[:, sorted_indices[:n_components]]
    # 5. Project data
    X_projected = np.dot(X_centered, top_components)
    return X_projected, eigenvalues[sorted_indices]`
      }
    ],
    examTips: [
      'If features are on vastly different scales (e.g. Income in dollars vs Age in years), PCA will be dominated by features with largest scale. Standardize features to zero mean and unit variance ($Z$-score) first!',
      'Eigenvalues of covariance matrix can NEVER be negative because $S = \\frac{1}{n} X^T X$ is Positive Semi-Definite.'
    ],
    handwrittenMnemonic: 'Center first $\\to$ Covariance $\\to$ Eigenvectors $\\to$ Project!'
  },
  {
    id: 'note-mlf-w4',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 4,
    title: 'Linear Regression, Ordinary Least Squares (OLS) & Normal Equations',
    detailedNotes: `### Week 4: Supervised Learning & Closed-Form Linear Regression

#### 1. Linear Regression Model Formulation
Given dataset $\\mathcal{D} = \\{(\\mathbf{x}_i, y_i)\\}_{i=1}^n$ with design matrix $X \\in \\mathbb{R}^{n \\times d}$ and target vector $\\mathbf{y} \\in \\mathbb{R}^n$:
- Linear prediction hypothesis: $\\hat{\\mathbf{y}} = X \\mathbf{w}$.
- **Residual Sum of Squares (RSS) Loss Function:**
$$\\mathcal{L}(\\mathbf{w}) = \\|X \\mathbf{w} - \\mathbf{y}\\|_2^2 = (X\\mathbf{w} - \\mathbf{y})^T (X\\mathbf{w} - \\mathbf{y}) = \\mathbf{w}^T X^T X \\mathbf{w} - 2 \\mathbf{w}^T X^T \\mathbf{y} + \\mathbf{y}^T \\mathbf{y}$$

#### 2. Derivation of Normal Equations
To find $\\mathbf{w}^* = \\arg\\min_\\mathbf{w} \\mathcal{L}(\\mathbf{w})$, take matrix gradient with respect to $\\mathbf{w}$ and set to zero:
$$\\nabla_\\mathbf{w} \\mathcal{L}(\\mathbf{w}) = 2 X^T X \\mathbf{w} - 2 X^T \\mathbf{y} = \\mathbf{0}$$
$$X^T X \\mathbf{w} = X^T \\mathbf{y} \\implies \\mathbf{w}^* = (X^T X)^{-1} X^T \\mathbf{y}$$
- **Orthogonality of Residuals:** The residual vector $\\mathbf{e} = \\mathbf{y} - \\hat{\\mathbf{y}} = \\mathbf{y} - X \\mathbf{w}^*$ is strictly orthogonal to the column space of $X$:
$$X^T (\\mathbf{y} - X \\mathbf{w}^*) = X^T \\mathbf{y} - X^T X (X^T X)^{-1} X^T \\mathbf{y} = \\mathbf{0}$$`,
    quickRevisionNotes: [
      'Normal equation: $\\mathbf{w}^* = (X^T X)^{-1} X^T \\mathbf{y}$.',
      'Requires $X^T X$ to be invertible (full column rank $d$, no collinear features).',
      'The projection (Hat) matrix $H = X(X^T X)^{-1} X^T$ projects $\\mathbf{y}$ onto the subspace spanned by columns of $X$.'
    ],
    formulaSheets: [
      {
        name: 'Normal Equations Closed-Form Solution',
        formula: '\\mathbf{w}^* = (X^T X)^{-1} X^T \\mathbf{y}',
        description: 'Exact analytical parameter vector minimizing Mean Squared Error.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'OLS Linear Regression with Normal Equations',
        code: `import numpy as np

def fit_ols(X, y):
    # Add bias intercept column of ones
    X_bias = np.c_[np.ones(X.shape[0]), X]
    # w = (X^T X)^-1 X^T y
    w = np.linalg.inv(X_bias.T @ X_bias) @ X_bias.T @ y
    return w`
      }
    ],
    examTips: [
      'If features are collinear (rank of $X < d$), $X^T X$ is singular and non-invertible. Solution: Use Moore-Penrose Pseudoinverse $(X^T X)^+$ or Ridge Regression ($L_2$ regularizer).',
      'The Hat matrix $H = X(X^T X)^{-1} X^T$ is idempotent: $H^2 = H$ and symmetric: $H^T = H$.'
    ],
    handwrittenMnemonic: 'Residuals are perpendicular to the feature span: $X^T \\mathbf{e} = 0$!'
  },
  {
    id: 'note-mlf-w5',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 5,
    title: 'Regularization: Ridge (L2), Lasso (L1), Bias-Variance Tradeoff',
    detailedNotes: `### Week 5: Overfitting, Generalization & Regularization

#### 1. Bias-Variance Decomposition
For target $y = f(\\mathbf{x}) + \\epsilon$ with noise $\\epsilon \\sim \\mathcal{N}(0, \\sigma^2)$, the expected test MSE of estimator $\\hat{f}(\\mathbf{x})$ decomposes as:
$$\\mathbb{E}\\left[ (y - \\hat{f}(\\mathbf{x}))^2 \\right] = \\underbrace{\\left( \\mathbb{E}[\\hat{f}(\\mathbf{x})] - f(\\mathbf{x}) \\right)^2}_{\\text{Bias}^2} + \\underbrace{\\mathbb{E}\\left[ (\\hat{f}(\\mathbf{x}) - \\mathbb{E}[\\hat{f}(\\mathbf{x})])^2 \\right]}_{\\text{Variance}} + \\underbrace{\\sigma^2}_{\\text{Irreducible Noise}}$$

#### 2. Ridge Regression ($L_2$ Regularization / Tikhonov)
Penalizes squared $L_2$ magnitude of coefficients to stabilize multicollinearity:
$$\\min_\\mathbf{w} \\|X \\mathbf{w} - \\mathbf{y}\\|_2^2 + \\lambda \\|\\mathbf{w}\\|_2^2 \\implies \\mathbf{w}_{\\text{ridge}}^* = (X^T X + \\lambda I)^{-1} X^T \\mathbf{y}$$
- Because $(X^T X + \\lambda I)$ is strictly positive definite for any $\\lambda > 0$, it is ALWAYS invertible!

#### 3. Lasso Regression ($L_1$ Regularization)
$$\\min_\\mathbf{w} \\|X \\mathbf{w} - \\mathbf{y}\\|_2^2 + \\lambda \\|\\mathbf{w}\\|_1$$
- Geometric effect: The $L_1$ constraint region is a diamond with sharp corners on coordinate axes. Contours of quadratic RSS loss hit corners first, driving uninformative feature weights to EXACTLY ZERO (feature selection).`,
    quickRevisionNotes: [
      'Ridge adds $\\lambda I$ to $X^T X$, guaranteeing non-singularity and shrinking weights smoothly towards zero.',
      'Lasso produces sparse solutions with exact zeros due to non-differentiable sharp corners of $L_1$ diamond.',
      'High $\\lambda \\implies$ High Bias, Low Variance (Underfitting). Low $\\lambda \\implies$ Low Bias, High Variance (Overfitting).'
    ],
    formulaSheets: [
      {
        name: 'Ridge Closed Form Solution',
        formula: '\\mathbf{w}_{\\text{ridge}} = (X^T X + \\lambda I)^{-1} X^T \\mathbf{y}',
        description: 'Analytical weights with strictly non-singular regularized matrix inversion.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Ridge vs Lasso Comparison with Scikit-Learn',
        code: `from sklearn.linear_model import Ridge, Lasso

ridge = Ridge(alpha=1.0)
ridge.fit(X_train, y_train)

lasso = Lasso(alpha=0.1)
lasso.fit(X_train, y_train)

# Non-zero feature count in Lasso (Feature Selection)
selected_features = np.sum(lasso.coef_ != 0)`
      }
    ],
    examTips: [
      'Never regularize the bias/intercept term $w_0$; only regularize feature weights $\\mathbf{w}_{1\\dots d}$.',
      'Lasso does NOT have a closed-form analytical solution; it is solved via iterative coordinate descent or subgradient descent.'
    ],
    handwrittenMnemonic: '$L_1$ has corners $\\to$ Sparsity; $L_2$ is a circle $\\to$ Smooth Shrinkage!'
  },
  {
    id: 'note-mlf-w6',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 6,
    title: 'Optimization for ML: Gradient Descent, SGD, Momentum & Adam',
    detailedNotes: `### Week 6: First-Order Iterative Optimization

#### 1. Gradient Descent Update Rule
For convex objective function $J(\\mathbf{w})$ with learning rate $\\eta > 0$:
$$\\mathbf{w}_{t+1} = \\mathbf{w}_t - \\eta \\nabla_\\mathbf{w} J(\\mathbf{w}_t)$$
- **Batch GD:** Computes exact gradient over all $N$ training examples. Stable but $O(N)$ per step.
- **Stochastic GD (SGD):** Updates weights using a single randomly chosen sample $i_t$:
$$\\mathbf{w}_{t+1} = \\mathbf{w}_t - \\eta \\nabla_\\mathbf{w} J_i(\\mathbf{w}_t)$$
- **Mini-Batch GD:** Balance speed and variance using mini-batches of size $B$ (e.g. $B=32, 64$).

#### 2. Momentum & Adaptive Optimizers
- **SGD with Momentum:** Accelerates through ravines by maintaining velocity $v_t$:
$$v_t = \\beta v_{t-1} + \\nabla J(\\mathbf{w}_t), \\quad \\mathbf{w}_{t+1} = \\mathbf{w}_t - \\eta v_t$$
- **Adam (Adaptive Moment Estimation):** Combines 1st moment (mean) and 2nd moment (uncentered variance):
$$\\hat{m}_t = \\frac{m_t}{1 - \\beta_1^t}, \\quad \\hat{v}_t = \\frac{v_t}{1 - \\beta_2^t}, \\quad \\mathbf{w}_{t+1} = \\mathbf{w}_t - \\frac{\\eta}{\\sqrt{\\hat{v}_t} + \\epsilon} \\hat{m}_t$$`,
    quickRevisionNotes: [
      'Learning rate $\\eta$ too large causes divergence/oscillation; too small causes exceedingly slow convergence.',
      'Momentum dampens high-frequency oscillations across steep ravine walls.',
      'Adam normalizes gradients per-parameter based on historical variance.'
    ],
    formulaSheets: [
      {
        name: 'Gradient Descent Parameter Step',
        formula: '\\mathbf{w}_{t+1} = \\mathbf{w}_t - \\eta \\nabla J(\\mathbf{w}_t)',
        description: 'Iterative step along the direction of steepest descent.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Mini-Batch SGD Optimizer Loop',
        code: `def mini_batch_sgd(X, y, epochs=100, lr=0.01, batch_size=32):
    n, d = X.shape
    w = np.zeros(d)
    for epoch in range(epochs):
        indices = np.random.permutation(n)
        for i in range(0, n, batch_size):
            batch_idx = indices[i:i+batch_size]
            X_b, y_b = X[batch_idx], y[batch_idx]
            grad = (2 / len(X_b)) * X_b.T @ (X_b @ w - y_b)
            w -= lr * grad
    return w`
      }
    ],
    examTips: [
      'In non-convex optimization (Deep Learning), SGD noise often helps escape shallow local minima and saddle points.',
      'Bias correction $\\frac{m_t}{1 - \\beta_1^t}$ in Adam prevents initial steps from vanishing to zero when moments are initialized to $\\mathbf{0}$.'
    ],
    handwrittenMnemonic: 'Adam = Momentum (1st moment) + RMSprop (2nd moment) + Bias Correction!'
  },
  {
    id: 'note-mlf-w7',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 7,
    title: 'Logistic Regression, Cross-Entropy Loss & Maximum Likelihood Estimation (MLE)',
    detailedNotes: `### Week 7: Probabilistic Binary Classification

#### 1. Sigmoid Activation & Posterior Odds
Models probability $P(y=1 \\mid \\mathbf{x})$ via the logistic sigmoid function $\\sigma(z)$:
$$P(y=1 \\mid \\mathbf{x}; \\mathbf{w}) = \\sigma(\\mathbf{w}^T \\mathbf{x}) = \\frac{1}{1 + e^{-\\mathbf{w}^T \\mathbf{x}}}$$
- **Log-Odds (Logit):** $\\ln\\left( \\frac{P(y=1 \\mid \\mathbf{x})}{1 - P(y=1 \\mid \\mathbf{x})} \\right) = \\mathbf{w}^T \\mathbf{x}$ (strictly linear in parameters).
- Sigmoid derivative: $\\sigma\'(z) = \\sigma(z)(1 - \\sigma(z))$.

#### 2. Binary Cross-Entropy Loss from MLE
Given independent Bernoulli labels $y_i \\in \\{0, 1\\}$, the Likelihood is:
$$L(\\mathbf{w}) = \\prod_{i=1}^n [\\hat{y}_i]^{y_i} [1 - \\hat{y}_i]^{1 - y_i} \\quad \\text{where } \\hat{y}_i = \\sigma(\\mathbf{w}^T \\mathbf{x}_i)$$
Negative Log-Likelihood (Binary Cross-Entropy Loss):
$$J(\\mathbf{w}) = - \\sum_{i=1}^n \\left[ y_i \\ln \\hat{y}_i + (1 - y_i) \\ln(1 - \\hat{y}_i) \\right]$$
Gradient: $\\nabla_\\mathbf{w} J(\\mathbf{w}) = X^T (\\hat{\\mathbf{y}} - \\mathbf{y})$ (identical elegant gradient form as Linear Regression MSE!).`,
    quickRevisionNotes: [
      'Logistic regression is a linear classifier because the decision boundary $\\sigma(\\mathbf{w}^T \\mathbf{x}) = 0.5 \\iff \\mathbf{w}^T \\mathbf{x} = 0$ is a flat hyperplane.',
      'Negative log-likelihood of Bernoulli variables yields Binary Cross-Entropy loss.',
      'Gradient of Cross-Entropy Loss: $\\nabla_\\mathbf{w} J = X^T (\\hat{\\mathbf{y}} - \\mathbf{y})$.'
    ],
    formulaSheets: [
      {
        name: 'Logistic Sigmoid Function & Cross-Entropy',
        formula: '\\sigma(z) = \\frac{1}{1 + e^{-z}}, \\quad J(\\mathbf{w}) = -\\sum_{i=1}^n \\left( y_i \\ln \\hat{y}_i + (1 - y_i) \\ln(1 - \\hat{y}_i) \\right)',
        description: 'Core probability mapper and convex optimization loss.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Logistic Regression Vectorized Gradient Step',
        code: `def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -250, 250)))

def logistic_step(X, y, w, lr=0.05):
    # Predict probabilities
    y_hat = sigmoid(X @ w)
    # Compute cross-entropy gradient
    grad = X.T @ (y_hat - y) / len(y)
    # Gradient descent update
    w_new = w - lr * grad
    return w_new`
      }
    ],
    examTips: [
      'Unlike linear regression, logistic regression has NO closed-form analytical solution because $\\nabla_\\mathbf{w} J(\\mathbf{w}) = \\mathbf{0}$ is transcendental. It must be solved numerically via Gradient Descent or Newton-Raphson (IRLS).',
      'If data is linearly separable, unregularized logistic regression weights will grow to $\\pm \\infty$ trying to drive loss to 0. Always apply $L_2$ regularization!'
    ],
    handwrittenMnemonic: 'Sigmoid maps $(-\\infty, +\\infty) \\to (0, 1)$; Log-odds is strictly linear!'
  },
  {
    id: 'note-mlf-w8',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 8,
    title: 'Support Vector Machines (SVM): Hard Margin, Soft Margin & Dual Formulation',
    detailedNotes: `### Week 8: Max-Margin Classifiers & Quadratic Programming

#### 1. Hard-Margin SVM (Linearly Separable Case)
Goal: Maximize the geometric margin $\\frac{2}{\\|\\mathbf{w}\\|_2}$ between two classes $y_i \\in \\{-1, +1\\}$:
$$\\min_\\mathbf{w, b} \\frac{1}{2} \\|\\mathbf{w}\\|_2^2 \\quad \\text{s.t.} \\quad y_i (\\mathbf{w}^T \\mathbf{x}_i + b) \\ge 1, \\quad \\forall i=1, \\dots, n$$
- Points with $y_i (\\mathbf{w}^T \\mathbf{x}_i + b) = 1$ are **Support Vectors**.

#### 2. Soft-Margin SVM (Slack Variables $\\xi_i$)
Permits margin violations for non-separable noisy data using penalty parameter $C > 0$:
$$\\min_\\mathbf{w, b, \\boldsymbol{\\xi}} \\frac{1}{2} \\|\\mathbf{w}\\|_2^2 + C \\sum_{i=1}^n \\xi_i \\quad \\text{s.t.} \\quad y_i (\\mathbf{w}^T \\mathbf{x}_i + b) \\ge 1 - \\xi_i, \\quad \\xi_i \\ge 0$$
- Large $C$: Heavy penalty on errors $\\to$ Narrower margin, risks overfitting.
- Small $C$: Tolerates errors $\\to$ Wider margin, more robust.

#### 3. Dual Formulation & KKT Conditions
$$\\max_{\\boldsymbol{\\alpha}} \\sum_{i=1}^n \\alpha_i - \\frac{1}{2} \\sum_{i=1}^n \\sum_{j=1}^n \\alpha_i \\alpha_j y_i y_j (\\mathbf{x}_i^T \\mathbf{x}_j) \\quad \\text{s.t.} \\quad 0 \\le \\alpha_i \\le C, \\quad \\sum_{i=1}^n \\alpha_i y_i = 0$$
- **Reconstructed Weights:** $\\mathbf{w}^* = \\sum_{i=1}^n \\alpha_i y_i \\mathbf{x}_i$. Only support vectors have $\\alpha_i > 0$!`,
    quickRevisionNotes: [
      'Hard margin width is exactly $\\frac{2}{\\|\\mathbf{w}\\|_2}$.',
      'Dual formulation depends ONLY on pairwise inner products $\\mathbf{x}_i^T \\mathbf{x}_j$.',
      'Only Support Vectors ($\\alpha_i > 0$) define the decision boundary; removing all other training points changes nothing!'
    ],
    formulaSheets: [
      {
        name: 'SVM Dual Optimization Problem',
        formula: '\\max_\\alpha \\sum_{i=1}^n \\alpha_i - \\frac{1}{2} \\sum_{i,j} \\alpha_i \\alpha_j y_i y_j (\\mathbf{x}_i^T \\mathbf{x}_j) \\quad \\text{s.t. } 0 \\le \\alpha_i \\le C, \\sum \\alpha_i y_i = 0',
        description: 'Quadratic programming dual enabling the Kernel Trick.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Linear & RBF Kernel SVM with Scikit-Learn',
        code: `from sklearn.svm import SVC

# Soft-margin linear SVM
clf_linear = SVC(kernel='linear', C=1.0)
clf_linear.fit(X_train, y_train)

# Number of support vectors per class
print("Support vector count:", clf_linear.n_support_)`
      }
    ],
    examTips: [
      'If $0 < \\alpha_i < C$, point $i$ is a support vector lying EXACTLY on the margin boundary.',
      'If $\\alpha_i = C$, point $i$ is a support vector violating the margin (slack $\\xi_i > 0$).'
    ],
    handwrittenMnemonic: 'Dual depends only on dot products $\\to$ Opens the door for Kernel Trick!'
  },
  {
    id: 'note-mlf-w9',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 9,
    title: 'Kernel Methods: Mercer\'s Theorem, Polynomial & RBF Gaussian Kernels',
    detailedNotes: `### Week 9: Non-Linear Transformations & The Kernel Trick

#### 1. The Kernel Concept
Map input $\\mathbf{x} \\in \\mathbb{R}^d$ to high-dimensional Hilbert feature space $\\Phi(\\mathbf{x}) \\in \\mathcal{H}$:
- Instead of explicitly computing expensive mapping $\\Phi(\\mathbf{x})$, compute kernel function:
$$K(\\mathbf{x}, \\mathbf{z}) = \\langle \\Phi(\\mathbf{x}), \\Phi(\\mathbf{z}) \\rangle$$

#### 2. Popular Mercer Kernel Functions
- **Linear Kernel:** $K(\\mathbf{x}, \\mathbf{z}) = \\mathbf{x}^T \\mathbf{z}$
- **Polynomial Kernel:** $K(\\mathbf{x}, \\mathbf{z}) = (\\mathbf{x}^T \\mathbf{z} + c)^d$ with degree $d$ and $c \\ge 0$.
- **Radial Basis Function (RBF / Gaussian):**
$$K(\\mathbf{x}, \\mathbf{z}) = \\exp\\left( -\\gamma \\|\\mathbf{x} - \\mathbf{z}\\|_2^2 \\right) = \\exp\\left( -\\frac{\\|\\mathbf{x} - \\mathbf{z}\\|_2^2}{2\\sigma^2} \\right)$$
- *Remark:* The RBF kernel corresponds to an **infinite-dimensional** feature space $\\mathcal{H}$!

#### 3. Mercer\'s Theorem
A symmetric function $K(\\mathbf{x}, \\mathbf{z})$ is a valid Mercer kernel $\\iff$ for any finite set of points, the Gram matrix $G_{ij} = K(\\mathbf{x}_i, \\mathbf{x}_j)$ is **Positive Semi-Definite (PSD)** ($G \\succeq 0$).`,
    quickRevisionNotes: [
      'Kernel trick evaluates inner product in high dimensions in $O(d)$ time without explicit $\\Phi(\\mathbf{x})$ expansion.',
      'RBF Gaussian kernel implicitly maps points into an infinite-dimensional feature space.',
      'Mercer\'s theorem guarantees Gram matrix $K$ has all non-negative eigenvalues $\\lambda_i \\ge 0$.'
    ],
    formulaSheets: [
      {
        name: 'RBF Gaussian Kernel',
        formula: 'K(\\mathbf{x}, \\mathbf{z}) = \\exp\\left( -\\gamma \\|\\mathbf{x} - \\mathbf{z}\\|_2^2 \\right)',
        description: 'Infinite-dimensional similarity metric parameterized by bandwidth $\\gamma$.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Gram Matrix Computation with RBF Kernel',
        code: `import numpy as np

def rbf_kernel_matrix(X, gamma=0.5):
    # Pairwise squared Euclidean distance: ||x - z||^2
    dists = np.sum(X**2, axis=1)[:, np.newaxis] + np.sum(X**2, axis=1) - 2 * np.dot(X, X.T)
    # K(x, z) = exp(-gamma * dist)
    K = np.exp(-gamma * np.maximum(0, dists))
    return K`
      }
    ],
    examTips: [
      'Large $\\gamma$ in RBF kernel creates tight, narrow decision bubbles around individual training points $\\to$ severe Overfitting. Small $\\gamma$ makes boundary overly smooth $\\to$ Underfitting.',
      'Sum and product of two valid Mercer kernels are always valid Mercer kernels!'
    ],
    handwrittenMnemonic: 'Kernel computes dot products directly in infinite dimensions!'
  },
  {
    id: 'note-mlf-w10',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 10,
    title: 'Decision Trees, Splitting Criteria (Gini, Entropy) & Pruning',
    detailedNotes: `### Week 10: Non-Parametric Partitioning & Decision Trees

#### 1. Splitting Impurity Metrics
For node $m$ with class probabilities $p_{mk}$ for classes $k \\in \\{1, \\dots, K\\}$:
- **Entropy (Information Theory):** $H(m) = -\\sum_{k=1}^K p_{mk} \\log_2 p_{mk}$
- **Gini Impurity (CART):** $I_G(m) = 1 - \\sum_{k=1}^K p_{mk}^2 = \\sum_{k \\ne j} p_{mk} p_{mj}$
- **Information Gain:** $\\Delta H = H(\\text{Parent}) - \\sum_{j \\in \\{\\text{Left}, \\text{Right}\\}} \\frac{N_j}{N} H(j)$

#### 2. Splitting Algorithm (CART - Classification & Regression Trees)
- For every continuous feature $X_j$, sort unique values and evaluate midpoint thresholds $t$.
- Choose feature $j^*$ and threshold $t^*$ that maximizes Information Gain (minimizes weighted child impurity).
- In Regression Trees, split to minimize Residual Sum of Squares (Variance reduction).

#### 3. Tree Pruning & Regularization
- Stopping criteria: \`max_depth\`, \`min_samples_split\`, \`min_samples_leaf\`.
- **Cost-Complexity Pruning (Weakest Link):** Minimizes cost $R_\\alpha(T) = R(T) + \\alpha |T|$ where $|T|$ is number of terminal leaf nodes.`,
    quickRevisionNotes: [
      'Gini impurity of pure node ($p=1$) is $0$; for balanced binary split ($p=0.5$), Gini is $0.5$ and Entropy is $1.0$.',
      'Decision trees are scale-invariant; feature normalization is NOT required.',
      'Unconstrained decision trees have high variance and zero bias (memorize training data).'
    ],
    formulaSheets: [
      {
        name: 'Gini Impurity & Information Gain',
        formula: 'I_G(m) = 1 - \\sum_{k=1}^K p_k^2, \\quad \\text{IG}(S, A) = H(S) - \\sum_{v} \\frac{|S_v|}{|S|} H(S_v)',
        description: 'Node impurity and feature split selection criteria.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Gini Impurity Calculation from Counts',
        code: `def gini_impurity(class_counts):
    total = sum(class_counts)
    if total == 0:
        return 0.0
    probabilities = [c / total for c in class_counts]
    return 1.0 - sum(p**2 for p in probabilities)`
      }
    ],
    examTips: [
      'Information Gain is biased towards features with many distinct values (e.g. ID numbers). Use Gain Ratio = $\\frac{\\text{Information Gain}}{\\text{Split Information}}$ (C4.5) to fix this.',
      'Decision trees create axis-parallel orthogonal decision boundaries; cannot capture diagonal lines efficiently.'
    ],
    handwrittenMnemonic: 'Pure node = 0 Impurity; Gini = $1 - \\sum p_k^2$!'
  },
  {
    id: 'note-mlf-w11',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 11,
    title: 'Ensemble Learning: Bagging, Random Forests, AdaBoost & Gradient Boosting',
    detailedNotes: `### Week 11: Ensemble Learning Paradigms

#### 1. Bagging (Bootstrap Aggregating) & Random Forests
- **Bootstrap Sampling:** Draw $N$ samples with replacement from dataset of size $N$ (each tree sees $\\approx 63.2\\%$ of unique samples; remaining $36.8\\%$ are **Out-Of-Bag (OOB)**).
- **Variance Reduction:** Averaging $B$ independent estimators with variance $\\sigma^2$ reduces variance to $\\frac{\\sigma^2}{B}$.
- **Random Forest Feature Subsampling:** At each node split, select a random subset of $m = \\sqrt{d}$ features for classification ($m = d/3$ for regression) to de-correlate trees!

#### 2. Boosting (Sequential Error Correction)
- **AdaBoost:** Sequentially increases weights of misclassified instances:
$$\\alpha_m = \\frac{1}{2} \\ln\\left( \\frac{1 - \\text{err}_m}{\\text{err}_m} \\right), \\quad w_i^{(m+1)} = w_i^{(m)} \\exp\\left( \\alpha_m \\mathbb{I}(y_i \\ne h_m(\\mathbf{x}_i)) \\right)$$
- **Gradient Boosting (GBDT):** Fits consecutive decision tree regressors directly to the **pseudo-residuals (negative gradients of loss function)**:
$$r_{im} = -\\left[ \\frac{\\partial L(y_i, f(\\mathbf{x}_i))}{\\partial f(\\mathbf{x}_i)} \\right]_{f = f_{m-1}}$$`,
    quickRevisionNotes: [
      'Bagging reduces Variance (builds deep independent trees in parallel).',
      'Boosting reduces Bias (builds shallow weak learners sequentially on residual errors).',
      'Random Forests de-correlate trees by randomly sampling $m = \\sqrt{d}$ features at each split.'
    ],
    formulaSheets: [
      {
        name: 'AdaBoost Classifier Weight & Residual Step',
        formula: '\\alpha_m = \\frac{1}{2} \\ln\\left( \\frac{1 - \\epsilon_m}{\\epsilon_m} \\right), \\quad r_{im} = -\\frac{\\partial L(y_i, \\hat{y}_i)}{\\partial \\hat{y}_i}',
        description: 'Weight update for weak learners and pseudo-residual formulation.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Random Forest vs Gradient Boosting in Scikit-Learn',
        code: `from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

# Bagging paradigm (parallel)
rf = RandomForestClassifier(n_estimators=100, max_features='sqrt', oob_score=True)
rf.fit(X_train, y_train)
print("OOB Accuracy Score:", rf.oob_score_)

# Boosting paradigm (sequential)
gbdt = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, max_depth=3)
gbdt.fit(X_train, y_train)`
      }
    ],
    examTips: [
      'Random Forests CANNOT overfit merely by increasing the number of trees $B$; adding more trees simply stabilizes variance reduction.',
      'In Gradient Boosting, increasing number of trees CAN cause overfitting if learning rate is too large.'
    ],
    handwrittenMnemonic: 'Bagging = Parallel variance reduction; Boosting = Sequential bias correction!'
  },
  {
    id: 'note-mlf-w12',
    courseId: 'course-mlf',
    courseTitle: 'Machine Learning Foundations',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 12,
    title: 'Unsupervised Learning: K-Means, Hierarchical Clustering & GMMs with EM',
    detailedNotes: `### Week 12: Clustering & Expectation-Maximization (EM)

#### 1. K-Means Clustering & Lloyd\'s Algorithm
Partitions $N$ points into $K$ disjoint clusters $S_1, \\dots, S_K$ minimizing within-cluster inertia:
$$J = \\sum_{k=1}^K \\sum_{\\mathbf{x}_i \\in S_k} \\|\\mathbf{x}_i - \\boldsymbol{\\mu}_k\\|_2^2$$
- **Lloyd\'s Iterative Two-Step:**
  1. **Assignment Step:** Assign each $\\mathbf{x}_i$ to nearest centroid: $c^{(i)} = \\arg\\min_k \\|\\mathbf{x}_i - \\boldsymbol{\\mu}_k\\|^2$.
  2. **Update Step:** Recalculate centroids: $\\boldsymbol{\\mu}_k = \\frac{1}{|S_k|} \\sum_{\\mathbf{x}_i \\in S_k} \\mathbf{x}_i$.
- **K-Means++ Initialization:** Picks first centroid randomly, subsequent centroids with probability proportional to squared distance $D(\\mathbf{x})^2$ from nearest existing center (guarantees $O(\\log K)$ approximation).

#### 2. Gaussian Mixture Models (GMM) & Expectation-Maximization (EM)
Soft-probabilistic clustering assuming data is generated from $K$ Gaussian distributions $\\mathcal{N}(\\boldsymbol{\\mu}_k, \\Sigma_k)$:
$$p(\\mathbf{x}) = \\sum_{k=1}^K \\pi_k \\mathcal{N}(\\mathbf{x} \\mid \\boldsymbol{\\mu}_k, \\Sigma_k)$$
- **E-Step (Responsibility):** $\\gamma_{ik} = P(z_i = k \\mid \\mathbf{x}_i) = \\frac{\\pi_k \\mathcal{N}(\\mathbf{x}_i \\mid \\boldsymbol{\\mu}_k, \\Sigma_k)}{\\sum_{j=1}^K \\pi_j \\mathcal{N}(\\mathbf{x}_i \\mid \\boldsymbol{\\mu}_j, \\Sigma_j)}$
- **M-Step:** Update mixture parameters $\\boldsymbol{\\mu}_k, \\Sigma_k, \\pi_k$ using weighted responsibilities $\\gamma_{ik}$.`,
    quickRevisionNotes: [
      'K-Means minimizes within-cluster sum of squared errors; sensitive to outliers and assumes spherical clusters.',
      'K-Means++ initialization chooses new centers proportional to $D(\\mathbf{x})^2$, preventing poor local minima.',
      'GMM EM performs soft cluster assignment with full covariance matrices $\\Sigma_k$.'
    ],
    formulaSheets: [
      {
        name: 'K-Means Objective & GMM Responsibility',
        formula: 'J = \\sum_{k=1}^K \\sum_{\\mathbf{x} \\in S_k} \\|\\mathbf{x} - \\boldsymbol{\\mu}_k\\|^2, \\quad \\gamma_{ik} = \\frac{\\pi_k \\mathcal{N}(\\mathbf{x}_i \\mid \\boldsymbol{\\mu}_k, \\Sigma_k)}{\\sum_j \\pi_j \\mathcal{N}(\\mathbf{x}_i \\mid \\boldsymbol{\\mu}_j, \\Sigma_j)}',
        description: 'Inertia minimization and posterior membership probabilities.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'K-Means Clustering with Silhouette Score Evaluation',
        code: `from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

kmeans = KMeans(n_clusters=3, init='k-means++', n_init=10, random_state=42)
cluster_labels = kmeans.fit_predict(X)
score = silhouette_score(X, cluster_labels)
print(f"Cluster Inertia: {kmeans.inertia_:.2f}, Silhouette Score: {score:.3f}")`
      }
    ],
    examTips: [
      'K-Means is guaranteed to converge because both assignment and update steps monotonically decrease objective $J$, but it can get stuck in a local minimum.',
      'Silhouette score ranges from $-1$ to $+1$; values near $+1$ indicate well-separated, dense clusters.'
    ],
    handwrittenMnemonic: 'E-Step = Compute Responsibilities; M-Step = Re-estimate Gaussian Parameters!'
  }
];

import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_ENGLISH_2_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-eng2-w1',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Critical Thinking, Rhetorical Analysis & Logical Fallacies',
    detailedNotes: `### Week 1: Rhetorical Modes & Logical Fallacies

#### 1. Aristotle\'s Rhetorical Triangle
- **Ethos (Credibility & Character):** Establishing authorial authority, expertise, domain knowledge, and ethical integrity.
- **Logos (Logical Reasoning & Evidence):** Using deductive/inductive logic, empirical data, formal proofs, and consistent premises.
- **Pathos (Emotional & Values-based Resonance):** Appealing to audience values, empathy, and urgency (used judiciously in scientific discourse).

#### 2. Canonical Logical Fallacies to Avoid in Research
- **Ad Hominem:** Attacking the individual\'s personal attributes rather than refuting their argument.
- **Straw Man:** Misrepresenting or exaggerating an opponent\'s stance to make it easier to attack.
- **False Dilemma (Black-and-White Fallacy):** Presenting two extremes as the only options when a spectrum exists.
- **Post Hoc Ergo Propter Hoc:** Assuming causality merely because event $B$ followed event $A$.
- **Bandwagon Fallacy (Argumentum ad Populum):** Asserting that a claim is valid simply because it is widely believed.`,
    quickRevisionNotes: [
      'Aristotle\'s triad: Ethos (Authority), Logos (Logic/Data), Pathos (Audience values).',
      'Ad Hominem attacks the person; Straw Man attacks a distorted caricature of the argument.',
      'Post hoc fallacy confuses correlation/temporal sequence with true causation.',
      'Academic papers rely overwhelmingly on Logos substantiated by Ethos.'
    ],
    formulaSheets: [
      {
        name: 'The Rhetorical Triangle Composition',
        formula: '\\text{Persuasive Rigor} = \\text{Logos (Evidence)} + \\text{Ethos (Credibility)} + \\text{Pathos (Audience Context)}',
        description: 'Classical Aristotelian rhetorical framework.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w1-p1',
        questionText: 'Identify the fallacy: "Our company installed new software on Tuesday, and sales increased by 20% on Wednesday; therefore, the software caused the sales surge."',
        options: ['Post Hoc Ergo Propter Hoc (False Cause)', 'Ad Hominem', 'Straw Man', 'Circular Reasoning'],
        correctOptionIndex: 0,
        solution: 'Assuming that because sales increased after the installation it was caused by the installation without controlling for other variables is the classic Post Hoc fallacy.',
        hints: ['Temporal sequence does not prove causality.']
      },
      {
        id: 'eng2-w1-p2',
        questionText: 'Which rhetorical appeal relies on statistical datasets, empirical proofs, and sound deductive logic?',
        options: ['Logos', 'Ethos', 'Pathos', 'Kairos'],
        correctOptionIndex: 0,
        solution: 'Logos appeals to logic, reasoned argument, and empirical evidence.',
        hints: ['Logic-based appeal.']
      },
      {
        id: 'eng2-w1-p3',
        questionText: 'When an author establishes their credibility by citing their peer-reviewed publications and institutional affiliations, they are utilizing:',
        options: ['Ethos', 'Pathos', 'Logos', 'Syllogism'],
        correctOptionIndex: 0,
        solution: 'Ethos builds credibility, qualifications, and trustworthiness.',
        hints: ['Authority and credibility appeal.']
      }
    ],
    keyTakeaways: [
      'Spotting logical fallacies protects researchers from flawed conclusions in literature reviews.',
      'Logos is the primary pillar of technical and scientific publications.'
    ],
    markdownContent: `### Week 1: Rhetorical Triangle & Fallacies\nEthos, Pathos, Logos, and identifying deceptive informal logical fallacies.`,
    examTips: ['Watch out for correlation-causation fallacies (Post Hoc) in data interpretation questions!']
  },
  {
    id: 'note-eng2-w2',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'The Toulmin Argumentation Model: Claims, Warrants & Counterarguments',
    detailedNotes: `### Week 2: Formal Argumentation & The Toulmin Model

#### 1. The Six Pillars of the Toulmin Argumentation Framework
1. **Claim:** The central thesis, assertion, or conclusion being advocated.
2. **Data / Grounds:** The empirical evidence, raw facts, and experimental observations supporting the claim.
3. **Warrant:** The underlying theoretical principle, rule, or logical bridge connecting data to the claim.
4. **Backing:** Additional credentials, references, or theory validating the warrant itself.
5. **Qualifier:** Language indicating the scope and certainty of the claim (*e.g., in most cases, under high temperatures*).
6. **Rebuttal / Counterargument:** Acknowledging potential objections and conditions under which the claim would not hold.

#### 2. Structuring Concession and Counter-argument
- Standard formula: *While proponents of approach X argue that [Opposing View], empirical benchmarks demonstrate that [Our Claim] because [Warranted Evidence].*`,
    quickRevisionNotes: [
      'Toulmin 6 components: Claim, Data, Warrant, Backing, Qualifier, Rebuttal.',
      'Warrant is the implicit or explicit bridge connecting Data to Claim.',
      'Qualifiers define the exact boundary conditions of an argument.',
      'Proactively addressing counterarguments strengthens research credibility.'
    ],
    formulaSheets: [
      {
        name: 'Toulmin Model Functional Architecture',
        formula: '\\text{Data} \\xrightarrow{\\text{Warrant (+ Backing)}} \\text{Claim} \\quad [\\text{Qualified by } Q, \\; \\text{Rebutted by } R]',
        description: 'Structural diagram of Toulmin argument components.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w2-p1',
        questionText: 'In the Toulmin model, what is the role of the "Warrant"?',
        options: ['The underlying logical reasoning or principle that connects the Data to the Claim', 'The emotional appeal', 'The bibliography citation', 'The final concluding sentence'],
        correctOptionIndex: 0,
        solution: 'The warrant is the logical justification explaining why the presented data supports the proposed claim.',
        hints: ['The bridge connecting evidence to conclusion.']
      },
      {
        id: 'eng2-w2-p2',
        questionText: 'In the statement "Our model achieves 95% accuracy under low-noise ambient conditions", the phrase "under low-noise ambient conditions" serves as a:',
        options: ['Qualifier', 'Warrant', 'Data', 'Backing'],
        correctOptionIndex: 0,
        solution: 'A qualifier specifies the limitations, scope, and operational conditions under which the claim remains valid.',
        hints: ['Identifies operational boundary conditions.']
      },
      {
        id: 'eng2-w2-p3',
        questionText: 'Why is incorporating a rebuttal/counterargument advantageous in academic research?',
        options: ['It demonstrates thoroughness, eliminates bias, and preempts peer-reviewer critiques', 'It makes the paper double in length', 'It proves the author does not believe their own claim', 'It is required by copyright law'],
        correctOptionIndex: 0,
        solution: 'Acknowledging counterarguments proves intellectual integrity and preempts anticipated reviewer criticisms.',
        hints: ['Demonstrates comprehensive scholarship.']
      }
    ],
    keyTakeaways: [
      'The Toulmin framework prevents unfounded inductive leaps in thesis defenses.',
      'Explicit warrants clarify technical assumptions in algorithmic research.'
    ],
    markdownContent: `### Week 2: Toulmin Argumentation Model\nClaims, grounds, warrants, backings, qualifiers, and rebuttal structures.`,
    examTips: ['Identify the warrant by asking: "Why does this specific data logically lead to that conclusion?"!']
  },
  {
    id: 'note-eng2-w3',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Research Methodology & Source Evaluation: The CRAAP Test',
    detailedNotes: `### Week 3: Source Verification & The CRAAP Framework

#### 1. Primary vs Secondary vs Tertiary Sources
- **Primary Sources:** Direct, firsthand empirical evidence, raw datasets, experimental trial logs, original interview transcripts, or patent filings.
- **Secondary Sources:** Analyses, reviews, syntheses, or interpretations of primary data (e.g., peer-reviewed review articles, meta-analyses).
- **Tertiary Sources:** Indexing compilations and general reference overviews (e.g., encyclopedias, textbooks).

#### 2. The CRAAP Source Evaluation Framework
1. **C - Currency:** The timeliness of the information. When was it published? Have there been major paradigm shifts since?
2. **R - Relevance:** The importance of the information for your specific research question and academic depth.
3. **A - Authority:** The source of the information. Who is the author, their institutional affiliation, and their h-index / peer reputation?
4. **A - Accuracy:** The reliability, truthfulness, and experimental reproducibility of the content. Is it peer-reviewed? Are methods transparent?
5. **P - Purpose:** The reason the information exists. Is it objective academic research, or commercial marketing / biased advocacy?`,
    quickRevisionNotes: [
      'Primary = Firsthand raw data; Secondary = Analysis/review of primary; Tertiary = Encyclopedias.',
      'CRAAP Test: Currency, Relevance, Authority, Accuracy, Purpose.',
      'Peer-reviewed journal papers carry the highest academic authority.',
      'Always scrutinize institutional affiliations for commercial conflicts of interest.'
    ],
    formulaSheets: [
      {
        name: 'The CRAAP Evaluation Metrics',
        formula: '\\text{Source Reliability} = \\text{Currency} \\times \\text{Relevance} \\times \\text{Authority} \\times \\text{Accuracy} \\times \\text{Purpose}',
        description: 'Multifactor verification criteria for academic sources.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w3-p1',
        questionText: 'A raw CSV dataset containing direct sensor readings collected during a laboratory experiment is an example of what type of source?',
        options: ['Primary Source', 'Secondary Source', 'Tertiary Source', 'Quaternary Source'],
        correctOptionIndex: 0,
        solution: 'Direct, uninterpreted empirical data collected firsthand is a Primary Source.',
        hints: ['Firsthand original experimental data.']
      },
      {
        id: 'eng2-w3-p2',
        questionText: 'In the CRAAP source evaluation model, what does the letter "P" represent?',
        options: ['Purpose', 'Protocol', 'Pagination', 'Platform'],
        correctOptionIndex: 0,
        solution: 'In CRAAP (Currency, Relevance, Authority, Accuracy, Purpose), "P" stands for Purpose.',
        hints: ['Investigating the underlying motivation of the publication.']
      },
      {
        id: 'eng2-w3-p3',
        questionText: 'Why should a blog post on a commercial vendor website be critically scrutinized before citing as a scientific benchmark?',
        options: ['Commercial purpose creates an inherent conflict of interest and lacks blind peer review', 'Blog posts are forbidden on the internet', 'Blogs never use English', 'Vendor posts cannot have authors'],
        correctOptionIndex: 0,
        solution: 'Commercial entities publish content for marketing and sales purposes, lacking rigorous blind peer review.',
        hints: ['Consider author motivation and commercial bias.']
      }
    ],
    keyTakeaways: [
      'Applying the CRAAP test filters out non-rigorous predatory and commercial claims.',
      'Primary literature forms the empirical backbone of reliable engineering research.'
    ],
    markdownContent: `### Week 3: Source Evaluation & CRAAP Test\nPrimary vs secondary data, authority scoring, and commercial bias detection.`,
    examTips: ['Check the publication date (Currency) especially in fast-evolving fields like AI and Data Science!']
  },
  {
    id: 'note-eng2-w4',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'The Academic Literature Review: Synthesizing Trends & Identifying Research Gaps',
    detailedNotes: `### Week 4: Conducting Literature Reviews & Identifying Gaps

#### 1. What is a Literature Review?
A critical synthesis and thematic evaluation of existing scholarly publications on a specific topic. It is NOT an annotated bibliography or a simple sequential summary of paper by paper.

#### 2. Organizational Structures for Literature Reviews
- **Chronological:** Tracing historical evolution and paradigm shifts over time.
- **Thematic:** Grouping research by underlying themes, methodologies, or competing theoretical frameworks (the standard in modern computer science).
- **Methodological:** Comparing studies based on experimental design (e.g. Qualitative vs Quantitative vs Simulation).

#### 3. Identifying the "Research Gap"
The literature review must culminate in identifying an unresolved problem, contradiction, or unexplored domain niche:
- **Theoretical Gap:** Concepts not addressed by existing models.
- **Methodological Gap:** Previous studies used limited or flawed evaluation frameworks.
- **Empirical Gap:** Lack of validation on modern, large-scale real-world datasets.`,
    quickRevisionNotes: [
      'A literature review synthesizes themes; it is NOT an annotated bibliography.',
      'Thematic organization groups papers by core methodology or shared challenges.',
      'Research gaps represent the missing knowledge your paper aims to resolve.',
      'Use synthesis matrix tables to map authors against comparative dimensions.'
    ],
    formulaSheets: [
      {
        name: 'Research Gap Derivation',
        formula: '\\text{State of the Art (SOTA)} \\cap \\text{Unresolved Limitations} \\implies \\text{Research Gap} \\implies \\text{Novel Contribution}',
        description: 'Logical derivation pipeline of academic contribution.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w4-p1',
        questionText: 'What is the primary difference between an Annotated Bibliography and a Literature Review?',
        options: ['An annotated bibliography lists isolated summaries paper-by-paper, whereas a literature review synthesizes thematically connected trends and gaps', 'An annotated bibliography is peer reviewed while a literature review is not', 'A literature review has no references', 'There is no difference'],
        correctOptionIndex: 0,
        solution: 'Literature reviews critically weave multiple studies into a synthesized thematic narrative rather than listing disjointed paper summaries.',
        hints: ['Synthesis vs isolated listing.']
      },
      {
        id: 'eng2-w4-p2',
        questionText: 'What is the ultimate objective of locating a "Research Gap" in an academic literature survey?',
        options: ['To justify the necessity and novelty of your own proposed research project', 'To prove that previous authors were incompetent', 'To avoid writing a methodology section', 'To reduce the word count'],
        correctOptionIndex: 0,
        solution: 'Establishing a research gap demonstrates why your new investigation is needed to expand scientific knowledge.',
        hints: ['Justifies the value of your work.']
      },
      {
        id: 'eng2-w4-p3',
        questionText: 'Which organizational approach to literature reviews groups studies by algorithms, model types, or problem formulations?',
        options: ['Thematic Organization', 'Alphabetical Organization', 'Random Organization', 'Author-Length Organization'],
        correctOptionIndex: 0,
        solution: 'Thematic organization categorizes the literature according to topics, methodologies, or core technical concepts.',
        hints: ['Grouping by themes and techniques.']
      }
    ],
    keyTakeaways: [
      'Effective literature reviews frame your research within the global academic conversation.',
      'Thematic synthesis matrix tables accelerate draft preparation.'
    ],
    markdownContent: `### Week 4: Academic Literature Reviews\nThematic synthesis, matrix tables, and identifying empirical research gaps.`,
    examTips: ['Never write a literature review as "Author A did this. Author B did that." Group by shared themes instead!']
  },
  {
    id: 'note-eng2-w5',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Executive Summaries, Abstracts & the IMRAD Architecture',
    detailedNotes: `### Week 5: Abstract Writing & The IMRAD Framework

#### 1. The IMRAD Scientific Paper Architecture
- **I - Introduction:** What problem was studied and why does it matter?
- **M - Methods:** How was the investigation conducted, and what was the experimental protocol?
- **R - Results:** What empirical findings, measurements, and benchmark outcomes were observed?
- **A - And**
- **D - Discussion:** What do the results mean, what are the limitations, and what are the future implications?

#### 2. The 5-Sentence Micro-Abstract Formula
1. **Context / Motivation:** 1 sentence establishing domain importance and current challenge.
2. **Problem Statement / Gap:** 1 sentence defining the exact limitation addressed.
3. **Proposed Method / Approach:** 1-2 sentences outlining the novel methodology.
4. **Key Results / Metrics:** 1 sentence with concrete quantitative benchmarks (*e.g., improves latency by 34%*).
5. **Broader Impact / Conclusion:** 1 sentence stating significance for future systems.`,
    quickRevisionNotes: [
      'IMRAD: Introduction, Methods, Results, and Discussion.',
      'An abstract must be completely self-contained with zero citations and zero acronyms without definitions.',
      'Always include concrete quantitative results in the abstract (e.g. percentages, speedups).',
      'The introduction forms an inverted pyramid (broad context $\\to$ specific research question).'
    ],
    formulaSheets: [
      {
        name: 'The 5-Step Abstract Blueprint',
        formula: '\\text{Abstract} = \\text{Motivation} (10\\%) + \\text{Problem} (15\\%) + \\text{Method} (35\\%) + \\text{Results} (30\\%) + \\text{Impact} (10\\%)',
        description: 'Proportional word distribution for high-impact scientific abstracts.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w5-p1',
        questionText: 'What does the acronym IMRAD stand for in scientific manuscript architecture?',
        options: ['Introduction, Methods, Results, and Discussion', 'Information, Modeling, Research, Analysis, Data', 'Input, Measurement, Recording, Application, Delivery', 'Index, Matrix, Review, Abstract, Diagrams'],
        correctOptionIndex: 0,
        solution: 'IMRAD is the standard acronym for Introduction, Methods, Results, and Discussion.',
        hints: ['Standard four-part research paper structure.']
      },
      {
        id: 'eng2-w5-p2',
        questionText: 'Which element should generally be AVOIDED in a self-contained scientific abstract?',
        options: ['Unexplained obscure acronyms and bibliographic citations', 'Quantitative accuracy metrics', 'The name of the proposed algorithm', 'The problem statement'],
        correctOptionIndex: 0,
        solution: 'Abstracts are indexed independently in databases and should not contain unresolved citation references or unexplained niche acronyms.',
        hints: ['Abstracts must be completely standalone.']
      },
      {
        id: 'eng2-w5-p3',
        questionText: 'Which section of an IMRAD paper analyzes experimental limitations and contrasts findings with prior literature?',
        options: ['Discussion', 'Methods', 'Introduction', 'Title Page'],
        correctOptionIndex: 0,
        solution: 'The Discussion section interprets the results, contextualizes them within broader literature, and addresses experimental limitations.',
        hints: ['Interpretation and limitations section.']
      }
    ],
    keyTakeaways: [
      'The abstract is the most widely read part of any research paper; make every word count.',
      'IMRAD provides an internationally standardized structural blueprint for scientific papers.'
    ],
    markdownContent: `### Week 5: Abstract & IMRAD Structure\nSelf-contained micro-abstracts, inverted pyramid intros, and Discussion framing.`,
    examTips: ['Ensure the abstract contains at least one quantitative metric (e.g., "achieved 94.2% accuracy")!']
  },
  {
    id: 'note-eng2-w6',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Technical Report Writing, Data Interpretation & Captioning Standards',
    detailedNotes: `### Week 6: Technical Reports & Visual Captioning Standards

#### 1. Anatomy of a Formal Technical Report
- **Front Matter:** Title page, Executive Summary, Table of Contents, List of Figures/Tables.
- **Main Body:** Introduction, System Architecture, Experimental Procedure, Data Analysis, Recommendations.
- **End Matter:** References (APA/IEEE), Appendices (raw logs, code snippets, mathematical derivations).

#### 2. Principles of Scientific Data Interpretation
- Never assume a chart speaks for itself. Every figure/table must be:
  1. **Referenced in text** before it appears (*e.g., As illustrated in Figure 3...*).
  2. **Interpreted explicitly** (*The inflection point at Epoch 25 indicates the onset of regularization saturation.*).

#### 3. Professional Captioning Rules
- **Figures (Charts, Diagrams, Plots):** Caption placed **BELOW** the figure (*Figure 1: Comparison of convergence rates across learning schedules.*).
- **Tables:** Caption / Title placed **ABOVE** the table (*Table 2: Hyperparameter configurations and ablation benchmarks.*).`,
    quickRevisionNotes: [
      'Figure captions go BELOW the figure; Table titles go ABOVE the table.',
      'Every figure and table MUST be explicitly cross-referenced in the text body.',
      'Reports use formal numbered headings (1.0, 1.1, 1.1.1).',
      'Appendices house supplemental code, proofs, and raw telemetry data.'
    ],
    formulaSheets: [
      {
        name: 'Caption Placement Convention',
        formula: '\\text{Caption}_{\\text{Table}} \\to \\text{TOP}, \\quad \\text{Caption}_{\\text{Figure}} \\to \\text{BOTTOM}',
        description: 'Standard international academic publishing typography rule.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w6-p1',
        questionText: 'According to standard academic and technical publishing conventions, where should table captions be placed?',
        options: ['Above the table', 'Below the table', 'Inside the bottom-right cell', 'In the document footer only'],
        correctOptionIndex: 0,
        solution: 'Table titles/captions are placed Above the table, while figure captions are placed Below.',
        hints: ['Tables on top, figures on bottom.']
      },
      {
        id: 'eng2-w6-p2',
        questionText: 'What must always precede or accompany a chart in the text of a technical report?',
        options: ['An explicit textual in-text reference and analytical commentary explaining its key trends', 'A screenshot of the Python script', 'A copyright disclaimer', 'A full-page blank break'],
        correctOptionIndex: 0,
        solution: 'Authors must explicitly reference the figure in the body text and explain the significance of the data presented.',
        hints: ['In-text cross reference and analysis.']
      },
      {
        id: 'eng2-w6-p3',
        questionText: 'Where do extensive raw log files, long mathematical proofs, and complete code repositories belong in a technical report?',
        options: ['Appendices', 'Executive Summary', 'Introduction', 'Table of Contents'],
        correctOptionIndex: 0,
        solution: 'Appendices contain supplementary detailed material that would disrupt the narrative flow of the main report.',
        hints: ['End matter supplementary section.']
      }
    ],
    keyTakeaways: [
      'Self-describing captions allow readers to understand figures without hunting through body text.',
      'Clear technical reporting bridges engineering teams with executive decision-makers.'
    ],
    markdownContent: `### Week 6: Technical Reports & Visuals\nReport anatomy, data commentary, and figure/table captioning conventions.`,
    examTips: ['Remember: Figure captions go BELOW, Table captions go ABOVE!']
  },
  {
    id: 'note-eng2-w7',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Advanced Syntax Mechanics: Parallelism, Dangling Modifiers & Punctuation',
    detailedNotes: `### Week 7: Advanced Syntactic Precision & Punctuation Mastery

#### 1. Faulty Parallelism
Items in a series or comparison must share the identical grammatical structure:
- **Incorrect:** *The engineer enjoys coding, to design algorithms, and data analysis.*
- **Correct:** *The engineer enjoys coding, designing algorithms, and analyzing data.* (All gerunds: *V-ing*).

#### 2. Dangling and Misplaced Modifiers
A modifier must clearly and directly modify the noun intended by the author:
- **Dangling (Incorrect):** *Having completed the simulation, the results were analyzed by the team.* (The results did not complete the simulation!).
- **Corrected:** *Having completed the simulation, the team analyzed the results.*

#### 3. Advanced Punctuation Mastery
- **Semicolon (;):** Joins two closely related independent clauses without a conjunction (*The server load peaked; the load balancer initiated autoscaling.*).
- **Colon (:):** Introduces an explanation, amplification, or formal list following a complete independent clause.
- **Em-Dash (—):** Creates dramatic emphasis or parenthetical interruption.`,
    quickRevisionNotes: [
      'Parallelism: Coordinate items in lists must share identical grammatical form.',
      'Dangling modifiers happen when the implied subject of an opening participial phrase doesn\'t match the grammatical subject.',
      'Semicolons connect two full independent clauses; colons require a complete clause before them.',
      'The Oxford comma prevents ambiguity in lists of three or more items.'
    ],
    formulaSheets: [
      {
        name: 'Parallel Series Template',
        formula: '\\text{List} = [\\text{Pattern}_X, \\; \\text{Pattern}_X, \\; \\text{and} \\; \\text{Pattern}_X]',
        description: 'Grammatical symmetry condition for coordinates and series.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w7-p1',
        questionText: 'Identify the sentence that has correct grammatical parallelism:',
        options: ['The data scientist is responsible for collecting data, cleaning features, and training models.', 'The data scientist is responsible for collecting data, to clean features, and model training.', 'The data scientist likes to code, analyzing datasets, and write reports.', 'The algorithm is fast, reliable, and operates with accuracy.'],
        correctOptionIndex: 0,
        solution: 'Option 1 maintains identical gerund phrase structures ("collecting...", "cleaning...", "training...").',
        hints: ['Look for consistent "-ing" verb forms across the list.']
      },
      {
        id: 'eng2-w7-p2',
        questionText: 'Fix the dangling modifier: "Running the benchmark test, the CPU overheated."',
        options: ['While the technician was running the benchmark test, the CPU overheated.', 'Running the benchmark test, overheating occurred in the CPU.', 'The CPU, running the benchmark test, was overheated.', 'Having run the test, overheating was seen.'],
        correctOptionIndex: 0,
        solution: 'The CPU cannot run tests on its own. Option 1 provides the true human agent ("the technician") as the subject of the action.',
        hints: ['Who was actually running the benchmark test?']
      },
      {
        id: 'eng2-w7-p3',
        questionText: 'Which punctuation mark is correct to join two independent clauses without a coordinating conjunction?',
        options: ['Semicolon (;)', 'Comma (,)', 'Hyphen (-)', 'Slash (/)'],
        correctOptionIndex: 0,
        solution: 'A semicolon correctly joins two related independent clauses; using a comma alone causes a comma splice error.',
        hints: ['Avoid comma splices with this punctuation mark.']
      }
    ],
    keyTakeaways: [
      'Eliminating dangling modifiers ensures unambiguous scientific reporting.',
      'Parallel phrasing improves reading rhythm and information processing speed.'
    ],
    markdownContent: `### Week 7: Advanced Grammar & Punctuation\nParallelism rules, dangling modifier fixes, and semicolon/colon mechanics.`,
    examTips: ['Watch out for introductory participial phrases (-ing): make sure the subject immediately following the comma is the one doing the action!']
  },
  {
    id: 'note-eng2-w8',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Persuasive Academic Discourse: Stance, Voice & Authorial Identity',
    detailedNotes: `### Week 8: Authorial Voice & Academic Stance

#### 1. Constructing Academic Stance
An author\'s stance expresses their degree of certainty, skepticism, or endorsement toward their own claims and the cited claims of others.
- **Reporting Verbs with Evaluative Flavor:**
  - **Neutral:** *states, observes, describes, notes*.
  - **Tentative / Weak:** *suggests, proposes, hypothesizes*.
  - **Strong / Endorsing:** *demonstrates, establishes, proves, confirms*.
  - **Critical / Skeptical:** *claims, alleges, contends, assumes*.

#### 2. First-Person Pronouns in Modern Academic Writing
- **Traditional View:** Total ban on *I* and *we* to maintain simulated third-person detachment.
- **Modern Consensus (IEEE, ACM, Nature):** Judicious use of *we* is encouraged when describing active methodological choices (*We trained a 12-layer model...*), while keeping conclusions and data interpretation objective.`,
    quickRevisionNotes: [
      'Reporting verbs carry evaluative stance (*proves* vs *claims* vs *suggests*).',
      'Modern science allows *we* for authorial methodological actions.',
      'Distinguish between acknowledging prior work and critically evaluating it.',
      'Avoid emotionally charged subjective adjectives in scientific discourse.'
    ],
    formulaSheets: [
      {
        name: 'Stance Spectrum for Reporting Verbs',
        formula: '\\text{Skeptical (claims)} \\longleftrightarrow \\text{Neutral (notes)} \\longleftrightarrow \\text{Endorsing (demonstrates)}',
        description: 'Evaluative gradient embedded in academic citation verbs.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w8-p1',
        questionText: 'Which reporting verb indicates skepticism regarding the cited author\'s claim?',
        options: ['alleges / claims', 'demonstrates', 'confirms', 'proves'],
        correctOptionIndex: 0,
        solution: '"Claims" or "alleges" distances the author from the assertion, signaling skepticism or lack of verified consensus.',
        hints: ['Distancing / skepticism verb.']
      },
      {
        id: 'eng2-w8-p2',
        questionText: 'What is the contemporary consensus regarding the use of "we" in scientific publications (e.g. IEEE / ACM)?',
        options: ['Acceptable when referring to the active methodological actions taken by the research team', 'Strictly forbidden under penalty of automatic desk rejection', 'Mandatory in every single sentence', 'Allowed only in acknowledgments'],
        correctOptionIndex: 0,
        solution: 'Modern academic style guides encourage first-person plurals ("We deployed...", "We evaluated...") when detailing methodological procedures.',
        hints: ['Modern guidelines allow "we" for methodological actions.']
      },
      {
        id: 'eng2-w8-p3',
        questionText: 'Which verb expresses the strongest authorial endorsement of a finding?',
        options: ['demonstrates', 'hypothesizes', 'intimates', 'speculates'],
        correctOptionIndex: 0,
        solution: '"Demonstrates" conveys strong empirical verification and authorial confidence.',
        hints: ['Shows strong proof and certainty.']
      }
    ],
    keyTakeaways: [
      'Reporting verbs provide nuanced commentary on prior literature without requiring lengthy explanation.',
      'Authorial voice establishes the credibility and authority of the research team.'
    ],
    markdownContent: `### Week 8: Stance & Authorial Voice\nEvaluative reporting verbs, first-person guidelines, and establishing scholarly authority.`,
    examTips: ['Choose reporting verbs carefully: "Smith claims" implies doubt, while "Smith establishes" implies acceptance!']
  },
  {
    id: 'note-eng2-w9',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Research & Project Proposals: Problem Statements, Feasibility & Milestones',
    detailedNotes: `### Week 9: Research Proposal & Grant Architecture

#### 1. Core Modules of an Engineering Proposal
1. **Executive Summary / Abstract:** High-level overview of objectives, novelty, deliverables, and total budget.
2. **Problem Statement & Justification:** What critical bottleneck or societal/technical challenge requires solving?
3. **Objectives & Scope Boundaries:** Explicit enumeration of primary goals and non-goals.
4. **Methodology & Work Breakdown Structure (WBS):** Decomposing the project into discrete work packages.
5. **Timeline & Milestones (Gantt Chart):** Time-indexed deliverables and review gates.
6. **Risk Mitigation & Feasibility Analysis:** Identifying technical failure modes and fallback plans.
7. **Budget Justification:** Itemized computation of personnel, hardware, cloud computing credits, and overheads.`,
    quickRevisionNotes: [
      'Proposals must clearly define both Goals and Non-Goals (Scope Boundaries).',
      'Work Breakdown Structure (WBS) decomposes the project into trackable work packages.',
      'Gantt charts visually map milestone timelines and task dependencies.',
      'Every budget item must have an explicit technical justification.'
    ],
    formulaSheets: [
      {
        name: 'Proposal Feasibility Equation',
        formula: '\\text{Feasibility} = \\frac{\\text{Technical Capability} \\times \\text{Allocated Resources}}{\\text{Project Scope} \\times \\text{Risk Factors}}',
        description: 'Conceptual viability assessment for technical engineering proposals.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w9-p1',
        questionText: 'What is the purpose of explicitly specifying "Non-Goals" in a technical project proposal?',
        options: ['To prevent scope creep and establish realistic operational boundaries', 'To make the project look smaller', 'To reduce the team size', 'To avoid testing the software'],
        correctOptionIndex: 0,
        solution: 'Defining non-goals prevents scope creep, clarifies project boundaries, and manages stakeholder expectations.',
        hints: ['Prevents uncontrollable expansion of scope.']
      },
      {
        id: 'eng2-w9-p2',
        questionText: 'Which visual project management artifact maps task timelines, milestones, and dependencies across a horizontal calendar axis?',
        options: ['Gantt Chart', 'Pie Chart', 'Venn Diagram', 'Scatter Plot'],
        correctOptionIndex: 0,
        solution: 'A Gantt chart is the standard visual timeline tool for project milestones and scheduling dependencies.',
        hints: ['Horizontal bar timeline diagram.']
      },
      {
        id: 'eng2-w9-p3',
        questionText: 'What does WBS stand for in engineering project planning?',
        options: ['Work Breakdown Structure', 'Web Binary Standard', 'Wide Bandwidth System', 'Weighted Benchmark Score'],
        correctOptionIndex: 0,
        solution: 'WBS stands for Work Breakdown Structure.',
        hints: ['Hierarchical project decomposition.']
      }
    ],
    keyTakeaways: [
      'Well-structured proposals secure funding and compute grants in competitive review boards.',
      'Risk mitigation matrices build stakeholder confidence in execution feasibility.'
    ],
    markdownContent: `### Week 9: Project Proposals & Grants\nProblem statements, Work Breakdown Structures (WBS), Gantt charts, and risk matrices.`,
    examTips: ['Include concrete quantifiable milestones with target dates in proposal timelines!']
  },
  {
    id: 'note-eng2-w10',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Peer Review Protocols, Constructive Critique & Academic Revision',
    detailedNotes: `### Week 10: The Peer Review Process & Author Response Letters

#### 1. Peer Review Models
- **Single-Blind:** Reviewers know author identities; authors do not know reviewers.
- **Double-Blind:** Neither authors nor reviewers know each other\'s identities (standard in computer science conferences like NeurIPS, ICML).
- **Open Peer Review:** Identities are public, and reviews are published alongside the article.

#### 2. Writing Constructive Peer Reviews
- Begin with a concise summary of the manuscript\'s core contribution.
- Highlight major conceptual strengths.
- Categorize critiques:
  - **Major Revisions:** Methodological flaws, missing baselines, unsubstantiated claims.
  - **Minor Revisions:** Typos, formatting, citation corrections, clarifying captions.

#### 3. Drafting Author Response / Rebuttal Letters
- **Golden Rule:** Polite, respectful, and point-by-point exhaustive.
- Formula: *[Quote Reviewer Comment] $\\to$ [Express Gratitude & Clarification] $\\to$ [Explain Exact Changes Made with Page/Line Numbers].*`,
    quickRevisionNotes: [
      'Double-blind review masks both author and reviewer identities to prevent bias.',
      'Separate peer feedback into Major Revisions (methodology/proofs) and Minor Revisions (text/typos).',
      'Rebuttal responses must address EVERY reviewer comment with exact page and line citations.',
      'Maintain professional courtesy regardless of reviewer tone.'
    ],
    formulaSheets: [
      {
        name: 'Rebuttal Point-by-Point Blueprint',
        formula: '\\text{Response} = \\text{Reviewer Comment Quote} + \\text{Direct Answer / Remedy} + \\text{Page/Line Pointer in Revised Draft}',
        description: 'Standard formula for academic journal rebuttal submissions.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w10-p1',
        questionText: 'In a Double-Blind peer review process, which of the following is true?',
        options: ['Neither the authors nor the reviewers know each other\'s identities', 'Only the reviewers are anonymous', 'The review is streamed live on video', 'All papers are automatically accepted without review'],
        correctOptionIndex: 0,
        solution: 'In double-blind peer review, both author identities and reviewer identities are masked to minimize evaluation bias.',
        hints: ['Both sides remain anonymous.']
      },
      {
        id: 'eng2-w10-p2',
        questionText: 'What is the correct protocol when responding to an aggressive or unfair peer-reviewer comment?',
        options: ['Respond objectively and respectfully, provide empirical data/clarifications, and state the exact revisions made in the manuscript', 'Insult the reviewer in the response letter', 'Withdraw from academic science forever', 'Refuse to answer that specific comment'],
        correctOptionIndex: 0,
        solution: 'Authors must maintain professional composure, address the critique objectively with data, and cite specific changes made in the revised draft.',
        hints: ['Professional composure and data-driven response.']
      },
      {
        id: 'eng2-w10-p3',
        questionText: 'Which critique category involves missing experimental baselines or flawed mathematical proofs?',
        options: ['Major Revision', 'Minor Revision', 'Typographical Error', 'Grammar Correction'],
        correctOptionIndex: 0,
        solution: 'Fundamental experimental or methodological deficiencies are classified under Major Revisions.',
        hints: ['Core scientific and methodological defects.']
      }
    ],
    keyTakeaways: [
      'Constructive peer review maintains the integrity of the scientific literature.',
      'A thorough, polite rebuttal letter can turn a rejection into an acceptance.'
    ],
    markdownContent: `### Week 10: Peer Review & Rebuttals\nSingle vs double blind reviews, major/minor categorization, and rebuttal letters.`,
    examTips: ['Always reference the specific page and line numbers of the changes in author rebuttal letters!']
  },
  {
    id: 'note-eng2-w11',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Cross-Cultural & Intercultural Communication in Global Engineering Teams',
    detailedNotes: `### Week 11: Intercultural Dynamics in Distributed Engineering

#### 1. High-Context vs Low-Context Communication (Edward T. Hall)
- **Low-Context Cultures (e.g., Germany, USA, Netherlands):** Communication is direct, explicit, literal, and precise. The message is entirely encoded in the spoken/written words.
- **High-Context Cultures (e.g., Japan, Arab World, India):** Communication relies heavily on implicit situational context, shared background, relationships, non-verbal cues, and hierarchy.

#### 2. Hofstede\'s Cultural Dimensions
- **Power Distance Index (PDI):** Degree to which inequality and hierarchy are accepted.
- **Individualism vs Collectivism:** Individual achievement vs group harmony.
- **Uncertainty Avoidance (UAI):** Tolerance for ambiguity, strict rules, and unstructured scenarios.

#### 3. Best Practices in Global Asynchronous Engineering
- Over-communicate context in documentation.
- Establish explicit agreements on time zones, asynchronous review SLAs, and clear definition-of-done criteria.`,
    quickRevisionNotes: [
      'Low-context communication is direct and explicit; high-context relies on unspoken situational context.',
      'Hofstede dimensions: Power Distance, Individualism, Uncertainty Avoidance.',
      'Distributed teams require clear written specifications to bridge cultural communication differences.',
      'Active listening and clarifying questions prevent intercultural misunderstandings.'
    ],
    formulaSheets: [
      {
        name: 'Context Spectrum',
        formula: '\\text{Low-Context (Explicit / Direct Words)} \\longleftrightarrow \\text{High-Context (Implicit / Relational Nuance)}',
        description: 'Edward T. Hall intercultural communication spectrum.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w11-p1',
        questionText: 'In Edward T. Hall\'s cultural framework, what characterizes a "Low-Context" communication culture?',
        options: ['Messages are explicit, direct, literal, and fully stated in words', 'Messages are primarily implied through non-verbal gestures and social status', 'Silence is preferred to speech', 'Communication occurs only through visual drawings'],
        correctOptionIndex: 0,
        solution: 'Low-context cultures value directness and explicit clarity, leaving little to implicit assumption.',
        hints: ['Direct and literal verbal encoding.']
      },
      {
        id: 'eng2-w11-p2',
        questionText: 'What cultural dimension in Hofstede\'s framework measures the degree to which members of a society feel uncomfortable with ambiguity and unstructured situations?',
        options: ['Uncertainty Avoidance Index (UAI)', 'Power Distance Index (PDI)', 'Individualism Index', 'Long-term Orientation'],
        correctOptionIndex: 0,
        solution: 'Uncertainty Avoidance measures how much a culture values strict rules, structured protocols, and predictability.',
        hints: ['Tolerance for ambiguity and unstructured events.']
      },
      {
        id: 'eng2-w11-p3',
        questionText: 'What is an effective strategy for managing asynchronous code reviews across multinational time zones?',
        options: ['Provide comprehensive written context, explicit reproduction steps, and clear acceptance criteria', 'Require all engineers to stay awake 24 hours', 'Never write comments on pull requests', 'Only communicate via emergency phone calls'],
        correctOptionIndex: 0,
        solution: 'Detailed, self-contained written context enables seamless asynchronous collaboration without real-time coordination.',
        hints: ['Rich self-describing documentation.']
      }
    ],
    keyTakeaways: [
      'Understanding cultural dimensions prevents misunderstandings in international engineering teams.',
      'Explicit written specifications reduce ambiguity in remote asynchronous workflows.'
    ],
    markdownContent: `### Week 11: Intercultural Engineering Communication\nHigh vs low context cultures, Hofstede dimensions, and asynchronous collaboration.`,
    examTips: ['Remember: low-context communication relies on literal explicit text, while high-context relies on shared social background!']
  },
  {
    id: 'note-eng2-w12',
    courseId: 'course-eng-2',
    courseTitle: 'English 2',
    courseCode: 'ENG1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Academic Citation Standards: APA, IEEE, MLA & Open Science Ethics',
    detailedNotes: `### Week 12: Citation Systems, Authorship Ethics & Open Science

#### 1. Major Academic Citation Styles
- **IEEE (Institute of Electrical and Electronics Engineers):**
  - **In-text:** Numbered brackets in order of citation appearance: *[1], [2-4]*.
  - **Reference List:** Sorted numerically by appearance order. Standard in CS and engineering.
- **APA 7th Edition (American Psychological Association):**
  - **In-text:** Author-Date format: *(Smith & Jones, 2024)* or *Smith et al. (2024)*.
  - **Reference List:** Alphabetical by first author\'s surname.
- **MLA (Modern Language Association):**
  - **In-text:** Author-Page format: *(Smith 45)*. Standard in humanities.

#### 2. Authorship Criteria (ICMJE Standards)
To qualify as a co-author, an individual MUST satisfy all 4 conditions:
1. Substantial intellectual contribution to conception, design, acquisition, or analysis of data.
2. Drafting or revising the manuscript critically for intellectual content.
3. Final approval of the version to be published.
4. Agreement to be accountable for all aspects of the work.
*(Merely providing funding, laboratory space, or general supervision does NOT warrant authorship; it belongs in Acknowledgments).*

#### 3. Open Science & Preprints
- **Preprints (arXiv, bioRxiv):** Rapid, unreviewed dissemination prior to formal peer review.
- **FAIR Principles:** Data must be **F**indable, **A**ccessible, **I**nteroperable, and **R**eusable.`,
    quickRevisionNotes: [
      'IEEE uses numbered bracket citations [1] in appearance order; APA uses Author-Date (Smith, 2024) alphabetically.',
      'ICMJE authorship requires substantial intellectual contribution + drafting + final approval + accountability.',
      'Financial backing or lab access alone does NOT qualify for authorship (belongs in Acknowledgments).',
      'FAIR data principles: Findable, Accessible, Interoperable, Reusable.'
    ],
    formulaSheets: [
      {
        name: 'IEEE vs APA Citation Topology',
        formula: '\\text{IEEE} = [n] \\; (\\text{Order of Appearance}) \\quad \\text{vs} \\quad \\text{APA} = (\\text{Author}, \\text{Year}) \\; (\\text{Alphabetical})',
        description: 'Comparative structural format of standard citation protocols.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng2-w12-p1',
        questionText: 'Which citation style uses numbered brackets like [1], [2] in the order of appearance in the text?',
        options: ['IEEE Style', 'APA 7th Edition', 'MLA 9th Edition', 'Chicago Author-Date'],
        correctOptionIndex: 0,
        solution: 'IEEE style uses bracketed numerals corresponding to a numerically ordered bibliography.',
        hints: ['Standard engineering numbered style.']
      },
      {
        id: 'eng2-w12-p2',
        questionText: 'According to ICMJE international scientific authorship guidelines, does providing financial funding alone qualify an individual for co-authorship?',
        options: ['No, funding alone belongs in the Acknowledgments section', 'Yes, funders are always first authors', 'Yes, if the grant is over $10,000', 'Only in private companies'],
        correctOptionIndex: 0,
        solution: 'Authorship requires direct intellectual contribution to the research. Funding without intellectual involvement is credited in Acknowledgments.',
        hints: ['Intellectual contribution vs financial support.']
      },
      {
        id: 'eng2-w12-p3',
        questionText: 'What does the acronym FAIR stand for in Open Science data management?',
        options: ['Findable, Accessible, Interoperable, Reusable', 'Fast, Accurate, Indexed, Reliable', 'Formatted, Audited, Integrated, Recorded', 'Free, Available, International, Regulated'],
        correctOptionIndex: 0,
        solution: 'FAIR data principles stand for Findable, Accessible, Interoperable, and Reusable.',
        hints: ['Open data principles.']
      }
    ],
    keyTakeaways: [
      'Consistent citation formatting maintains professional academic publishing standards.',
      'Adhering to ICMJE authorship guidelines prevents disputes and ethical misconduct.'
    ],
    markdownContent: `### Week 12: Citations & Academic Ethics\nIEEE vs APA standards, ICMJE authorship rules, and FAIR open data principles.`,
    examTips: ['Use IEEE bracketed numbers [1] for Computer Science and Engineering reports!']
  }
];

import { WeeklyStudyMaterial } from '../types';

export const DEGREE_AI_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-ai-w1',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 1,
    title: 'Problem Formulation, State Space Graphs & Uninformed Search (BFS, DFS, UCS, IDDFS)',
    detailedNotes: `### Week 1: State Space Search & Uninformed Search Strategies

#### 1. Formal Problem Formulation
An agent problem in AI is formalized as a 5-tuple $\\langle S_0, \\text{Actions}(s), \\text{Result}(s, a), \\text{GoalTest}(s), c(s, a, s') \\rangle$:
1. **Initial State ($S_0$):** Starting world configuration.
2. **Action Space ($\\text{Actions}(s)$):** Set of legal moves available in state $s$.
3. **Transition Model ($\\text{Result}(s, a)$):** State reached by executing action $a$ in state $s$.
4. **Goal Test:** Boolean predicate testing if current state is a goal state.
5. **Path Cost Function ($c(s, a, s')$):** Step cost; total path cost is $g(n) = \\sum c(s_i, a_i, s_{i+1})$.

#### 2. Comparison of Uninformed Search Algorithms
Let $b$ be the branching factor, $d$ the depth of the shallowest goal, and $m$ the maximum search tree depth:
- **Breadth-First Search (BFS):** FIFO queue frontier. Complete? Yes (if $b$ is finite). Time: $O(b^d)$, Space: $O(b^d)$ (Memory bottleneck!). Optimal? Yes (if step costs are identical).
- **Depth-First Search (DFS):** LIFO stack frontier. Complete? No (fails in infinite loops unless cycle check). Time: $O(b^m)$, Space: $O(bm)$ (Linear space efficiency!). Optimal? No.
- **Uniform Cost Search (UCS / Dijkstra):** Priority queue ordered by path cost $g(n)$. Complete? Yes (if step costs $\\ge \\epsilon > 0$). Time & Space: $O(b^{1 + \\lfloor C^* / \\epsilon \\rfloor})$. Optimal? **Yes, for arbitrary positive step costs!**
- **Iterative Deepening DFS (IDDFS):** Calls depth-limited search with increasing limits $l = 0, 1, 2, \\dots, d$. Complete? Yes. Time: $O(b^d)$, Space: $O(bd)$. Optimal? Yes (for uniform step costs). Combines the linear space of DFS with the optimality of BFS!`,
    quickRevisionNotes: [
      'Uniform Cost Search expands the node with the minimum cumulative path cost g(n).',
      'IDDFS combines the O(bd) linear space of DFS with the completeness and optimality of BFS.',
      'Goal test for UCS/Dijkstra must be applied when a node is POPPED from the priority queue, NOT when generated!'
    ],
    formulaSheets: [
      {
        name: 'IDDFS Total Node Generation Count',
        formula: 'N(\\text{IDDFS}) = (d)b^1 + (d-1)b^2 + \\dots + 1 b^d = O(b^d)',
        description: 'Total states generated across all iterative deepening levels up to goal depth d.'
      },
      {
        name: 'Uniform Cost Search Frontier Priority',
        formula: '\\text{Priority}(n) = g(n) = \\sum_{i=1}^k c(s_{i-1}, a_i, s_i)',
        description: 'Frontier priority order in Dijkstra / UCS.'
      }
    ],
    definitions: [
      {
        term: 'Iterative Deepening Search',
        explanation: 'A search strategy that systematically increases the search depth limit until a goal is found, achieving optimal time/space bounds.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Uniform Cost Search (UCS) Implementation in Python',
        code: `import heapq

def uniform_cost_search(start_state, goal_fn, successors_fn):
    # Priority Queue stores tuples: (cumulative_cost, state, path)
    frontier = [(0, start_state, [])]
    explored = set()
    
    while frontier:
        cost, current_state, path = heapq.heappop(frontier)
        
        # Apply goal test when POPPED from queue!
        if goal_fn(current_state):
            return path + [current_state], cost
            
        if current_state in explored:
            continue
        explored.add(current_state)
        
        for next_state, step_cost in successors_fn(current_state):
            if next_state not in explored:
                heapq.heappush(frontier, (cost + step_cost, next_state, path + [current_state]))
                
    return None, float('inf') # No path found`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w1-q1',
        questionText: 'Why must the goal test in Uniform Cost Search (UCS) be evaluated when a node is removed from the priority queue rather than when it is generated?',
        options: ['Because a shorter path to the goal may still exist in the queue with lower cost g(n)', 'To save memory in the closed set', 'Because priority queues cannot evaluate goal tests', 'To avoid visiting the root node twice'],
        correctOptionIndex: 0,
        solution: 'When a goal node is generated, its cost may be higher than alternative unexpanded paths currently on the frontier. Testing on pop guarantees that no cheaper path remains.',
        hints: ['Think of Dijkstra shortest-path correctness.']
      }
    ],
    examTips: [
      'In state space search, the explored set (Closed List) prevents redundant graph search cycles.',
      'Space complexity is almost always the limiting constraint in practical BFS search problems.'
    ],
    handwrittenMnemonic: 'IDDFS: BFS optimality with DFS linear memory; Test goal on pop in UCS!'
  },
  {
    id: 'note-ai-w2',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 2,
    title: 'Informed / Heuristic Search: A* Search, Admissibility, Consistency & IDA*',
    detailedNotes: `### Week 2: Heuristic Evaluation & The A* Search Algorithm

#### 1. A* Evaluation Function
A* evaluates candidate nodes using:
$$f(n) = g(n) + h(n)$$
- $g(n)$: Exact known cost from start state to node $n$.
- $h(n)$: Estimated heuristic cost from node $n$ to the nearest goal state ($h(\\text{goal}) = 0$).

#### 2. Heuristic Properties for Optimality
1. **Admissibility (Tree Search Optimality):**
   A heuristic $h(n)$ is **Admissible** if it **never overestimates** the true optimal cost $h^*(n)$ to reach the goal:
   $$0 \\le h(n) \\le h^*(n) \\quad \\forall n$$
2. **Consistency / Monotonicity (Graph Search Optimality):**
   A heuristic $h(n)$ is **Consistent** if for every node $n$ and every successor $n'$ generated by action $a$:
   $$h(n) \\le c(n, a, n') + h(n') \\quad (\\text{Triangle Inequality})$$
   - **Theorem:** If $h(n)$ is consistent, then $f(n)$ values along any path are non-decreasing, and A* is guaranteed to find the optimal path **without ever having to reopen/re-expand nodes in the explored set**!
   - Every consistent heuristic is admissible ($h \\text{ Consistent} \\implies h \\text{ Admissible}$).

#### 3. Dominance & Heuristic Quality
If $h_2(n) \\ge h_1(n)$ for all $n$ (and both are admissible), $h_2$ is said to **Dominate** $h_1$. A* using $h_2$ will never expand more nodes than A* using $h_1$.`,
    quickRevisionNotes: [
      'A* evaluation: f(n) = g(n) + h(n).',
      'Admissible heuristic never overestimates: h(n) <= h*(n) (guarantees tree search optimality).',
      'Consistent heuristic satisfies triangle inequality: h(n) <= c(n, a, n\') + h(n\') (guarantees graph search optimality without reopening nodes).'
    ],
    formulaSheets: [
      {
        name: 'A* Evaluation Function',
        formula: 'f(n) = g(n) + h(n)',
        description: 'Estimated total path cost through node n to goal.'
      },
      {
        name: 'Heuristic Consistency (Triangle Inequality)',
        formula: 'h(n) \\le c(n, a, n\') + h(n\')',
        description: 'Monotonicity condition ensuring explored nodes are never reopened in A* graph search.'
      }
    ],
    definitions: [
      {
        term: 'Admissible Heuristic',
        explanation: 'A cost-to-goal estimator that never overestimates the true remaining distance to the closest goal.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'A* Graph Search Implementation with Priority Queue',
        code: `import heapq

def a_star_search(start, goal_test, get_successors, heuristic):
    # Entry format: (f_score, g_score, state, path)
    start_h = heuristic(start)
    frontier = [(start_h, 0, start, [])]
    g_costs = {start: 0}
    closed_set = set()
    
    while frontier:
        f, g, current, path = heapq.heappop(frontier)
        
        if goal_test(current):
            return path + [current], g
            
        if current in closed_set:
            continue
        closed_set.add(current)
        
        for neighbor, step_cost in get_successors(current):
            new_g = g + step_cost
            if neighbor not in g_costs or new_g < g_costs[neighbor]:
                g_costs[neighbor] = new_g
                new_f = new_g + heuristic(neighbor)
                heapq.heappush(frontier, (new_f, new_g, neighbor, path + [current]))
                
    return None, float('inf')`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w2-q1',
        questionText: 'If heuristic h(n) is consistent, what does it guarantee about the sequence of f(n) values along any search path?',
        options: ['f(n) values are monotonically non-decreasing', 'f(n) values must strictly decrease', 'f(n) values are always zero', 'f(n) oscillates randomly'],
        correctOptionIndex: 0,
        solution: 'Consistency ensures h(n) <= c(n, n\') + h(n\'). Adding g(n) to both sides yields f(n) <= f(n\'), meaning f-costs never decrease along any path.',
        hints: ['Add g(n) to both sides of the consistency inequality.']
      }
    ],
    examTips: [
      'Relaxing problem constraints creates admissible heuristics (e.g. Manhattan Distance in 8-puzzle relaxes the constraint that tiles cannot pass through occupied cells).',
      'The composite heuristic $h(n) = \\max(h_1(n), h_2(n))$ is always admissible if both $h_1$ and $h_2$ are admissible, and dominates both!'
    ],
    handwrittenMnemonic: 'Consistent implies Admissible; Max of admissible heuristics dominates both!'
  },
  {
    id: 'note-ai-w3',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 3,
    title: 'Adversarial Search & Games: Minimax Algorithm, Alpha-Beta Pruning & Transposition Tables',
    detailedNotes: `### Week 3: Adversarial Game Playing & Alpha-Beta Pruning

#### 1. Minimax Value Derivation (Zero-Sum Games)
In a deterministic, perfect-information two-player zero-sum game between MAX and MIN:
$$\\text{Minimax}(s) = \\begin{cases} \\text{Utility}(s) & \\text{if Terminal}(s) \\\\ \\max_{a \\in \\text{Actions}(s)} \\text{Minimax}(\\text{Result}(s, a)) & \\text{if Player}(s) = \\text{MAX} \\\\ \\min_{a \\in \\text{Actions}(s)} \\text{Minimax}(\\text{Result}(s, a)) & \\text{if Player}(s) = \\text{MIN} \\end{cases}$$
- Time complexity: $O(b^m)$, Space complexity: $O(bm)$.

#### 2. Alpha-Beta ($\\alpha$-$\\beta$) Pruning
$\\alpha$-$\\beta$ pruning returns the EXACT same optimal decision as Minimax while skipping unpromising subtrees:
- $\\alpha$: The best (highest) value that MAX can guarantee along the path so far (Initialized to $-\\infty$).
- $\\beta$: The best (lowest) value that MIN can guarantee along the path so far (Initialized to $+\\infty$).
- **Pruning Rule:** Prune branch whenever $\\alpha \\ge \\beta$!

#### 3. Efficiency & Move Ordering
- **Worst-case (Poor move ordering):** No branches pruned $\\implies O(b^m)$.
- **Best-case (Perfect move ordering - exploring best moves first):**
  $$\\text{Effective Branching Factor} = \\sqrt{b} \\implies \\text{Time Complexity} = O(b^{m/2})$$
  (Effectively doubles the searchable lookahead depth in the same compute budget!).`,
    quickRevisionNotes: [
      'Alpha-Beta pruning computes the identical minimax value while pruning branches where alpha >= beta.',
      'Alpha is the lower bound for MAX; Beta is the upper bound for MIN.',
      'With perfect move ordering, alpha-beta pruning doubles the search depth to O(b^(m/2)).'
    ],
    formulaSheets: [
      {
        name: 'Alpha-Beta Pruning Condition',
        formula: '\\alpha \\ge \\beta \\implies \\text{Prune remaining sibling branches}',
        description: 'Pruning cutoff invariant where MAX lower bound exceeds MIN upper bound.'
      }
    ],
    definitions: [
      {
        term: 'Transposition Table',
        explanation: 'A hash table caching evaluated game state evaluations to avoid re-searching identical board states reached via different move permutations.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Alpha-Beta Pruning Implementation in Python',
        code: `def alpha_beta(state, depth, alpha, beta, is_max):
    if depth == 0 or state.is_terminal():
        return state.evaluate(), None
        
    best_move = None
    if is_max:
        max_eval = float('-inf')
        for move, child in state.get_children():
            eval_val, _ = alpha_beta(child, depth - 1, alpha, beta, False)
            if eval_val > max_eval:
                max_eval, best_move = eval_val, move
            alpha = max(alpha, eval_val)
            if beta <= alpha:
                break # Beta cutoff
        return max_eval, best_move
    else:
        min_eval = float('inf')
        for move, child in state.get_children():
            eval_val, _ = alpha_beta(child, depth - 1, alpha, beta, True)
            if eval_val < min_eval:
                min_eval, best_move = eval_val, move
            beta = min(beta, eval_val)
            if beta <= alpha:
                break # Alpha cutoff
        return min_eval, best_move`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w3-q1',
        questionText: 'Under optimal move ordering, what is the time complexity of Alpha-Beta pruning on a game tree with branching factor b and depth m?',
        options: ['O(b^(m/2))', 'O(b^m)', 'O(m * b)', 'O(log(b^m))'],
        correctOptionIndex: 0,
        solution: 'Perfect move ordering allows alpha-beta pruning to examine only O(b^(m/2)) nodes, effectively doubling the searchable depth.',
        hints: ['Effective branching factor drops from b to sqrt(b).']
      }
    ],
    examTips: [
      'Transposition tables store evaluations of previously visited states using Zobrist Hashing.',
      'Horizon effect occurs when a damaging move by opponent is merely pushed beyond search depth limit.'
    ],
    handwrittenMnemonic: 'Alpha is MAX\'s floor; Beta is MIN\'s ceiling; Prune when Alpha >= Beta!'
  },
  {
    id: 'note-ai-w4',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 4,
    title: 'Constraint Satisfaction Problems (CSP): Backtracking, AC-3 Arc Consistency & Variable Heuristics',
    detailedNotes: `### Week 4: Constraint Propagation & Arc Consistency (AC-3)

#### 1. Formal CSP Formulation
A CSP is defined by $\\langle X, D, C \\rangle$:
- Variables $X = \\{X_1, \\dots, X_n\\}$.
- Domains $D = \\{D_1, \\dots, D_n\\}$.
- Constraints $C = \\{C_1, \\dots, C_m\\}$ specifying allowable value combinations.

#### 2. Constraint Propagation: AC-3 (Arc Consistency) Algorithm
An arc $X_i \\to X_j$ is **Arc Consistent** if for every value $x \\in D_i$, there exists some legal value $y \\in D_j$ satisfying binary constraint $C(X_i, X_j)$.
- **AC-3 Algorithm:**
  1. Initialize queue $Q$ with all directed binary arcs in the CSP.
  2. While $Q$ not empty: Pop arc $(X_i, X_j)$.
  3. If \`RemoveInconsistentValues(Xi, Xj)\` reduces $D_i$:
     - If $D_i = \\emptyset \\implies$ Return False (Inconsistent CSP!).
     - Add all incoming arcs $(X_k, X_i)$ back to queue for all $X_k \\in \\text{Neighbors}(X_i) \\setminus \\{X_j\\}$.
- Time Complexity: $O(c d^3)$ where $c$ is number of binary constraints and $d$ is maximum domain size.

#### 3. Backtracking Search Heuristics
1. **MRV (Minimum Remaining Values / Most Constrained Variable):** Choose variable with fewest legal remaining values in its domain (Fail-First principle).
2. **Degree Heuristic:** Tie-breaker for MRV; choose variable involved in the largest number of constraints on remaining unassigned variables.
3. **LCV (Least Constraining Value):** Given chosen variable, pick value that rules out the fewest choices in neighboring variables (Fail-Last principle).`,
    quickRevisionNotes: [
      'AC-3 enforces arc consistency across all binary constraints in O(c * d^3) time.',
      'Variable selection: MRV (Fail-First) chooses variable with smallest remaining domain.',
      'Value selection: LCV (Fail-Last) chooses value that leaves maximum flexibility for neighbors.'
    ],
    formulaSheets: [
      {
        name: 'AC-3 Time Complexity Bound',
        formula: 'T(\\text{AC-3}) = O(c \\cdot d^3)',
        description: 'Worst-case time complexity for c binary constraints with maximum domain size d.'
      }
    ],
    definitions: [
      {
        term: 'Arc Consistency',
        explanation: 'A variable Xi is arc-consistent with respect to Xj if every value in Di has a supporting valid value in Dj.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'AC-3 Arc Consistency Algorithm in Python',
        code: `from collections import deque

def ac3(csp):
    queue = deque(csp.get_all_arcs())
    
    while queue:
        xi, xj = queue.popleft()
        if revise(csp, xi, xj):
            if len(csp.domains[xi]) == 0:
                return False # Domain wiped out -> No solution
            for xk in csp.neighbors[xi]:
                if xk != xj:
                    queue.append((xk, xi))
    return True

def revise(csp, xi, xj):
    revised = False
    to_remove = set()
    for x in csp.domains[xi]:
        # Check if there is ANY y in Dj satisfying constraint(x, y)
        if not any(csp.satisfies_constraint(x, y, xi, xj) for y in csp.domains[xj]):
            to_remove.add(x)
            revised = True
    csp.domains[xi] -= to_remove
    return revised`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w4-q1',
        questionText: 'When choosing which variable to assign next in CSP backtracking search, which heuristic chooses the variable with the fewest legal values?',
        options: ['Minimum Remaining Values (MRV)', 'Least Constraining Value (LCV)', 'Uniform Cost Priority', 'Max-Margin Heuristic'],
        correctOptionIndex: 0,
        solution: 'MRV (also known as the "fail-first" heuristic) picks the variable with the smallest number of remaining values in its domain.',
        hints: ['Think of minimizing remaining domain values.']
      }
    ],
    examTips: [
      'Forward Checking propagates constraints from the newly assigned variable to its immediate neighbors only; AC-3 propagates constraints globally across all arcs until fixpoint.',
      'Tree-structured CSPs can be solved in linear time $O(n d^2)$ using directional arc consistency.'
    ],
    handwrittenMnemonic: 'MRV picks variable (Fail First); LCV picks value (Fail Last)!'
  },
  {
    id: 'note-ai-w5',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 5,
    title: 'Local Search & Optimization: Hill Climbing, Simulated Annealing & Genetic Algorithms',
    detailedNotes: `### Week 5: Local Optimization & Metaheuristics

#### 1. Hill-Climbing Search & Failure Modes
Hill climbing iteratively moves to neighbor with highest evaluation value $f(s)$.
- **Local Maxima:** Peaks higher than neighbors but lower than global maximum.
- **Plateaux / Shoulders:** Flat regions where all neighbors have identical score (random walk).
- **Ridges:** Narrow slopes where gradient points off the grid axes.

#### 2. Simulated Annealing (Metropolis-Hastings Criterion)
Inspired by metallurgical cooling: escapes local optima by allowing downhill moves with temperature-dependent probability:
$$P(\\text{Accept worse move with } \\Delta E < 0) = \\exp\\left( \\frac{\\Delta E}{T} \\right) = e^{\\frac{\\Delta E}{T}}$$
- At high Temperature $T$: $e^{\\Delta E / T} \\approx 1$ (Explores state space randomly).
- As Temperature $T \\to 0$: $e^{\\Delta E / T} \\to 0$ (Transitions to pure greedy hill climbing).
- **Annealing Schedule Theorem:** If temperature $T$ decreases sufficiently slowly (e.g. $T(t) = \\frac{T_0}{\\log(1 + t)}$), Simulated Annealing is guaranteed to converge to the **global optimum**!`,
    quickRevisionNotes: [
      'Simulated Annealing accepts downhill moves with probability exp(Delta E / T) to escape local minima.',
      'High temperature encourages broad exploration; low temperature enforces greedy exploitation.',
      'Genetic algorithms utilize crossover (recombination) and mutation over candidate population pools.'
    ],
    formulaSheets: [
      {
        name: 'Metropolis Acceptance Probability',
        formula: 'P(\\text{accept}) = \\exp\\left( \\frac{\\Delta E}{T} \\right) \\quad \\text{for } \\Delta E < 0',
        description: 'Probability of accepting a worsening solution in Simulated Annealing at temperature T.'
      }
    ],
    definitions: [
      {
        term: 'Simulated Annealing',
        explanation: 'Probabilistic local search metaheuristic that accepts suboptimal moves with decreasing probability to escape local extrema.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Simulated Annealing Optimization Loop',
        code: `import math, random

def simulated_annealing(initial_state, objective_fn, get_neighbor, schedule):
    current = initial_state
    current_val = objective_fn(current)
    best_state, best_val = current, current_val
    
    for t in range(1, 10000):
        T = schedule(t)
        if T <= 1e-6:
            break
            
        neighbor = get_neighbor(current)
        neighbor_val = objective_fn(neighbor)
        delta_e = neighbor_val - current_val
        
        # Accept if better OR probabilistically if worse
        if delta_e > 0 or random.random() < math.exp(delta_e / T):
            current, current_val = neighbor, neighbor_val
            if current_val > best_val:
                best_state, best_val = current, current_val
                
    return best_state, best_val`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w5-q1',
        questionText: 'What happens to the acceptance probability exp(Delta E / T) in Simulated Annealing as the temperature T approaches 0?',
        options: ['The acceptance probability for worsening moves approaches 0 (acts as pure hill climbing)', 'The acceptance probability approaches 1', 'The algorithm oscillates infinitely', 'The energy Delta E becomes zero'],
        correctOptionIndex: 0,
        solution: 'For negative Delta E (worse moves), as T -> 0, Delta E / T -> -infinity, so exp(Delta E / T) -> 0, eliminating acceptance of worse moves.',
        hints: ['Evaluate limit of exp(-c / T) as T -> 0.']
      }
    ],
    examTips: [
      'In Genetic Algorithms, Crossover combines components from two fit parents; Mutation maintains genetic diversity and prevents premature convergence.',
      'Random-restart hill climbing with $k$ restarts finds optimum with probability $1 - (1 - p)^k$.'
    ],
    handwrittenMnemonic: 'High T explores wide; Low T exploits greedily; Anneal slowly to find global best!'
  },
  {
    id: 'note-ai-w6',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 6,
    title: 'Propositional Logic, Entailment, CNF Conversion & DPLL SAT Solver',
    detailedNotes: `### Week 6: Propositional Knowledge Bases & Satisfiability (SAT)

#### 1. Entailment & Models
Knowledge Base $KB$ entails sentence $\\alpha$ ($KB \\models \\alpha$) if and only if in every model where $KB$ is true, $\\alpha$ is also true:
$$KB \\models \\alpha \\iff M(KB) \\subseteq M(\\alpha) \\iff (KB \\land \\neg \\alpha) \\text{ is Unsatisfiable}$$

#### 2. Conversion to Conjunctive Normal Form (CNF)
A CNF sentence is a conjunction of clauses (disjunction of literals): $(A \\lor \\neg B) \\land (C \\lor D \\lor \\neg A)$.
**Steps to Convert Any Propositional Formula to CNF:**
1. Eliminate $\\iff$: Replace $P \\iff Q$ with $(P \\implies Q) \\land (Q \\implies P)$.
2. Eliminate $\\implies$: Replace $P \\implies Q$ with $\\neg P \\lor Q$.
3. Push $\\neg$ inward using De Morgan\'s laws: $\\neg (P \\land Q) \\equiv \\neg P \\lor \\neg Q$, $\\neg (P \\lor Q) \\equiv \\neg P \\land \\neg Q$, $\\neg \\neg P \\equiv P$.
4. Distribute $\\lor$ over $\\land$: $P \\lor (Q \\land R) \\equiv (P \\lor Q) \\land (P \\lor R)$.

#### 3. DPLL (Davis-Putnam-Logemann-Loveland) Algorithm
Complete backtracking SAT solver utilizing:
1. **Early Termination:** If any clause is false $\\implies$ backtrack; if all clauses are true $\\implies$ SAT!
2. **Pure Symbol Elimination:** A symbol that appears with the same polarity (always positive or always negative) in all unresolved clauses is assigned that polarity.
3. **Unit Clause Elimination:** A clause with only 1 unassigned literal (e.g. $(P)$ or $(P \\lor \\text{False})$) forces the assignment of $P = \\text{True}$!`,
    quickRevisionNotes: [
      'KB |= alpha iff (KB and not alpha) is unsatisfiable (Refutation theorem).',
      'CNF represents formulas as a conjunction of disjunctive clauses.',
      'DPLL optimizes SAT backtracking using pure symbol and unit clause propagation.'
    ],
    formulaSheets: [
      {
        name: 'Proof by Refutation Theorem',
        formula: 'KB \\models \\alpha \\iff (KB \\land \\neg \\alpha) \\text{ is Unsatisfiable}',
        description: 'Foundation of resolution theorem proving and SAT-based inference.'
      },
      {
        name: 'De Morgan\'s Propositional Laws',
        formula: '\\neg (A \\land B) \\equiv \\neg A \\lor \\neg B, \\quad \\neg (A \\lor B) \\equiv \\neg A \\land \\neg B',
        description: 'Negation propagation rules for CNF translation.'
      }
    ],
    definitions: [
      {
        term: 'Unit Clause',
        explanation: 'A clause containing exactly one unassigned literal, whose truth value is deterministically forced.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Unit Propagation Routine in DPLL',
        code: `def find_unit_clause(clauses, model):
    for clause in clauses:
        unassigned_literals = []
        is_clause_satisfied = False
        for lit in clause:
            symbol = abs(lit)
            val = model.get(symbol)
            if val is not None:
                if (lit > 0 and val) or (lit < 0 and not val):
                    is_clause_satisfied = True
                    break
            else:
                unassigned_literals.append(lit)
        if not is_clause_satisfied and len(unassigned_literals) == 1:
            return unassigned_literals[0] # Forced unit literal
    return None`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w6-q1',
        questionText: 'What is the CNF equivalent of the implication formula P -> (Q and R)?',
        options: ['(~P or Q) and (~P or R)', '(~P or Q) or R', '~P and Q and R', 'P or ~Q or ~R'],
        correctOptionIndex: 0,
        solution: 'P -> (Q and R) becomes ~P or (Q and R). Distributing OR over AND yields (~P or Q) and (~P or R).',
        hints: ['Replace implication with ~P or (Q and R), then distribute OR over AND.']
      }
    ],
    examTips: [
      'Resolution rule resolves $(A \\lor B)$ and $(\\neg B \\lor C)$ to derive the resolvent $(A \\lor C)$.',
      'Deriving the empty clause $(\\Box)$ in resolution proves unsatisfiability and confirms entailment.'
    ],
    handwrittenMnemonic: 'Entailment via Refutation: KB and not alpha produces empty clause!'
  },
  {
    id: 'note-ai-w7',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 7,
    title: 'First-Order Logic (FOL), Unification & Generalized Modus Ponens',
    detailedNotes: `### Week 7: First-Order Logic & Automated Theorem Proving

#### 1. First-Order Logic Syntax & Quantifiers
- **Terms:** Constant symbols, Variables ($x, y$), Functions ($f(x)$).
- **Atomic Sentences:** Predicates over terms: $\\text{Brother}(\\text{John}, \\text{Richard})$.
- **Universal Quantifier ($\\forall$):** $\\forall x \\ (\\text{King}(x) \\implies \\text{Person}(x))$. (Typically paired with implication $\\implies$).
- **Existential Quantifier ($\\exists$):** $\\exists x \\ (\\text{Crown}(x) \\land \\text{OnHead}(x, \\text{John}))$. (Typically paired with conjunction $\\land$).

#### 2. Most General Unifier (MGU)
Unification algorithm $\\text{UNIFY}(p, q) = \\theta$ finds variable substitution $\\theta$ such that $\\text{Subst}(\\theta, p) = \\text{Subst}(\\theta, q)$.
- Example: $\\text{UNIFY}(\\text{Knows}(\\text{John}, x), \\text{Knows}(y, \\text{Bill})) = \\{ y / \\text{John}, x / \\text{Bill} \\}$.
- **Occurs-Check:** Prevents binding variable $x$ to term containing $x$ (e.g. $x / f(x)$), which would create infinite cyclic terms!

#### 3. Generalized Modus Ponens (GMP)
For atomic sentences $p_i, p'_i$ and substitution $\\theta$ such that $\\text{Subst}(\\theta, p'_i) = \\text{Subst}(\\theta, p_i)$ for all $i$:
$$\\frac{p'_1, \\ p'_2, \\dots, p'_n, \\quad (p_1 \\land p_2 \\land \\dots \\land p_n \\implies q)}{\\text{Subst}(\\theta, q)}$$`,
    quickRevisionNotes: [
      'Universal quantifier (forall) pairs with implication (=>); Existential quantifier (exists) pairs with conjunction (&).',
      'Unification finds the most general substitution theta that equates two logic expressions.',
      'Occurs-check avoids invalid self-referential variable bindings like x / f(x).'
    ],
    formulaSheets: [
      {
        name: 'Generalized Modus Ponens (GMP)',
        formula: '\\frac{p\'_1, \\dots, p\'_n, \\quad (p_1 \\land \\dots \\land p_n \\implies q)}{\\text{Subst}(\\theta, q)} \\quad \\text{where } \\text{Subst}(\\theta, p\'_i) = \\text{Subst}(\\theta, p_i)',
        description: 'Inference rule lifting propositional modus ponens to first-order logic.'
      }
    ],
    definitions: [
      {
        term: 'Skolemization',
        explanation: 'The process of eliminating existential quantifiers by replacing existentially quantified variables with new Skolem constants or Skolem functions of enclosing universal variables.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'First-Order Logic Substitution Application',
        code: `def apply_subst(theta, expr):
    if isinstance(expr, str):
        return theta.get(expr, expr)
    elif isinstance(expr, tuple):
        op, args = expr[0], expr[1:]
        return (op,) + tuple(apply_subst(theta, arg) for arg in args)
    return expr

# Example substitution: {x: 'John', y: 'Mary'} applied to Loves(x, y)
theta = {'x': 'John', 'y': 'Mary'}
expr = ('Loves', 'x', 'y')
print(apply_subst(theta, expr)) # ('Loves', 'John', 'Mary')`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w7-q1',
        questionText: 'What is the result of applying the unification algorithm to `Knows(John, x)` and `Knows(y, Mother(y))`?',
        options: ['{y / John, x / Mother(John)}', '{x / John, y / Mother(John)}', 'Fails due to Occurs-Check', 'Empty substitution {}'],
        correctOptionIndex: 0,
        solution: 'Binding y to John makes the first argument identical. Then x unifies with Mother(y) substituting y/John, giving x / Mother(John).',
        hints: ['Unify first arguments then substitute into second arguments.']
      }
    ],
    examTips: [
      'First-order logic with equality and function symbols is semi-decidable (if sentence is entailed, proof will terminate; if not entailed, algorithm may run forever).',
      'Skolem constants replace $\\exists x$; Skolem functions $f(y)$ replace $\\exists x$ when inside scope of $\\forall y$.'
    ],
    handwrittenMnemonic: 'Forall pairs with Implication; Exists pairs with AND; Skolemize exists!'
  },
  {
    id: 'note-ai-w8',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 8,
    title: 'Classical Planning: STRIPS, PDDL, Progression/Regression Search & Graphplan',
    detailedNotes: `### Week 8: Automated Planning & Planning Graphs

#### 1. PDDL (Planning Domain Definition Language) Operator Schema
An action schema $A$ consists of:
- **Action Name & Parameter List:** e.g. $\\text{Fly}(p, \\text{from}, \\text{to})$.
- **Preconditions ($\text{Pre}(A)$):** Conjunction of positive/negative literals that must be true in state $s$ to execute action $A$.
- **Effects ($\text{Eff}(A)$):** Add-list (literals made true) and Delete-list (literals made false):
  $$\\text{Result}(s, A) = (s \\setminus \\text{Del}(A)) \\cup \\text{Add}(A)$$

#### 2. Planning State Search
- **Forward State-Space Search (Progression):** Start from initial state $S_0$ and apply applicable actions forward toward goal state. Prone to huge branching factor!
- **Backward Relevant-States Search (Regression):** Start from goal description and apply actions backwards.

#### 3. Planning Graphs & Graphplan Algorithm
A planning graph alternates between Proposition levels $P_i$ and Action levels $A_i$:
- **Mutex (Mutual Exclusion) Relations:**
  1. *Inconsistent Effects:* One action deletes an effect of the other.
  2. *Interference:* One action deletes a precondition of the other.
  3. *Competing Needs:* Preconditions of two actions are mutually exclusive at preceding level.
  4. *Inconsistent Support (Propositions):* All actions achieving proposition $P$ are mutex with all actions achieving $Q$.`,
    quickRevisionNotes: [
      'PDDL actions define Preconditions, Add lists, and Delete lists.',
      'Progression searches forward from initial state; Regression searches backward from goals.',
      'Graphplan extracts valid parallel plans by detecting Mutex (mutual exclusion) relations.'
    ],
    formulaSheets: [
      {
        name: 'STRIPS Action Transition State Update',
        formula: 'S\' = (S \\setminus \\text{Del}(A)) \\cup \\text{Add}(A)',
        description: 'Deterministic discrete state update under STRIPS action schema.'
      }
    ],
    definitions: [
      {
        term: 'Mutual Exclusion (Mutex)',
        explanation: 'A constraint indicating that two actions or propositions cannot be executed or co-occur at the same planning time step.'
      }
    ],
    codeSnippets: [
      {
        language: 'text',
        title: 'PDDL Action Schema Example',
        code: `(:action Move
  :parameters (?b - block ?from - block ?to - block)
  :precondition (and (on ?b ?from) (clear ?b) (clear ?to))
  :effect (and (on ?b ?to) (clear ?from) (not (on ?b ?from)) (not (clear ?to))))`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w8-q1',
        questionText: 'In planning graphs, what type of mutex occurs when action A deletes a precondition of action B?',
        options: ['Interference', 'Inconsistent Effects', 'Competing Needs', 'Inconsistent Support'],
        correctOptionIndex: 0,
        solution: 'Interference mutex occurs when one action deletes an effect or precondition needed by another simultaneous action.',
        hints: ['Deleting another action\'s prerequisite causes interference.']
      }
    ],
    examTips: [
      'Planning graph heuristics provide admissible distance estimates for forward search without requiring state expansions.',
      'Persistence actions ("no-op") in Graphplan carry propositions forward to subsequent levels.'
    ],
    handwrittenMnemonic: 'STRIPS state = (State - DeleteList) + AddList; Mutex blocks conflicts!'
  },
  {
    id: 'note-ai-w9',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 9,
    title: 'Probabilistic Reasoning, Axioms of Probability & Conditional Independence',
    detailedNotes: `### Week 9: Uncertainty & Probabilistic Independence

#### 1. Full Joint Probability Distribution
For $n$ boolean random variables, the Full Joint Distribution specifies probabilities for all $2^n$ atomic events.
- Sums to 1: $\\sum_{\\omega} P(\\omega) = 1$.
- **Marginalization (Summing Out):**
  $$P(Y) = \\sum_{z} P(Y, Z = z)$$
- **Conditioning (Product Rule):**
  $$P(Y \\mid E = e) = \\frac{P(Y, E = e)}{P(E = e)} = \\alpha P(Y, E = e)$$

#### 2. Conditional Independence & Dimensionality Reduction
- Two variables $X$ and $Y$ are **Conditionally Independent given $Z$** ($X \\perp Y \\mid Z$) if:
  $$P(X, Y \\mid Z) = P(X \\mid Z) P(Y \\mid Z) \\iff P(X \\mid Y, Z) = P(X \\mid Z)$$
- **Impact:** Reduces exponential $O(2^n)$ joint distribution storage to factored products of small local conditional probability tables (CPTs)!`,
    quickRevisionNotes: [
      'Full joint distributions scale exponentially O(2^n) without conditional independence assumptions.',
      'Marginalization sums out unobserved hidden variables: P(Y) = sum_z P(Y, z).',
      'Conditional independence P(X, Y | Z) = P(X | Z) * P(Y | Z) factors joint distributions.'
    ],
    formulaSheets: [
      {
        name: 'Bayes\' Rule with Background Evidence',
        formula: 'P(A \\mid B, E) = \\frac{P(B \\mid A, E) P(A \\mid E)}{P(B \\mid E)}',
        description: 'Bayesian posterior updating with contextual evidence E.'
      },
      {
        name: 'Conditional Independence Invariant',
        formula: 'X \\perp Y \\mid Z \\iff P(X \\mid Y, Z) = P(X \\mid Z)',
        description: 'Mathematical definition of conditional independence given conditioning variable Z.'
      }
    ],
    definitions: [
      {
        term: 'Marginalization',
        explanation: 'The process of calculating marginal probabilities of a subset of variables by summing out irrelevant variables from the joint distribution.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Marginalization and Normalization in Python',
        code: `import numpy as np

# Joint distribution P(Cavity, Toothache): rows=Cavity, cols=Toothache
# [0, 0]=NoCavity,NoAche; [0, 1]=NoCavity,Ache; [1, 0]=Cavity,NoAche; [1, 1]=Cavity,Ache
joint = np.array([
    [0.70, 0.10], # Cavity = False
    [0.08, 0.12]  # Cavity = True
])

# Compute P(Cavity | Toothache = True)
# Step 1: Slice Toothache = 1 column
unnormalized = joint[:, 1] # array([0.10, 0.12])

# Step 2: Normalize (alpha)
posterior = unnormalized / np.sum(unnormalized)
print("P(Cavity | Toothache=True):", posterior) # [0.4545, 0.5455]`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w9-q1',
        questionText: 'If variables A and B are conditionally independent given C, how does P(A | B, C) simplify?',
        options: ['P(A | C)', 'P(A) * P(B)', 'P(A | B)', 'P(C | A, B)'],
        correctOptionIndex: 0,
        solution: 'By definition of conditional independence given C, knowledge of B provides no additional information about A once C is known: P(A | B, C) = P(A | C).',
        hints: ['Conditioning on C renders B irrelevant.']
      }
    ],
    examTips: [
      'Normalization constant $\\alpha = 1 / P(E)$ eliminates the need to compute joint denominators directly.',
      'Absolute independence $P(X, Y) = P(X)P(Y)$ does NOT necessarily imply conditional independence $P(X, Y \\mid Z) = P(X \\mid Z)P(Y \\mid Z)$.'
    ],
    handwrittenMnemonic: 'Sum out hidden variables; Conditional independence factorizes joint CPTs!'
  },
  {
    id: 'note-ai-w10',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 10,
    title: 'Bayesian Networks: Semantics, d-Separation, Markov Blankets & Exact Inference (Variable Elimination)',
    detailedNotes: `### Week 10: Directed Graphical Models & Exact Inference

#### 1. Bayesian Network Semantics & Chain Rule
A Bayesian Network is a Directed Acyclic Graph (DAG) where nodes represent random variables and directed edges represent direct probabilistic dependencies.
- **Factorization Theorem:** The full joint distribution factors into the product of local conditional distributions:
  $$P(X_1, \\dots, X_n) = \\prod_{i=1}^n P(X_i \\mid \\text{Parents}(X_i))$$

#### 2. d-Separation (Directional Separation)
A path between $X$ and $Y$ is **Blocked** by evidence set $E$ if:
1. Path contains **Causal Chain** ($X \\to Z \\to Y$) or **Common Cause** ($X \\leftarrow Z \\to Y$) and $Z \\in E$.
2. Path contains a **Collider / Common Effect** ($X \\to Z \\leftarrow Y$) and **neither $Z$ nor any descendant of $Z$ is in $E$**!
- If all paths between $X$ and $Y$ are blocked by $E$, $X$ and $Y$ are **d-separated** $\\implies X \\perp Y \\mid E$.

#### 3. Markov Blanket
A node $X$ is conditionally independent of all other nodes in the network given its **Markov Blanket**:
$$\\text{MB}(X) = \\text{Parents}(X) \\cup \\text{Children}(X) \\cup \\text{Co-parents of Children}(X)$$

#### 4. Variable Elimination Algorithm
Computes exact queries $P(Q \\mid E)$ by summing out non-query, non-evidence variables in reverse topological order, caching intermediate factors $\\mathbf{f}_i$.`,
    quickRevisionNotes: [
      'Full joint is product of local CPTs: P(X1...Xn) = prod P(Xi | Parents(Xi)).',
      'Collider (V-structure X -> Z <- Y) is BLOCKED when Z and its descendants are UNNOTICED/NOT in evidence.',
      'Markov Blanket consists of Parents + Children + Co-parents of Children.'
    ],
    formulaSheets: [
      {
        name: 'Bayes Net Joint Distribution Factorization',
        formula: 'P(X_1, \\dots, X_n) = \\prod_{i=1}^n P(X_i \\mid \\text{Parents}(X_i))',
        description: 'Complete joint probability expressed through DAG parent conditional distributions.'
      },
      {
        name: 'Markov Blanket Definition',
        formula: '\\text{MB}(X) = \\text{Parents}(X) \\cup \\text{Children}(X) \\cup \\text{Spouses}(X)',
        description: 'Set of nodes shielding X from the rest of the Bayesian network.'
      }
    ],
    definitions: [
      {
        term: 'd-Separation',
        explanation: 'A graphical criterion that determines whether a set of variables is conditionally independent of another set given evidence.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Exact Inference with Variable Elimination (pgmpy)',
        code: `from pgmpy.models import BayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

# Define Alarm Network: Burglary -> Alarm <- Earthquake
model = BayesianNetwork([('Burglary', 'Alarm'), ('Earthquake', 'Alarm')])

cpd_b = TabularCPD('Burglary', 2, [[0.999], [0.001]])
cpd_e = TabularCPD('Earthquake', 2, [[0.998], [0.002]])
cpd_a = TabularCPD('Alarm', 2, 
                   [[0.999, 0.71, 0.06, 0.05],
                    [0.001, 0.29, 0.94, 0.95]],
                   evidence=['Burglary', 'Earthquake'], evidence_card=[2, 2])

model.add_cpds(cpd_b, cpd_e, cpd_a)
infer = VariableElimination(model)

# Query P(Burglary | Alarm=True)
result = infer.query(variables=['Burglary'], evidence={'Alarm': 1})
print(result)`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w10-q1',
        questionText: 'In a collider structure X -> Z <- Y, what happens to the path between X and Y when evidence is observed at node Z?',
        options: ['The path becomes ACTIVE (unblocked), rendering X and Y conditionally dependent (Explaining Away)', 'The path is blocked', 'X and Y become mutually exclusive', 'The network becomes cyclic'],
        correctOptionIndex: 0,
        solution: 'In a collider, observing the common effect Z activates the path between its parents X and Y (known as Berkson\'s paradox or the "explaining away" phenomenon).',
        hints: ['Observing common effect induces dependence between causes.']
      }
    ],
    examTips: [
      'Variable elimination complexity depends exponentially on the **treewidth** (largest factor size) of the induced graph under the chosen elimination ordering.',
      'Finding the optimal variable elimination order is NP-hard; min-degree and min-fill heuristics are used in practice.'
    ],
    handwrittenMnemonic: 'Collider opens when evidence observed; Markov Blanket = Parents + Kids + Co-parents!'
  },
  {
    id: 'note-ai-w11',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 11,
    title: 'Approximate Inference: Rejection Sampling, Likelihood Weighting & Gibbs Sampling (MCMC)',
    detailedNotes: `### Week 11: Monte Carlo Sampling & Markov Chain Monte Carlo (MCMC)

#### 1. Forward Sampling & Rejection Sampling
- **Prior / Forward Sampling:** Sample variables in topological order from their conditional CPTs.
- **Rejection Sampling:** Discard all samples that do not match the observed evidence $E = e$.
  - **Limitation:** If evidence $P(E = e)$ is rare (e.g. 0.0001), 99.99% of generated samples are discarded!

#### 2. Likelihood Weighting
Fixes evidence variables to their observed values $E = e$ (so no samples are ever rejected) and assigns each sample a **Weight** $w$:
$$w = \\prod_{Z_j \\in E} P(Z_j = e_j \\mid \\text{Parents}(Z_j))$$
- Generates unbiased estimates, but weights degrade rapidly if evidence occurs late in deep causal chains.

#### 3. Gibbs Sampling (Markov Chain Monte Carlo - MCMC)
Maintains current state vector $\\mathbf{x}$. In each iteration:
1. Select a non-evidence variable $X_i$.
2. Sample new value for $X_i$ from its conditional distribution given its **Markov Blanket**:
   $$P(X_i \\mid \\text{MB}(X_i)) = \\alpha P(X_i \\mid \\text{Parents}(X_i)) \\prod_{Y_j \\in \\text{Children}(X_i)} P(Y_j \\mid \\text{Parents}(Y_j))$$
- Stationary distribution of the resulting Markov chain is guaranteed to converge to the exact true posterior distribution $P(\\mathbf{X} \\mid \\mathbf{e})$!`,
    quickRevisionNotes: [
      'Rejection sampling wastes samples when evidence is rare.',
      'Likelihood weighting fixes evidence and weights each sample by P(evidence | parents).',
      'Gibbs sampling resamples one variable at a time conditioned on its Markov Blanket (MCMC).'
    ],
    formulaSheets: [
      {
        name: 'Likelihood Weight Calculation',
        formula: 'w = \\prod_{i=1}^m P(E_i = e_i \\mid \\text{Parents}(E_i))',
        description: 'Importance weight assigned to each sample in likelihood weighting.'
      },
      {
        name: 'Gibbs Sampling Local Conditional Distribution',
        formula: 'P(X_i \\mid \\text{MB}(X_i)) = \\alpha P(X_i \\mid \\text{Parents}(X_i)) \\prod_{Y_j \\in \\text{Children}(X_i)} P(Y_j \\mid \\text{Parents}(Y_j))',
        description: 'Transition probability for resampling variable X_i in Gibbs sampling.'
      }
    ],
    definitions: [
      {
        term: 'Markov Chain Monte Carlo (MCMC)',
        explanation: 'A class of sampling algorithms that generates dependent samples by wandering through state space in a Markov chain whose stationary distribution matches the target distribution.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Likelihood Weighting Sampling Algorithm in Python',
        code: `import random

def likelihood_weighting(bayes_net, query_var, evidence, num_samples=10000):
    weights_sum = {}
    
    for _ in range(num_samples):
        sample = {}
        weight = 1.0
        
        for var in bayes_net.topological_order():
            if var in evidence:
                sample[var] = evidence[var]
                # Multiply weight by P(var=evidence_val | parents)
                weight *= bayes_net.get_prob(var, evidence[var], sample)
            else:
                sample[var] = bayes_net.sample_var(var, sample)
                
        val = sample[query_var]
        weights_sum[val] = weights_sum.get(val, 0.0) + weight
        
    # Normalize weights
    total_w = sum(weights_sum.values())
    return {k: v / total_w for k, v in weights_sum.items()}`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w11-q1',
        questionText: 'In Likelihood Weighting, which variables are sampled from their conditional distributions and which variables have their values fixed?',
        options: ['Non-evidence variables are sampled; evidence variables are fixed and contribute to sample weight', 'All variables are sampled', 'Evidence variables are sampled; non-evidence are fixed', 'Only the root nodes are sampled'],
        correctOptionIndex: 0,
        solution: 'Likelihood weighting fixes all evidence variables to their observed values and samples only non-evidence variables, weighting the run by the joint likelihood of the fixed evidence.',
        hints: ['Evidence is never changed during sampling.']
      }
    ],
    examTips: [
      'In MCMC Gibbs sampling, a "burn-in" period of initial samples must be discarded before the chain reaches its stationary equilibrium.',
      'Thinning (recording every $k$-th sample) reduces autocorrelation between consecutive MCMC samples.'
    ],
    handwrittenMnemonic: 'Likelihood Weighting fixes evidence and accumulates weights; Gibbs resamples via Markov Blanket!'
  },
  {
    id: 'note-ai-w12',
    courseId: 'course-ai',
    courseTitle: 'Artificial Intelligence: Search & Reasoning',
    courseCode: 'CS3002',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 12,
    title: 'Markov Decision Processes (MDP), Bellman Optimality Equations & Value/Policy Iteration',
    detailedNotes: `### Week 12: Sequential Decision Making & Dynamic Programming for MDPs

#### 1. MDP Formulation & The Bellman Equation
An MDP is formalized as $\\langle S, A, T(s, a, s'), R(s, a, s'), \\gamma \\rangle$:
- Discount factor $\\gamma \\in [0, 1)$ bounds infinite-horizon return: $U = \\sum_{t=0}^\\infty \\gamma^t R_t$.
- **Bellman Expectation Equation for Policy $\\pi$:**
  $$V^\\pi(s) = \\sum_{s'} T(s, \\pi(s), s') \\left[ R(s, \\pi(s), s') + \\gamma V^\\pi(s') \\right]$$
- **Bellman Optimality Equation:**
  $$V^*(s) = \\max_{a \\in A} \\sum_{s'} T(s, a, s') \\left[ R(s, a, s') + \\gamma V^*(s') \\right]$$
- **Optimal Action-Value Function ($Q^*(s, a)$):**
  $$Q^*(s, a) = \\sum_{s'} T(s, a, s') \\left[ R(s, a, s') + \\gamma \\max_{a'} Q^*(s', a') \\right]$$

#### 2. Value Iteration vs. Policy Iteration
1. **Value Iteration (Dynamic Programming):**
   Iteratively updates state values until convergence:
   $$V_{k+1}(s) = \\max_{a} \\sum_{s'} T(s, a, s') \\left[ R(s, a, s') + \\gamma V_k(s') \\right]$$
   - **Contraction Mapping Theorem:** Bellman operator is a $\\gamma$-contraction in $L_\\infty$ norm (guarantees monotonic exponential convergence to unique fixed point $V^*$).
2. **Policy Iteration:**
   Alternates between two distinct phases until policy becomes stable:
   - **Policy Evaluation:** Solve linear system $V^{\\pi_k}(s)$ for fixed policy $\\pi_k$.
   - **Policy Improvement:** $\\pi_{k+1}(s) = \\arg\\max_a \\sum_{s'} T(s, a, s') [R(s, a, s') + \\gamma V^{\\pi_k}(s')]$.
   - Policy iteration converges in strictly fewer iterations than Value Iteration!`,
    quickRevisionNotes: [
      'Bellman Optimality Equation expresses the recursive maximum over immediate reward plus discounted future value.',
      'Value iteration applies the Bellman contraction operator iteratively until ||V_(k+1) - V_k|| < epsilon.',
      'Policy iteration alternates between linear Policy Evaluation and greedy Policy Improvement.'
    ],
    formulaSheets: [
      {
        name: 'Bellman Optimality Equation for V*(s)',
        formula: 'V^*(s) = \\max_{a \\in A} \\sum_{s\'} T(s, a, s\') \\left[ R(s, a, s\') + \\gamma V^*(s\') \\right]',
        description: 'Recursive optimality condition for optimal state value function V*.'
      },
      {
        name: 'Bellman Contraction Property',
        formula: '\\|B(V_1) - B(V_2)\\|_\\infty \\le \\gamma \\|V_1 - V_2\\|_\\infty',
        description: 'Contraction mapping proof guaranteeing convergence of Value Iteration.'
      }
    ],
    definitions: [
      {
        term: 'Markov Property',
        explanation: 'Property stating that future states depend only upon the current state and action, and are conditionally independent of all historical states.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Value Iteration Algorithm for Gridworld MDP',
        code: `import numpy as np

def value_iteration(states, actions, transition_prob, reward_fn, gamma=0.9, theta=1e-5):
    V = {s: 0.0 for s in states}
    
    while True:
        delta = 0
        new_V = {}
        for s in states:
            q_values = []
            for a in actions:
                q_val = sum(transition_prob(s, a, s_prime) * (reward_fn(s, a, s_prime) + gamma * V[s_prime]) 
                            for s_prime in states)
                q_values.append(q_val)
            new_V[s] = max(q_values)
            delta = max(delta, abs(new_V[s] - V[s]))
            
        V = new_V
        if delta < theta:
            break
            
    # Extract optimal policy
    policy = {}
    for s in states:
        policy[s] = actions[np.argmax([
            sum(transition_prob(s, a, s_prime) * (reward_fn(s, a, s_prime) + gamma * V[s_prime]) for s_prime in states)
            for a in actions
        ])]
    return V, policy`
      }
    ],
    practiceQuestions: [
      {
        id: 'ai-w12-q1',
        questionText: 'Why does the Value Iteration algorithm always converge to a unique optimal value function V* for discount factor gamma in [0, 1)?',
        options: ['The Bellman backup operator is a gamma-contraction mapping in the infinity norm, guaranteeing a unique fixed point (Banach Fixed-Point Theorem)', 'Because the state space is always continuous', 'Because rewards are always positive', 'Because value iteration uses random walk'],
        correctOptionIndex: 0,
        solution: 'By the Banach Fixed-Point Theorem, applying a gamma-contraction operator on a complete metric space monotonically shrinks distances by at least gamma in each iteration, guaranteeing convergence to a unique fixed point.',
        hints: ['Think of contraction mappings and fixed-point theorems.']
      }
    ],
    examTips: [
      'If $||V_{k+1} - V_k||_\\infty < \\epsilon (1 - \\gamma) / (2\\gamma)$, the greedy policy derived from $V_{k+1}$ is guaranteed to be within $\\epsilon$ of optimal policy value!',
      'Q-Value $Q(s, a)$ differs from $V(s)$ by capturing the value of taking specific action $a$ before acting optimally thereafter.'
    ],
    handwrittenMnemonic: 'Value Iteration contracts to optimal V*; Policy Iteration alternates Evaluate & Improve!'
  }
];

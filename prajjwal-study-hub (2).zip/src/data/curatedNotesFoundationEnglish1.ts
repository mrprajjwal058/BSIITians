import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_ENGLISH_1_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-eng1-w1',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Phonetics, Articulation & the International Phonetic Alphabet (IPA)',
    detailedNotes: `### Week 1: English Phonetics, Articulation & Sound Systems

#### 1. The Speech Mechanism & Organs of Speech
Speech sounds in English are produced by modifying air expelled from the lungs (pulmonic egressive airstream):
- **Active Articulators:** Tongue (tip, blade, dorsum), lower lip.
- **Passive Articulators:** Upper teeth, alveolar ridge, hard palate, soft palate (velum), uvula.

#### 2. The International Phonetic Alphabet (IPA) for English
English has 26 letters of the alphabet but **44 distinct phonemes** (speech sounds):
- **20 Vowel Sounds:**
  - **12 Pure Vowels (Monophthongs):** Short vowels (e.g. /ɪ/ in *bit*, /æ/ in *cat*, /ə/ the schwa in *ago*) and Long vowels (e.g. /iː/ in *fleece*, /ɑː/ in *father*).
  - **8 Diphthongs (Gliding Vowels):** Sounds that glide from one vowel position to another (e.g. /eɪ/ in *face*, /aɪ/ in *price*, /əʊ/ in *goat*).
- **24 Consonant Sounds:**
  - Classified by **Place of Articulation** (Bilabial, Labiodental, Dental, Alveolar, Post-alveolar, Palatal, Velar, Glottal).
  - Classified by **Manner of Articulation** (Plosives/Stops, Fricatives, Affricates, Nasals, Approximants/Liquids, Glides).
  - Classified by **Voicing** (Voiced vs Voiceless vocal cord vibration).`,
    quickRevisionNotes: [
      'English has 26 alphabetic letters but 44 distinct phonemic sounds.',
      '44 sounds = 20 vowels (12 monophthongs + 8 diphthongs) + 24 consonants.',
      'Schwa /ə/ is the most frequent unstressed vowel in English (e.g. *about*, *banana*).',
      'Consonants are defined by: Place, Manner, and Voicing.'
    ],
    formulaSheets: [
      {
        name: 'Consonant Classification Triad',
        formula: '\\text{Consonant} = \\langle \\text{Voicing}, \\text{Place of Articulation}, \\text{Manner of Articulation} \\rangle',
        description: 'Standard 3-term phonetic label (e.g., /b/ is a Voiced Bilabial Plosive).'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w1-p1',
        questionText: 'How many phonemes (distinct sounds) are there in the standard Received Pronunciation (RP) English sound system?',
        options: ['44', '26', '52', '20'],
        correctOptionIndex: 0,
        solution: 'Standard English has 44 phonemes: 24 consonants and 20 vowels (12 monophthongs + 8 diphthongs).',
        hints: ['Distinguish letters of alphabet (26) from phonemes (44).']
      },
      {
        id: 'eng1-w1-p2',
        questionText: 'What is the phonetic symbol for the neutral, unstressed vowel sound in "banana" /bəˈnɑːnə/?',
        options: ['Schwa /ə/', 'Monophthong /iː/', 'Diphthong /aɪ/', 'Glottal /ʔ/'],
        correctOptionIndex: 0,
        solution: 'The neutral central unstressed vowel sound is the Schwa, denoted as /ə/.',
        hints: ['Named after the German linguistic term.']
      },
      {
        id: 'eng1-w1-p3',
        questionText: 'Which organ serves as the primary active articulator in producing dental and alveolar sounds?',
        options: ['The tongue', 'The vocal cords', 'The hard palate', 'The uvula'],
        correctOptionIndex: 0,
        solution: 'The tongue is the most flexible active articulator that moves toward passive structures like the teeth or alveolar ridge.',
        hints: ['Most agile muscle in the vocal tract.']
      }
    ],
    keyTakeaways: [
      'Phonetic transcription removes ambiguity caused by non-phonetic English orthography.',
      'Proper articulation awareness prevents miscommunication in international academic presentations.'
    ],
    markdownContent: `### Week 1: Phonetics & IPA\nSpeech organs, 44 English phonemes, monophthongs, diphthongs, and consonant matrices.`,
    examTips: ['Remember that Schwa /ə/ ONLY appears in unstressed syllables!']
  },
  {
    id: 'note-eng1-w2',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Parts of Speech, Word Classes & Morphological Structure',
    detailedNotes: `### Week 2: Word Classes & English Morphology

#### 1. Open vs Closed Word Classes
- **Open Classes (Content Words - Carry core semantic meaning):**
  - **Nouns:** Proper, Common, Abstract, Concrete, Countable, Uncountable.
  - **Verbs:** Main verbs, Transitive (requires object), Intransitive (no object), Linking verbs.
  - **Adjectives:** Qualitative, Demonstrative, Quantitative, Interrogative.
  - **Adverbs:** Manner, Time, Place, Frequency, Degree.
- **Closed Classes (Function Words - Provide grammatical scaffolding):**
  - Pronouns, Prepositions, Conjunctions, Determiners/Articles.

#### 2. Morphology: Morphemes & Word Formation
- **Free Morphemes:** Can stand alone as independent words (e.g. *play*, *book*).
- **Bound Morphemes:** Must attach to a root/stem (e.g. *-ful*, *un-*, *-ed*).
- **Derivational Morphology:** Affixes that change the word class or core meaning (e.g. *happy* [Adj] $\\to$ *unhappiness* [Noun]).
- **Inflectional Morphology:** Affixes indicating grammatical categories like tense, number, or aspect without changing the word class (e.g. *walk* $\\to$ *walked*, *cat* $\\to$ *cats*).`,
    quickRevisionNotes: [
      'Open classes (Nouns, Verbs, Adjectives, Adverbs) readily accept new words into the language.',
      'Closed classes (Pronouns, Prepositions, Conjunctions, Articles) rarely change over time.',
      'Derivational affixes change word category (e.g. *create* $\\to$ *creation*).',
      'Inflectional affixes modify grammatical form (tense, plural, comparative) without changing category.'
    ],
    formulaSheets: [
      {
        name: 'Morphological Structure Formula',
        formula: '\\text{Word} = [\\text{Prefix}] + \\text{Root / Base} + [\\text{Suffix}_{\\text{deriv}}] + [\\text{Suffix}_{\\text{inflect}}]',
        description: 'Standard English compositional morphology template.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w2-p1',
        questionText: 'In the word "unbelievable", what type of affix is the prefix "un-"?',
        options: ['Derivational bound morpheme', 'Inflectional bound morpheme', 'Free lexical morpheme', 'Zero morpheme'],
        correctOptionIndex: 0,
        solution: 'The prefix "un-" modifies the root meaning to its antonym and cannot stand alone, making it a derivational bound morpheme.',
        hints: ['Can "un-" stand on its own as a standalone word?']
      },
      {
        id: 'eng1-w2-p2',
        questionText: 'Which of the following is an example of an intransitive verb?',
        options: ['The baby slept peacefully.', 'She read the research paper.', 'He kicked the ball.', 'They bought a server.'],
        correctOptionIndex: 0,
        solution: '"Slept" does not take a direct object; "peacefully" is an adverb modifying the action. Hence, it is an intransitive verb.',
        hints: ['Check which verb does not require a direct object.']
      },
      {
        id: 'eng1-w2-p3',
        questionText: 'Which word class is considered a "closed class" in English grammar?',
        options: ['Prepositions', 'Nouns', 'Verbs', 'Adjectives'],
        correctOptionIndex: 0,
        solution: 'Prepositions are functional grammatical markers that form a closed set, unlike nouns and verbs which continually expand.',
        hints: ['Identify the function word category.']
      }
    ],
    keyTakeaways: [
      'Morphological awareness enhances academic vocabulary acquisition and reading comprehension.',
      'Distinguishing transitive vs intransitive verbs is essential for accurate passive voice transformations.'
    ],
    markdownContent: `### Week 2: Parts of Speech & Morphology\nOpen vs closed word classes, morphemic parsing, and derivational affixation.`,
    examTips: ['Remember: Inflectional suffixes never change the part of speech of the root word!']
  },
  {
    id: 'note-eng1-w3',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Sentence Architecture: Subject-Verb Agreement & Clause Structure',
    detailedNotes: `### Week 3: Syntax, Subject-Verb Agreement & Clause Types

#### 1. Clauses vs Phrases
- **Phrase:** Group of words without a subject-verb pairing (e.g. *in the morning*, *a highly capable engineer*).
- **Clause:** Group of words containing both a Subject and a Finite Verb:
  - **Independent (Main) Clause:** Expresses a complete thought and can stand alone as a sentence.
  - **Dependent (Subordinate) Clause:** Introduced by a subordinating conjunction (e.g. *because*, *although*, *if*) or relative pronoun (*which*, *who*); cannot stand alone.

#### 2. The Four Fundamental Sentence Structures
1. **Simple Sentence:** Exactly 1 Independent Clause.
2. **Compound Sentence:** 2+ Independent Clauses linked by coordinating conjunctions (FANBOYS: *For, And, Nor, But, Or, Yet, So*) or a semicolon.
3. **Complex Sentence:** 1 Independent Clause $+$ 1+ Dependent Clauses.
4. **Compound-Complex Sentence:** 2+ Independent Clauses $+$ 1+ Dependent Clauses.

#### 3. Subject-Verb Agreement Rules
- Singular subjects take singular verbs; plural subjects take plural verbs.
- Phrases intervening between subject and verb (*along with, as well as, including*) do not alter the grammatical number of the subject.
- Either/Neither structures: Verb agrees with the **closer subject** (proximity rule).`,
    quickRevisionNotes: [
      'Simple = 1 Independent Clause; Compound = 2 Independent Clauses (FANBOYS); Complex = 1 Independent + 1+ Dependent.',
      'FANBOYS coordinating conjunctions: For, And, Nor, But, Or, Yet, So.',
      'Intervening prepositional phrases do not affect subject-verb agreement.',
      'Either/or and Neither/nor: Verb agrees in number with the closer subject.'
    ],
    formulaSheets: [
      {
        name: 'Complex Sentence Structural Topology',
        formula: '\\text{Sentence}_{\\text{Complex}} = \\text{Clause}_{\\text{Independent}} + \\text{Subordinating Conjunction} + \\text{Clause}_{\\text{Dependent}}',
        description: 'Canonical complex sentence syntactic composition.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w3-p1',
        questionText: 'Identify the sentence type: "Although the algorithm achieved 98% accuracy, it was too computationally expensive for mobile deployment."',
        options: ['Complex Sentence', 'Simple Sentence', 'Compound Sentence', 'Compound-Complex Sentence'],
        correctOptionIndex: 0,
        solution: 'The sentence consists of one dependent clause ("Although...") and one independent clause ("it was too..."), making it a Complex Sentence.',
        hints: ['Notice the subordinating conjunction "Although".']
      },
      {
        id: 'eng1-w3-p2',
        questionText: 'Choose the grammatically correct sentence:',
        options: ['The team of researchers, along with the professor, is publishing the results.', 'The team of researchers, along with the professor, are publishing the results.', 'Neither the manager nor the engineers is available.', 'The criteria for evaluation was updated.'],
        correctOptionIndex: 0,
        solution: 'The grammatical subject is the singular collective noun "team". The intervening phrase "along with the professor" does not change the singular subject, requiring the singular verb "is".',
        hints: ['Identify the true grammatical subject before the parenthetical comma.']
      },
      {
        id: 'eng1-w3-p3',
        questionText: 'What mnemonic acronym represents the seven coordinating conjunctions in English?',
        options: ['FANBOYS', 'PEMDAS', 'SWOT', 'SMART'],
        correctOptionIndex: 0,
        solution: 'FANBOYS stands for For, And, Nor, But, Or, Yet, So.',
        hints: ['For, And, Nor, But...']
      }
    ],
    keyTakeaways: [
      'Varying sentence structures (simple, compound, complex) creates engaging academic writing rhythm.',
      'Subject-verb proximity errors are the most common grammatical defect in technical reporting.'
    ],
    markdownContent: `### Week 3: Sentence Architecture\nPhrases vs clauses, FANBOYS conjunctions, complex sentences, and agreement rules.`,
    examTips: ['Cross out intervening prepositional phrases to easily identify the real grammatical subject!']
  },
  {
    id: 'note-eng1-w4',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Tenses, Aspect, Active vs Passive Voice & Modal Auxiliaries',
    detailedNotes: `### Week 4: Verb Tenses, Aspect, Voice & Modality

#### 1. The 12 English Tense-Aspect Combinations
- **Time Frames:** Present, Past, Future.
- **Aspects:**
  - **Simple:** Habitual actions, timeless general truths, or completed events.
  - **Continuous / Progressive (Be + V-ing):** Ongoing, temporary actions in progress.
  - **Perfect (Have + V3):** Actions completed prior to a reference point with present relevance.
  - **Perfect Continuous (Have + Been + V-ing):** Actions starting in past and continuing to present.

#### 2. Active vs Passive Voice in Academic Writing
- **Active:** Subject performs action $\\implies$ *The researchers conducted the experiment.*
- **Passive:** Object becomes subject $\\implies$ *The experiment was conducted by the researchers.*
- **Academic Convention:** Passive voice is frequently used in scientific methodology sections to emphasize the procedure, object of study, and empirical data rather than the personal investigator.

#### 3. Modal Auxiliaries & Hedging
Modals (*can, could, may, might, must, should, would*) modulate certainty, obligation, and possibility:
- **Academic Hedging:** Using *may*, *might*, *suggests*, *indicates* to temper claims and avoid unprovable overstatements.`,
    quickRevisionNotes: [
      '12 tenses = 3 Times (Present, Past, Future) $\\times$ 4 Aspects (Simple, Continuous, Perfect, Perfect Continuous).',
      'Passive voice formula: Subject + Appropriate form of "Be" + Past Participle (V3).',
      'Passive voice prioritizes the action/object over the actor in scientific methodology.',
      'Modals enable epistemic hedging in academic research.'
    ],
    formulaSheets: [
      {
        name: 'Passive Voice Transformation',
        formula: '\\text{Object}_{\\text{Active}} + \\text{Be}_{\\text{Tense}} + \\text{Verb}_{\\text{Past Participle (V3)}} + [\\text{by } \\text{Subject}_{\\text{Active}}]',
        description: 'Standard passive voice syntactic derivation.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w4-p1',
        questionText: 'Transform into passive voice: "The team developed a novel neural network architecture."',
        options: ['A novel neural network architecture was developed by the team.', 'A novel neural network architecture is developed by the team.', 'A novel neural network architecture had been developed by the team.', 'A novel neural network architecture was being developed by the team.'],
        correctOptionIndex: 0,
        solution: 'Past simple "developed" becomes "was developed" in the passive voice.',
        hints: ['Past simple uses was/were + V3.']
      },
      {
        id: 'eng1-w4-p2',
        questionText: 'Which modal verb expresses cautious possibility (hedging) in academic discourse?',
        options: ['may', 'must', 'will', 'shall'],
        correctOptionIndex: 0,
        solution: '"May" introduces tentative probability without absolute certainty, which is ideal for scientific hedging.',
        hints: ['Choose the modal that expresses tentative possibility.']
      },
      {
        id: 'eng1-w4-p3',
        questionText: 'Identify the tense and aspect: "She has been working on the quantum computing project for two years."',
        options: ['Present Perfect Continuous', 'Present Continuous', 'Past Perfect Continuous', 'Future Perfect'],
        correctOptionIndex: 0,
        solution: '"has been working" = Present tense auxiliary (has) + Continuous aspect (been + V-ing) + Perfect aspect (has been). Hence, Present Perfect Continuous.',
        hints: ['Look at "has" + "been" + "-ing".']
      }
    ],
    keyTakeaways: [
      'Passive constructions objectify methodology descriptions in scientific publications.',
      'Strategic hedging protects research findings from over-generalized refutation.'
    ],
    markdownContent: `### Week 4: Tenses, Voice & Modality\nTense-aspect matrix, passive transformations, and academic hedging.`,
    examTips: ['Ensure the form of "to be" in passive voice strictly matches the tense of the original active verb!']
  },
  {
    id: 'note-eng1-w5',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Prepositions, Collocations, Phrasal Verbs & Contextual Idioms',
    detailedNotes: `### Week 5: Prepositional Mechanics, Collocations & Idiomatic Usage

#### 1. Prepositions of Time, Place & Direction
- **Time:** *At* (precise time, e.g. *at 9:00 AM*), *On* (days and dates, e.g. *on Monday, on May 4th*), *In* (months, years, centuries, e.g. *in 2026, in summer*).
- **Place:** *At* (specific point, e.g. *at the entrance*), *In* (enclosed 3D space, e.g. *in the room*), *On* (2D surface, e.g. *on the screen*).

#### 2. Academic Collocations (Words that Naturally Co-occur)
- *conduct an experiment* (NOT *do an experiment*).
- *draw a conclusion* (NOT *make a conclusion*).
- *statistically significant* (NOT *statistically big*).
- *pose a question* / *formulate a hypothesis*.

#### 3. Phrasal Verbs & Academic Register
Phrasal verbs (verb + particle) are common in informal speech, but academic prose prefers formal Latinate one-word equivalents:
- *look into* $\\to$ **investigate**
- *put off* $\\to$ **postpone / defer**
- *bring about* $\\to$ **cause / generate**
- *come up with* $\\to$ **devise / formulate**`,
    quickRevisionNotes: [
      'Preposition hierarchy: AT (specific point/time) $\\subset$ ON (surface/day) $\\subset$ IN (enclosed space/year).',
      'Collocations are conventional word pairings (*conduct research*, *draw conclusions*).',
      'Replace colloquial phrasal verbs with formal Latinate verbs in academic papers.',
      'Dependent prepositions attach to specific adjectives and verbs (*depend on*, *interested in*, *capable of*).'
    ],
    formulaSheets: [
      {
        name: 'Prepositional Hierarchy Funnel',
        formula: '\\text{At (Specific)} \\subset \\text{On (Intermediate/Surface)} \\subset \\text{In (Broad/Enclosed)}',
        description: 'Spatial and temporal scale categorization for English prepositions.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w5-p1',
        questionText: 'Choose the appropriate academic collocation: "The researcher _______ a series of experiments to validate the hypothesis."',
        options: ['conducted', 'did', 'made', 'created'],
        correctOptionIndex: 0,
        solution: '"Conducted" is the canonical high-register academic collocation with "experiments".',
        hints: ['Academic standard pairing for experiments.']
      },
      {
        id: 'eng1-w5-p2',
        questionText: 'Which formal one-word verb should replace the phrasal verb "find out" in an academic paper?',
        options: ['discover / determine', 'look for', 'bring up', 'get into'],
        correctOptionIndex: 0,
        solution: '"Determine" or "discover" represents the precise Latinate academic equivalent of the conversational phrasal verb "find out".',
        hints: ['Choose the high-register single-word verb.']
      },
      {
        id: 'eng1-w5-p3',
        questionText: 'Choose the correct preposition: "The final exam is scheduled ____ Friday morning."',
        options: ['on', 'at', 'in', 'by'],
        correctOptionIndex: 0,
        solution: 'Specific days of the week use the preposition "on".',
        hints: ['Days and dates take "on".']
      }
    ],
    keyTakeaways: [
      'Mastering academic collocations produces natural, idiomatic scholarly prose.',
      'Substituting phrasal verbs with Latinate verbs instantly elevates the register of technical papers.'
    ],
    markdownContent: `### Week 5: Prepositions & Collocations\nTime/place prepositions, academic collocations, and formal verb replacements.`,
    examTips: ['Remember: "dependent ON", "interested IN", "capable OF", "associated WITH"!']
  },
  {
    id: 'note-eng1-w6',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Academic Vocabulary Building: Etymology, Greek/Latin Roots & Connotations',
    detailedNotes: `### Week 6: Etymology, Root Words & Semantic Nuances

#### 1. Greek & Latin Roots in Scientific Vocabulary
- **Bio (Life):** Biology, Biometrics, Biodiversity.
- **Chron (Time):** Chronology, Asynchronous, Synchronize.
- **Graph / Gram (Write / Draw):** Cryptography, Diagram, Graph.
- **Log / Logy (Study / Discourse):** Epistemology, Logic, Dialogue.
- **Tele (Distant):** Telecommunications, Telemetry.
- **Omni (All):** Omniscient, Omnipresent, Omnipotent.

#### 2. Prefixes and Suffixes
- **Prefixes:** *anti-* (against), *hyper-* (excessive), *hypo-* (under), *inter-* (between), *intra-* (within), *trans-* (across).
- **Suffixes:** *-able/-ible* (capable of), *-ize/-ise* (to make), *-ology* (study of), *-tion/-sion* (state/action).

#### 3. Denotation vs Connotation
- **Denotation:** The literal, primary dictionary definition of a word.
- **Connotation:** The cultural, emotional, or evaluative association evoked by a word:
  - *Inexpensive* (Positive) vs *Cheap* (Negative).
  - *Meticulous* (Positive) vs *Obsessive* (Negative).
  - *Confident* (Positive) vs *Arrogant* (Negative).`,
    quickRevisionNotes: [
      'Greek and Latin roots form over 70% of academic and scientific vocabulary.',
      '*Inter-* means between distinct entities; *Intra-* means within a single entity.',
      'Denotation is literal meaning; Connotation is emotional/stylistic implication.',
      'Morphological decoding allows deducing meanings of unfamiliar scientific terms.'
    ],
    formulaSheets: [
      {
        name: 'Prefix Distinctions',
        formula: '\\text{Inter-} (\\text{Between Entities}) \\ne \\text{Intra-} (\\text{Within Entity})',
        description: 'Crucial morphological boundary differentiation.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w6-p1',
        questionText: 'What is the morphological meaning of the prefix in "Intranet"?',
        options: ['Within a single organization/network', 'Between different networks', 'Against networks', 'Without a network'],
        correctOptionIndex: 0,
        solution: 'The prefix "Intra-" means inside or within (internal private network).',
        hints: ['Contrast intra (within) vs inter (between).']
      },
      {
        id: 'eng1-w6-p2',
        questionText: 'Which word has a positive connotation for someone who is cautious with financial resources?',
        options: ['Frugal', 'Stingy', 'Miserly', 'Cheap'],
        correctOptionIndex: 0,
        solution: '"Frugal" carries a positive connotation of prudence and care, whereas stingy and cheap carry negative connotations.',
        hints: ['Identify the term with a positive, respectful tone.']
      },
      {
        id: 'eng1-w6-p3',
        questionText: 'What root word means "time" in asynchronous communication?',
        options: ['Chron', 'Bio', 'Graph', 'Phon'],
        correctOptionIndex: 0,
        solution: 'The Greek root "chron" means time (asynchronous = not at the same time).',
        hints: ['Think of chronology or chronic.']
      }
    ],
    keyTakeaways: [
      'Recognizing Greek/Latin roots accelerates technical reading comprehension.',
      'Connotation selection establishes the subtle rhetorical stance of academic papers.'
    ],
    markdownContent: `### Week 6: Vocabulary & Etymology\nClassical roots, affix semantics, and denotative vs connotative distinctions.`,
    examTips: ['Be careful with "inter" (between) vs "intra" (inside): e.g. interstate vs intrastate!']
  },
  {
    id: 'note-eng1-w7',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Reading Comprehension Strategies: Skimming, Scanning & Critical Inference',
    detailedNotes: `### Week 7: Reading Speed, Strategies & Critical Analysis

#### 1. Strategic Reading Modalities
1. **Skimming (Reading for the Gist):**
   - Rapidly reading headings, introductory sentences (topic sentences), and concluding paragraphs to capture the overall conceptual framework.
2. **Scanning (Reading for Specific Details):**
   - Searching eyes rapidly across text for a specific targeted keyword, number, date, or metric without reading every surrounding word.
3. **Intensive / Critical Reading:**
   - Deep, line-by-line analytical evaluation of arguments, logical validity, methodological limitations, and evidential backing.

#### 2. The SQ3R Academic Reading Framework
- **Survey:** Skim headings, graphs, abstracts.
- **Question:** Turn headings into active questions (*e.g., What causes gradient vanishing?*).
- **Read:** Actively read to answer the formulated questions.
- **Recite / Recall:** Summarize key sections in your own words.
- **Review:** Revisit key takeaways periodically to solidify memory.

#### 3. Making Critical Inferences
Deducing unstated premises or underlying implications using textual evidence and logical deduction.`,
    quickRevisionNotes: [
      'Skimming captures main ideas; Scanning locates specific target keywords/data.',
      'SQ3R method: Survey, Question, Read, Recite, Review.',
      'Critical inference relies on explicit textual clues combined with deductive logic.',
      'Topic sentences at the start of paragraphs contain the primary argumentative assertion.'
    ],
    formulaSheets: [
      {
        name: 'Inference Equation',
        formula: '\\text{Inference} = \\text{Explicit Textual Clues} + \\text{Logical Deduction}',
        description: 'Deductive formula for valid reading comprehension inferences.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w7-p1',
        questionText: 'Which reading strategy is optimal when searching an index for a specific date or theorem name?',
        options: ['Scanning', 'Skimming', 'Extensive Reading', 'Proofreading'],
        correctOptionIndex: 0,
        solution: 'Scanning is the targeted visual search for specific pre-identified terms or data points without reading the entire text.',
        hints: ['Looking for a specific needle in a haystack.']
      },
      {
        id: 'eng1-w7-p2',
        questionText: 'What does the "Q" in the SQ3R academic study methodology represent?',
        options: ['Question', 'Quantify', 'Query', 'Quick-read'],
        correctOptionIndex: 0,
        solution: 'SQ3R stands for Survey, Question, Read, Recite, Review.',
        hints: ['Formulating interrogative prompts before reading.']
      },
      {
        id: 'eng1-w7-p3',
        questionText: 'Where is the main idea or topic sentence most typically located in a standard academic paragraph?',
        options: ['First sentence of the paragraph', 'Middle footnote', 'Last word only', 'Appendix'],
        correctOptionIndex: 0,
        solution: 'Academic paragraphs traditionally place the topic sentence in the first (or occasionally second) sentence to establish the argumentative claim immediately.',
        hints: ['Opening thesis of the paragraph.']
      }
    ],
    keyTakeaways: [
      'Employing skimming and scanning cuts academic literature review time by over 50%.',
      'Formulating questions before reading converts passive reading into active inquiry.'
    ],
    markdownContent: `### Week 7: Reading Comprehension\nSkimming, scanning, SQ3R framework, and critical inference deduction.`,
    examTips: ['Read the comprehension questions first before scanning the passage for keywords!']
  },
  {
    id: 'note-eng1-w8',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Discourse Cohesion & Coherence: Transitional Markers & Anaphora',
    detailedNotes: `### Week 8: Discourse Mechanics: Cohesion & Coherence

#### 1. Coherence vs Cohesion
- **Coherence (Macro-level):** The logical, thematic clarity and semantic flow of ideas throughout the text.
- **Cohesion (Micro-level):** The explicit grammatical and lexical linkages that tie individual sentences together.

#### 2. Categories of Transitional Discourse Markers
- **Addition:** *Furthermore, Moreover, In addition, Additionally*.
- **Contrast / Concession:** *However, Nevertheless, On the contrary, Conversely, Although*.
- **Causality / Result:** *Consequently, Therefore, Thus, As a result, Hence*.
- **Exemplification:** *For instance, Specifically, To illustrate*.
- **Sequencing:** *Subsequently, Simultaneously, Initially, Finally*.

#### 3. Reference Devices
- **Anaphora:** Referring backward to an entity already mentioned (*The server crashed. **It** was restarted.*).
- **Cataphora:** Referring forward to an entity revealed later (*When **she** arrived, Dr. Smith began the lecture.*).
- **Lexical Chains:** Repeating thematic synonyms to maintain continuity.`,
    quickRevisionNotes: [
      'Coherence = Logical flow of ideas; Cohesion = Grammatical/lexical connectors.',
      'Transitional markers signal logical shifts (Contrast: *However*; Cause: *Therefore*; Addition: *Furthermore*).',
      'Anaphoric reference points back to previously introduced antecedents.',
      'Avoid vague pronoun references like standalone *This* without an accompanying noun.'
    ],
    formulaSheets: [
      {
        name: 'Discourse Linkage Principle',
        formula: '\\text{Sentence}_{n+1} = \\text{Old Information (Connector)} + \\text{New Information}',
        description: 'Given-New information flow principle for seamless academic readability.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w8-p1',
        questionText: 'Which transitional connector indicates a logical consequence or result?',
        options: ['Consequently', 'Furthermore', 'Nevertheless', 'Simultaneously'],
        correctOptionIndex: 0,
        solution: '"Consequently" introduces a direct result or outcome of the preceding premise.',
        hints: ['Signals cause-and-effect relationship.']
      },
      {
        id: 'eng1-w8-p2',
        questionText: 'What term describes referring backward to an already established noun using a pronoun?',
        options: ['Anaphora', 'Cataphora', 'Metaphor', 'Hyperbole'],
        correctOptionIndex: 0,
        solution: 'Anaphoric reference refers backward to a previously stated antecedent.',
        hints: ['Backwards reference.']
      },
      {
        id: 'eng1-w8-p3',
        questionText: 'Choose the transition that best shows contrast: "The initial model suffered from severe overfitting; _______, the regularized variant generalized robustly."',
        options: ['however', 'furthermore', 'moreover', 'namely'],
        correctOptionIndex: 0,
        solution: '"However" signals a contrast between the overfitting initial model and the well-generalizing regularized model.',
        hints: ['Identify the connector indicating contrast.']
      }
    ],
    keyTakeaways: [
      'Seamless Given-New information ordering keeps technical papers readable.',
      'Appropriate discourse markers clarify cause-and-effect reasoning.'
    ],
    markdownContent: `### Week 8: Cohesion & Coherence\nTransitional markers, anaphoric references, and given-new information structures.`,
    examTips: ['Never use standalone "This." at the beginning of a sentence; always specify "This finding," or "This discrepancy."!']
  },
  {
    id: 'note-eng1-w9',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Paragraph Architecture: The MEAL Plan & Thematic Development',
    detailedNotes: `### Week 9: Paragraph Structure & The MEAL Framework

#### 1. The MEAL Paragraph Blueprint
1. **M - Main Idea (Topic Sentence):** The foundational assertion or core claim of the paragraph.
2. **E - Evidence / Explanation:** Concrete data, experimental results, theoretical proofs, or literature citations supporting the claim.
3. **A - Analysis / Evaluation:** Critical interpretation of how the evidence supports the main idea, explaining why it matters.
4. **L - Lead-out / Link:** Concluding synthesis sentence connecting back to the overarching thesis or bridging to the next paragraph.

#### 2. Common Paragraph Architecture Defects
- **The "Data Dump" Paragraph:** Presenting isolated statistics without analysis or explanatory commentary.
- **The "Fragmented" Paragraph:** Single-sentence or two-sentence paragraphs lacking development.
- **The "Wandering" Paragraph:** Introducing multiple competing topics without a unifying focus.`,
    quickRevisionNotes: [
      'MEAL Plan: Main Idea, Evidence, Analysis, Link.',
      'A paragraph should focus on exactly ONE central thematic idea.',
      'Always follow evidence with critical analysis explaining its significance.',
      'Concluding link transitions gracefully into the subsequent paragraph.'
    ],
    formulaSheets: [
      {
        name: 'The MEAL Framework Composition',
        formula: '\\text{Paragraph} = \\text{Topic Sentence} + \\text{Empirical Evidence} + \\text{Critical Analysis} + \\text{Synthesis Link}',
        description: 'Standard academic paragraph development structure.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w9-p1',
        questionText: 'In the MEAL academic paragraph framework, what does the letter "A" stand for?',
        options: ['Analysis', 'Argument', 'Appendix', 'Annotation'],
        correctOptionIndex: 0,
        solution: 'In the MEAL framework (Main idea, Evidence, Analysis, Link), "A" stands for Analysis.',
        hints: ['Critical interpretation step.']
      },
      {
        id: 'eng1-w9-p2',
        questionText: 'What is the primary flaw of a paragraph that cites five research statistics in succession without explaining their implications?',
        options: ['Lack of critical Analysis (Data dump)', 'Excessive topic sentences', 'Use of passive voice', 'Missing citations'],
        correctOptionIndex: 0,
        solution: 'Listing evidence without explaining how it supports the claim is a lack of Analysis.',
        hints: ['Evidence without explanation.']
      },
      {
        id: 'eng1-w9-p3',
        questionText: 'What is the ideal function of the final sentence (Link) in an academic body paragraph?',
        options: ['Synthesizes the paragraph\'s main claim and transitions to the next concept', 'Introduces an entirely unrelated new topic', 'Repeats the topic sentence verbatim', 'Lists raw numerical references'],
        correctOptionIndex: 0,
        solution: 'The Link synthesizes the paragraph\'s insight and provides a logical segue to the next section.',
        hints: ['Connective bridge to the next idea.']
      }
    ],
    keyTakeaways: [
      'Strict adherence to MEAL prevents rambling, unstructured academic paragraphs.',
      'Analysis is where the author demonstrates scholarly critical thinking.'
    ],
    markdownContent: `### Week 9: Paragraph Architecture\nThe MEAL framework, topic sentence scoping, and evidence-analysis balancing.`,
    examTips: ['Ensure every cited fact is immediately followed by at least one sentence of analytical interpretation!']
  },
  {
    id: 'note-eng1-w10',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Academic Writing Register, Tone, Objectivity & Hedging Formulations',
    detailedNotes: `### Week 10: Academic Register & Objective Discourse

#### 1. Characteristics of Academic Register
- **Formality:** Avoiding contractions (*don\'t* $\\to$ *do not*), slang, and colloquialisms.
- **Objectivity & Impersonality:** Focusing on phenomena, data, and methodology rather than subjective personal emotion.
- **Precision:** Using exact quantitative metrics and technical terminology rather than vague generalizations (*many people* $\\to$ *74% of participants*).
- **Conciseness:** Eliminating tautologies, filler phrases, and unnecessary wordiness (*due to the fact that* $\\to$ *because*).

#### 2. The Art of Academic Hedging (Epistemic Caution)
Academic claims must avoid absolute dogmatism (*This proves that...* is rarely acceptable in empirical sciences):
- **Cautious Verbs:** *suggests, indicates, implies, appears to, tends to*.
- **Probability Modals:** *may, might, could*.
- **Quantifying Adverbs:** *predominantly, relatively, frequently, possibly*.`,
    quickRevisionNotes: [
      'Never use informal contractions (e.g. *can\'t, won\'t*) in formal academic papers.',
      'Replace vague intensifiers (*very, huge, really*) with precise descriptions.',
      'Hedging verbs: *suggests, indicates, appears* temper claims and avoid unprovable absolutes.',
      'Academic tone is objective, impersonal, concise, and mathematically precise.'
    ],
    formulaSheets: [
      {
        name: 'Hedging Gradient Spectrum',
        formula: '\\text{Absolute: "This proves"} \\longrightarrow \\text{Academic Hedged: "These findings suggest a potential correlation"}',
        description: 'De-escalating dogmatic claims into defensible empirical conclusions.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w10-p1',
        questionText: 'Which sentence best exemplifies appropriate academic register and hedging?',
        options: ['The experimental data suggests that increasing learning rate may accelerate convergence.', 'This amazing algorithm definitely proves that all old models are completely useless.', 'We don\'t think the server can handle more load.', 'A huge bunch of users totally loved the new interface.'],
        correctOptionIndex: 0,
        solution: 'Sentence 1 avoids contractions, uses objective phrasing, and employs cautious hedging ("suggests", "may accelerate").',
        hints: ['Look for objective tone and absence of informal language.']
      },
      {
        id: 'eng1-w10-p2',
        questionText: 'Why are absolute assertions like "This definitively proves that..." generally discouraged in academic research papers?',
        options: ['Scientific knowledge is empirical and open to future falsification or boundary condition exceptions', 'Journals charge per word', 'Hedging makes papers longer', 'It is grammatically incorrect'],
        correctOptionIndex: 0,
        solution: 'Empirical science relies on probabilistic evidence; dogmatic claims of absolute proof overlook model assumptions and measurement uncertainty.',
        hints: ['Consider scientific fallibility and empirical bounds.']
      },
      {
        id: 'eng1-w10-p3',
        questionText: 'Replace the wordy phrase "due to the fact that" with its concise academic equivalent:',
        options: ['because', 'owing to that', 'in light of the fact that', 'for the purpose of'],
        correctOptionIndex: 0,
        solution: '"Because" communicates the causal relationship directly and eliminates bloated filler phrasing.',
        hints: ['Choose the most direct single-word connector.']
      }
    ],
    keyTakeaways: [
      'Academic writing builds authority through measured, evidence-backed claims rather than hyperbole.',
      'Eliminating conversational filler sharpens the density and impact of scientific prose.'
    ],
    markdownContent: `### Week 10: Academic Register & Hedging\nFormality guidelines, contraction bans, objective tone, and epistemic hedging.`,
    examTips: ['Check for and eliminate contractions (it\'s, don\'t, haven\'t) across all formal writing submissions!']
  },
  {
    id: 'note-eng1-w11',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Paraphrasing, Summary Synthesis & Plagiarism Prevention',
    detailedNotes: `### Week 11: Academic Integrity, Paraphrasing & Synthesis

#### 1. Plagiarism & Academic Integrity
Plagiarism is the unacknowledged presentation of another person\'s ideas, words, code, or data as one\'s own:
- **Verbatim Plagiarism:** Copying exact text without quotation marks and citation.
- **Patchwriting:** Swapping a few isolated words with synonyms while retaining the exact sentence structure of the original author.
- **Self-Plagiarism:** Resubmitting one\'s own prior evaluated work without explicit permission and attribution.

#### 2. The 4-Step Professional Paraphrasing Strategy
1. **Read & Understand:** Read the original text multiple times until its complete conceptual meaning is understood.
2. **Set Aside:** Look away from the source text so you are not anchored by its syntax.
3. **Rewrite in Your Own Words:** Re-express the idea using entirely different sentence architecture, word classes, and active/passive forms.
4. **Compare & Cite:** Verify that the core meaning is preserved without retaining phrasing strings, and attach the formal citation (e.g. *Smith et al., 2024*).

#### 3. Synthesizing Multiple Sources
Integrating contrasting or complementary perspectives from multiple authors to construct a cohesive literature review.`,
    quickRevisionNotes: [
      'Patchwriting (shallow synonym swapping) is still a form of plagiarism.',
      'True paraphrasing restructures both grammar and vocabulary from scratch.',
      'All paraphrased ideas MUST still include an in-text attribution/citation.',
      'Literature synthesis contrasts and weaves multiple sources into a single coherent narrative.'
    ],
    formulaSheets: [
      {
        name: 'Valid Academic Paraphrase Criterion',
        formula: '\\text{Valid Paraphrase} = \\text{Original Core Meaning} + \\text{New Syntactic Structure} + \\text{New Vocabulary} + \\text{Formal Citation}',
        description: 'Mandatory conditions for an ethical, valid academic paraphrase.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w11-p1',
        questionText: 'What is "patchwriting" in academic writing?',
        options: ['Shallow swapping of synonyms while copying the original author\'s exact sentence structure', 'Writing code patches for bugs', 'Formatting references in APA style', 'Writing short paragraphs'],
        correctOptionIndex: 0,
        solution: 'Patchwriting is an unacceptable form of paraphrasing where words are replaced with synonyms but the original sentence syntax remains copied.',
        hints: ['Superficial synonym substitution without restructuring.']
      },
      {
        id: 'eng1-w11-p2',
        questionText: 'Do you still need to provide an in-text citation if you have completely paraphrased an idea in your own original words?',
        options: ['Yes, because the underlying idea/intellectual discovery originated from another author', 'No, because the wording is entirely yours', 'Only if the original author is alive', 'Only if the paper has more than 3 authors'],
        correctOptionIndex: 0,
        solution: 'Citations credit intellectual ideas, data, and theories, not merely verbatim string sequences. Paraphrased concepts always require citation.',
        hints: ['Ideas, not just exact words, must be credited.']
      },
      {
        id: 'eng1-w11-p3',
        questionText: 'What is the most effective first step when preparing to paraphrase a complex academic paragraph?',
        options: ['Read to understand, then look away from the text before writing', 'Open a thesaurus for every word', 'Copy-paste into a translator twice', 'Delete all verbs'],
        correctOptionIndex: 0,
        solution: 'Internalizing the core concept and writing without looking at the original text ensures an authentic, original syntax structure.',
        hints: ['Set the source text aside before drafting.']
      }
    ],
    keyTakeaways: [
      'Mastering ethical paraphrasing protects researchers from academic misconduct proceedings.',
      'Synthesis connects fragmented research papers into a coherent domain narrative.'
    ],
    markdownContent: `### Week 11: Paraphrasing & Academic Integrity\nPlagiarism forms, patchwriting risks, 4-step paraphrasing, and source synthesis.`,
    examTips: ['Always provide an in-text citation even when paraphrasing ideas in your own original words!']
  },
  {
    id: 'note-eng1-w12',
    courseId: 'course-eng-1',
    courseTitle: 'English 1',
    courseCode: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Professional Communication: Email Etiquette, Formal Letters & Presentation Skills',
    detailedNotes: `### Week 12: Professional & Oral Academic Communication

#### 1. Professional Email Etiquette
- **Subject Line:** Concise, specific, and actionable (*e.g., [CS1001] Assignment 2 Query - Roll No. 22001*).
- **Salutation:** Formal and respectful (*Dear Professor Sharma / Dear Dr. Miller*, avoiding casual *Hey guys*).
- **Context & Purpose:** State the context and purpose of the email in the opening two sentences.
- **Call-to-Action (CTA):** State clearly what action is requested and by when.
- **Sign-off:** Professional closing (*Sincerely / Best regards*) with full contact details.

#### 2. Formal Letter & Report Structures
- Sender/Recipient address blocks, formal date formats, subject header, numbered sections, clear appendices.

#### 3. Oral Presentation & Slide Design
- **10/20/30 Rule of Presentations:** 10 slides, 20 minutes maximum, minimum 30pt font.
- **Signposting Expressions:** Verbal cues guiding the audience through the speech (*To begin with..., Turning now to our methodology..., To summarize our findings...*).
- **Non-Verbal Delivery:** Eye contact, vocal modulation, pacing, and open body language.`,
    quickRevisionNotes: [
      'Email subjects must be actionable and include student roll number and course code.',
      'Use formal titles (*Dr.*, *Prof.*) in initial correspondence.',
      'Signposting phrases (*Turning now to...*, *To summarize...*) orient presentation listeners.',
      'Keep presentation slides concise: avoid dense walls of text.'
    ],
    formulaSheets: [
      {
        name: 'Professional Email Blueprint',
        formula: '\\text{Email} = \\text{Actionable Subject} + \\text{Formal Salutation} + \\text{Purpose Context} + \\text{Action Request} + \\text{Professional Sign-off}',
        description: 'Standard institutional email communication structure.'
      }
    ],
    practiceQuestions: [
      {
        id: 'eng1-w12-p1',
        questionText: 'Which email subject line is most appropriate and professional when requesting a deadline extension for an assignment?',
        options: ['[CS1001] Request for Assignment 3 Extension - Roll No. 240567', 'urgent help please!!', 'extension request', 'Need more time for the homework'],
        correctOptionIndex: 0,
        solution: 'The first subject line includes the course code, clear purpose, and the student roll number, allowing the instructor to triage immediately.',
        hints: ['Look for course code, purpose, and student identifier.']
      },
      {
        id: 'eng1-w12-p2',
        questionText: 'What are "signposting phrases" in academic presentations?',
        options: ['Verbal transit cues that guide the audience through the structure of the presentation', 'Road traffic warnings', 'Hyperlinks in slide notes', 'Bibliography citations'],
        correctOptionIndex: 0,
        solution: 'Signposting phrases (e.g. "Let us now examine...", "In conclusion...") provide clear auditory structure to listeners during oral presentations.',
        hints: ['Auditory roadmaps for the audience.']
      },
      {
        id: 'eng1-w12-p3',
        questionText: 'What is a recommended design practice for academic presentation slides?',
        options: ['Use high-contrast visuals with concise bullet points and large readable fonts', 'Paste entire paragraphs of text in 10pt font', 'Use flashing multicolored animations on every slide', 'Read verbatim from the slide without facing the audience'],
        correctOptionIndex: 0,
        solution: 'Slides should serve as high-contrast visual anchors with large readable text, while the speaker provides the in-depth verbal narrative.',
        hints: ['High legibility and minimal clutter.']
      }
    ],
    keyTakeaways: [
      'Clear, professional email etiquette builds fruitful academic and industry working relationships.',
      'Oral signposting turns complex technical presentations into engaging narratives.'
    ],
    markdownContent: `### Week 12: Professional Communication\nEmail protocols, formal letter drafting, slide design, and presentation signposting.`,
    examTips: ['Include your course code and student ID in the subject line of every academic email inquiry!']
  }
];

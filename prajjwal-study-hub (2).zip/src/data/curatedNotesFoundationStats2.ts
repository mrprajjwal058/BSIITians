import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_STATS_2_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-stats2-w1',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Joint Distributions, Marginal Distributions & Statistical Independence',
    detailedNotes: `### Week 1: Bivariate Random Variables & Joint Probability Structures

#### 1. Joint Probability Mass/Density Function
- **Discrete:** $p_{X, Y}(x, y) = P(X = x, Y = y)$ where $\\sum_x \\sum_y p_{X, Y}(x, y) = 1$.
- **Continuous:** $f_{X, Y}(x, y) \\ge 0$ where $\\int_{-\\infty}^\\infty \\int_{-\\infty}^\\infty f_{X, Y}(x, y) \\, dx \\, dy = 1$.

#### 2. Marginal Probability Distributions
- **Discrete Marginals:**
  $$p_X(x) = \\sum_y p_{X, Y}(x, y), \\quad p_Y(y) = \\sum_x p_{X, Y}(x, y)$$
- **Continuous Marginals:**
  $$f_X(x) = \\int_{-\\infty}^\\infty f_{X, Y}(x, y) \\, dy, \\quad f_Y(y) = \\int_{-\\infty}^\\infty f_{X, Y}(x, y) \\, dx$$

#### 3. Conditional Distributions & Independence
- **Conditional PDF/PMF:**
  $$f_{Y \\mid X}(y \\mid x) = \\frac{f_{X, Y}(x, y)}{f_X(x)} \\quad (f_X(x) > 0)$$
- **Independence Criterion:** Random variables $X$ and $Y$ are independent if and only if:
  $$f_{X, Y}(x, y) = f_X(x) \\cdot f_Y(y) \\quad \\forall x, y$$`,
    quickRevisionNotes: [
      'Marginal distribution is obtained by integrating/summing out the unwanted variable.',
      'Conditional distribution: $f_{Y|X}(y|x) = \\frac{f_{X,Y}(x,y)}{f_X(x)}$.',
      'Independence condition: $f_{X, Y}(x, y) = f_X(x) f_Y(y)$ everywhere.',
      'Joint CDF: $F_{X, Y}(x, y) = P(X \\le x, Y \\le y)$.'
    ],
    formulaSheets: [
      {
        name: 'Marginal Density Integration',
        formula: 'f_X(x) = \\int_{-\\infty}^\\infty f_{X, Y}(x, y) \\, dy',
        description: 'Summing out variable Y to extract marginal distribution of X.'
      },
      {
        name: 'Joint Independence Factorization',
        formula: 'f_{X, Y}(x, y) = f_X(x) \\cdot f_Y(y)',
        description: 'Necessary and sufficient condition for bivariate statistical independence.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w1-p1',
        questionText: 'Let $f(x, y) = c(x + y)$ for $0 \\le x \\le 1, 0 \\le y \\le 1$. Find constant $c$.',
        options: ['1', '2', '1/2', '4'],
        correctOptionIndex: 0,
        solution: '$\\int_0^1 \\int_0^1 c(x + y) dx dy = c \\int_0^1 [x^2/2 + xy]_0^1 dy = c \\int_0^1 (1/2 + y) dy = c [y/2 + y^2/2]_0^1 = c(1/2 + 1/2) = c$. Setting $c = 1$.',
        hints: ['Evaluate the double integral over the unit square and equate to 1.']
      },
      {
        id: 'stats2-w1-p2',
        questionText: 'If $f_{X, Y}(x, y) = 4xy$ for $0 \\le x \\le 1, 0 \\le y \\le 1$, are $X$ and $Y$ independent?',
        options: ['Yes, because f(x, y) = (2x)(2y) = f_X(x) f_Y(y)', 'No, because they are defined on the same unit square', 'No, because correlation is non-zero', 'Cannot be determined without covariance'],
        correctOptionIndex: 0,
        solution: '$f_X(x) = \\int_0^1 4xy dy = 4x [y^2/2]_0^1 = 2x$. $f_Y(y) = 2y$. Since $f_{X,Y}(x,y) = 4xy = (2x)(2y) = f_X(x)f_Y(y)$, $X$ and $Y$ are independent.',
        hints: ['Check if joint density factors into product of marginals.']
      },
      {
        id: 'stats2-w1-p3',
        questionText: 'What is the conditional expectation $E[Y \\mid X = x]$?',
        options: ['\\int_{-\\infty}^\\infty y f_{Y|X}(y|x) dy', '\\int_{-\\infty}^\\infty x f_{X,Y}(x,y) dx', 'E[Y] / E[X]', '\\int_{-\\infty}^\\infty y f_Y(y) dy'],
        correctOptionIndex: 0,
        solution: 'Conditional expectation is the mean of $Y$ with respect to the conditional density $f_{Y|X}(y|x)$: $E[Y|X=x] = \\int y f_{Y|X}(y|x) dy$.',
        hints: ['Use conditional density in standard expectation formula.']
      }
    ],
    keyTakeaways: [
      'Bivariate marginalization integrates out latent variables in probabilistic graphical models.',
      'Factorization of joint densities implies zero mutual dependence.'
    ],
    markdownContent: `### Week 1: Joint & Marginal Distributions\nBivariate density integrals, conditional densities, and independence.`,
    examTips: ['Remember to check that the support (domain region) factors into rectangular bounds when verifying independence!']
  },
  {
    id: 'note-stats2-w2',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Covariance, Correlation & Cauchy-Schwarz Bound',
    detailedNotes: `### Week 2: Joint Moments, Covariance & Pearson Correlation

#### 1. Covariance (Linear Association)
$$\\text{Cov}(X, Y) = \\sigma_{XY} = E[(X - \\mu_X)(Y - \\mu_Y)] = E[XY] - E[X] E[Y]$$
- **Properties:**
  - $\\text{Cov}(X, X) = \\text{Var}(X)$.
  - $\\text{Cov}(aX + b, cY + d) = ac \\text{Cov}(X, Y)$.
  - If $X$ and $Y$ are independent $\\implies \\text{Cov}(X, Y) = 0$. *(The converse is generally FALSE!)*.

#### 2. Pearson Correlation Coefficient ($\\rho$)
$$\\rho_{XY} = \\frac{\\text{Cov}(X, Y)}{\\sigma_X \\sigma_Y} = \\frac{E[XY] - \\mu_X \\mu_Y}{\\sqrt{\\text{Var}(X) \\text{Var}(Y)}}$$
- **Cauchy-Schwarz Inequality Bound:**
  $$-1 \\le \\rho_{XY} \\le +1$$
- **Interpretation:**
  - $\\rho = +1$: Perfect positive deterministic linear relationship ($Y = aX + b, a > 0$).
  - $\\rho = -1$: Perfect negative deterministic linear relationship ($Y = aX + b, a < 0$).
  - $\\rho = 0$: Uncorrelated (no **linear** association; non-linear dependencies may still exist, e.g. $Y = X^2$ for symmetric $X$).`,
    quickRevisionNotes: [
      '$\\text{Cov}(X, Y) = E[XY] - E[X]E[Y]$; $\\text{Cov}(aX+b, cY+d) = ac\\text{Cov}(X,Y)$.',
      'Pearson correlation is bounded: $-1 \\le \\rho \\le 1$.',
      'Independent $\\implies$ Uncorrelated ($\\rho = 0$), but $\\rho = 0$ does NOT imply independence.',
      'Correlation measures ONLY linear associations, not non-linear relationships.'
    ],
    formulaSheets: [
      {
        name: 'Pearson Correlation Coefficient',
        formula: '\\rho_{XY} = \\frac{\\text{Cov}(X, Y)}{\\sigma_X \\sigma_Y}',
        description: 'Dimensionless standardized measure of linear bivariate association.'
      },
      {
        name: 'Bivariate Variance of Linear Sum',
        formula: '\\text{Var}(aX + bY) = a^2 \\text{Var}(X) + b^2 \\text{Var}(Y) + 2ab \\text{Cov}(X, Y)',
        description: 'Variance expansion for joint dependent linear combinations.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w2-p1',
        questionText: 'If $X \\sim U(-1, 1)$ and $Y = X^2$, what is $\\text{Cov}(X, Y)$ and are $X, Y$ independent?',
        options: ['\\text{Cov}(X, Y) = 0, Dependent', '\\text{Cov}(X, Y) = 1/3, Dependent', '\\text{Cov}(X, Y) = 0, Independent', '\\text{Cov}(X, Y) = 1, Independent'],
        correctOptionIndex: 0,
        solution: '$E[X] = 0$. $E[XY] = E[X^3] = 0$ (odd function over symmetric interval). $\\text{Cov}(X, Y) = E[XY] - E[X]E[Y] = 0 - 0 = 0$. However, $Y$ is completely determined by $X$ ($Y = X^2$), so they are heavily dependent.',
        hints: ['Compute $E[X]$ and $E[X^3]$ for uniform distribution on $[-1, 1]$.']
      },
      {
        id: 'stats2-w2-p2',
        questionText: 'If $\\rho(X, Y) = 0.8$, what is $\\rho(-2X + 5, 3Y - 7)$?',
        options: ['-0.8', '0.8', '-1.6', '0.4'],
        correctOptionIndex: 0,
        solution: '$\\text{Cov}(-2X + 5, 3Y - 7) = (-2)(3) \\text{Cov}(X, Y) = -6 \\text{Cov}(X, Y)$. $\\sigma_{-2X+5} = 2\\sigma_X$, $\\sigma_{3Y-7} = 3\\sigma_Y$. $\\rho_{\\text{new}} = \\frac{-6\\text{Cov}(X, Y)}{(2\\sigma_X)(3\\sigma_Y)} = -\\rho(X, Y) = -0.8$.',
        hints: ['Notice the opposite signs in scalar coefficients $-2$ and $+3$.']
      },
      {
        id: 'stats2-w2-p3',
        questionText: 'If $\\text{Var}(X) = 9, \\text{Var}(Y) = 16$, and $\\text{Cov}(X, Y) = 6$, find $\\text{Var}(2X - Y)$.',
        options: ['28', '52', '40', '16'],
        correctOptionIndex: 0,
        solution: '$\\text{Var}(2X - Y) = 2^2 \\text{Var}(X) + (-1)^2 \\text{Var}(Y) + 2(2)(-1)\\text{Cov}(X, Y) = 4(9) + 1(16) - 4(6) = 36 + 16 - 24 = 28$.',
        hints: ['Use $\\text{Var}(aX+bY) = a^2\\text{Var}(X) + b^2\\text{Var}(Y) + 2ab\\text{Cov}(X,Y)$.']
      }
    ],
    keyTakeaways: [
      'Zero correlation does not preclude nonlinear functional dependencies.',
      'Covariance matrices determine confidence ellipses and Mahalanobis distances.'
    ],
    markdownContent: `### Week 2: Covariance & Correlation\nPearson r, linear transformations, and counterexamples to independence.`,
    examTips: ['Watch the signs: multiplying one variable by a negative constant flips the sign of correlation!']
  },
  {
    id: 'note-stats2-w3',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'The Normal Distribution & Standard Normal Transformations',
    detailedNotes: `### Week 3: The Gaussian (Normal) Distribution & Standard Z-Scores

#### 1. Probability Density Function of $X \\sim N(\\mu, \\sigma^2)$
$$f(x) = \\frac{1}{\\sigma \\sqrt{2\\pi}} \\exp\\left( -\\frac{(x - \\mu)^2}{2\\sigma^2} \\right), \\quad -\\infty < x < \\infty$$
- **Moments:** $E[X] = \\mu, \\quad \\text{Var}(X) = \\sigma^2$.
- **Symmetry:** Perfectly symmetric bell curve centered at $\\mu$; $\\text{Mean} = \\text{Median} = \\text{Mode} = \\mu$.
- **Inflection Points:** Occur precisely at $x = \\mu - \\sigma$ and $x = \\mu + \\sigma$.

#### 2. Standardization to Standard Normal $Z \\sim N(0, 1)$
$$Z = \\frac{X - \\mu}{\\sigma}$$
- Standard Normal CDF: $\\Phi(z) = P(Z \\le z) = \\int_{-\\infty}^z \\frac{1}{\\sqrt{2\\pi}} e^{-t^2/2} \\, dt$.
- Symmetry Identity: $\\Phi(-z) = 1 - \\Phi(z)$.

#### 3. The 68-95-99.7 Empirical Rule
- $P(\\mu - \\sigma \\le X \\le \\mu + \\sigma) \\approx 68.27\\%$
- $P(\\mu - 2\\sigma \\le X \\le \\mu + 2\\sigma) \\approx 95.45\\%$
- $P(\\mu - 3\\sigma \\le X \\le \\mu + 3\\sigma) \\approx 99.73\\%$
- Critical $Z$-values: $Z_{0.025} = 1.96$ (for $95\\%$ two-tailed area), $Z_{0.005} = 2.576$ (for $99\\%$).`,
    quickRevisionNotes: [
      'Gaussian bell curve is symmetric around $\\mu$ with inflection points at $\\mu \\pm \\sigma$.',
      'Standardization formula: $Z = \\frac{X - \\mu}{\\sigma}$.',
      '68-95-99.7 empirical rule governs 1, 2, and 3 standard deviations.',
      'Symmetry property: $\\Phi(-z) = 1 - \\Phi(z)$ and $P(Z > z) = 1 - \\Phi(z)$.'
    ],
    formulaSheets: [
      {
        name: 'Standard Normal Z-Score',
        formula: 'Z = \\frac{X - \\mu}{\\sigma} \\sim N(0, 1)',
        description: 'Affine transformation reducing any normal variable to standard normal.'
      },
      {
        name: 'Gaussian Inflection Coordinates',
        formula: 'x = \\mu \\pm \\sigma',
        description: 'Points where second derivative of Gaussian density vanishes.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w3-p1',
        questionText: 'If $X \\sim N(\\mu = 50, \\sigma^2 = 25)$, what is $P(X > 60)$ given $\\Phi(2) = 0.9772$?',
        options: ['0.0228', '0.9772', '0.05', '0.0456'],
        correctOptionIndex: 0,
        solution: '$\\sigma = \\sqrt{25} = 5$. $Z = \\frac{60 - 50}{5} = \\frac{10}{5} = 2$. $P(X > 60) = P(Z > 2) = 1 - \\Phi(2) = 1 - 0.9772 = 0.0228$.',
        hints: ['Convert 60 to a standard Z-score using $\\sigma = 5$.']
      },
      {
        id: 'stats2-w3-p2',
        questionText: 'Where do the points of inflection occur for $X \\sim N(100, 16)$?',
        options: ['96 and 104', '92 and 108', '100 and 116', '84 and 116'],
        correctOptionIndex: 0,
        solution: '$\\sigma = \\sqrt{16} = 4$. Inflection points occur at $\\mu \\pm \\sigma = 100 \\pm 4 = 96$ and $104$.',
        hints: ['Inflection points are at $\\mu - \\sigma$ and $\\mu + \\sigma$.']
      },
      {
        id: 'stats2-w3-p3',
        questionText: 'If $X_1 \\sim N(10, 4)$ and $X_2 \\sim N(20, 9)$ are independent, what is the distribution of $W = 2X_1 - X_2$?',
        options: ['N(0, 25)', 'N(0, 1)', 'N(0, 17)', 'N(0, 7)'],
        correctOptionIndex: 0,
        solution: '$E[W] = 2(10) - 20 = 0$. $\\text{Var}(W) = 2^2 \\text{Var}(X_1) + (-1)^2 \\text{Var}(X_2) = 4(4) + 1(9) = 16 + 9 = 25$. Linear combinations of independent normal variables are normal: $W \\sim N(0, 25)$.',
        hints: ['Linear combination of normal variables is normal. Add scaled variances.']
      }
    ],
    keyTakeaways: [
      'Normal distribution is the maximum entropy distribution for a specified mean and variance.',
      'Linear combinations of independent normal random variables are always normally distributed.'
    ],
    markdownContent: `### Week 3: The Gaussian Distribution\nStandard normal Z transformations, empirical rules, and linear combinations.`,
    examTips: ['Be careful when given variance $\\sigma^2$: always take the square root to get standard deviation $\\sigma$ before computing $Z$!']
  },
  {
    id: 'note-stats2-w4',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Central Limit Theorem (CLT) & Law of Large Numbers (LLN)',
    detailedNotes: `### Week 4: Asymptotic Theory, LLN & Central Limit Theorem

#### 1. Law of Large Numbers (LLN)
Let $X_1, X_2, \\dots, X_n$ be i.i.d. random variables with finite mean $\\mu$:
- **Weak LLN:** $\\lim_{n \\to \\infty} P(|\\bar{X}_n - \\mu| \\ge \\epsilon) = 0$ for any $\\epsilon > 0$ (Convergence in probability).
- Sample mean $\\bar{X}_n$ converges consistently to the population mean $\\mu$.

#### 2. The Central Limit Theorem (CLT)
Let $X_1, X_2, \\dots, X_n$ be i.i.d. random variables from **any distribution** with finite mean $\\mu$ and finite variance $\\sigma^2$:
As $n \\to \\infty$, the standardized sample mean converges in distribution to a Standard Normal:
$$Z_n = \\frac{\\bar{X}_n - \\mu}{\\sigma / \\sqrt{n}} \\xrightarrow{d} N(0, 1)$$
- **Sample Mean Distribution:** $\\bar{X}_n \\approx N\\left( \\mu, \\frac{\\sigma^2}{n} \\right)$.
- **Sample Sum Distribution:** $S_n = \\sum_{i=1}^n X_i \\approx N(n\\mu, n\\sigma^2)$.
- **Rule of Thumb:** $n \\ge 30$ is generally sufficient for moderate skewness.`,
    quickRevisionNotes: [
      'CLT holds for ANY underlying distribution provided mean $\\mu$ and variance $\\sigma^2$ are finite.',
      'Standard error of the sample mean is $\\text{SE}(\\bar{X}) = \\frac{\\sigma}{\\sqrt{n}}$.',
      'As sample size $n$ quadruples ($4\\times$), standard error is halved ($1/2$).',
      'Sample sum $S_n \\sim N(n\\mu, n\\sigma^2)$.'
    ],
    formulaSheets: [
      {
        name: 'Central Limit Theorem Asymptotic Form',
        formula: 'Z = \\frac{\\bar{X} - \\mu}{\\sigma / \\sqrt{n}} \\xrightarrow{d} N(0, 1)',
        description: 'Standardized sample mean asymptotic convergence to standard normal.'
      },
      {
        name: 'Standard Error of Sample Mean',
        formula: '\\text{SE}(\\bar{X}) = \\frac{\\sigma}{\\sqrt{n}}',
        description: 'Standard deviation of the sampling distribution of the mean.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w4-p1',
        questionText: 'A distribution has mean $\\mu = 100$ and $\\sigma = 20$. A random sample of size $n = 64$ is drawn. What is the standard error of the sample mean?',
        options: ['2.5', '20', '3.125', '0.3125'],
        correctOptionIndex: 0,
        solution: '$\\text{SE}(\\bar{X}) = \\frac{\\sigma}{\\sqrt{n}} = \\frac{20}{\\sqrt{64}} = \\frac{20}{8} = 2.5$.',
        hints: ['Divide $\\sigma$ by $\\sqrt{n}$.']
      },
      {
        id: 'stats2-w4-p2',
        questionText: 'By what factor must the sample size $n$ increase to reduce the standard error of the mean by half?',
        options: ['4 times', '2 times', '16 times', '\\sqrt{2} times'],
        correctOptionIndex: 0,
        solution: 'Since $\\text{SE} = \\sigma / \\sqrt{n}$, halving SE requires $\\sqrt{n_{\\text{new}}} = 2\\sqrt{n_{\\text{old}}} \\implies n_{\\text{new}} = 4 n_{\\text{old}}$.',
        hints: ['Set $\\sigma/\\sqrt{n_{\\text{new}}} = 0.5 (\\sigma/\\sqrt{n})$.']
      },
      {
        id: 'stats2-w4-p3',
        questionText: 'Which assumption is strictly necessary for the classical Lindeberg-Lévy Central Limit Theorem to hold?',
        options: ['Finite population variance \\sigma^2 < \\infty', 'Underlying population must be symmetric', 'Underlying population must be normal', 'Sample size must exceed 1000'],
        correctOptionIndex: 0,
        solution: 'The classical CLT requires observations to be i.i.d. with finite mean $\\mu$ and finite variance $\\sigma^2 < \\infty$. (Distributions like Cauchy with infinite variance do not obey CLT).',
        hints: ['Consider distributions with undefined or infinite variance.']
      }
    ],
    keyTakeaways: [
      'CLT justifies constructing Gaussian confidence intervals even when data is non-normal.',
      'Diminishing returns of sampling error: halving error requires $4\\times$ more data.'
    ],
    markdownContent: `### Week 4: CLT & Asymptotic Statistics\nSampling distributions of the mean, standard errors, and sample size scaling.`,
    examTips: ['Remember to divide $\\sigma$ by $\\sqrt{n}$ when computing Z-scores for sample means $\\bar{X}$!']
  },
  {
    id: 'note-stats2-w5',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Sampling Distributions: Chi-Square, Student\'s t & Snedecor\'s F',
    detailedNotes: `### Week 5: Exact Sampling Distributions ($\\chi^2, t, F$)

#### 1. Chi-Square Distribution: $\\chi^2_k$
Let $Z_1, Z_2, \\dots, Z_k \\stackrel{\\text{iid}}{\\sim} N(0, 1)$:
$$V = \\sum_{i=1}^k Z_i^2 \\sim \\chi^2_k \\quad (k \\text{ degrees of freedom})$$
- **Moments:** $E[V] = k, \\quad \\text{Var}(V) = 2k$.
- **Sample Variance Distribution (Normal population):**
  $$\\frac{(n - 1)s^2}{\\sigma^2} \\sim \\chi^2_{n - 1}$$

#### 2. Student\'s $t$-Distribution: $t_k$
Ratio of a standard normal to the square root of an independent normalized chi-square:
$$T = \\frac{Z}{\\sqrt{V / k}} \\sim t_k \\quad (Z \\sim N(0, 1), V \\sim \\chi^2_k)$$
- Symmetric bell curve with heavier tails than $N(0, 1)$; as $k \\to \\infty$, $t_k \\xrightarrow{d} N(0, 1)$.
- $E[T] = 0 \\quad (k > 1), \\quad \\text{Var}(T) = \\frac{k}{k - 2} \\quad (k > 2)$.

#### 3. Snedecor\'s $F$-Distribution: $F_{d_1, d_2}$
Ratio of two independent chi-square variables divided by their degrees of freedom:
$$F = \\frac{V_1 / d_1}{V_2 / d_2} \\sim F_{d_1, d_2} \\quad (V_1 \\sim \\chi^2_{d_1}, V_2 \\sim \\chi^2_{d_2})$$
- **Relationship:** If $T \\sim t_k$, then $T^2 \\sim F_{1, k}$.`,
    quickRevisionNotes: [
      'Sum of squares of $k$ independent standard normal variables is $\\chi^2_k$ with Mean $= k$ and Variance $= 2k$.',
      'Sample variance pivot: $\\frac{(n-1)s^2}{\\sigma^2} \\sim \\chi^2_{n-1}$.',
      'Student\'s $t$: $T = \\frac{Z}{\\sqrt{V/k}}$ has heavier tails than normal, converges to $N(0,1)$ as $k \\to \\infty$.',
      'Square of $t_k$ variable is an $F_{1, k}$ variable ($T^2 \\sim F_{1, k}$).'
    ],
    formulaSheets: [
      {
        name: 'Sample Variance Chi-Square Pivot',
        formula: '\\frac{(n - 1)s^2}{\\sigma^2} \\sim \\chi^2_{n - 1}',
        description: 'Exact sampling distribution of sample variance for normal populations.'
      },
      {
        name: 'Student\'s t-Statistic Definition',
        formula: 'T = \\frac{\\bar{X} - \\mu}{s / \\sqrt{n}} \\sim t_{n - 1}',
        description: 'T-statistic when population variance is unknown.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w5-p1',
        questionText: 'If $V \\sim \\chi^2_{10}$, what is $E[V]$ and $\\text{Var}(V)$?',
        options: ['E[V] = 10, Var(V) = 20', 'E[V] = 10, Var(V) = 10', 'E[V] = 20, Var(V) = 40', 'E[V] = 5, Var(V) = 10'],
        correctOptionIndex: 0,
        solution: 'For $\\chi^2_k$, mean is $k$ and variance is $2k$. With $k = 10$: $E[V] = 10, \\text{Var}(V) = 2(10) = 20$.',
        hints: ['Mean of chi-square is $k$, variance is $2k$.']
      },
      {
        id: 'stats2-w5-p2',
        questionText: 'What is the relationship between a Student\'s $t$-distribution with $k$ degrees of freedom and an $F$-distribution?',
        options: ['T^2 \\sim F_{1, k}', 'T^2 \\sim F_{k, 1}', 'T \\sim \\sqrt{F_{k, k}}', 'T^2 \\sim \\chi^2_k'],
        correctOptionIndex: 0,
        solution: '$T^2 = \\frac{Z^2}{V/k} = \\frac{\\chi^2_1 / 1}{\\chi^2_k / k} \\sim F_{1, k}$.',
        hints: ['Square the $t$-statistic expression.']
      },
      {
        id: 'stats2-w5-p3',
        questionText: 'Under what condition does the $t$-distribution become identical to the standard normal distribution $N(0, 1)$?',
        options: ['As degrees of freedom k \\to \\infty', 'When k = 1', 'When variance is 1', 'When sample size is small (n < 5)'],
        correctOptionIndex: 0,
        solution: 'As $k \\to \\infty$, the denominator $\\sqrt{V/k} \\xrightarrow{p} 1$ by LLN, so $T \\xrightarrow{d} Z \\sim N(0, 1)$.',
        hints: ['Consider infinite degrees of freedom.']
      }
    ],
    keyTakeaways: [
      'Student\'s $t$ handles parameter uncertainty when estimating variance from small samples.',
      '$F$-distributions govern ANOVA and regression omnibus tests.'
    ],
    markdownContent: `### Week 5: Sampling Distributions\nChi-square, Student t, and Snedecor F distributions and pivot statistics.`,
    examTips: ['Degrees of freedom for sample variance of $n$ observations from normal is always $n - 1$!']
  },
  {
    id: 'note-stats2-w6',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Point Estimation: Unbiasedness, Efficiency, Consistency & MSE',
    detailedNotes: `### Week 6: Point Estimation & Desirable Properties of Estimators

#### 1. Point Estimator ($\\hat{\\theta}$)
A statistic $T(X_1, \\dots, X_n)$ used to estimate an unknown population parameter $\\theta$.

#### 2. Desirable Properties of Estimators
1. **Unbiasedness:**
   $$\\text{Bias}(\\hat{\\theta}) = E[\\hat{\\theta}] - \\theta = 0 \\iff E[\\hat{\\theta}] = \\theta$$
   - $\\bar{X}$ is an unbiased estimator of $\\mu$.
   - $S^2 = \\frac{1}{n-1}\\sum (X_i - \\bar{X})^2$ is an unbiased estimator of $\\sigma^2$.
2. **Mean Squared Error (MSE):**
   $$\\text{MSE}(\\hat{\\theta}) = E[(\\hat{\\theta} - \\theta)^2] = \\text{Var}(\\hat{\\theta}) + [\\text{Bias}(\\hat{\\theta})]^2$$
   *(Bias-Variance Tradeoff: A slightly biased estimator with much lower variance can have smaller MSE than an unbiased one).*
3. **Efficiency:** An unbiased estimator $\\hat{\\theta}_1$ is more efficient than $\\hat{\\theta}_2$ if $\\text{Var}(\\hat{\\theta}_1) < \\text{Var}(\\hat{\\theta}_2)$.
4. **Consistency:** $\\hat{\\theta}_n \\xrightarrow{p} \\theta$ as $n \\to \\infty$ (MSE $\\to 0$).`,
    quickRevisionNotes: [
      'Unbiasedness: $E[\\hat{\\theta}] = \\theta$; Bias $= E[\\hat{\\theta}] - \\theta$.',
      'MSE decomposition: $\\text{MSE}(\\hat{\\theta}) = \\text{Var}(\\hat{\\theta}) + (\\text{Bias})^2$.',
      'Relative efficiency: Ratio of estimator variances $\\text{Var}(\\hat{\\theta}_2)/\\text{Var}(\\hat{\\theta}_1)$.',
      'Consistency requires both Bias $\\to 0$ and $\\text{Var} \\to 0$ as $n \\to \\infty$.'
    ],
    formulaSheets: [
      {
        name: 'MSE Bias-Variance Decomposition',
        formula: '\\text{MSE}(\\hat{\\theta}) = \\text{Var}(\\hat{\\theta}) + [\\text{Bias}(\\hat{\\theta})]^2',
        description: 'Fundamental decomposition of estimation error into variance and squared bias.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w6-p1',
        questionText: 'An estimator has $\\text{Var}(\\hat{\\theta}) = 4$ and $\\text{Bias}(\\hat{\\theta}) = 3$. What is its MSE?',
        options: ['13', '7', '25', '1'],
        correctOptionIndex: 0,
        solution: '$\\text{MSE} = \\text{Var}(\\hat{\\theta}) + (\\text{Bias})^2 = 4 + 3^2 = 4 + 9 = 13$.',
        hints: ['Use $\\text{MSE} = \\text{Var} + \\text{Bias}^2$.']
      },
      {
        id: 'stats2-w6-p2',
        questionText: 'Is the sample variance divisor $n$ estimator $S_n^2 = \\frac{1}{n}\\sum (X_i - \\bar{X})^2$ unbiased for $\\sigma^2$?',
        options: ['No, it is biased with $E[S_n^2] = \\frac{n-1}{n}\\sigma^2$', 'Yes, it is strictly unbiased', 'No, it overestimates variance', 'It depends on whether data is normal'],
        correctOptionIndex: 0,
        solution: '$E[S_n^2] = \\frac{n-1}{n}\\sigma^2 < \\sigma^2$, so it systematically underestimates $\\sigma^2$ by a factor of $(n-1)/n$.',
        hints: ['Recall why Bessel\'s correction uses $n - 1$.']
      },
      {
        id: 'stats2-w6-p3',
        questionText: 'If an estimator is unbiased, what does its MSE equal?',
        options: ['Its variance', 'Zero', 'Its bias', 'Infinity'],
        correctOptionIndex: 0,
        solution: 'When $\\text{Bias} = 0$, $\\text{MSE}(\\hat{\\theta}) = \\text{Var}(\\hat{\\theta}) + 0^2 = \\text{Var}(\\hat{\\theta})$.',
        hints: ['Substitute $\\text{Bias} = 0$ into the MSE equation.']
      }
    ],
    keyTakeaways: [
      'The bias-variance tradeoff governs machine learning regularization techniques like Ridge and Lasso.',
      'Consistency guarantees asymptotic convergence to ground truth parameters.'
    ],
    markdownContent: `### Week 6: Point Estimation Theory\nUnbiasedness, efficiency, consistency, and MSE decompositions.`,
    examTips: ['MSE can never be smaller than the variance of an estimator!']
  },
  {
    id: 'note-stats2-w7',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Maximum Likelihood Estimation (MLE) & Method of Moments (MOM)',
    detailedNotes: `### Week 7: Parameter Estimation: MLE & Method of Moments

#### 1. Method of Moments (MOM)
Equate population theoretical moments $\\mu_k = E[X^k]$ to sample raw moments $m_k = \\frac{1}{n}\\sum_{i=1}^n X_i^k$:
$$\\begin{cases} E[X] = \\bar{X} \\\\ E[X^2] = \\frac{1}{n}\\sum X_i^2 \\end{cases}$$

#### 2. Maximum Likelihood Estimation (MLE)
Given sample $\\mathbf{x} = \\{x_1, \\dots, x_n\\}$:
- **Likelihood Function:** $L(\\theta) = \\prod_{i=1}^n f(x_i; \\theta)$.
- **Log-Likelihood Function:** $\\ell(\\theta) = \\ln L(\\theta) = \\sum_{i=1}^n \\ln f(x_i; \\theta)$.
- **Score Equation:**
  $$\\frac{d \\ell(\\theta)}{d \\theta} = 0 \\quad \\text{and verify } \\left. \\frac{d^2 \\ell(\\theta)}{d \\theta^2} \\right|_{\\hat{\\theta}} < 0$$
- **Invariance Property of MLE:** If $\\hat{\\theta}$ is the MLE of $\\theta$, then $g(\\hat{\\theta})$ is the MLE of $g(\\theta)$.
- **Asymptotic Optimality:** Under regularity conditions, MLE is asymptotically unbiased, consistent, and achieves the Cramér-Rao Lower Bound (CRLB).`,
    quickRevisionNotes: [
      'MOM equates sample moments to theoretical population moments: $m_k = \\mu_k$.',
      'MLE maximizes log-likelihood $\\ell(\\theta) = \\sum \\ln f(x_i; \\theta)$.',
      'Invariance: MLE of $g(\\theta)$ is simply $g(\\hat{\\theta}_{\\text{MLE}})$.',
      'MLE for Normal mean $\\mu$ is $\\bar{X}$; MLE for $\\sigma^2$ is $\\frac{1}{n}\\sum (x_i - \\bar{x})^2$ (biased by $(n-1)/n$).'
    ],
    formulaSheets: [
      {
        name: 'Log-Likelihood Score Equation',
        formula: '\\frac{\\partial \\ell(\\theta)}{\\partial \\theta} = \\frac{\\partial}{\\partial \\theta} \\sum_{i=1}^n \\ln f(x_i; \\theta) = 0',
        description: 'First-order condition for maximum likelihood parameter estimation.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w7-p1',
        questionText: 'Find the MLE of $\\lambda$ for i.i.d. observations $X_1, \\dots, X_n \\sim \\text{Poisson}(\\lambda)$.',
        options: ['\\hat{\\lambda} = \\bar{X}', '\\hat{\\lambda} = 1/\\bar{X}', '\\hat{\\lambda} = \\sqrt{\\bar{X}}', '\\hat{\\lambda} = S^2'],
        correctOptionIndex: 0,
        solution: '$L(\\lambda) = \\prod \\frac{e^{-\\lambda} \\lambda^{x_i}}{x_i!} = e^{-n\\lambda} \\lambda^{\\sum x_i} / \\prod x_i!$. $\\ell(\\lambda) = -n\\lambda + (\\sum x_i)\\ln \\lambda - \\sum \\ln(x_i!)$. Setting $\\frac{d\\ell}{d\\lambda} = -n + \\frac{\\sum x_i}{\\lambda} = 0 \\implies \\hat{\\lambda} = \\frac{\\sum x_i}{n} = \\bar{X}$.',
        hints: ['Differentiate log-likelihood with respect to $\\lambda$.']
      },
      {
        id: 'stats2-w7-p2',
        questionText: 'For $X_1, \\dots, X_n \\sim \\text{Exp}(\\lambda)$ with PDF $f(x) = \\lambda e^{-\\lambda x}$, what is the MLE of the mean lifetime $\\theta = 1/\\lambda$?',
        options: ['\\hat{\\theta} = \\bar{X}', '\\hat{\\theta} = 1/\\bar{X}', '\\hat{\\theta} = n \\bar{X}', '\\hat{\\theta} = \\bar{X}^2'],
        correctOptionIndex: 0,
        solution: 'The MLE of $\\lambda$ is $\\hat{\\lambda} = 1/\\bar{X}$. By the Invariance Property of MLE, the MLE of $\\theta = 1/\\lambda$ is $\\hat{\\theta} = 1/\\hat{\\lambda} = \\bar{X}$.',
        hints: ['Apply the invariance property to $\\hat{\\lambda} = 1/\\bar{X}$.']
      },
      {
        id: 'stats2-w7-p3',
        questionText: 'Find the MOM estimator of $p$ for $X_1, \\dots, X_n \\sim \\text{Bernoulli}(p)$.',
        options: ['\\hat{p} = \\bar{X}', '\\hat{p} = 1 - \\bar{X}', '\\hat{p} = \\bar{X}(1 - \\bar{X})', '\\hat{p} = \\sqrt{\\bar{X}}'],
        correctOptionIndex: 0,
        solution: 'Theoretical moment $\\mu_1 = E[X] = p$. Sample moment $m_1 = \\bar{X}$. Equating $\\mu_1 = m_1 \\implies \\hat{p} = \\bar{X}$.',
        hints: ['Equate $E[X] = p$ to sample mean $\\bar{X}$.']
      }
    ],
    keyTakeaways: [
      'MLE underpins logistic regression, neural network cross-entropy loss, and parameter fitting.',
      'Log transformation turns product likelihoods into easily differentiable sums.'
    ],
    markdownContent: `### Week 7: MLE & Method of Moments\nLikelihood functions, score equations, and invariance properties.`,
    examTips: ['Always verify the second derivative $\\ell\'\'(\\theta) < 0$ to confirm you found a maximum, not a minimum!']
  },
  {
    id: 'note-stats2-w8',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Confidence Intervals for Means, Proportions & Variance',
    detailedNotes: `### Week 8: Interval Estimation & Confidence Intervals

#### 1. Conceptual Meaning of a $(1 - \\alpha)$ Confidence Interval
In repeated independent sampling, $(1 - \\alpha) \\times 100\\%$ of constructed intervals will contain the true fixed parameter $\\theta$. *(The parameter $\\theta$ is fixed, not random; the random element is the interval endpoints).*

#### 2. Confidence Intervals for Population Mean $\\mu$
- **Case 1: Known Population Variance $\\sigma^2$ (or large $n \\ge 30$):**
  $$\\bar{x} \\pm z_{\\alpha/2} \\frac{\\sigma}{\\sqrt{n}}$$
- **Case 2: Unknown $\\sigma^2$ and Small Sample ($n < 30$, Normal population):**
  $$\\bar{x} \\pm t_{n-1, \\alpha/2} \\frac{s}{\\sqrt{n}}$$

#### 3. Confidence Interval for Population Proportion $p$ (Wald Interval)
$$\\hat{p} \\pm z_{\\alpha/2} \\sqrt{\\frac{\\hat{p}(1 - \\hat{p})}{n}}$$
- **Sample Size Determination for Margin of Error $E$:**
  $$n = \\left( \\frac{z_{\\alpha/2}}{E} \\right)^2 p^*(1 - p^*) \\le \\frac{z_{\\alpha/2}^2}{4 E^2} \\quad (\\text{using worst-case } p^* = 0.5)$$`,
    quickRevisionNotes: [
      'Use $Z$-critical value when $\\sigma$ is known or $n \\ge 30$; use $t_{n-1}$ when $\\sigma$ is estimated via $s$ for small samples.',
      '$95\\%$ CI uses $Z_{0.025} = 1.96$; $99\\%$ uses $Z_{0.005} = 2.576$.',
      'Margin of Error: $E = z_{\\alpha/2} \\frac{\\sigma}{\\sqrt{n}}$.',
      'Worst-case sample size for proportion uses $p(1-p) = 0.25$.'
    ],
    formulaSheets: [
      {
        name: 'Confidence Interval for Mean (t-distribution)',
        formula: '\\bar{x} \\pm t_{n - 1, \\alpha/2} \\frac{s}{\\sqrt{n}}',
        description: 'Exact confidence interval for normal population mean with unknown variance.'
      },
      {
        name: 'Sample Size for Margin of Error',
        formula: 'n = \\left( \\frac{z_{\\alpha/2} \\cdot \\sigma}{E} \\right)^2',
        description: 'Required sample size to achieve margin of error E at level alpha.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w8-p1',
        questionText: 'A sample of size $n = 100$ has mean $\\bar{x} = 50$ and known $\\sigma = 10$. Construct a 95% confidence interval for $\\mu$ ($z_{0.025} = 1.96$).',
        options: ['[48.04, 51.96]', '[49.00, 51.00]', '[40.00, 60.00]', '[47.42, 52.58]'],
        correctOptionIndex: 0,
        solution: '$\\text{Margin of Error} = 1.96 \\times \\frac{10}{\\sqrt{100}} = 1.96 \\times 1 = 1.96$. $\\text{CI} = 50 \\pm 1.96 = [48.04, 51.96]$.',
        hints: ['Use $\\bar{x} \\pm z \\frac{\\sigma}{\\sqrt{n}}$.']
      },
      {
        id: 'stats2-w8-p2',
        questionText: 'To estimate a population proportion with margin of error $E = 0.05$ at 95% confidence ($Z = 1.96$) with no prior estimate of $p$, what is the required sample size?',
        options: ['385', '100', '400', '250'],
        correctOptionIndex: 0,
        solution: 'Using conservative $p^* = 0.5$: $n = \\frac{(1.96)^2 \\times 0.5 \\times 0.5}{(0.05)^2} = \\frac{3.8416 \\times 0.25}{0.0025} = \\frac{0.9604}{0.0025} = 384.16 \\implies 385$.',
        hints: ['Use $n = \\frac{z^2 p(1-p)}{E^2}$ with $p = 0.5$.']
      },
      {
        id: 'stats2-w8-p3',
        questionText: 'What happens to the width of a confidence interval if the sample size $n$ is multiplied by 4 while keeping the confidence level constant?',
        options: ['Width is halved (multiplied by 1/2)', 'Width is doubled', 'Width is divided by 4', 'Width remains unchanged'],
        correctOptionIndex: 0,
        solution: 'Width $= 2 z \\frac{\\sigma}{\\sqrt{n}}$. When $n \\to 4n$, $\\sqrt{4n} = 2\\sqrt{n}$, so the denominator doubles and interval width is halved.',
        hints: ['Width is inversely proportional to $\\sqrt{n}$.']
      }
    ],
    keyTakeaways: [
      'Confidence intervals provide uncertainty bounds rather than single point estimates.',
      'Higher confidence level ($99\\%$ vs $95\\%$) produces wider intervals for fixed sample size.'
    ],
    markdownContent: `### Week 8: Confidence Intervals\nInterval estimations for means, proportions, and sample size planning.`,
    examTips: ['Always round UP sample size calculations to the next whole integer!']
  },
  {
    id: 'note-stats2-w9',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Hypothesis Testing Framework: Hypotheses, Errors & p-Values',
    detailedNotes: `### Week 9: The Statistical Hypothesis Testing Framework

#### 1. Null ($H_0$) & Alternative ($H_1$) Hypotheses
- **Null Hypothesis ($H_0$):** Statement of no effect, equality, or status quo (e.g. $\\mu = \\mu_0$). Always contains the equality condition ($=, \\le, \\ge$).
- **Alternative Hypothesis ($H_1$):** Research claim of difference or effect.
  - Two-tailed: $H_1: \\mu \\ne \\mu_0$.
  - Right-tailed: $H_1: \\mu > \\mu_0$.
  - Left-tailed: $H_1: \\mu < \\mu_0$.

#### 2. Decision Errors & Statistical Power
- **Type I Error ($\\alpha$, Significance Level):** Rejecting $H_0$ when $H_0$ is TRUE (False Positive).
  $$\\alpha = P(\\text{Reject } H_0 \\mid H_0 \\text{ is True})$$
- **Type II Error ($\\beta$):** Failing to reject $H_0$ when $H_0$ is FALSE (False Negative).
  $$\\beta = P(\\text{Fail to Reject } H_0 \\mid H_0 \\text{ is False})$$
- **Statistical Power ($1 - \\beta$):** Probability of correctly rejecting a false null hypothesis:
  $$\\text{Power} = 1 - \\beta = P(\\text{Reject } H_0 \\mid H_1 \\text{ is True})$$

#### 3. The $p$-Value Approach
The **$p$-value** is the probability of observing a test statistic as extreme as, or more extreme than, the sample result under the assumption that $H_0$ is true.
- **Decision Rule:**
  - If $p\\text{-value} \\le \\alpha \\implies$ **Reject $H_0$** (Statistically significant).
  - If $p\\text{-value} > \\alpha \\implies$ **Fail to Reject $H_0$**.`,
    quickRevisionNotes: [
      'Type I error ($\\alpha$): False positive (Reject true $H_0$); Type II error ($\\beta$): False negative (Retain false $H_0$).',
      'Power of the test $= 1 - \\beta$.',
      'Decision rule: Reject $H_0$ if $p\\text{-value} \\le \\alpha$.',
      '$H_0$ always includes the equals sign ($=, \\le, \\ge$).'
    ],
    formulaSheets: [
      {
        name: 'Statistical Power',
        formula: '\\text{Power} = 1 - \\beta = P(\\text{Reject } H_0 \\mid H_1 \\text{ is True})',
        description: 'Probability of detecting a real effect when one exists.'
      },
      {
        name: 'p-Value Decision Rule',
        formula: 'p\\text{-value} \\le \\alpha \\implies \\text{Reject } H_0',
        description: 'Universal criterion for statistical significance testing.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w9-p1',
        questionText: 'If a test is conducted at $\\alpha = 0.05$ and yields a $p$-value of 0.018, what is the conclusion?',
        options: ['Reject H_0 (Statistically significant at 5% level)', 'Fail to reject H_0', 'Accept H_0 with 98.2% confidence', 'Type I error has occurred with certainty'],
        correctOptionIndex: 0,
        solution: 'Since $p\\text{-value} = 0.018 \\le \\alpha = 0.05$, we reject $H_0$ in favor of $H_1$.',
        hints: ['Compare $p$-value with $\\alpha$.']
      },
      {
        id: 'stats2-w9-p2',
        questionText: 'What is a Type II error?',
        options: ['Failing to reject H_0 when H_0 is false', 'Rejecting H_0 when H_0 is true', 'Calculating the wrong p-value', 'Choosing a two-tailed test instead of one-tailed'],
        correctOptionIndex: 0,
        solution: 'A Type II error ($\\beta$) occurs when the null hypothesis is false, but the test fails to detect the effect and retains $H_0$ (False Negative).',
        hints: ['Type I is False Alarm, Type II is Missed Detection.']
      },
      {
        id: 'stats2-w9-p3',
        questionText: 'How can you increase the statistical power ($1 - \\beta$) of a hypothesis test without increasing $\\alpha$?',
        options: ['Increase sample size n', 'Decrease sample size n', 'Decrease significance level \\alpha', 'Use a two-tailed test instead of one-tailed'],
        correctOptionIndex: 0,
        solution: 'Increasing sample size $n$ reduces standard error, narrowing distributions and increasing power $1 - \\beta$ for any fixed $\\alpha$.',
        hints: ['Larger sample sizes reduce estimation variance.']
      }
    ],
    keyTakeaways: [
      'Hypothesis testing provides a formal decision framework under probabilistic uncertainty.',
      'Significance level $\\alpha$ is the pre-committed tolerance for false alarms.'
    ],
    markdownContent: `### Week 9: Hypothesis Testing Foundations\nNull vs alternative hypotheses, Type I/II errors, and p-value decision criteria.`,
    examTips: ['Remember: we NEVER "accept" $H_0$; we either "reject $H_0$" or "fail to reject $H_0$"!']
  },
  {
    id: 'note-stats2-w10',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Parametric Tests: One-Sample & Two-Sample Z-Tests and t-Tests',
    detailedNotes: `### Week 10: Parametric Hypothesis Tests for Means

#### 1. One-Sample Tests
- **$Z$-Test (Known $\\sigma$ or large $n$):** $Z = \\frac{\\bar{X} - \\mu_0}{\\sigma / \\sqrt{n}} \\sim N(0, 1)$.
- **$t$-Test (Unknown $\\sigma$, Normal population):** $T = \\frac{\\bar{X} - \\mu_0}{s / \\sqrt{n}} \\sim t_{n-1}$.

#### 2. Two Independent Samples $t$-Test
Testing $H_0: \\mu_1 - \\mu_2 = \\Delta_0$:
- **Equal Variance Assumption ($\\sigma_1^2 = \\sigma_2^2$ - Pooled $t$-test):**
  $$T = \\frac{(\\bar{X}_1 - \\bar{X}_2) - \\Delta_0}{s_p \\sqrt{\\frac{1}{n_1} + \\frac{1}{n_2}}} \\sim t_{n_1 + n_2 - 2}$$
  Where pooled variance is:
  $$s_p^2 = \\frac{(n_1 - 1)s_1^2 + (n_2 - 1)s_2^2}{n_1 + n_2 - 2}$$

#### 3. Paired Samples $t$-Test (Matched Pairs / Before-After)
For dependent pairs $(X_{1i}, X_{2i})$, let differences be $D_i = X_{1i} - X_{2i}$:
$$T = \\frac{\\bar{D} - \\mu_{D0}}{s_D / \\sqrt{n}} \\sim t_{n-1}$$`,
    quickRevisionNotes: [
      'One-sample $t$-test has $n-1$ degrees of freedom.',
      'Two-sample pooled $t$-test has $n_1 + n_2 - 2$ degrees of freedom.',
      'Paired $t$-test reduces bivariate paired data to 1D difference vector $D_i = X_{1i} - X_{2i}$ with $n-1$ df.',
      'Pooled variance $s_p^2$ is a weighted average of individual sample variances.'
    ],
    formulaSheets: [
      {
        name: 'Two-Sample Pooled Variance',
        formula: 's_p^2 = \\frac{(n_1 - 1)s_1^2 + (n_2 - 1)s_2^2}{n_1 + n_2 - 2}',
        description: 'Weighted combination variance for equal-variance two-sample t-test.'
      },
      {
        name: 'Paired t-Statistic',
        formula: 'T = \\frac{\\bar{d} - \\mu_{d0}}{s_d / \\sqrt{n}} \\sim t_{n - 1}',
        description: 'Test statistic for dependent pre-post matched paired designs.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w10-p1',
        questionText: 'A sample of 16 students has mean test score $\\bar{x} = 72$ with sample standard deviation $s = 8$. Test $H_0: \\mu = 70$ vs $H_1: \\mu > 70$. What is the test statistic?',
        options: ['T = 1.0, df = 15', 'Z = 1.0', 'T = 0.25, df = 15', 'T = 2.0, df = 16'],
        correctOptionIndex: 0,
        solution: '$T = \\frac{72 - 70}{8 / \\sqrt{16}} = \\frac{2}{8 / 4} = \\frac{2}{2} = 1.0$. Degrees of freedom $= n - 1 = 16 - 1 = 15$.',
        hints: ['Calculate $T = \\frac{\\bar{x} - \\mu_0}{s / \\sqrt{n}}$ and df $= n - 1$.']
      },
      {
        id: 'stats2-w10-p2',
        questionText: 'When testing a blood pressure medication on 10 patients with readings measured before and after drug administration, which test is appropriate?',
        options: ['Paired Samples t-test (df = 9)', 'Two Independent Samples t-test (df = 18)', 'Z-test for two proportions', 'Chi-square test of independence'],
        correctOptionIndex: 0,
        solution: 'Because the measurements are taken on the same subjects (dependent before-after pairs), the Paired Samples $t$-test with $n - 1 = 10 - 1 = 9$ df is appropriate.',
        hints: ['Repeated measures on same individuals $\\implies$ paired test.']
      },
      {
        id: 'stats2-w10-p3',
        questionText: 'In a two-sample pooled $t$-test with $n_1 = 12$ and $n_2 = 15$, what are the degrees of freedom?',
        options: ['25', '27', '26', '12'],
        correctOptionIndex: 0,
        solution: 'Degrees of freedom $= n_1 + n_2 - 2 = 12 + 15 - 2 = 25$.',
        hints: ['Use $\\text{df} = n_1 + n_2 - 2$.']
      }
    ],
    keyTakeaways: [
      'Two-sample tests power A/B testing experiment evaluations in tech companies.',
      'Paired designs eliminate subject-to-subject baseline variance, boosting statistical power.'
    ],
    markdownContent: `### Week 10: Parametric Tests\nZ-tests, independent pooled t-tests, and paired differences.`,
    examTips: ['Always use paired t-test when the same subject is tested twice (before vs after)!']
  },
  {
    id: 'note-stats2-w11',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Chi-Square Goodness-of-Fit & Contingency Table Independence Tests',
    detailedNotes: `### Week 11: Non-Parametric Categorical Tests: $\\chi^2$ Tests

#### 1. Karl Pearson\'s Chi-Square Test Statistic
$$\\chi^2 = \\sum_{i=1}^k \\frac{(O_i - E_i)^2}{E_i}$$
Where $O_i$ is Observed count and $E_i$ is Expected count under $H_0$.

#### 2. Chi-Square Goodness-of-Fit Test
Tests whether observed frequency distribution conforms to a theoretical distribution:
- Degrees of freedom: $\\text{df} = k - 1 - m$ (where $k$ is number of categories and $m$ is number of estimated parameters).
- **Rule of Thumb:** Expected counts must be at least 5 ($E_i \\ge 5$).

#### 3. Chi-Square Test of Independence (Contingency Tables $r \\times c$)
Tests independence of two categorical variables:
- **Expected Cell Frequency:**
  $$E_{ij} = \\frac{(\\text{Row } i \\text{ Total}) \\times (\\text{Column } j \\text{ Total})}{\\text{Grand Total } N}$$
- **Degrees of Freedom:**
  $$\\text{df} = (r - 1)(c - 1)$$`,
    quickRevisionNotes: [
      'Chi-square statistic: $\\chi^2 = \\sum \\frac{(O - E)^2}{E}$.',
      'Contingency table expected cell value: $E_{ij} = \\frac{R_i \\times C_j}{N}$.',
      'Degrees of freedom for $r \\times c$ table: $\\text{df} = (r - 1)(c - 1)$.',
      'Goodness of fit df: $\\text{df} = k - 1 - m$ (subtract parameters estimated from data).'
    ],
    formulaSheets: [
      {
        name: 'Pearson Chi-Square Statistic',
        formula: '\\chi^2 = \\sum_{i=1}^k \\frac{(O_i - E_i)^2}{E_i}',
        description: 'Discrepancy measure between observed and theoretical expected counts.'
      },
      {
        name: 'Contingency Table Expected Value',
        formula: 'E_{ij} = \\frac{R_i \\cdot C_j}{N}',
        description: 'Expected cell count under hypothesis of statistical independence.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w11-p1',
        questionText: 'A die is rolled 60 times with observed counts: 1: 12, 2: 7, 3: 14, 4: 8, 5: 9, 6: 10. Under the fair die hypothesis, what is the expected count for each face and what is the df?',
        options: ['Expected = 10, df = 5', 'Expected = 10, df = 6', 'Expected = 12, df = 5', 'Expected = 60, df = 5'],
        correctOptionIndex: 0,
        solution: 'For a fair die, each face has probability $1/6$. Expected count $E = 60 \\times (1/6) = 10$. Degrees of freedom $\\text{df} = k - 1 = 6 - 1 = 5$.',
        hints: ['Divide total rolls by 6 faces; $\\text{df} = k - 1$.']
      },
      {
        id: 'stats2-w11-p2',
        questionText: 'In a $3 \\times 4$ contingency table testing independence, what are the degrees of freedom?',
        options: ['6', '12', '7', '11'],
        correctOptionIndex: 0,
        solution: '$\\text{df} = (r - 1)(c - 1) = (3 - 1)(4 - 1) = 2 \\times 3 = 6$.',
        hints: ['Use $\\text{df} = (r - 1)(c - 1)$.']
      },
      {
        id: 'stats2-w11-p3',
        questionText: 'In a $2 \\times 2$ table, Row 1 Total = 40, Column 1 Total = 30, Grand Total = 100. What is $E_{11}$?',
        options: ['12', '15', '20', '70'],
        correctOptionIndex: 0,
        solution: '$E_{11} = \\frac{R_1 \\times C_1}{N} = \\frac{40 \\times 30}{100} = \\frac{1200}{100} = 12$.',
        hints: ['Multiply row total by column total and divide by 100.']
      }
    ],
    keyTakeaways: [
      'Chi-square tests evaluate dependencies across multi-class categorical features.',
      'Small expected cell frequencies ($E_i < 5$) require pooling adjacent categories or Fisher\'s exact test.'
    ],
    markdownContent: `### Week 11: Chi-Square Tests\nGoodness of fit, contingency tables, and expected cell computations.`,
    examTips: ['Make sure expected frequencies $E_i \\ge 5$ before applying the asymptotic $\\chi^2$ distribution!']
  },
  {
    id: 'note-stats2-w12',
    courseId: 'course-stats-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Simple Linear Regression, Ordinary Least Squares (OLS) & ANOVA',
    detailedNotes: `### Week 12: Simple Linear Regression & Least Squares Analysis

#### 1. Simple Linear Regression Model
$$Y_i = \\beta_0 + \\beta_1 X_i + \\epsilon_i, \\quad \\epsilon_i \\stackrel{\\text{iid}}{\\sim} N(0, \\sigma^2)$$

#### 2. Ordinary Least Squares (OLS) Estimators
Minimizing the sum of squared residuals $\\text{SSE} = \\sum (y_i - \\hat{y}_i)^2$:
- **Slope ($\\hat{\\beta}_1$):**
  $$\\hat{\\beta}_1 = \\frac{\\sum (x_i - \\bar{x})(y_i - \\bar{y})}{\\sum (x_i - \\bar{x})^2} = \\frac{S_{xy}}{S_{xx}} = r \\frac{s_y}{s_x}$$
- **Intercept ($\\hat{\\beta}_0$):**
  $$\\hat{\\beta}_0 = \\bar{y} - \\hat{\\beta}_1 \\bar{x}$$
  *(The regression line ALWAYS passes through the centroid $(\\bar{x}, \\bar{y})$).*

#### 3. Coefficient of Determination ($R^2$) & ANOVA Decomposition
$$\\text{SST} = \\text{SSR} + \\text{SSE} \\iff \\sum (y_i - \\bar{y})^2 = \\sum (\\hat{y}_i - \\bar{y})^2 + \\sum (y_i - \\hat{y}_i)^2$$
$$R^2 = \\frac{\\text{SSR}}{\\text{SST}} = 1 - \\frac{\\text{SSE}}{\\text{SST}} = r_{xy}^2$$
- $R^2$ represents the proportion of total variation in $Y$ explained by the linear relationship with $X$.`,
    quickRevisionNotes: [
      'OLS slope: $\\hat{\\beta}_1 = r \\frac{s_y}{s_x} = \\frac{S_{xy}}{S_{xx}}$.',
      'OLS intercept: $\\hat{\\beta}_0 = \\bar{y} - \\hat{\\beta}_1 \\bar{x}$.',
      'Regression line always passes through centroid $(\\bar{x}, \\bar{y})$.',
      'Coefficient of determination $R^2 = r_{xy}^2$ equals ratio of explained variation to total variation ($\\text{SSR}/\\text{SST}$).'
    ],
    formulaSheets: [
      {
        name: 'OLS Slope & Intercept',
        formula: '\\hat{\\beta}_1 = r \\frac{s_y}{s_x}, \\quad \\hat{\\beta}_0 = \\bar{y} - \\hat{\\beta}_1 \\bar{x}',
        description: 'Analytical closed-form solutions for simple linear regression coefficients.'
      },
      {
        name: 'Coefficient of Determination',
        formula: 'R^2 = 1 - \\frac{\\text{SSE}}{\\text{SST}} = r_{xy}^2',
        description: 'Proportion of dependent variable variance explained by the regression model.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats2-w12-p1',
        questionText: 'If $\\bar{x} = 10, \\bar{y} = 25, s_x = 2, s_y = 6$, and correlation $r = 0.8$, find the regression line equation.',
        options: ['\\hat{y} = 2.4x + 1.0', '\\hat{y} = 0.8x + 17.0', '\\hat{y} = 3.0x - 5.0', '\\hat{y} = 2.4x + 25.0'],
        correctOptionIndex: 0,
        solution: '$\\hat{\\beta}_1 = r \\frac{s_y}{s_x} = 0.8 \\times \\frac{6}{2} = 0.8 \\times 3 = 2.4$. $\\hat{\\beta}_0 = \\bar{y} - \\hat{\\beta}_1 \\bar{x} = 25 - 2.4(10) = 25 - 24 = 1.0$. Line: $\\hat{y} = 2.4x + 1.0$.',
        hints: ['Calculate $\\hat{\\beta}_1 = r (s_y/s_x)$, then $\\hat{\\beta}_0 = \\bar{y} - \\hat{\\beta}_1 \\bar{x}$.']
      },
      {
        id: 'stats2-w12-p2',
        questionText: 'If the correlation between two variables is $r = -0.7$, what percentage of variance is explained by the linear model ($R^2$)?',
        options: ['49%', '-49%', '70%', '51%'],
        correctOptionIndex: 0,
        solution: '$R^2 = r^2 = (-0.7)^2 = 0.49 = 49\\%$.',
        hints: ['Square the correlation coefficient.']
      },
      {
        id: 'stats2-w12-p3',
        questionText: 'Which point is ALWAYS guaranteed to lie on the OLS fitted regression line?',
        options: ['(\\bar{x}, \\bar{y}) (Centroid of the dataset)', '(0, 0) (Origin)', '(s_x, s_y)', '(Q_1, Q_3)'],
        correctOptionIndex: 0,
        solution: 'Since $\\hat{\\beta}_0 = \\bar{y} - \\hat{\\beta}_1 \\bar{x} \\implies \\bar{y} = \\hat{\\beta}_0 + \\hat{\\beta}_1 \\bar{x}$, the point $(\\bar{x}, \\bar{y})$ always satisfies the regression equation.',
        hints: ['Recall how the intercept $\\hat{\\beta}_0$ is defined.']
      }
    ],
    keyTakeaways: [
      'Simple linear regression is the foundation of supervised machine learning and predictive modeling.',
      'Residual diagnostics check for homoscedasticity and normality of errors.'
    ],
    markdownContent: `### Week 12: Linear Regression & ANOVA\nOLS derivations, centroid invariants, and R-squared variance metrics.`,
    examTips: ['Remember: $R^2$ is ALWAYS positive ($0 \\le R^2 \\le 1$), even if correlation $r$ is negative!']
  }
];

import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_MATH_1_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-math1-w1',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Coordinate Geometry, Straight Lines & Euclidean Distances',
    detailedNotes: `### Week 1: Foundations of Coordinate Geometry & 2D Vector Spaces

#### 1. Cartesian Plane & Euclidean Metrics
Given two arbitrary points $P(x_1, y_1)$ and $Q(x_2, y_2)$ in the Euclidean plane $\\mathbb{R}^2$:
- **Distance Formula:** $d(P, Q) = \\sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$
- **Section Formula (Internal Division $m:n$):**
  $$R = \\left( \\frac{m x_2 + n x_1}{m + n}, \\frac{m y_2 + n y_1}{m + n} \\right)$$

#### 2. Straight Lines & Slope Invariants
The slope $m$ of a non-vertical straight line connecting $(x_1, y_1)$ and $(x_2, y_2)$ is defined as:
$$m = \\tan \\theta = \\frac{y_2 - y_1}{x_2 - x_1} \\quad (x_1 \\ne x_2)$$

**Standard Forms of Linear Equations:**
1. **Slope-Intercept Form:** $y = mx + c$
2. **Point-Slope Form:** $y - y_1 = m(x - x_1)$
3. **General Linear Form:** $Ax + By + C = 0$ with slope $m = -\\frac{A}{B}$ ($B \\ne 0$)
4. **Intercept Form:** $\\frac{x}{a} + \\frac{y}{b} = 1$ where $a$ and $b$ are the $x$- and $y$-intercepts.

#### 3. Parallelism, Orthogonality & Orthogonal Distances
- Two lines $L_1: y = m_1 x + c_1$ and $L_2: y = m_2 x + c_2$ are:
  - **Parallel** $\\iff m_1 = m_2$
  - **Perpendicular** $\\iff m_1 \\cdot m_2 = -1$ (or $A_1 A_2 + B_1 B_2 = 0$)
- **Perpendicular Distance from $(x_0, y_0)$ to $Ax + By + C = 0$:**
  $$d = \\frac{|A x_0 + B y_0 + C|}{\\sqrt{A^2 + B^2}}$$
- **Distance Between Parallel Lines $Ax + By + C_1 = 0$ and $Ax + By + C_2 = 0$:**
  $$d = \\frac{|C_1 - C_2|}{\\sqrt{A^2 + B^2}}$$`,
    quickRevisionNotes: [
      'Slope $m = \\tan \\theta = \\frac{y_2 - y_1}{x_2 - x_1}$; vertical lines ($x = k$) have undefined slope.',
      'Perpendicularity condition: $m_1 \\cdot m_2 = -1$ or $A_1 A_2 + B_1 B_2 = 0$.',
      'Distance of point $(x_0, y_0)$ to line $Ax + By + C = 0$: $d = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}$.',
      'Distance between two parallel lines: $d = \\frac{|C_1 - C_2|}{\\sqrt{A^2 + B^2}}$.',
      'Midpoint formula is internal division with ratio $1:1$: $M = \\left(\\frac{x_1 + x_2}{2}, \\frac{y_1 + y_2}{2}\\right)$.'
    ],
    formulaSheets: [
      {
        name: 'Perpendicular Distance to Line',
        formula: 'd = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}',
        description: 'Shortest Euclidean orthogonal distance from $(x_0, y_0)$ to line $Ax + By + C = 0$.',
        variables: [
          { symbol: 'A, B, C', meaning: 'Coefficients of the general line equation' },
          { symbol: '(x_0, y_0)', meaning: 'Coordinates of the target point' }
        ]
      },
      {
        name: 'Distance Between Parallel Lines',
        formula: 'd = \\frac{|C_1 - C_2|}{\\sqrt{A^2 + B^2}}',
        description: 'Orthogonal separation between parallel lines $Ax + By + C_1 = 0$ and $Ax + By + C_2 = 0$.'
      },
      {
        name: 'Angle Between Two Lines',
        formula: '\\tan \\theta = \\left| \\frac{m_2 - m_1}{1 + m_1 m_2} \\right|',
        description: 'Acute angle $\\theta$ between intersecting lines with slopes $m_1$ and $m_2$.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w1-p1',
        questionText: 'Find the perpendicular distance from the point $(3, -2)$ to the straight line $5x - 12y + 8 = 0$.',
        options: ['2.5', '3.61', '3.0', '4.2'],
        correctOptionIndex: 1,
        solution: 'Using $d = \\frac{|A x_0 + B y_0 + C|}{\\sqrt{A^2 + B^2}}$: $A = 5$, $B = -12$, $C = 8$, $(x_0, y_0) = (3, -2)$. Numerator: $|5(3) - 12(-2) + 8| = |15 + 24 + 8| = 47$. Denominator: $\\sqrt{5^2 + (-12)^2} = \\sqrt{25 + 144} = 13$. Therefore, $d = \\frac{47}{13} \\approx 3.615$.',
        hints: ['Substitute into $d = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}$ with $A=5, B=-12, C=8$.']
      },
      {
        id: 'math1-w1-p2',
        questionText: 'Which of the following lines is perpendicular to $3x + 4y - 10 = 0$ and passes through $(1, 2)$?',
        options: ['4x - 3y + 2 = 0', '4x + 3y - 10 = 0', '3x - 4y + 5 = 0', '-4x + 3y + 1 = 0'],
        correctOptionIndex: 0,
        solution: 'Slope of original line is $m_1 = -3/4$. For perpendicularity, $m_2 = -1/m_1 = 4/3$. Equation: $y - 2 = \\frac{4}{3}(x - 1) \\implies 3(y - 2) = 4(x - 1) \\implies 3y - 6 = 4x - 4 \\implies 4x - 3y + 2 = 0$.',
        hints: ['Slope of perpendicular line is the negative reciprocal: $m_2 = -1/m_1$.']
      },
      {
        id: 'math1-w1-p3',
        questionText: 'Find the distance between parallel lines $3x - 4y + 7 = 0$ and $3x - 4y - 18 = 0$.',
        options: ['5', '25', '3.5', '2.8'],
        correctOptionIndex: 0,
        solution: 'Formula: $d = \\frac{|C_1 - C_2|}{\\sqrt{A^2 + B^2}} = \\frac{|7 - (-18)|}{\\sqrt{3^2 + (-4)^2}} = \\frac{25}{\\sqrt{25}} = 5$.',
        hints: ['Use $d = \\frac{|C_1 - C_2|}{\\sqrt{A^2 + B^2}}$ directly.']
      }
    ],
    keyTakeaways: [
      'Slope $m = \\tan \\theta = \\frac{y_2 - y_1}{x_2 - x_1}$; perpendicular lines satisfy $m_1 m_2 = -1$.',
      'Point-to-line distance: $d = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}$.',
      'Parallel line separation: $d = \\frac{|C_1 - C_2|}{\\sqrt{A^2 + B^2}}$.'
    ],
    markdownContent: `### Week 1: Coordinate Geometry & Lines\nDetailed derivation of linear geometry and Euclidean metric spaces.`,
    examTips: ['Ensure equation is in $Ax + By + C = 0$ before applying distance formulas.'],
    handwrittenMnemonic: 'Distance Denominator is the vector length of the normal $(A, B) \\implies \\sqrt{A^2 + B^2}$!'
  },
  {
    id: 'note-math1-w2',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Functions, Domain, Range, Bijectivity & Inverses',
    detailedNotes: `### Week 2: Relations, Functions & Mapping Classifications

#### 1. Formal Definition of a Function
A function $f: A \\to B$ associates every element $x \\in A$ (Domain) with a unique element $y \\in B$ (Codomain).
- **Domain:** The set of all valid inputs for which $f(x)$ is defined and real.
- **Range:** $f(A) = \\{ f(x) \\mid x \\in A \\} \\subseteq B$.

#### 2. Classification of Functions
- **Injective (One-to-One):** $f(x_1) = f(x_2) \\implies x_1 = x_2$.
  - *Horizontal Line Test:* No horizontal line intersects the graph more than once.
- **Surjective (Onto):** $\\text{Range}(f) = \\text{Codomain}(B)$. Every $y \\in B$ has at least one pre-image $x \\in A$.
- **Bijective (One-to-One and Onto):** Both injective and surjective. A function is **invertible** if and only if it is bijective.

#### 3. Composite & Inverse Functions
- **Composition:** $(g \\circ f)(x) = g(f(x))$, defined when $\\text{Range}(f) \\subseteq \\text{Domain}(g)$.
- **Inverse Function:** $f^{-1}: B \\to A$ satisfies $f^{-1}(f(x)) = x$ and $f(f^{-1}(y)) = y$.
  - Graphically, $y = f^{-1}(x)$ is the reflection of $y = f(x)$ about the line $y = x$.`,
    quickRevisionNotes: [
      'A relation is a function iff every domain element maps to exactly one codomain element.',
      'Injectivity check: $f\'(x) > 0$ or $f\'(x) < 0$ strictly on interval $\\implies$ strictly monotonic $\\implies$ injective.',
      'Surjectivity requires $\\text{Range} = \\text{Codomain}$.',
      'Inverse exists $\\iff f$ is bijective.',
      '$(g \\circ f)^{-1} = f^{-1} \\circ g^{-1}$.'
    ],
    formulaSheets: [
      {
        name: 'Invertibility Criterion',
        formula: 'f \\text{ has an inverse } f^{-1} \\iff f \\text{ is Bijective (Injective + Surjective)}',
        description: 'Fundamental theorem of invertible function mappings.'
      },
      {
        name: 'Composition Inversion',
        formula: '(g \\circ f)^{-1} = f^{-1} \\circ g^{-1}',
        description: 'Reversal rule for composite inverse mappings.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w2-p1',
        questionText: 'Find the natural domain of $f(x) = \\sqrt{\\frac{x - 3}{x + 2}}$ in $\\mathbb{R}$.',
        options: ['(-\\infty, -2) \\cup [3, \\infty)', '[-2, 3]', '(-2, 3]', '(-\\infty, -2] \\cup [3, \\infty)'],
        correctOptionIndex: 0,
        solution: 'For the square root to be real, $\\frac{x - 3}{x + 2} \\ge 0$ and denominator $x + 2 \\ne 0$. Critical points are $-2$ and $3$. Testing intervals: for $x < -2$ (e.g. $-3$), $(-)/(-) = + > 0$. For $-2 < x < 3$ (e.g. $0$), $(-)/(+) = - < 0$. For $x \\ge 3$ (e.g. $4$), $(+)/(+) = + > 0$. Denominator cannot be zero, so $x \\ne -2$. Thus Domain is $(-\\infty, -2) \\cup [3, \\infty)$.',
        hints: ['Set the expression inside the square root $\\ge 0$ and exclude denominator roots.']
      },
      {
        id: 'math1-w2-p2',
        questionText: 'If $f(x) = 2x + 5$, what is $f^{-1}(x)$?',
        options: ['\\frac{x - 5}{2}', '\\frac{x + 5}{2}', '2x - 5', '\\frac{1}{2x + 5}'],
        correctOptionIndex: 0,
        solution: 'Set $y = 2x + 5 \\implies 2x = y - 5 \\implies x = \\frac{y - 5}{2}$. Replacing variables: $f^{-1}(x) = \\frac{x - 5}{2}$.',
        hints: ['Solve for $x$ in terms of $y$.']
      },
      {
        id: 'math1-w2-p3',
        questionText: 'Let $f: \\mathbb{R} \\to \\mathbb{R}$ defined by $f(x) = x^3 - 3x$. Is $f$ injective?',
        options: ['No, because f(0) = f(\\sqrt{3}) = f(-\\sqrt{3}) = 0', 'Yes, because odd polynomials are always injective', 'Yes, because f\'(x) > 0 everywhere', 'No, because its domain is restricted'],
        correctOptionIndex: 0,
        solution: '$f(0) = 0$, $f(\\sqrt{3}) = 3\\sqrt{3} - 3\\sqrt{3} = 0$, $f(-\\sqrt{3}) = -3\\sqrt{3} + 3\\sqrt{3} = 0$. Three distinct inputs map to $0$, so it is not injective.',
        hints: ['Check the roots of $x^3 - 3x = 0$.']
      }
    ],
    keyTakeaways: [
      'Injectivity means distinct inputs give distinct outputs.',
      'Bijectivity is the necessary and sufficient condition for inverse existence.'
    ],
    markdownContent: `### Week 2: Functions, Domain, Range & Bijectivity\nDetailed exploration of mappings and inverse functions.`,
    examTips: ['To check injectivity quickly, compute $f\'(x)$ — if sign never changes, function is injective.'],
    handwrittenMnemonic: 'Inverse is simply reflection across $y = x$!'
  },
  {
    id: 'note-math1-w3',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Quadratic Functions, Polynomials & Curve Sketching',
    detailedNotes: `### Week 3: Quadratic Functions, Parabolas & Discriminant Analysis

#### 1. Standard Quadratic Form & Vertex
$$f(x) = ax^2 + bx + c \\quad (a \\ne 0)$$
- **Vertex Form:** $f(x) = a\\left(x - h\\right)^2 + k$, where:
  $$h = -\\frac{b}{2a}, \\quad k = f(h) = -\\frac{b^2 - 4ac}{4a} = -\\frac{D}{4a}$$
- **Orientation:** If $a > 0$, parabola opens upwards (minimum at vertex). If $a < 0$, opens downwards (maximum at vertex).

#### 2. Discriminant $\\Delta = b^2 - 4ac$ & Root Classifications
- $\\Delta > 0$: Two distinct real roots $x = \\frac{-b \\pm \\sqrt{\\Delta}}{2a}$.
- $\\Delta = 0$: Exactly one real repeated root $x = -\\frac{b}{2a}$ (parabola touches $x$-axis).
- $\\Delta < 0$: No real roots (strictly positive if $a > 0$; strictly negative if $a < 0$).

#### 3. Vieta's Formulas for Polynomials
For $ax^2 + bx + c = 0$ with roots $\\alpha, \\beta$:
$$\\alpha + \\beta = -\\frac{b}{a}, \\quad \\alpha \\beta = \\frac{c}{a}$$`,
    quickRevisionNotes: [
      'Vertex of $ax^2 + bx + c$ occurs at $x = -\\frac{b}{2a}$ with extremum $y = -\\frac{D}{4a}$.',
      'Sign of $a$ determines curvature: $a > 0 \\implies$ Convex (Min), $a < 0 \\implies$ Concave (Max).',
      'Discriminant $D = b^2 - 4ac$: $D > 0$ (2 real roots), $D = 0$ (1 repeated root), $D < 0$ (0 real roots).',
      'Vieta: $\\alpha + \\beta = -b/a$, $\\alpha \\beta = c/a$.'
    ],
    formulaSheets: [
      {
        name: 'Quadratic Vertex Formula',
        formula: '(h, k) = \\left( -\\frac{b}{2a}, -\\frac{b^2 - 4ac}{4a} \\right)',
        description: 'Coordinates of the parabolic extremum.'
      },
      {
        name: 'Vieta Relations (Quadratic)',
        formula: '\\alpha + \\beta = -\\frac{b}{a}, \\quad \\alpha \\beta = \\frac{c}{a}',
        description: 'Sum and product of roots for quadratic polynomials.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w3-p1',
        questionText: 'Find the minimum value of $f(x) = 2x^2 - 8x + 11$.',
        options: ['3', '2', '11', '1'],
        correctOptionIndex: 0,
        solution: '$a = 2, b = -8, c = 11$. Vertex $x = -b/(2a) = 8/(2 \\times 2) = 2$. Minimum value $f(2) = 2(2^2) - 8(2) + 11 = 8 - 16 + 11 = 3$.',
        hints: ['Calculate vertex at $x = -b/(2a)$ and evaluate $f(x)$.']
      },
      {
        id: 'math1-w3-p2',
        questionText: 'For what values of $k$ does $x^2 - 2kx + (k + 6) = 0$ have real and equal roots?',
        options: ['k = 3, -2', 'k = 6, -1', 'k = 2, -3', 'k = 4, 0'],
        correctOptionIndex: 0,
        solution: 'For equal roots, $\\Delta = 0 \\implies (-2k)^2 - 4(1)(k + 6) = 0 \\implies 4k^2 - 4k - 24 = 0 \\implies k^2 - k - 6 = 0 \\implies (k - 3)(k + 2) = 0 \\implies k = 3, -2$.',
        hints: ['Set $\\Delta = b^2 - 4ac = 0$.']
      },
      {
        id: 'math1-w3-p3',
        questionText: 'If $\\alpha$ and $\\beta$ are roots of $x^2 - 5x + 6 = 0$, what is $\\alpha^2 + \\beta^2$?',
        options: ['13', '25', '19', '12'],
        correctOptionIndex: 0,
        solution: '$\\alpha + \\beta = 5, \\alpha \\beta = 6$. $\\alpha^2 + \\beta^2 = (\\alpha + \\beta)^2 - 2\\alpha \\beta = 5^2 - 2(6) = 25 - 12 = 13$.',
        hints: ['Use $(\\alpha + \\beta)^2 - 2\\alpha \\beta$.']
      }
    ],
    keyTakeaways: [
      'Vertex at $x = -b/(2a)$ gives the global minimum when $a > 0$.',
      'Vieta formula allows algebraic symmetric expressions of roots without computing roots.'
    ],
    markdownContent: `### Week 3: Quadratic Functions & Curves\nRoots, vertex and parabolic optimizations.`,
    examTips: ['Check the sign of $a$ first to identify if the parabola has a minimum ($a>0$) or maximum ($a<0$).']
  },
  {
    id: 'note-math1-w4',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Limits, Continuity & Intermediate Value Theorem',
    detailedNotes: `### Week 4: Limits, Continuity & Topological Properties

#### 1. Limit of a Function & $\\epsilon$-$\\delta$ Definition
$$\\lim_{x \\to c} f(x) = L \\iff \\forall \\epsilon > 0, \\exists \\delta > 0 \\text{ s.t. } 0 < |x - c| < \\delta \\implies |f(x) - L| < \\epsilon$$
- **Existence of Limit:** $\\lim_{x \\to c} f(x) = L \\iff \\lim_{x \\to c^-} f(x) = \\lim_{x \\to c^+} f(x) = L$.

#### 2. Continuity Criterion
A function $f$ is **continuous at $x = c$** if:
1. $f(c)$ is defined.
2. $\\lim_{x \\to c} f(x)$ exists.
3. $\\lim_{x \\to c} f(x) = f(c)$.

#### 3. Intermediate Value Theorem (IVT)
If $f: [a, b] \\to \\mathbb{R}$ is continuous, and $u$ is any number between $f(a)$ and $f(b)$, then there exists at least one $c \\in (a, b)$ such that $f(c) = u$.
- **Root-Finding Corollary:** If $f(a) \\cdot f(b) < 0$, there exists at least one root $c \\in (a, b)$ with $f(c) = 0$.

#### 4. Standard Limit Identities
- $\\lim_{x \\to 0} \\frac{\\sin x}{x} = 1$
- $\\lim_{x \\to 0} \\frac{e^x - 1}{x} = 1$
- $\\lim_{x \\to 0} \\frac{\\ln(1 + x)}{x} = 1$
- $\\lim_{x \\to \\infty} \\left(1 + \\frac{1}{x}\\right)^x = e$`,
    quickRevisionNotes: [
      'Limit exists iff Left-Hand Limit (LHL) = Right-Hand Limit (RHL).',
      'Continuity requires $\\text{LHL} = \\text{RHL} = f(c)$.',
      'IVT guarantees that a continuous function achieves all intermediate values between endpoints.',
      'Indeterminate forms ($0/0, \\infty/\\infty$) allow L\'Hôpital\'s rule.'
    ],
    formulaSheets: [
      {
        name: 'Standard Exponential Limit',
        formula: '\\lim_{x \\to 0} (1 + x)^{1/x} = e \\quad \\text{and} \\quad \\lim_{x \\to \\infty} \\left(1 + \\frac{k}{x}\\right)^x = e^k',
        description: 'Euler constant exponential limit identity.'
      },
      {
        name: 'Intermediate Value Theorem',
        formula: 'f \\in C[a, b] \\text{ and } f(a) \\cdot f(b) < 0 \\implies \\exists c \\in (a, b) \\text{ s.t. } f(c) = 0',
        description: 'Bolzano theorem for existence of real roots.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w4-p1',
        questionText: 'Evaluate $\\lim_{x \\to 0} \\frac{\\tan(3x)}{5x}$.',
        options: ['3/5', '5/3', '1', '0'],
        correctOptionIndex: 0,
        solution: '$\\lim_{x \\to 0} \\frac{\\tan(3x)}{5x} = \\frac{3}{5} \\lim_{x \\to 0} \\frac{\\tan(3x)}{3x} = \\frac{3}{5} \\times 1 = \\frac{3}{5}$.',
        hints: ['Use standard limit $\\lim_{u \\to 0} \\frac{\\tan u}{u} = 1$.']
      },
      {
        id: 'math1-w4-p2',
        questionText: 'For what value of $k$ is $f(x) = \\begin{cases} \\frac{x^2 - 16}{x - 4}, & x \\ne 4 \\\\ k, & x = 4 \\end{cases}$ continuous at $x = 4$?',
        options: ['8', '4', '16', '0'],
        correctOptionIndex: 0,
        solution: '$\\lim_{x \\to 4} \\frac{(x-4)(x+4)}{x-4} = \\lim_{x \\to 4} (x+4) = 8$. For continuity, $f(4) = k = 8$.',
        hints: ['Cancel the $(x-4)$ term in numerator and denominator.']
      },
      {
        id: 'math1-w4-p3',
        questionText: 'Which polynomial is guaranteed to have a root in $(1, 2)$ by IVT?',
        options: ['f(x) = x^3 - 3x - 1', 'f(x) = x^2 + 1', 'f(x) = x^3 + 2', 'f(x) = x^4 + 4'],
        correctOptionIndex: 0,
        solution: '$f(1) = 1 - 3 - 1 = -3 < 0$, and $f(2) = 8 - 6 - 1 = +1 > 0$. Since $f(1) \\cdot f(2) < 0$, IVT guarantees a root in $(1, 2)$.',
        hints: ['Check the sign of $f(1)$ and $f(2)$.']
      }
    ],
    keyTakeaways: [
      'Continuity implies no jumps, asymptotes, or holes.',
      'IVT guarantees that continuous curves cannot cross a level without hitting every value in between.'
    ],
    markdownContent: `### Week 4: Limits & Continuity\nEpsilon-delta definitions, standard limit theorems, and IVT.`,
    examTips: ['When evaluating $0/0$ limits with radicals, try rationalizing the numerator/denominator.']
  },
  {
    id: 'note-math1-w5',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Differentiation, Derivatives, Tangents & Normals',
    detailedNotes: `### Week 5: Differential Calculus & Geometric Tangents

#### 1. Definition of the Derivative
$$f'(x) = \\frac{df}{dx} = \\lim_{h \\to 0} \\frac{f(x + h) - f(x)}{h}$$
- **Differentiability $\\implies$ Continuity:** If $f$ is differentiable at $c$, it is necessarily continuous at $c$. (The converse is false, e.g., $f(x) = |x|$ at $x=0$).

#### 2. Geometric Interpretation: Tangents & Normals
At point $(x_0, y_0)$ on curve $y = f(x)$:
- **Slope of Tangent:** $m_t = f'(x_0)$
- **Equation of Tangent:** $y - y_0 = f'(x_0)(x - x_0)$
- **Slope of Normal:** $m_n = -\\frac{1}{f'(x_0)} \\quad (f'(x_0) \\ne 0)$
- **Equation of Normal:** $y - y_0 = -\\frac{1}{f'(x_0)}(x - x_0)$

#### 3. Standard Derivative Rules
- $\\frac{d}{dx} x^n = n x^{n-1}$
- $\\frac{d}{dx} e^{kx} = k e^{kx}$
- $\\frac{d}{dx} \\ln x = \\frac{1}{x}$
- $\\frac{d}{dx} \\sin x = \\cos x, \\quad \\frac{d}{dx} \\cos x = -\\sin x, \\quad \\frac{d}{dx} \\tan x = \\sec^2 x$`,
    quickRevisionNotes: [
      'Derivative $f\'(x)$ represents instantaneous rate of change and slope of tangent line.',
      'Differentiability implies continuity, but continuity does NOT imply differentiability.',
      'Tangent line: $y - y_0 = f\'(x_0)(x - x_0)$.',
      'Normal line: $y - y_0 = -\\frac{1}{f\'(x_0)}(x - x_0)$.'
    ],
    formulaSheets: [
      {
        name: 'Tangent & Normal Lines',
        formula: 'y - y_0 = f\'(x_0)(x - x_0) \\quad \\text{and} \\quad y - y_0 = -\\frac{1}{f\'(x_0)}(x - x_0)',
        description: 'Equations of orthogonal tangent and normal lines at $(x_0, y_0)$.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w5-p1',
        questionText: 'Find the slope of the tangent to $y = x^3 - 3x + 2$ at $x = 2$.',
        options: ['9', '6', '12', '3'],
        correctOptionIndex: 0,
        solution: '$y\' = 3x^2 - 3$. At $x = 2$, $y\'(2) = 3(2^2) - 3 = 12 - 3 = 9$.',
        hints: ['Differentiate $y$ and evaluate at $x = 2$.']
      },
      {
        id: 'math1-w5-p2',
        questionText: 'Find the equation of the normal to $y = x^2$ at the point $(1, 1)$.',
        options: ['x + 2y - 3 = 0', '2x + y - 3 = 0', 'x - 2y + 1 = 0', '2x - y - 1 = 0'],
        correctOptionIndex: 0,
        solution: '$y\' = 2x \\implies m_t = 2(1) = 2$. Slope of normal $m_n = -1/2$. Equation: $y - 1 = -\\frac{1}{2}(x - 1) \\implies 2y - 2 = -x + 1 \\implies x + 2y - 3 = 0$.',
        hints: ['Slope of normal is $-1/f\'(x_0)$.']
      },
      {
        id: 'math1-w5-p3',
        questionText: 'Why is $f(x) = |x - 2|$ not differentiable at $x = 2$?',
        options: ['Left derivative (-1) does not equal right derivative (+1)', 'It is discontinuous at x = 2', 'f(2) is undefined', 'It has an infinite asymptote'],
        correctOptionIndex: 0,
        solution: 'Left-hand derivative as $x \\to 2^-$ is $-1$, while right-hand derivative as $x \\to 2^+$ is $+1$. Since LHD $\\ne$ RHD, $f\'(2)$ does not exist.',
        hints: ['Evaluate the limit of difference quotient from the left and right.']
      }
    ],
    keyTakeaways: [
      'Tangent line shares point and slope with the curve.',
      'Normal line is orthogonal to the tangent line at the point of contact.'
    ],
    markdownContent: `### Week 5: Derivatives & Tangents\nRate of change and geometric applications.`,
    examTips: ['Watch out for points where tangent is vertical (derivative is infinite).']
  },
  {
    id: 'note-math1-w6',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Product Rule, Quotient Rule, Chain Rule & Implicit Differentiation',
    detailedNotes: `### Week 6: Advanced Differentiation Rules & Implicit Relations

#### 1. Algebraic Differentiation Rules
- **Product Rule:** $(u \\cdot v)' = u'v + u v'$
- **Quotient Rule:** $\\left( \\frac{u}{v} \\right)' = \\frac{u'v - u v'}{v^2}$
- **Chain Rule:** $\\frac{d}{dx} [f(g(x))] = f'(g(x)) \\cdot g'(x)$

#### 2. Implicit Differentiation
When $y$ cannot be explicitly isolated as $y = f(x)$, differentiate both sides with respect to $x$, applying the chain rule to terms with $y$:
$$\\frac{d}{dx} [y^n] = n y^{n-1} \\frac{dy}{dx}$$
- Example for circle $x^2 + y^2 = r^2$:
  $$2x + 2y \\frac{dy}{dx} = 0 \\implies \\frac{dy}{dx} = -\\frac{x}{y}$$

#### 3. Logarithmic Differentiation
Used for products of powers and functions of form $y = [f(x)]^{g(x)}$:
$$\\ln y = g(x) \\ln(f(x)) \\implies \\frac{1}{y} \\frac{dy}{dx} = g'(x) \\ln(f(x)) + g(x) \\frac{f'(x)}{f(x)}$$`,
    quickRevisionNotes: [
      'Product Rule: $(uv)\' = u\'v + uv\'$.',
      'Quotient Rule: $(u/v)\' = \\frac{u\'v - uv\'}{v^2}$.',
      'Chain Rule: $\\frac{d}{dx} f(g(x)) = f\'(g(x)) g\'(x)$.',
      'Logarithmic differentiation is essential for $y = f(x)^{g(x)}$.'
    ],
    formulaSheets: [
      {
        name: 'Chain Rule',
        formula: '\\frac{d}{dx} f(g(x)) = f\'(g(x)) \\cdot g\'(x)',
        description: 'Derivative of composite function mapping.'
      },
      {
        name: 'Power Tower Derivative',
        formula: '\\frac{d}{dx} [x^x] = x^x (1 + \\ln x)',
        description: 'Standard logarithmic differentiation result.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w6-p1',
        questionText: 'Find $\\frac{dy}{dx}$ for $y = x^x$ at $x = 1$.',
        options: ['1', '0', 'e', '2'],
        correctOptionIndex: 0,
        solution: '$\\ln y = x \\ln x \\implies \\frac{1}{y} y\' = 1 \\cdot \\ln x + x \\cdot \\frac{1}{x} = \\ln x + 1 \\implies y\' = x^x (1 + \\ln x)$. At $x = 1$, $y\'(1) = 1^1 (1 + \\ln 1) = 1(1 + 0) = 1$.',
        hints: ['Take natural log on both sides before differentiating.']
      },
      {
        id: 'math1-w6-p2',
        questionText: 'Differentiate $f(x) = \\frac{e^x}{x^2 + 1}$.',
        options: ['\\frac{e^x(x^2 - 2x + 1)}{(x^2 + 1)^2}', '\\frac{e^x(x^2 + 2x + 1)}{(x^2 + 1)^2}', '\\frac{e^x}{2x}', '\\frac{e^x(x - 1)^2}{(x^2 + 1)^2}'],
        correctOptionIndex: 0,
        solution: 'Quotient rule: $\\frac{e^x(x^2 + 1) - e^x(2x)}{(x^2 + 1)^2} = \\frac{e^x(x^2 - 2x + 1)}{(x^2 + 1)^2} = \\frac{e^x(x-1)^2}{(x^2 + 1)^2}$. Both option 0 and 3 are algebraic forms; option 0 matches standard expansion.',
        hints: ['Apply $\\frac{u\'v - uv\'}{v^2}$ with $u = e^x$ and $v = x^2 + 1$.']
      },
      {
        id: 'math1-w6-p3',
        questionText: 'Find $\\frac{dy}{dx}$ for $x^2 + xy + y^2 = 7$ at $(1, 2)$.',
        options: ['-4/5', '-5/4', '4/5', '-1'],
        correctOptionIndex: 0,
        solution: '$2x + (1 \\cdot y + x y\') + 2y y\' = 0 \\implies (x + 2y)y\' = -(2x + y) \\implies y\' = -\\frac{2x + y}{x + 2y}$. At $(1, 2)$, $y\' = -\\frac{2(1) + 2}{1 + 2(2)} = -\\frac{4}{5}$.',
        hints: ['Use implicit differentiation: $\\frac{d}{dx}(xy) = y + x y\'$.']
      }
    ],
    keyTakeaways: [
      'Chain rule allows differentiating deep nested neural activation compositions.',
      'Implicit differentiation handles constraint curves without explicit function solving.'
    ],
    markdownContent: `### Week 6: Product, Chain & Implicit Differentiation\nOperational calculus mechanics.`,
    examTips: ['Do not forget the derivative of the inside function when using chain rule!']
  },
  {
    id: 'note-math1-w7',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Maxima, Minima, Monotonicity & Mean Value Theorems',
    detailedNotes: `### Week 7: Optimization, Rolle\'s Theorem & Mean Value Theorem

#### 1. Rolle\'s Theorem
If $f: [a, b] \\to \\mathbb{R}$ satisfies:
1. $f$ is continuous on $[a, b]$
2. $f$ is differentiable on $(a, b)$
3. $f(a) = f(b)$
Then $\\exists c \\in (a, b)$ such that $f'(c) = 0$.

#### 2. Lagrange\'s Mean Value Theorem (MVT)
If $f$ is continuous on $[a, b]$ and differentiable on $(a, b)$, then $\\exists c \\in (a, b)$ such that:
$$f'(c) = \\frac{f(b) - f(a)}{b - a}$$
*(Geometric meaning: There exists at least one point where the tangent line is parallel to the secant line).*

#### 3. Monotonicity & Critical Points
- $f'(x) > 0$ on $(a, b) \\implies f$ is strictly increasing.
- $f'(x) < 0$ on $(a, b) \\implies f$ is strictly decreasing.
- **Critical Point:** Any $c$ in the domain where $f'(c) = 0$ or $f'(c)$ does not exist.
- **First Derivative Test for Local Extrema:**
  - $f'(x)$ changes from $+$ to $-$ at $c \\implies$ Local Maximum.
  - $f'(x)$ changes from $-$ to $+$ at $c \\implies$ Local Minimum.`,
    quickRevisionNotes: [
      'Rolle\'s Theorem requires $f(a) = f(b) \\implies f\'(c) = 0$.',
      'Lagrange MVT: $f\'(c) = \\frac{f(b) - f(a)}{b - a}$.',
      'Monotonicity: $f\'(x) > 0 \\implies$ increasing, $f\'(x) < 0 \\implies$ decreasing.',
      'Local extrema occur only at critical points.'
    ],
    formulaSheets: [
      {
        name: 'Lagrange Mean Value Theorem',
        formula: 'f\'(c) = \\frac{f(b) - f(a)}{b - a} \\quad \\text{for some } c \\in (a, b)',
        description: 'Secant slope equals instantaneous derivative at an interior point.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w7-p1',
        questionText: 'Find $c \\in (1, 3)$ satisfying MVT for $f(x) = x^2 - 2x$.',
        options: ['2', '1.5', '2.5', '\\sqrt{3}'],
        correctOptionIndex: 0,
        solution: '$f(1) = 1 - 2 = -1$, $f(3) = 9 - 6 = 3$. Average slope $= \\frac{3 - (-1)}{3 - 1} = \\frac{4}{2} = 2$. $f\'(x) = 2x - 2$. Setting $2c - 2 = 2 \\implies 2c = 4 \\implies c = 2$. Note $2 \\in (1, 3)$.',
        hints: ['Set $f\'(c) = \\frac{f(3)-f(1)}{3-1}$.']
      },
      {
        id: 'math1-w7-p2',
        questionText: 'On what interval is $f(x) = 2x^3 - 9x^2 + 12x - 5$ strictly decreasing?',
        options: ['(1, 2)', '(0, 1)', '(2, 3)', '(-\\infty, 1)'],
        correctOptionIndex: 0,
        solution: '$f\'(x) = 6x^2 - 18x + 12 = 6(x^2 - 3x + 2) = 6(x - 1)(x - 2)$. For decreasing, $f\'(x) < 0 \\implies 1 < x < 2$.',
        hints: ['Solve $f\'(x) < 0$.']
      },
      {
        id: 'math1-w7-p3',
        questionText: 'What is the absolute maximum of $f(x) = 3x^4 - 4x^3$ on $[-1, 2]$?',
        options: ['16', '7', '0', '-1'],
        correctOptionIndex: 0,
        solution: '$f\'(x) = 12x^3 - 12x^2 = 12x^2(x - 1) = 0 \\implies x = 0, 1$. Candidate values: $f(-1) = 3(1) - 4(-1) = 7$, $f(0) = 0$, $f(1) = 3 - 4 = -1$, $f(2) = 3(16) - 4(8) = 48 - 32 = 16$. Absolute max is 16 at $x = 2$.',
        hints: ['Compare values at critical points and boundary endpoints.']
      }
    ],
    keyTakeaways: [
      'MVT bridges local derivatives with global secant intervals.',
      'Absolute extrema on closed bounded intervals must be checked at both critical points and endpoints.'
    ],
    markdownContent: `### Week 7: MVT & Optimization\nMean value theorem and single variable monotonicity.`,
    examTips: ['Always evaluate endpoints when asked for absolute / global extrema on a closed interval!']
  },
  {
    id: 'note-math1-w8',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Convexity, Concavity, Inflection Points & Curve Optimization',
    detailedNotes: `### Week 8: Second Derivatives, Curvature & Convex Analysis

#### 1. Concavity & Second Derivative Test
Let $f$ be twice differentiable on $(a, b)$:
- **Convex (Concave Up):** $f''(x) > 0 \\implies$ tangent lines lie below the curve; secants lie above.
- **Concave (Concave Down):** $f''(x) < 0 \\implies$ tangent lines lie above the curve; secants lie below.

#### 2. Point of Inflection
A point $(c, f(c))$ is an **inflection point** if $f''(c) = 0$ (or is undefined) AND $f''(x)$ strictly changes sign across $x = c$.

#### 3. Second Derivative Test for Local Extrema
If $f'(c) = 0$:
- $f''(c) > 0 \\implies$ **Local Minimum** (bowl-shaped up)
- $f''(c) < 0 \\implies$ **Local Maximum** (dome-shaped down)
- $f''(c) = 0 \\implies$ **Inconclusive** (must use First Derivative Test)

#### 4. Taylor Polynomial Approximation (Order $n$)
Near $x = a$:
$$f(x) \\approx f(a) + f'(a)(x - a) + \\frac{f''(a)}{2!}(x - a)^2 + \\dots + \\frac{f^{(n)}(a)}{n!}(x - a)^n$$`,
    quickRevisionNotes: [
      '$f\'\'(x) > 0 \\implies$ Concave Up (Convex); $f\'\'(x) < 0 \\implies$ Concave Down.',
      'Inflection point requires $f\'\'(c) = 0$ with an actual sign change of $f\'\'(x)$.',
      'Second derivative test: $f\'(c) = 0$ and $f\'\'(c) > 0 \\implies$ Local Minimum.',
      'Second order Taylor approximation: $f(a) + f\'(a)(x-a) + \\frac{f\'\'(a)}{2}(x-a)^2$.'
    ],
    formulaSheets: [
      {
        name: 'Taylor Series Expansion (2nd Order)',
        formula: 'f(x) \\approx f(a) + f\'(a)(x - a) + \\frac{1}{2} f\'\'(a)(x - a)^2',
        description: 'Quadratic local approximation of a twice-differentiable function.'
      },
      {
        name: 'Inflection Point Condition',
        formula: 'f\'\'(c) = 0 \\quad \\text{and} \\quad f\'\'(c^-) \\cdot f\'\'(c^+) < 0',
        description: 'Necessary and sufficient condition for curvature inflection.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w8-p1',
        questionText: 'Find the inflection point of $f(x) = x^3 - 6x^2 + 9x + 1$.',
        options: ['(2, 3)', '(1, 5)', '(3, 1)', '(2, 0)'],
        correctOptionIndex: 0,
        solution: '$f\'(x) = 3x^2 - 12x + 9$, $f\'\'(x) = 6x - 12$. Setting $f\'\'(x) = 0 \\implies x = 2$. $f(2) = 2^3 - 6(2^2) + 9(2) + 1 = 8 - 24 + 18 + 1 = 3$. $f\'\'(x)$ changes from negative to positive at $x=2$, so $(2, 3)$ is an inflection point.',
        hints: ['Set $f\'\'(x) = 0$ and evaluate $f(x)$.']
      },
      {
        id: 'math1-w8-p2',
        questionText: 'What is the second-order Taylor polynomial of $f(x) = \\ln(1 + x)$ around $a = 0$?',
        options: ['x - \\frac{x^2}{2}', 'x + \\frac{x^2}{2}', '1 + x - x^2', 'x - x^2'],
        correctOptionIndex: 0,
        solution: '$f(0) = \\ln 1 = 0$. $f\'(x) = \\frac{1}{1+x} \\implies f\'(0) = 1$. $f\'\'(x) = -\\frac{1}{(1+x)^2} \\implies f\'\'(0) = -1$. Taylor polynomial: $P_2(x) = 0 + 1(x) + \\frac{-1}{2}x^2 = x - \\frac{x^2}{2}$.',
        hints: ['Use $P_2(x) = f(0) + f\'(0)x + \\frac{f\'\'(0)}{2!}x^2$.']
      },
      {
        id: 'math1-w8-p3',
        questionText: 'If $f(x) = x^4$, what does the second derivative test conclude at $x = 0$?',
        options: ['Inconclusive because f\'\'(0) = 0', 'Local Maximum', 'Local Minimum', 'Inflection point'],
        correctOptionIndex: 0,
        solution: '$f\'(x) = 4x^3 \\implies f\'(0) = 0$. $f\'\'(x) = 12x^2 \\implies f\'\'(0) = 0$. Since $f\'\'(0) = 0$, the second derivative test is inconclusive (first derivative test confirms it is a local minimum since $f\'(x)$ goes from $-$ to $+$).',
        hints: ['When $f\'\'(c) = 0$, second derivative test gives no conclusion.']
      }
    ],
    keyTakeaways: [
      'Convex functions guarantee that every local minimum is a global minimum.',
      'Second derivatives govern curvature in optimization loss landscapes.'
    ],
    markdownContent: `### Week 8: Convexity & Taylor Series\nCurvature, concavity and polynomial series approximations.`,
    examTips: ['If $f\'\'(c) = 0$, do not jump to conclusion that it is an inflection point — verify that $f\'\'(x)$ actually changes sign!']
  },
  {
    id: 'note-math1-w9',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Introduction to Integration & Fundamental Theorem of Calculus',
    detailedNotes: `### Week 9: Antiderivatives, Riemann Sums & FTC

#### 1. Indefinite Integrals (Antiderivatives)
If $F'(x) = f(x)$, then $\\int f(x) \\, dx = F(x) + C$.
- $\\int x^n \\, dx = \\frac{x^{n+1}}{n+1} + C \\quad (n \\ne -1)$
- $\\int \\frac{1}{x} \\, dx = \\ln|x| + C$
- $\\int e^{kx} \\, dx = \\frac{1}{k} e^{kx} + C$
- $\\int \\cos x \\, dx = \\sin x + C, \\quad \\int \\sin x \\, dx = -\\cos x + C$

#### 2. Definite Integral as a Riemann Sum Limit
$$\\int_a^b f(x) \\, dx = \\lim_{n \\to \\infty} \\sum_{i=1}^n f(x_i^*) \\Delta x, \\quad \\Delta x = \\frac{b - a}{n}$$

#### 3. Fundamental Theorem of Calculus (FTC)
- **FTC Part 1:** If $f$ is continuous on $[a, b]$ and $g(x) = \\int_a^x f(t) \\, dt$, then $g'(x) = f(x)$.
  - **Leibniz Rule:** $\\frac{d}{dx} \\left[ \\int_{u(x)}^{v(x)} f(t) \\, dt \\right] = f(v(x)) v'(x) - f(u(x)) u'(x)$.
- **FTC Part 2 (Evaluation Theorem):** If $F$ is an antiderivative of $f$, then:
  $$\\int_a^b f(x) \\, dx = F(b) - F(a)$$`,
    quickRevisionNotes: [
      'Integration is the inverse operation (antiderivative) of differentiation.',
      'FTC Part 1: $\\frac{d}{dx}\\int_a^x f(t)dt = f(x)$.',
      'Leibniz Rule handles variable limits: $\\frac{d}{dx}\\int_{u(x)}^{v(x)} f(t)dt = f(v(x))v\'(x) - f(u(x))u\'(x)$.',
      'FTC Part 2: $\\int_a^b f(x)dx = F(b) - F(a)$.'
    ],
    formulaSheets: [
      {
        name: 'Leibniz Integral Rule',
        formula: '\\frac{d}{dx} \\left[ \\int_{u(x)}^{v(x)} f(t) \\, dt \\right] = f(v(x)) v\'(x) - f(u(x)) u\'(x)',
        description: 'Differentiation under the integral sign with variable bounds.'
      },
      {
        name: 'Fundamental Theorem of Calculus',
        formula: '\\int_a^b f(x) \\, dx = F(b) - F(a) \\quad \\text{where } F\'(x) = f(x)',
        description: 'Evaluation theorem connecting antiderivative to area under curve.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w9-p1',
        questionText: 'Find $\\frac{d}{dx} \\left[ \\int_0^{x^2} \\sin(t^2) \\, dt \\right]$.',
        options: ['2x \\sin(x^4)', '\\sin(x^4)', '2x \\sin(x^2)', '\\cos(x^4)'],
        correctOptionIndex: 0,
        solution: 'By Leibniz rule: $f(v(x)) v\'(x) = \\sin((x^2)^2) \\cdot (2x) = 2x \\sin(x^4)$.',
        hints: ['Apply Leibniz differentiation rule.']
      },
      {
        id: 'math1-w9-p2',
        questionText: 'Evaluate $\\int_1^2 (3x^2 - 2x + 1) \\, dx$.',
        options: ['5', '6', '4', '7'],
        correctOptionIndex: 0,
        solution: 'Antiderivative $F(x) = x^3 - x^2 + x$. $F(2) = 2^3 - 2^2 + 2 = 8 - 4 + 2 = 6$. $F(1) = 1^3 - 1^2 + 1 = 1$. $\\int_1^2 f(x)dx = 6 - 1 = 5$.',
        hints: ['Find antiderivative and evaluate at limits 2 and 1.']
      },
      {
        id: 'math1-w9-p3',
        questionText: 'Evaluate $\\int_0^{\\pi/2} \\cos x \\, dx$.',
        options: ['1', '0', '-1', '\\pi/2'],
        correctOptionIndex: 0,
        solution: '$[\\sin x]_0^{\\pi/2} = \\sin(\\pi/2) - \\sin(0) = 1 - 0 = 1$.',
        hints: ['Antiderivative of $\\cos x$ is $\\sin x$.']
      }
    ],
    keyTakeaways: [
      'FTC directly links differential rates of change to accumulated areas.',
      'Leibniz rule is heavily tested in IITM exams for variable limit integrals.'
    ],
    markdownContent: `### Week 9: Riemann Sums & FTC\nFundamental theorems connecting derivative and integral.`,
    examTips: ['Remember to multiply by the derivative of the upper limit when applying Leibniz rule!']
  },
  {
    id: 'note-math1-w10',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Techniques of Integration: Substitution, By Parts & Partial Fractions',
    detailedNotes: `### Week 10: Advanced Analytical Integration Techniques

#### 1. $u$-Substitution (Reverse Chain Rule)
$$\\int f(g(x)) g'(x) \\, dx = \\int f(u) \\, du \\quad (u = g(x))$$

#### 2. Integration by Parts (Reverse Product Rule)
$$\\int u \\, dv = u v - \\int v \\, du$$
- **LIATE Rule for picking $u$:**
  1. **L** - Logarithmic functions ($\\ln x$)
  2. **I** - Inverse trigonometric ($\\arctan x, \\arcsin x$)
  3. **A** - Algebraic polynomials ($x^2, 3x$)
  4. **T** - Trigonometric ($\\sin x, \\cos x$)
  5. **E** - Exponential ($e^x$)

#### 3. Method of Partial Fractions
For rational functions $\\frac{P(x)}{Q(x)}$ where $\\deg(P) < \\deg(Q)$:
- Distinct linear factors: $\\frac{1}{(x-a)(x-b)} = \\frac{A}{x-a} + \\frac{B}{x-b}$
- Repeated linear factors: $\\frac{1}{(x-a)^2} = \\frac{A}{x-a} + \\frac{B}{(x-a)^2}$
- Irreducible quadratic: $\\frac{1}{(x-a)(x^2 + b)} = \\frac{A}{x-a} + \\frac{Bx + C}{x^2 + b}$`,
    quickRevisionNotes: [
      '$u$-substitution simplifies integrals matching the pattern $\\int f(g(x))g\'(x)dx$.',
      'Integration by parts: $\\int u dv = uv - \\int v du$.',
      'Pick $u$ using LIATE priority (Log > Inverse Trig > Algebraic > Trig > Exponential).',
      'Partial fractions decompose complex rational polynomials into simple logarithms.'
    ],
    formulaSheets: [
      {
        name: 'Integration by Parts',
        formula: '\\int u \\, dv = u v - \\int v \\, du',
        description: 'Integral transformation for products of dissimilar functions.'
      },
      {
        name: 'Logarithmic Derivative Integral',
        formula: '\\int \\frac{f\'(x)}{f(x)} \\, dx = \\ln|f(x)| + C',
        description: 'Direct substitution shortcut for numerator derivative ratios.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w10-p1',
        questionText: 'Evaluate $\\int x e^x \\, dx$.',
        options: ['(x - 1)e^x + C', '(x + 1)e^x + C', 'x^2 e^x + C', 'e^x + C'],
        correctOptionIndex: 0,
        solution: 'Let $u = x \\implies du = dx$; $dv = e^x dx \\implies v = e^x$. $\\int x e^x dx = x e^x - \\int e^x dx = x e^x - e^x + C = (x - 1)e^x + C$.',
        hints: ['Use integration by parts with $u = x$ and $dv = e^x dx$.']
      },
      {
        id: 'math1-w10-p2',
        questionText: 'Evaluate $\\int \\frac{2x}{x^2 + 5} \\, dx$.',
        options: ['\\ln(x^2 + 5) + C', '\\frac{1}{x^2 + 5} + C', '2\\ln(x^2 + 5) + C', '\\arctan(x) + C'],
        correctOptionIndex: 0,
        solution: 'Numerator is the exact derivative of denominator: $\\frac{d}{dx}(x^2 + 5) = 2x$. Thus $\\int \\frac{f\'(x)}{f(x)} dx = \\ln|x^2 + 5| + C$.',
        hints: ['Let $u = x^2 + 5 \\implies du = 2x dx$.']
      },
      {
        id: 'math1-w10-p3',
        questionText: 'Decompose $\\frac{1}{x^2 - 1}$ into partial fractions.',
        options: ['\\frac{1/2}{x - 1} - \\frac{1/2}{x + 1}', '\\frac{1}{x - 1} + \\frac{1}{x + 1}', '\\frac{1}{x - 1} - \\frac{1}{x + 1}', '\\frac{2}{x - 1} - \\frac{1}{x + 1}'],
        correctOptionIndex: 0,
        solution: '$\\frac{1}{(x-1)(x+1)} = \\frac{A}{x-1} + \\frac{B}{x+1}$. $1 = A(x+1) + B(x-1)$. Setting $x=1 \\implies A = 1/2$. Setting $x=-1 \\implies B = -1/2$.',
        hints: ['Factor denominator as $(x-1)(x+1)$.']
      }
    ],
    keyTakeaways: [
      'LIATE guideline guarantees optimal algebraic reduction for integration by parts.',
      'Partial fractions decompose rational likelihood functions in statistics.'
    ],
    markdownContent: `### Week 10: Advanced Integration Methods\nSubstitution, LIATE parts, and partial fraction expansions.`,
    examTips: ['Watch out for definite integrals with $u$-substitution — update the upper and lower integration bounds!']
  },
  {
    id: 'note-math1-w11',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Definite Integrals, Areas Under Curves & Geometric Applications',
    detailedNotes: `### Week 11: Definite Integrals, Symmetry & Area Computation

#### 1. Symmetry Properties of Definite Integrals
- **Odd Function ($f(-x) = -f(x)$):** $\\int_{-a}^a f(x) \\, dx = 0$
- **Even Function ($f(-x) = f(x)$):** $\\int_{-a}^a f(x) \\, dx = 2 \\int_0^a f(x) \\, dx$
- **King\'s Property:**
  $$\\int_a^b f(x) \\, dx = \\int_a^b f(a + b - x) \\, dx$$

#### 2. Area Between Two Curves
If $f(x) \\ge g(x)$ on $[a, b]$:
$$A = \\int_a^b [f(x) - g(x)] \\, dx$$
- If curves intersect at intermediate points, partition into subintervals:
  $$A = \\int_a^b |f(x) - g(x)| \\, dx$$

#### 3. Average Value of a Continuous Function
$$f_{\\text{avg}} = \\frac{1}{b - a} \\int_a^b f(x) \\, dx$$`,
    quickRevisionNotes: [
      'Odd function on $[-a, a] \\implies \\int_{-a}^a f(x)dx = 0$.',
      'King\'s property: $\\int_a^b f(x)dx = \\int_a^b f(a+b-x)dx$.',
      'Area between curves: $\\int_a^b [\\text{Upper}(x) - \\text{Lower}(x)]dx$.',
      'Average value formula: $\\frac{1}{b-a}\\int_a^b f(x)dx$.'
    ],
    formulaSheets: [
      {
        name: 'King\'s Property of Definite Integrals',
        formula: '\\int_a^b f(x) \\, dx = \\int_a^b f(a + b - x) \\, dx',
        description: 'Integral transformation exploiting symmetric interval reflection.'
      },
      {
        name: 'Area Between Intersecting Curves',
        formula: 'A = \\int_a^b [f(x) - g(x)] \\, dx \\quad \\text{where } f(x) \\ge g(x)',
        description: 'Euclidean planar area enclosed by two continuous bounding curves.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w11-p1',
        questionText: 'Evaluate $\\int_{-\\pi}^{\\pi} (x^3 + \\sin x + x^5) \\, dx$.',
        options: ['0', '2\\pi', '\\pi^2', '1'],
        correctOptionIndex: 0,
        solution: 'The integrand $f(x) = x^3 + \\sin x + x^5$ is an odd function because $f(-x) = (-x)^3 + \\sin(-x) + (-x)^5 = -f(x)$. The integral of any odd function over $[-a, a]$ is strictly 0.',
        hints: ['Check if the integrand is odd or even.']
      },
      {
        id: 'math1-w11-p2',
        questionText: 'Find the area enclosed between $y = x^2$ and $y = x$.',
        options: ['1/6', '1/3', '1/2', '1/12'],
        correctOptionIndex: 0,
        solution: 'Intersection points: $x^2 = x \\implies x(x-1) = 0 \\implies x = 0, 1$. On $[0, 1]$, $x \\ge x^2$. Area $= \\int_0^1 (x - x^2) dx = \\left[ \\frac{x^2}{2} - \\frac{x^3}{3} \\right]_0^1 = \\frac{1}{2} - \\frac{1}{3} = \\frac{1}{6}$.',
        hints: ['Find intersection points and compute $\\int_0^1 (x - x^2)dx$.']
      },
      {
        id: 'math1-w11-p3',
        questionText: 'Find the average value of $f(x) = 3x^2$ on $[0, 2]$.',
        options: ['4', '8', '2', '6'],
        correctOptionIndex: 0,
        solution: '$f_{\\text{avg}} = \\frac{1}{2 - 0} \\int_0^2 3x^2 dx = \\frac{1}{2} [x^3]_0^2 = \\frac{1}{2}(8 - 0) = 4$.',
        hints: ['Use formula $f_{\\text{avg}} = \\frac{1}{b-a}\\int_a^b f(x)dx$.']
      }
    ],
    keyTakeaways: [
      'Symmetry properties allow immediate zero evaluation of complex trigonometric polynomials.',
      'Definite integrals compute total probability mass under density curves in statistics.'
    ],
    markdownContent: `### Week 11: Definite Integrals & Areas\nSymmetry theorems, King\'s rule, and planar enclosed areas.`,
    examTips: ['Always test $f(a+b-x)$ when dealing with fractions involving $\\sin x / (\\sin x + \\cos x)$.']
  },
  {
    id: 'note-math1-w12',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Sequences, Series, Geometric Progression & Convergence Tests',
    detailedNotes: `### Week 12: Infinite Series, Convergence Tests & Power Expansions

#### 1. Arithmetic & Geometric Progressions
- **Arithmetic Progression (AP):** $a_n = a + (n-1)d$, $S_n = \\frac{n}{2}[2a + (n-1)d]$
- **Geometric Progression (GP):** $a_n = a r^{n-1}$, $S_n = \\frac{a(1 - r^n)}{1 - r}$
- **Infinite Geometric Series:**
  $$S_\\infty = \\sum_{n=0}^\\infty a r^n = \\frac{a}{1 - r} \\quad \\iff |r| < 1$$

#### 2. Convergence Tests for Positive Series $\\sum a_n$
- **$n$-th Term Test for Divergence:** If $\\lim_{n \\to \\infty} a_n \\ne 0$, then $\\sum a_n$ diverges. (Note: $\\lim a_n = 0$ does NOT guarantee convergence, e.g. harmonic series $\\sum 1/n$).
- **$p$-Series Test:** $\\sum_{n=1}^\\infty \\frac{1}{n^p}$ converges $\\iff p > 1$.
- **Ratio Test:** Let $L = \\lim_{n \\to \\infty} \\left| \\frac{a_{n+1}}{a_n} \\right|$:
  - $L < 1 \\implies$ Absolute Convergence
  - $L > 1 \\implies$ Divergence
  - $L = 1 \\implies$ Inconclusive

#### 3. Alternating Series & Leibniz Test
$\\sum (-1)^n b_n$ converges if:
1. $b_{n+1} \\le b_n$ (monotonically decreasing)
2. $\\lim_{n \\to \\infty} b_n = 0$`,
    quickRevisionNotes: [
      'Infinite GP sum: $S_\\infty = \\frac{a}{1 - r}$ converges iff $|r| < 1$.',
      '$p$-series $\\sum 1/n^p$ converges iff $p > 1$.',
      'Ratio test: $L = \\lim |a_{n+1}/a_n| < 1 \\implies$ Converges; $> 1 \\implies$ Diverges.',
      '$n$-th term test: $\\lim a_n \\ne 0 \\implies$ Diverges.'
    ],
    formulaSheets: [
      {
        name: 'Infinite Geometric Series Sum',
        formula: 'S_\\infty = \\sum_{k=0}^\\infty a r^k = \\frac{a}{1 - r} \\quad \\text{for } |r| < 1',
        description: 'Closed-form sum of infinite converging geometric series.'
      },
      {
        name: 'D\'Alembert Ratio Test',
        formula: 'L = \\lim_{n \\to \\infty} \\left| \\frac{a_{n+1}}{a_n} \\right| < 1 \\implies \\sum a_n \\text{ converges}',
        description: 'Standard ratio convergence criterion for factorials and exponentials.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math1-w12-p1',
        questionText: 'Find the sum of the infinite series $4 + 2 + 1 + 1/2 + 1/4 + \\dots$',
        options: ['8', '6', '12', '16'],
        correctOptionIndex: 0,
        solution: 'First term $a = 4$, common ratio $r = 2/4 = 1/2 < 1$. Sum $S_\\infty = \\frac{a}{1 - r} = \\frac{4}{1 - 1/2} = \\frac{4}{1/2} = 8$.',
        hints: ['Use $S_\\infty = \\frac{a}{1 - r}$ with $a = 4$ and $r = 1/2$.']
      },
      {
        id: 'math1-w12-p2',
        questionText: 'For which value of $p$ does the series $\\sum_{n=1}^\\infty \\frac{1}{n^{2p - 3}}$ converge?',
        options: ['p > 2', 'p > 1', 'p < 2', 'p \\ge 2'],
        correctOptionIndex: 0,
        solution: 'By $p$-series test, the exponent must be strictly greater than $1$: $2p - 3 > 1 \\implies 2p > 4 \\implies p > 2$.',
        hints: ['Apply $p$-series condition: power $> 1$.']
      },
      {
        id: 'math1-w12-p3',
        questionText: 'Using the ratio test on $\\sum_{n=1}^\\infty \\frac{3^n}{n!}$, what is $L$ and does it converge?',
        options: ['L = 0, converges', 'L = 3, diverges', 'L = 1, inconclusive', 'L = \\infty, diverges'],
        correctOptionIndex: 0,
        solution: '$\\frac{a_{n+1}}{a_n} = \\frac{3^{n+1}}{(n+1)!} \\times \\frac{n!}{3^n} = \\frac{3}{n+1}$. $\\lim_{n \\to \\infty} \\frac{3}{n+1} = 0 < 1$. Thus $L = 0$, series converges absolutely.',
        hints: ['Simplify $\\frac{a_{n+1}}{a_n}$ and take limit as $n \\to \\infty$.']
      }
    ],
    keyTakeaways: [
      'Series convergence underpins polynomial expansions and expectation sums in probability.',
      'Ratio test is the primary tool whenever factorials $n!$ or exponentials $k^n$ appear.'
    ],
    markdownContent: `### Week 12: Sequences & Series\nGeometric progressions, ratio tests, and p-series convergence.`,
    examTips: ['Remember: $\\lim a_n = 0$ is a necessary condition for convergence, NOT a sufficient condition! (e.g. $\\sum 1/n$ diverges).']
  }
];

import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_JAVA_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-java-w1',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 1,
    title: 'Java Architecture, Bytecode, JVM/JRE/JDK, Primitive Types & Control Structures',
    detailedNotes: `### Week 1: Java Platform Architecture & Language Fundamentals

#### 1. Java Virtual Machine (JVM) & "Write Once, Run Anywhere" (WORA)
Java source code (\`.java\`) is compiled by \`javac\` into platform-independent intermediate **Bytecode** (\`.class\` files). The Java Virtual Machine (JVM) interprets or just-in-time (JIT) compiles this bytecode into native machine instructions for the host CPU.

$$\\text{Source Code (.java)} \\xrightarrow{\\text{javac}} \\text{Bytecode (.class)} \\xrightarrow{\\text{JVM / JIT}} \\text{Native Machine Code}$$

- **JDK (Java Development Kit):** Compiler (\`javac\`), debugger, archiver (\`jar\`), and development tools + JRE.
- **JRE (Java Runtime Environment):** JVM + standard core class libraries (\`java.lang\`, \`java.util\`, etc.).
- **JVM Components:** ClassLoader subsystem, Runtime Data Areas (Method Area, Heap, JVM Stacks, PC Registers, Native Method Stacks), and Execution Engine (Interpreter + JIT Compiler + Garbage Collector).

#### 2. Data Types & Memory Layout
1. **Primitive Data Types:**
   - Integral: \`byte\` (8-bit, $[-128, 127]$), \`short\` (16-bit, $[-32768, 32767]$), \`int\` (32-bit, $[-2^{31}, 2^{31}-1]$), \`long\` (64-bit, $[-2^{63}, 2^{63}-1]$).
   - Floating-point: \`float\` (32-bit IEEE 754), \`double\` (64-bit IEEE 754).
   - Character: \`char\` (16-bit Unicode UTF-16, $[0, 65535]$).
   - Boolean: \`boolean\` (\`true\` or \`false\`).
2. **Type Promotion in Expressions:**
   - Small integer types (\`byte\`, \`short\`, \`char\`) are automatically promoted to \`int\` before binary arithmetic operations!

#### 3. Fully Solved Step-by-Step Numerical & Code Examples

**Example 1 (Type Promotion & Casting):**
*Problem:* What is the result and data type of the expression \`byte a = 40; byte b = 50; byte c = (byte)(a * b);\`?
*Solution:*
1. In the expression \`a * b\`, both \`a\` and \`b\` are promoted to 32-bit \`int\`.
2. Multiplication: $40 \\times 50 = 2000$ (an integer).
3. 2000 in 32-bit binary: \`00000000 00000000 00000111 11010000\`.
4. Casting to \`byte\` truncates all except the lowest 8 bits: \`11010000\`.
5. In two\'s complement 8-bit, the leading 1 signifies a negative number. Value $= -128 + 64 + 16 = -48$.
6. Final output assigned to \`c\` is \`-48\`.

**Example 2 (Short-Circuit Evaluation):**
*Problem:* Analyze the output of \`int x = 5, y = 10; if (x > 10 && ++y > 10) { } System.out.println(y);\`
*Solution:*
1. Left operand of \`&&\` is \`x > 10\` ($5 > 10$), which evaluates to \`false\`.
2. Short-circuit rule for logical AND: if the first operand is \`false\`, the second operand \`++y > 10\` is **never executed**.
3. Therefore, \`y\` remains \`10\`.`,
    quickRevisionNotes: [
      'Bytecode (.class) is platform-neutral; the JVM is platform-specific.',
      'byte, short, char always promote to int in arithmetic expressions.',
      '&& and || are short-circuit logical operators; & and | evaluate both sides unconditionally.'
    ],
    formulaSheets: [
      {
        name: 'Primitive Type Range Formula',
        formula: '[-2^{b-1}, 2^{b-1}-1]',
        description: 'Range of signed two\'s complement integral type with b bits.'
      }
    ],
    definitions: [
      {
        term: 'Just-In-Time (JIT) Compiler',
        explanation: 'JVM subsystem that compiles frequently executed bytecode (hotspots) directly into native machine code at runtime.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Primitive Types & Bitwise Arithmetic',
        code: `public class DataPrimitives {
    public static void main(String[] args) {
        byte b1 = 50;
        byte b2 = 50;
        // Explicit cast required as b1 * b2 promotes to int
        byte result = (byte)(b1 * b2); 
        System.out.println("Result: " + result); // Prints -60 due to overflow
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w1-q1',
        questionText: 'What is the output of compiling and running: `int a = 10; System.out.println(a++ + ++a);`?',
        options: ['21', '22', '20', '23'],
        correctOptionIndex: 1,
        solution: '`a++` returns current value 10 and then increments `a` to 11. `++a` increments `a` to 12 and returns 12. Sum is 10 + 12 = 22.',
        hints: ['Post-increment uses value first, pre-increment modifies before returning.']
      }
    ],
    examTips: [
      'Always remember that array indices in Java are 32-bit signed ints; array length cannot exceed 2^31 - 1.',
      'Floating point operations adhere strictly to IEEE 754 standards.'
    ],
    handwrittenMnemonic: 'Bytecode travels anywhere, but JVM translates locally!'
  },
  {
    id: 'note-java-w2',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 2,
    title: 'Classes, Objects, Constructors, "this" Keyword & Garbage Collection',
    detailedNotes: `### Week 2: Object-Oriented Principles: Classes, Objects & Memory Lifecycle

#### 1. Heap vs. Stack Memory Allocation
- **Stack Memory:** Stores method invocation frames, local variable primitives, and object references. Stack frames are allocated and deallocated automatically in LIFO order upon method entry/return.
- **Heap Memory:** All Java objects and arrays are dynamically allocated on the shared heap using the \`new\` operator.

#### 2. Constructors & The \`this\` Reference
- A constructor initializes newly instantiated objects. If no constructor is explicitly provided, Java supplies a default parameterless constructor.
- \`this\` refers to the current object instance:
  1. Resolves shadowing between instance fields and parameter names (\`this.name = name\`).
  2. Constructor chaining using \`this(arg1, arg2)\` (MUST be the first statement in constructor!).

#### 3. Solved Step-by-Step Examples

**Example 1 (Constructor Chaining & Execution Order):**
*Problem:* Trace the output of instantiating \`new Derived()\` where \`Base\` has \`Base() { print("B"); }\` and \`Derived() { super(); print("D"); }\`.
*Solution:*
1. Memory is allocated on the heap for the \`Derived\` instance.
2. \`Derived()\` constructor calls \`super()\` (invoking \`Base()\`).
3. \`Base()\` executes, printing "B".
4. Control returns to \`Derived()\`, printing "D". Output: "BD".

**Example 2 (Garbage Collection Eligibility):**
*Problem:* In \`Student s1 = new Student("A"); Student s2 = new Student("B"); s1 = s2;\`, how many objects are eligible for GC?
*Solution:*
1. Two objects ("A" and "B") were created on heap.
2. Reassigning \`s1 = s2\` leaves object "A" with zero incoming references.
3. Therefore, exactly 1 object ("A") becomes eligible for Garbage Collection.`,
    quickRevisionNotes: [
      'Constructors do not have a return type (not even void).',
      'this() must be the very first line inside a constructor.',
      'Objects on heap with zero live reachable references become GC eligible.'
    ],
    formulaSheets: [
      {
        name: 'Heap Object Lifecycle',
        formula: '\\text{Reachable References} = 0 \\implies \\text{GC Candidate}',
        description: 'Condition for Mark-and-Sweep Garbage Collector eligibility.'
      }
    ],
    definitions: [
      {
        term: 'Garbage Collector (GC)',
        explanation: 'Automatic memory management thread in the JVM that reclaims memory occupied by unreachable objects.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Constructor Overloading & Chaining',
        code: `public class Account {
    private String id;
    private double balance;

    public Account(String id) {
        this(id, 0.0); // Constructor chaining
    }

    public Account(String id, double balance) {
        this.id = id;
        this.balance = balance;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w2-q1',
        questionText: 'Which keyword is used to explicitly call another constructor of the same class?',
        options: ['this()', 'super()', 'self()', 'new()'],
        correctOptionIndex: 0,
        solution: '`this()` invokes an overloaded constructor in the same class and must be the first statement.',
        hints: ['`super()` calls parent constructor, `this()` calls own constructor.']
      }
    ],
    examTips: [
      'Instance initializer blocks execute before the constructor body whenever an object is instantiated.',
      'GC invocation via `System.gc()` is merely a request, NOT a guarantee of immediate execution.'
    ],
    handwrittenMnemonic: 'Stack holds references; Heap holds real objects!'
  },
  {
    id: 'note-java-w3',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 3,
    title: 'Inheritance, Method Overriding, Dynamic Method Dispatch & "super"',
    detailedNotes: `### Week 3: Inheritance & Runtime Polymorphism

#### 1. Class Inheritance Model
Java supports single implementation inheritance using \`extends\`. Multiple inheritance of state is prohibited to avoid the Diamond Problem.

#### 2. Method Overriding Rules
An overriding method in a subclass MUST:
1. Have the identical method signature (name, parameter types, parameter order).
2. Have the same or a **covariant return type** (subclass of the parent return type).
3. Have an equal or **less restrictive access modifier** (\`public\` $\\ge$ \`protected\` $\\ge$ package-private).
4. NOT throw new or broader checked exceptions than declared by the superclass method.

#### 3. Dynamic Method Dispatch (Runtime Polymorphism)
When a superclass reference variable points to a subclass instance:
$$\\text{SuperClass ref} = \\text{new SubClass}(); \\quad \\text{ref.method}();$$
- The compiler checks if \`method()\` exists in \`SuperClass\`.
- At runtime, the JVM executes the implementation corresponding to the actual instance type (\`SubClass\`).`,
    quickRevisionNotes: [
      'Method overriding is determined at runtime based on the actual object instance on the heap.',
      'Method overloading is resolved at compile-time based on static reference parameter types.',
      'Private, static, and final methods cannot be overridden!'
    ],
    formulaSheets: [
      {
        name: 'Dynamic Dispatch Principle',
        formula: '\\text{Ref Type} \\to \\text{Checks Visibility at Compile-time}; \\quad \\text{Instance Type} \\to \\text{Executes Method at Runtime}',
        description: 'Core law of Java runtime polymorphism.'
      }
    ],
    definitions: [
      {
        term: 'Covariant Return Type',
        explanation: 'Subclass overriding method returning a more specific subtype than the parent method return type.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Polymorphic Dispatch Example',
        code: `class Shape {
    void draw() { System.out.println("Shape"); }
}
class Circle extends Shape {
    @Override
    void draw() { System.out.println("Circle"); }
}
public class Test {
    public static void main(String[] args) {
        Shape s = new Circle();
        s.draw(); // Prints "Circle" via dynamic dispatch
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w3-q1',
        questionText: 'Can a static method in a parent class be overridden in a child class?',
        options: ['No, it is method hidden, not overridden', 'Yes, with @Override annotation', 'Only if made public', 'Yes, dynamically dispatched'],
        correctOptionIndex: 0,
        solution: 'Static methods belong to the class, not instance. Redefining a static method is Method Hiding, resolved at compile-time.',
        hints: ['Static methods are resolved based on compile-time reference type.']
      }
    ],
    examTips: [
      'Constructors are NEVER inherited and cannot be overridden.',
      '`super.method()` bypasses subclass overriding to invoke the parent implementation.'
    ],
    handwrittenMnemonic: 'Reference decides legality; Real object executes reality!'
  },
  {
    id: 'note-java-w4',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 4,
    title: 'Abstract Classes, Interfaces, Default Methods & Multiple Interface Inheritance',
    detailedNotes: `### Week 4: Abstraction, Interfaces & Multiple Inheritance

#### 1. Abstract Classes vs. Interfaces
- **Abstract Class:** Can contain instance fields, constructors, concrete methods, and abstract methods (\`abstract void run();\`). Used for "is-a" relationships sharing state.
- **Interface:** Pure contract. In modern Java (Java 8+):
  - Fields are implicitly \`public static final\` (constants).
  - Methods are implicitly \`public abstract\` unless declared \`default\` or \`static\`.
  - Java 9 added \`private\` helper methods in interfaces.

#### 2. Diamond Problem Resolution with Default Methods
When a class implements two interfaces declaring identical \`default\` methods:
\`interface A { default void show() { ... } }\` and \`interface B { default void show() { ... } }\`.
The implementing class MUST explicitly override \`show()\` and disambiguate:
\`A.super.show();\` or provide its own logic.`,
    quickRevisionNotes: [
      'A class can extend only 1 class, but implement multiple interfaces.',
      'Interface fields are always public static final.',
      'Default methods enable backward-compatible library extension without breaking implementations.'
    ],
    formulaSheets: [
      {
        name: 'Interface Disambiguation',
        formula: 'InterfaceName.super.methodName()',
        description: 'Syntax to resolve duplicate default method conflicts in implementing classes.'
      }
    ],
    definitions: [
      {
        term: 'Functional Interface',
        explanation: 'An interface containing exactly one abstract method (Single Abstract Method - SAM), eligible for Lambda expressions.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Interface Default Method Disambiguation',
        code: `interface Alpha {
    default void log() { System.out.println("Alpha"); }
}
interface Beta {
    default void log() { System.out.println("Beta"); }
}
class Omega implements Alpha, Beta {
    @Override
    public void log() {
        Alpha.super.log(); // Explicit disambiguation
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w4-q1',
        questionText: 'Can an interface have a constructor in Java?',
        options: ['No, interfaces cannot be instantiated or have state', 'Yes, only private constructors', 'Yes, default constructors', 'Only in Java 9+'],
        correctOptionIndex: 0,
        solution: 'Interfaces do not have instance variables/state, and cannot have constructors.',
        hints: ['Constructors initialize instance state; interfaces have no instance state.']
      }
    ],
    examTips: [
      'An abstract class does NOT have to contain any abstract methods.',
      'If a concrete class implements an interface, it must implement ALL abstract methods.'
    ],
    handwrittenMnemonic: 'Abstract classes share state; Interfaces share contracts!'
  },
  {
    id: 'note-java-w5',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 5,
    title: 'Exception Handling: Checked vs Unchecked, try-catch-finally & try-with-resources',
    detailedNotes: `### Week 5: Robust Exception Handling & Resource Management

#### 1. Throwable Hierarchy
$$\\text{Throwable} \\begin{cases} \\text{Error (Unchecked: OutOfMemoryError, StackOverflowError)} \\\\ \\text{Exception} \\begin{cases} \\text{RuntimeException (Unchecked: NullPointerException, ArrayIndexOutOfBoundsException)} \\\\ \\text{Checked Exceptions (IOException, SQLException, ClassNotFoundException)} \\end{cases} \\end{cases}$$

- **Checked Exceptions:** Inherit directly from \`Exception\`. Must be either caught (\`try-catch\`) or declared in method signature (\`throws\`). Checked by compiler.
- **Unchecked Exceptions:** Inherit from \`RuntimeException\` or \`Error\`. Indicate logic bugs or unrecoverable JVM faults.

#### 2. \`finally\` Block Execution & \`try-with-resources\`
- \`finally\` executes unconditionally, even if \`return\` or an unhandled exception occurs in \`try\`/\`catch\`!
- **AutoCloseable & try-with-resources (Java 7+):** Any resource implementing \`java.lang.AutoCloseable\` is automatically closed at the end of the block in reverse order of declaration.`,
    quickRevisionNotes: [
      'Checked exceptions require try-catch or throws clause; unchecked exceptions do not.',
      'finally block runs even if try contains a return statement (except System.exit(0)).',
      'try-with-resources closes streams automatically without explicit finally blocks.'
    ],
    formulaSheets: [
      {
        name: 'AutoCloseable Contract',
        formula: '\\text{try}(R_1 \\ r_1 = \\dots; R_2 \\ r_2 = \\dots) \\implies r_2.\\text{close}(); \\ r_1.\\text{close}();',
        description: 'Deterministic reverse-order resource closing in try-with-resources.'
      }
    ],
    definitions: [
      {
        term: 'try-with-resources',
        explanation: 'Statement that declares one or more resources and automatically closes them at statement termination.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'try-with-resources with AutoCloseable',
        code: `import java.io.*;

public class FileUtil {
    public static void readFile(String path) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } // br.close() is automatically called here
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w5-q1',
        questionText: 'What happens if a return statement is present in both `try` and `finally` blocks?',
        options: ['The value from `finally` overrides the `try` return value', 'Compile-time error', 'The value from `try` is returned', 'Undefined runtime behavior'],
        correctOptionIndex: 0,
        solution: 'The finally block executes last and its return statement overrides any return statement in the try block.',
        hints: ['finally always has the last word.']
      }
    ],
    examTips: [
      'Never catch generic Throwable or Error; catch specific exception classes.',
      'Multi-catch block `catch (IOException | SQLException e)` makes variable `e` implicitly final.'
    ],
    handwrittenMnemonic: 'Checked = Compiler enforces; Unchecked = Runtime logic bug!'
  },
  {
    id: 'note-java-w6',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 6,
    title: 'Java Generics, Type Erasure, Bounded Wildcards (PECS) & Generic Classes',
    detailedNotes: `### Week 6: Parametric Polymorphism: Java Generics & Type Safety

#### 1. Compile-Time Type Safety & Type Erasure
Java Generics provide compile-time safety and eliminate explicit casting.
- **Type Erasure:** To ensure backward compatibility with pre-generic Java (Java 1.4), the compiler erases all generic type parameters and replaces them with their bounds (or \`Object\` if unbounded) and inserts appropriate casts.
- Therefore, at runtime, \`List<String>\` and \`List<Integer>\` share the exact same bytecode class \`List.class\`!

#### 2. Bounded Types & Wildcards (PECS Principle)
- **Upper-Bounded Wildcard:** \`<? extends Number>\` (Producer $\\implies$ Covariance). Can read items as \`Number\`, but cannot write elements!
- **Lower-Bounded Wildcard:** \`<? super Integer>\` (Consumer $\\implies$ Contravariance). Can safely write \`Integer\` elements.
- **PECS Rule:** **P**roducer **E**xtends, **C**onsumer **S**uper!`,
    quickRevisionNotes: [
      'Generics prevent ClassCastException at runtime via compile-time verification.',
      'Type Erasure removes type arguments at runtime; you cannot do `new T()` or `instanceof List<String>`.',
      'PECS: Use `? extends T` when reading from collection; use `? super T` when writing into collection.'
    ],
    formulaSheets: [
      {
        name: 'PECS Rule',
        formula: '\\text{Producer} \\implies \\text{? extends T}, \\quad \\text{Consumer} \\implies \\text{? super T}',
        description: 'Joshua Bloch\'s mnemonic for generic bounded wildcards.'
      }
    ],
    definitions: [
      {
        term: 'Type Erasure',
        explanation: 'Compiler process that removes all type parameters and replaces them with raw types or bounds in bytecode.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Generic Method with Bounded Wildcards (PECS)',
        code: `import java.util.List;

public class MathCollections {
    // Producer Extends: Reads numbers and sums them
    public static double sum(List<? extends Number> list) {
        double total = 0.0;
        for (Number n : list) {
            total += n.doubleValue();
        }
        return total;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w6-q1',
        questionText: 'Can you instantiate a generic array directly like `T[] arr = new T[10];` in Java?',
        options: ['No, because type erasure prevents the runtime from knowing type T', 'Yes, always allowed', 'Only if T extends Object', 'Yes, using `new T[10]` syntax'],
        correctOptionIndex: 0,
        solution: 'Arrays need reifiable type information at runtime to ensure type safety. Due to type erasure, generic type T is not reifiable.',
        hints: ['Arrays are covariant and reifiable; Generics are invariant and erased.']
      }
    ],
    examTips: [
      'You cannot create instances of type parameters (`new T()`) or static fields of type `T`.',
      'Primitive types (`int`, `double`) cannot be used as generic type arguments (use `Integer`, `Double`).'
    ],
    handwrittenMnemonic: 'Producer Extends (read only), Consumer Super (write only)!'
  },
  {
    id: 'note-java-w7',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 7,
    title: 'Java Collections Framework: List, Set, Map, Queue & Concurrent Collections',
    detailedNotes: `### Week 7: Collections Framework & Data Structures

#### 1. Core Collection Hierarchy
$$\\text{Iterable} \\to \\text{Collection} \\begin{cases} \\text{List (Ordered, indexed, allows duplicates): ArrayList, LinkedList, Vector} \\\\ \\text{Set (Unique elements): HashSet, LinkedHashSet, TreeSet (Sorted)} \\\\ \\text{Queue (FIFO / Priority): ArrayDeque, PriorityQueue} \\end{cases}$$
$$\\text{Map (Key-Value pairs, not Collection): HashMap, LinkedHashMap, TreeMap (Sorted by Key)}$$

#### 2. Internal Mechanism of \`HashMap\`
- Uses an array of buckets (Node/Entry linked lists).
- Index calculated via: $\\text{index} = (n - 1) \\& \\text{hash}(key)$.
- **Hash Collision Resolution:** Chaining. In Java 8+, if a single bucket contains more than 8 elements (and total table capacity $\\ge 64$), the bucket transforms from a linked list ($O(n)$) into a Red-Black Balanced Binary Search Tree ($O(\\log n)$)!
- **Load Factor:** Default is $0.75$. When size $> 0.75 \\times \\text{capacity}$, table doubles in size (rehashing).`,
    quickRevisionNotes: [
      'ArrayList provides O(1) random access; LinkedList provides O(1) insertion/deletion at pointers.',
      'HashSet and HashMap require proper implementation of both equals() and hashCode().',
      'TreeSet and TreeMap maintain natural or comparator-specified sorted order (O(log n)).'
    ],
    formulaSheets: [
      {
        name: 'HashMap Bucket Indexing',
        formula: '\\text{index} = (n - 1) \\ \\& \\ \\text{hash}(key)',
        description: 'Bitwise AND bucket index calculation where table size n is a power of 2.'
      }
    ],
    definitions: [
      {
        term: 'Treeification in HashMap',
        explanation: 'Conversion of overloaded bucket linked list to Red-Black tree when chain length reaches 8.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Custom Object in HashMap with equals and hashCode',
        code: `import java.util.Objects;

class Student {
    private int id;
    private String name;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Student)) return false;
        Student s = (Student) o;
        return id == s.id && Objects.equals(name, s.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w7-q1',
        questionText: 'If two objects are equal according to `equals()`, what must be true about their `hashCode()`?',
        options: ['Their hashCodes must be identical', 'Their hashCodes must be different', 'No relationship required', 'HashCodes must be positive'],
        correctOptionIndex: 0,
        solution: 'The Java equals-hashCode contract mandates that if a.equals(b) is true, then a.hashCode() == b.hashCode() must also be true.',
        hints: ['Equal objects must hash to the exact same bucket.']
      }
    ],
    examTips: [
      'Iterating over a collection while modifying it directly causes `ConcurrentModificationException` (Fail-Fast iterator). Use `Iterator.remove()` instead!',
      'PriorityQueue does NOT guarantee sorted iteration order; only `poll()` extracts in min/max priority order.'
    ],
    handwrittenMnemonic: 'Equal objects MUST have equal hash codes!'
  },
  {
    id: 'note-java-w8',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 8,
    title: 'Multithreading: Threads, Runnable, Synchronization & Inter-Thread Communication',
    detailedNotes: `### Week 8: Concurrent Programming & Thread Synchronization

#### 1. Creating Threads in Java
1. Extend \`java.lang.Thread\` and override \`run()\`.
2. Implement \`java.lang.Runnable\` and pass instance to \`new Thread(runnable).start()\`.
3. Implement \`Callable<V>\` and submit to \`ExecutorService\` (returns \`Future<V>\`).

#### 2. Race Conditions & Critical Sections
A race condition occurs when concurrent threads access shared mutable data without coordination.
- **\`synchronized\` Keyword:** Acquires the intrinsic monitor lock of the object:
  - Instance method: Synchronizes on \`this\`.
  - Static method: Synchronizes on \`ClassName.class\`.
  - Synchronized block: \`synchronized(lockObject) { ... }\`.

#### 3. Inter-Thread Communication (\`wait\`, \`notify\`, \`notifyAll\`)
- Must be called inside a \`synchronized\` block holding the target object\'s monitor lock!
- \`wait()\` releases the monitor lock and suspends the thread until another thread calls \`notify()\` or \`notifyAll()\`.`,
    quickRevisionNotes: [
      'Call start() to spawn a new OS thread; calling run() directly executes in the current thread synchronously!',
      'synchronized keyword guarantees both Mutual Exclusion and Visibility.',
      'volatile keyword guarantees visibility across CPU core caches, but NOT atomicity of compound operations (like count++).'
    ],
    formulaSheets: [
      {
        name: 'Amdahl\'s Law of Parallel Speedup',
        formula: 'S(p) = \\frac{1}{(1 - f) + \\frac{f}{p}}',
        description: 'Theoretical maximum speedup for parallel program with parallel fraction f on p processor cores.'
      }
    ],
    definitions: [
      {
        term: 'Deadlock',
        explanation: 'A condition where two or more threads are permanently blocked, each waiting for a lock held by the other.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Producer-Consumer Pattern with wait/notify',
        code: `class Buffer {
    private int data;
    private boolean hasData = false;

    public synchronized void produce(int val) throws InterruptedException {
        while (hasData) {
            wait(); // Wait until consumer reads
        }
        this.data = val;
        this.hasData = true;
        notifyAll();
    }

    public synchronized int consume() throws InterruptedException {
        while (!hasData) {
            wait(); // Wait until producer writes
        }
        this.hasData = false;
        notifyAll();
        return this.data;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w8-q1',
        questionText: 'What happens if you invoke `wait()` outside of a `synchronized` context?',
        options: ['IllegalMonitorStateException is thrown at runtime', 'Deadlock occurs immediately', 'Thread sleeps normally', 'Compile-time syntax error'],
        correctOptionIndex: 0,
        solution: 'The calling thread must own the monitor lock of the object before calling wait() or notify(); otherwise IllegalMonitorStateException is thrown.',
        hints: ['wait() releases the lock, so it must own it first!']
      }
    ],
    examTips: [
      'Always invoke wait() inside a `while` loop, NEVER an `if` statement, to guard against spurious wakeups.',
      'The `join()` method causes the current thread to pause execution until the target thread completes.'
    ],
    handwrittenMnemonic: 'Always wait inside a while loop to beat spurious wakeups!'
  },
  {
    id: 'note-java-w9',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 9,
    title: 'Functional Programming in Java: Lambda Expressions, Method References & Streams API',
    detailedNotes: `### Week 9: Functional Java: Lambdas, Functional Interfaces & Streams

#### 1. Lambda Syntax & Core Functional Interfaces
Lambdas represent anonymous functions implementing Single Abstract Method (SAM) interfaces:
$$\\text{Syntax: } (\\text{parameters}) \\to \\text{expression / body}$$
- \`Predicate<T>\`: \`boolean test(T t)\`
- \`Function<T, R>\`: \`R apply(T t)\`
- \`Consumer<T>\`: \`void accept(T t)\`
- \`Supplier<T>\`: \`T get()\`
- \`UnaryOperator<T>\`: \`T apply(T t)\`, \`BinaryOperator<T>\`: \`T apply(T t1, T t2)\`

#### 2. Java 8 Streams API (Pipeline Processing)
A Stream is a sequence of elements supporting sequential and parallel aggregate operations.
- **Intermediate Operations (Lazy):** \`filter()\`, \`map()\`, \`flatMap()\`, \`distinct()\`, \`sorted()\`.
- **Terminal Operations (Eager, triggers computation):** \`collect()\`, \`forEach()\`, \`reduce()\`, \`count()\`, \`anyMatch()\`.`,
    quickRevisionNotes: [
      'Lambdas can only capture final or effectively final local variables from surrounding scope.',
      'Streams are lazy; intermediate operations execute only when a terminal operation is called.',
      'Streams cannot be reused once a terminal operation has executed.'
    ],
    formulaSheets: [
      {
        name: 'Stream Reduction Formula',
        formula: 'U = \\text{reduce}(\\text{identity}, (acc, x) \\to \\text{accumulator}(acc, x))',
        description: 'Functional folding reduction over stream elements.'
      }
    ],
    definitions: [
      {
        term: 'Terminal Operation',
        explanation: 'Stream pipeline operation that consumes the stream and produces a non-stream result or side-effect.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Stream Pipeline: Filtering, Mapping and Grouping',
        code: `import java.util.*;
import java.util.stream.Collectors;

public class StreamDemo {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David", "Anna");
        
        // Filter names starting with 'A', map to upper case, collect to list
        List<String> aNames = names.stream()
            .filter(name -> name.startsWith("A"))
            .map(String::toUpperCase)
            .collect(Collectors.toList());
            
        System.out.println(aNames); // [ALICE, ANNA]
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w9-q1',
        questionText: 'Which of the following is a Terminal Operation in the Java Streams API?',
        options: ['collect()', 'filter()', 'map()', 'sorted()'],
        correctOptionIndex: 0,
        solution: '`collect()` is a terminal operation that triggers evaluation of the stream pipeline and returns a collection.',
        hints: ['filter, map, and sorted return a new Stream (intermediate).']
      }
    ],
    examTips: [
      'Avoid stateful lambda expressions in parallel streams to prevent race conditions.',
      'Method references `ClassName::methodName` provide clean shorthand for single-call lambdas.'
    ],
    handwrittenMnemonic: 'Streams are lazy until terminal operations call the shots!'
  },
  {
    id: 'note-java-w10',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 10,
    title: 'Java I/O, NIO.2, Serialization & File Channels',
    detailedNotes: `### Week 10: Input/Output Streams, NIO.2 & Object Serialization

#### 1. Byte Streams vs. Character Streams
- **Byte Streams (8-bit bytes):** \`InputStream\`, \`OutputStream\`, \`FileInputStream\`, \`FileOutputStream\`. Used for raw binary data (images, compiled classes).
- **Character Streams (16-bit Unicode chars):** \`Reader\`, \`Writer\`, \`FileReader\`, \`FileWriter\`, \`BufferedReader\`, \`BufferedWriter\`. Handles text encodings properly.

#### 2. Java Object Serialization
Converts in-memory object graphs into a portable byte stream for disk storage or network transmission.
- Class MUST implement \`java.io.Serializable\` (marker interface).
- **\`serialVersionUID\`:** Version control identifier ensuring deserialized class matches sender class.
- **\`transient\` Keyword:** Fields marked \`transient\` are skipped during serialization and initialized to default values upon deserialization!`,
    quickRevisionNotes: [
      'Use Character Streams (Reader/Writer) for text files and Byte Streams (InputStream/OutputStream) for binary files.',
      'Serializable is a marker interface (contains no methods).',
      'transient fields and static fields are NOT serialized.'
    ],
    formulaSheets: [
      {
        name: 'Serialization Output Flow',
        formula: '\\text{Object} \\xrightarrow{\\text{ObjectOutputStream.writeObject()}} \\text{Byte Stream} \\xrightarrow{\\text{ObjectInputStream.readObject()}} \\text{Object}',
        description: 'Round-trip object serialization and deserialization.'
      }
    ],
    definitions: [
      {
        term: 'transient Keyword',
        explanation: 'Modifier specifying that an instance field must not be included in the serialized byte representation.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Serializable Class with transient field',
        code: `import java.io.Serializable;

public class UserSession implements Serializable {
    private static final long serialVersionUID = 1L;
    private String username;
    private transient String rawPassword; // Not serialized!

    public UserSession(String username, String password) {
        this.username = username;
        this.rawPassword = password;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w10-q1',
        questionText: 'What happens to a `transient` variable during deserialization?',
        options: ['It is set to its default value (null, 0, false)', 'It retains its serialized value', 'An InvalidClassException is thrown', 'It causes a NullPointerException'],
        correctOptionIndex: 0,
        solution: 'Transient fields are not persisted; during deserialization, Java initializes them to standard default values (null for objects, 0 for numbers, false for booleans).',
        hints: ['Transient fields are skipped during writing.']
      }
    ],
    examTips: [
      'Always declare explicit `private static final long serialVersionUID` in Serializable classes to prevent unexpected Deserialization mismatches.',
      'NIO.2 `java.nio.file.Files` and `Path` provide non-blocking asynchronous file operations.'
    ],
    handwrittenMnemonic: 'Transient fields vanish during serialization!'
  },
  {
    id: 'note-java-w11',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 11,
    title: 'Java Database Connectivity (JDBC), Connection Pooling & Transactions',
    detailedNotes: `### Week 11: Relational Persistence with JDBC & Transaction Isolation

#### 1. JDBC Architecture & Core Steps
1. **Load Driver:** \`Class.forName("org.postgresql.Driver");\`
2. **Establish Connection:** \`Connection conn = DriverManager.getConnection(url, user, pass);\`
3. **Create Statement:** Use \`PreparedStatement\` with parameter placeholders (\`?\`) to prevent SQL Injection!
4. **Execute Query:** \`ResultSet rs = pstmt.executeQuery();\` or \`int rows = pstmt.executeUpdate();\`
5. **Process ResultSet:** \`while(rs.next()) { ... }\`
6. **Close Resources:** Cleanly in \`try-with-resources\`.

#### 2. SQL Transactions & ACID in JDBC
By default, JDBC connections are in auto-commit mode (\`conn.getAutoCommit() == true\`).
- To execute multi-step atomic transactions:
  \`conn.setAutoCommit(false);\`
  \`try { ... conn.commit(); } catch(Exception e) { conn.rollback(); }\``,
    quickRevisionNotes: [
      'Always use PreparedStatement instead of Statement to prevent SQL injection vulnerabilities.',
      'Disable auto-commit (conn.setAutoCommit(false)) to bundle operations into atomic transactions.',
      'Connection pools (like HikariCP) reuse database connections to avoid TCP connection overhead.'
    ],
    formulaSheets: [
      {
        name: 'JDBC Transaction Protocol',
        formula: '\\text{setAutoCommit(false)} \\to \\text{Execute Operations} \\to \\text{commit}() \\text{ / } \\text{rollback}()',
        description: 'Standard protocol for ACID transaction management in JDBC.'
      }
    ],
    definitions: [
      {
        term: 'PreparedStatement',
        explanation: 'Precompiled SQL statement object that securely parameterizes inputs, boosting performance and eliminating SQL injection.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Secure Parameterized Query with JDBC',
        code: `import java.sql.*;

public class StudentDao {
    public void updateScore(Connection conn, int studentId, double newScore) throws SQLException {
        String sql = "UPDATE grades SET score = ? WHERE student_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, newScore);
            pstmt.setInt(2, studentId);
            pstmt.executeUpdate();
        }
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w11-q1',
        questionText: 'Why is `PreparedStatement` preferred over standard `Statement`?',
        options: ['It prevents SQL injection and allows database precompilation', 'It works without database connection', 'It runs only in memory', 'It bypasses database authentication'],
        correctOptionIndex: 0,
        solution: '`PreparedStatement` parameterizes queries, treating user input strictly as literals, thereby preventing SQL injection attacks, and precompiles SQL on the database engine.',
        hints: ['Think of query security and database execution plans.']
      }
    ],
    examTips: [
      'ResultSet indices are 1-based (`rs.getString(1)`), NOT 0-based!',
      'Always wrap Connection, PreparedStatement, and ResultSet inside try-with-resources blocks.'
    ],
    handwrittenMnemonic: 'PreparedStatement protects against SQL injection; ResultSet is 1-indexed!'
  },
  {
    id: 'note-java-w12',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    courseCode: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 12,
    title: 'Reflection API, Custom Annotations, Design Patterns (Singleton, Factory) & Memory Optimization',
    detailedNotes: `### Week 12: Reflection, Annotations & Enterprise Design Patterns

#### 1. Java Reflection API
Inspects and modifies the runtime structure of classes, methods, constructors, and fields:
\`Class<?> clazz = Class.forName("com.example.Service");\`
\`Method m = clazz.getDeclaredMethod("process", String.class);\`
\`m.setAccessible(true); // Bypasses private encapsulation\`
\`m.invoke(instance, "payload");\`

#### 2. Custom Annotations (\`@Retention\`, \`@Target\`)
- **\`@Retention(RetentionPolicy.RUNTIME)\`:** Retained in bytecode and readable via reflection at runtime.
- **\`@Target(ElementType.METHOD)\`:** Specifies where the annotation can be applied.

#### 3. Core Creational Design Patterns
1. **Singleton (Thread-Safe Double-Checked Locking):**
   Ensures exactly one instance of a class exists throughout the JVM lifecycle.
2. **Factory Method:**
   Defines an interface for creating objects, delegating instantiation to subclasses.`,
    quickRevisionNotes: [
      'Reflection inspects and modifies private members at runtime but incurs performance overhead.',
      '@Retention(RetentionPolicy.RUNTIME) is required for annotations to be visible via reflection.',
      'Double-Checked Locking Singleton requires a volatile instance variable to prevent instruction reordering.'
    ],
    formulaSheets: [
      {
        name: 'Thread-Safe Singleton with Double-Checked Locking',
        formula: '\\text{if}(instance == null) \\ \\{ \\text{synchronized}(Lock) \\ \\{ \\text{if}(instance == null) \\ instance = \\text{new} \\dots \\} \\}',
        description: 'Double-checked locking pattern preventing thread race during lazy singleton instantiation.'
      }
    ],
    definitions: [
      {
        term: 'Double-Checked Locking',
        explanation: 'Optimization pattern that checks locking condition before and after acquiring monitor lock.'
      }
    ],
    codeSnippets: [
      {
        language: 'java',
        title: 'Thread-Safe Singleton with Double-Checked Locking',
        code: `public class DatabaseRegistry {
    private static volatile DatabaseRegistry instance;

    private DatabaseRegistry() {} // Private constructor

    public static DatabaseRegistry getInstance() {
        if (instance == null) {
            synchronized (DatabaseRegistry.class) {
                if (instance == null) {
                    instance = new DatabaseRegistry();
                }
            }
        }
        return instance;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'java-w12-q1',
        questionText: 'Why must the static instance variable in Double-Checked Locking Singleton be declared `volatile`?',
        options: ['To prevent instruction reordering by the compiler/CPU', 'To allow garbage collection', 'To make it serialize automatically', 'To make it immutable'],
        correctOptionIndex: 0,
        solution: 'Without `volatile`, instruction reordering may allow another thread to observe a non-null reference before object construction completes.',
        hints: ['Think of memory visibility and instruction reordering.']
      }
    ],
    examTips: [
      'An enum type is the safest, most concise way to implement a Singleton in Java (immune to reflection and serialization attacks).',
      'Reflection breaks encapsulation; use with caution in performance-critical loops.'
    ],
    handwrittenMnemonic: 'Volatile prevents reordering; Enums make indestructible Singletons!'
  }
];

import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_MAD2_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-mad2-w1',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 1,
    title: 'Enterprise Full-Stack Architecture: Monoliths vs Microservices & Asynchronous Task Processing',
    detailedNotes: `### Week 1: Full-Stack Enterprise Architecture & Async Task Offloading

#### 1. Architectural Paradigms: Monolith vs. Modular Monolith vs. Microservices
- **Monolithic Architecture:** Single unified codebase and deployment artifact.
  - *Pros:* Simple deployment, easy transaction management (ACID), zero network latency between internal modules.
  - *Cons:* Scaling bottlenecks (must scale entire app even if only one module is hot), tight coupling, blast radius of bugs.
- **Microservices Architecture:** Distributed autonomous services communicating over HTTP/gRPC or message queues.
  - *Pros:* Independent scaling, polyglot tech stacks, isolated fault domains.
  - *Cons:* Network latency, eventual consistency challenges (CAP theorem / Sagas), distributed tracing complexity.

#### 2. The Asynchronous Task Processing Problem
In standard synchronous HTTP request-response cycles:
- Web server workers (Gunicorn) have finite worker threads.
- If a client requests a slow operation (e.g. generating a 500-page PDF report, bulk CSV export, or training an ML model taking 45 seconds), holding the HTTP connection open blocks the worker thread from serving other users and risks client HTTP timeouts (504 Gateway Timeout).

#### 3. Solution: Asynchronous Task Queue Pattern
- **Producer (Flask App):** Receives HTTP request, creates a task message payload, pushes it to a Message Broker (Redis/RabbitMQ), and immediately returns \`202 Accepted\` with a \`task_id\`.
- **Message Broker:** Persistent in-memory queue holding pending tasks.
- **Consumer (Celery Worker):** Background daemon process polling broker, executing the long-running job out-of-band.
- **Result Backend:** Stores task execution state and return values.`,
    quickRevisionNotes: [
      'Synchronous long-running HTTP requests cause worker starvation and 504 timeouts.',
      'Async task queues decouple request intake from background job execution.',
      'Flask immediately returns HTTP 202 Accepted with a task_id for polling.',
      'Core components: Producer (Web app), Broker (Redis), Worker (Celery), Result Backend.'
    ],
    formulaSheets: [
      {
        name: 'Worker Saturation Limit',
        formula: 'T_{\\text{sync}} = \\frac{N_{\\text{workers}}}{\\text{Requests per Second} \\times T_{\\text{task duration}}} \\quad (\\text{Fails if } T_{\\text{task}} > 2\\text{s})',
        description: 'Mathematical basis for offloading long tasks to background workers.'
      }
    ],
    definitions: [
      {
        term: 'Asynchronous Task Queue',
        explanation: 'An architectural mechanism that executes resource-intensive operations outside the synchronous HTTP request-response lifecycle.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Asynchronous Job Dispatch Pattern in Flask',
        code: `from flask import Flask, jsonify, request
from celery_app import generate_csv_report

app = Flask(__name__)

@app.route('/api/reports/generate', methods=['POST'])
def start_report_generation():
    params = request.json
    # Dispatch task asynchronously to message broker
    task = generate_csv_report.delay(params)
    
    # Return HTTP 202 Accepted immediately with tracking task_id
    return jsonify({
        'message': 'Report generation dispatched successfully',
        'task_id': task.id,
        'status_check_url': f'/api/reports/status/{task.id}'
    }), 202`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w1-q1',
        questionText: 'What HTTP status code is most appropriate for a REST API endpoint that successfully queues an asynchronous background task without waiting for its completion?',
        options: ['202 Accepted', '200 OK', '201 Created', '204 No Content'],
        correctOptionIndex: 0,
        solution: 'HTTP 202 Accepted indicates that the request has been accepted for processing, but the processing has not been completed.',
        hints: ['Indicates accepted for asynchronous processing.']
      }
    ],
    examTips: [
      'Never execute heavy file I/O, email sending, or ML predictions inside synchronous Flask routes.',
      'Always return a task ID so the client can query progress via polling or receive updates via WebSockets.'
    ],
    handwrittenMnemonic: 'Long tasks block workers; return 202 Accepted and delegate to Celery!'
  },
  {
    id: 'note-mad2-w2',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 2,
    title: 'Advanced Vue 3: Composables, Custom Directives, Provide/Inject & Teleport',
    detailedNotes: `### Week 2: Advanced Vue 3 Architecture & Design Patterns

#### 1. Vue 3 Composables (Reusable State & Logic)
Composables leverage the Composition API to encapsulate and share stateful business logic across components (replacing outdated Vue 2 Mixins):
\`\`\`javascript
// composables/useFetch.js
import { ref, watchEffect } from 'vue';

export function useFetch(urlRef) {
  const data = ref(null);
  const error = ref(null);
  const loading = ref(true);

  watchEffect(async () => {
    loading.value = true;
    try {
      const res = await fetch(urlRef.value);
      data.value = await res.json();
    } catch (err) {
      error.value = err.message;
    } finally {
      loading.value = false;
    }
  });

  return { data, error, loading };
}
\`\`\`

#### 2. Provide / Inject (Dependency Injection Pattern)
Allows an ancestor component to pass data and methods deeply down to any descendant component without prop drilling:
\`\`\`javascript
// In Root Ancestor:
provide('themeContext', { theme: 'dark', toggleTheme });

// In Deep Descendant:
const { theme, toggleTheme } = inject('themeContext');
\`\`\`

#### 3. Advanced Built-in Components
- **\`<Teleport to="body">\`:** Renders a component's DOM node in a different location in the DOM tree (essential for Modals, Tooltips, and Toast notifications) while preserving Vue component hierarchy!
- **\`<Suspense>\`:** Orchestrates asynchronous dependencies (async \`setup()\`) with fallback loading states.
- **Custom Directives:** \`v-focus\`, \`v-click-outside\` for direct low-level DOM control.`,
    quickRevisionNotes: [
      'Composables encapsulate reusable stateful logic into clean functions (`useFetch`, `useAuth`).',
      'Provide/Inject enables dependency injection down deep component trees without prop drilling.',
      '`<Teleport to="body">` renders modal DOM nodes at root while maintaining component state.',
      '`<Suspense>` displays fallback skeletons while async setup components resolve.'
    ],
    formulaSheets: [
      {
        name: 'Vue 3 Composable Structure',
        formula: '\\text{export function useFeature()} \\implies \\{ \\text{state: ref(), computed(), methods()} \\}',
        description: 'Standard composable functional pattern in Vue 3.'
      }
    ],
    definitions: [
      {
        term: 'Vue Composable',
        explanation: 'A function that leverages Vue\'s Composition API to encapsulate and reuse stateful reactive logic across multiple components.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Modal Component with Teleport and Custom Directives',
        code: `<!-- ModalDialog.vue -->
<template>
  <Teleport to="body">
    <div v-if="isOpen" class="modal-backdrop" @click.self="$emit('close')">
      <div class="modal-dialog" v-focus>
        <header>
          <slot name="header"><h3>Default Title</h3></slot>
        </header>
        <main>
          <slot></slot>
        </main>
        <footer>
          <button @click="$emit('close')">Dismiss</button>
        </footer>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
defineProps({ isOpen: Boolean });
defineEmits(['close']);

// Custom local directive to auto-focus dialog for accessibility
const vFocus = {
  mounted: (el) => el.focus()
};
</script>`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w2-q1',
        questionText: 'Why is `<Teleport to="body">` preferred over standard CSS `z-index` when building complex modal dialogs?',
        options: ['Because it moves the modal DOM node outside parent containers with `overflow: hidden` or `transform` properties that break CSS z-index stacking contexts', 'Because it makes modals load faster', 'Because teleport translates text to French', 'Because it converts HTML to SVG'],
        correctOptionIndex: 0,
        solution: 'Parent elements with CSS overflow:hidden or transform establish isolated stacking contexts that clip or restrict child z-index values. Teleport escapes this by placing the DOM node directly under <body>.',
        hints: ['Escapes CSS overflow:hidden stacking contexts.']
      }
    ],
    examTips: [
      'Always start composable function names with `use` (e.g. `useStudentList`, `useFormValidation`).',
      'Provide/Inject keys should ideally be JavaScript `Symbol()` primitives in large projects to avoid naming collisions.'
    ],
    handwrittenMnemonic: 'Composables share logic; Teleport escapes stacking contexts; Provide/Inject skips prop drilling!'
  },
  {
    id: 'note-mad2-w3',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 3,
    title: 'Background Tasks with Celery & Redis: Architecture, Workers, Serialization & Error Retries',
    detailedNotes: `### Week 3: Distributed Task Queues with Celery & Redis

#### 1. Celery Architecture & Workflow
Celery is a distributed asynchronous task queue based on distributed message passing:
1. **Producer (Flask):** Calls \`task_name.delay(*args, **kwargs)\`.
2. **Broker (Redis):** Stores serialized task messages in a Redis List (\`LPUSH\` / \`BRPOP\`).
3. **Worker Pool (Celery):** Pre-forks worker processes that consume messages from Redis, deserialize arguments, execute Python functions, and store results.
4. **Result Backend (Redis / DB):** Stores return value and status (\`PENDING\`, \`STARTED\`, \`SUCCESS\`, \`FAILURE\`, \`RETRY\`).

#### 2. Configuring Celery with Flask
\`\`\`python
from celery import Celery

def make_celery(app):
    celery = Celery(
        app.import_name,
        broker=app.config['CELERY_BROKER_URL'],
        backend=app.config['CELERY_RESULT_BACKEND']
    )
    celery.conf.update(app.config)
    return celery
\`\`\`

#### 3. Defining Tasks with Automatic Exponential Retries
\`\`\`python
@celery.task(bind=True, max_retries=3, default_retry_delay=60)
def send_webhook_notification(self, target_url, payload):
    try:
        response = requests.post(target_url, json=payload, timeout=5)
        response.raise_for_status()
        return {"status": "delivered"}
    except requests.exceptions.RequestException as exc:
        # Exponential backoff retry: 60s, 120s, 240s
        countdown = 60 * (2 ** self.request.retries)
        raise self.retry(exc=exc, countdown=countdown)
\`\`\``,
    quickRevisionNotes: [
      'Celery uses Redis as a message broker to queue tasks and store execution results.',
      '`task.delay(*args)` is shorthand for `task.apply_async(args=args)`.',
      '`bind=True` gives task access to `self` for retries (`self.retry(countdown=...)`).',
      'Task arguments must be JSON-serializable primitives (strings, ints, lists, dicts).'
    ],
    formulaSheets: [
      {
        name: 'Exponential Backoff Retry Formula',
        formula: 'T_{\\text{wait}} = T_{\\text{base}} \\times 2^{\\text{retry\\_count}} \\quad (\\text{e.g. } 60s, 120s, 240s)',
        description: 'Progressive delay algorithm for handling transient network failures in Celery.'
      }
    ],
    definitions: [
      {
        term: 'Message Broker',
        explanation: 'An intermediary software module (such as Redis or RabbitMQ) that facilitates asynchronous messaging by storing and routing task payloads between producers and worker consumers.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Complete Celery Task Definition with Result Querying',
        code: `from celery import shared_task
import time

@shared_task(bind=True)
def export_large_dataset(self, user_id, filters):
    total_steps = 100
    for i in range(total_steps):
        time.sleep(0.05) # Simulating heavy batch processing
        # Update custom state for frontend progress bars
        self.update_state(
            state='PROGRESS',
            meta={'current': i, 'total': total_steps, 'percent': int((i / total_steps) * 100)}
        )
    return {'result_url': f'/downloads/export_{user_id}.zip', 'status': 'COMPLETED'}`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w3-q1',
        questionText: 'Why is it an anti-pattern to pass complex SQLAlchemy ORM Model instances as arguments to Celery tasks (e.g. `task.delay(user_instance)`)?',
        options: ['ORM objects are bound to database sessions, not easily JSON-serializable, and their state can become stale by the time the worker executes; pass the primary key ID instead', 'Celery only supports Python 2 types', 'ORM objects crash the Redis broker immediately', 'Celery cannot connect to SQL databases'],
        correctOptionIndex: 0,
        solution: 'Pass primitive identifiers (e.g. user_id: int) to Celery tasks and have the worker query the fresh object state from the database at execution time.',
        hints: ['Pass IDs instead of ORM instances.']
      }
    ],
    examTips: [
      'Always pass primary keys (IDs) instead of full ORM objects to Celery tasks.',
      'Run worker with `celery -A app.celery worker --loglevel=info`.'
    ],
    handwrittenMnemonic: 'delay() queues task; Redis brokers messages; Celery executes; Pass IDs not objects!'
  },
  {
    id: 'note-mad2-w4',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 4,
    title: 'Periodic Job Scheduling with Celery Beat & Automated Email Reports (SMTP / Mailgun)',
    detailedNotes: `### Week 4: Periodic Task Scheduling with Celery Beat & Batch Mailers

#### 1. Celery Beat Periodic Scheduler Architecture
\`Celery Beat\` is a singleton scheduler daemon that periodically trips and pushes task messages into the Celery message broker according to defined cron schedules or intervals:
\`\`\`python
# celery_config.py
from celery.schedules import crontab

beat_schedule = {
    'send-monthly-activity-reports': {
        'task': 'tasks.send_monthly_digest',
        'schedule': crontab(day_of_month='1', hour=8, minute=0), # 1st of every month at 8:00 AM
    },
    'daily-inactive-user-reminder': {
        'task': 'tasks.check_inactive_users',
        'schedule': crontab(hour=18, minute=30), # Daily at 6:30 PM
    }
}
\`\`\`

#### 2. Automated Email Generation & SMTP Dispatch
Sending bulk emails synchronously blocks web servers and triggers rate limits. Celery batches email delivery:
\`\`\`python
from flask_mail import Mail, Message

mail = Mail()

@celery.task
def send_email_report(recipient_email, subject, html_content):
    msg = Message(
        subject=subject,
        recipients=[recipient_email],
        html=html_content,
        sender="no-reply@university.org"
    )
    mail.send(msg)
\`\`\``,
    quickRevisionNotes: [
      'Celery Beat acts as a cron scheduler pushing task messages to Redis on configured intervals.',
      'Only run ONE instance of Celery Beat to prevent duplicate task dispatches.',
      'Email templates should be rendered to HTML strings before passing to background mail tasks.'
    ],
    formulaSheets: [
      {
        name: 'Celery Crontab Syntax',
        formula: '\\text{crontab(minute=\"0\", hour=\"8\", day\\_of\\_week=\"mon-fri\", day\\_of\\_month=\"*\", month\\_of\\_year=\"*\")}',
        description: 'Cron scheduling specification in Celery Beat.'
      }
    ],
    definitions: [
      {
        term: 'Celery Beat',
        explanation: 'A scheduler process that reads scheduled task definitions and enqueues task execution requests to the broker at designated intervals.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Batch Email Dispatch Task with HTML Template Rendering',
        code: `from celery import shared_task
from flask import render_template
from models import User, PerformanceReport
from extensions import mail, Message

@shared_task
def send_monthly_digest():
    users = User.query.filter_by(is_active=True).all()
    
    for user in users:
        report = PerformanceReport.query.filter_by(user_id=user.id).first()
        html_body = render_template('emails/digest.html', user=user, report=report)
        
        msg = Message(
            subject="Your Monthly Academic Digest",
            recipients=[user.email],
            html=html_body
        )
        mail.send(msg)
    return f"Sent monthly digest to {len(users)} students"`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w4-q1',
        questionText: 'What critical bug occurs if you inadvertently launch multiple parallel instances of the `celery beat` process simultaneously?',
        options: ['Scheduled tasks will be triggered multiple times simultaneously, resulting in duplicate emails and duplicated batch jobs', 'Redis will run out of memory', 'All tasks are deleted', 'Celery worker crashes with SIGSEGV'],
        correctOptionIndex: 0,
        solution: 'Celery Beat does not have distributed leader election by default; multiple beat instances will each fire their schedule independently, enqueueing duplicate tasks.',
        hints: ['Never run multiple beat processes; duplicate tasks will fire.']
      }
    ],
    examTips: [
      'Never run more than one instance of Celery Beat in a cluster.',
      'Use Celery chord or chunking when dispatching thousands of individual email tasks to avoid overwhelming the Redis queue.'
    ],
    handwrittenMnemonic: 'Beat schedules; Workers execute; Run exactly ONE Beat daemon!'
  },
  {
    id: 'note-mad2-w5',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 5,
    title: 'High-Performance Caching with Redis: Cache-Aside Pattern, Invalidation & TTL',
    detailedNotes: `### Week 5: Distributed Caching Architecture with Redis

#### 1. In-Memory Caching Fundamentals
- **Disk I/O (Database):** $\\approx 5 - 50$ ms latency.
- **In-Memory RAM (Redis):** $\\approx 0.1 - 1$ ms latency ($100\\times$ faster!).
- Caching eliminates expensive database queries and complex aggregation computations for frequently requested, read-heavy data.

#### 2. The Cache-Aside (Lazy Loading) Pattern
1. Application receives request for data with key $K$.
2. Check Redis cache:
   - **Cache Hit:** Return cached data directly to user.
   - **Cache Miss:** Query relational database $\\implies$ Store retrieved data in Redis with a **TTL (Time to Live)** $\\implies$ Return data to user.

#### 3. Cache Invalidation Strategies & The Two Hard Things in CS
- **TTL (Time to Live / Expiration):** Automatically evicts keys after $N$ seconds (e.g. \`SETEX key 300 value\`).
- **Explicit Invalidation on Mutation (Write-Through / Evict):**
  - When a student profile is updated (\`PUT /api/students/12\`), immediately invalidate/delete the corresponding cache key: \`redis_client.delete("student:12")\`.
- **Eviction Policies (when RAM is full):**
  - \`allkeys-lru\`: Evicts Least Recently Used keys first.
  - \`volatile-ttl\`: Evicts keys with shortest TTL remaining.`,
    quickRevisionNotes: [
      'Redis operates in-memory (sub-millisecond latency) reducing database query load.',
      'Cache-Aside pattern: Check cache -> on miss, read DB -> populate cache with TTL.',
      'Always invalidate cache on write/update mutations to prevent serving stale data.',
      'Use TTLs on all cache keys to prevent memory leaks.'
    ],
    formulaSheets: [
      {
        name: 'Cache Hit Ratio',
        formula: '\\text{Hit Ratio} = \\frac{\\text{Cache Hits}}{\\text{Cache Hits} + \\text{Cache Misses}} \\times 100\\% \\quad (\\text{Goal } > 90\\%)',
        description: 'Efficiency metric for caching systems.'
      }
    ],
    definitions: [
      {
        term: 'Cache Invalidation',
        explanation: 'The process of purging or updating stale entries in the cache when the underlying authoritative data source is modified.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Custom Python Caching Decorator with Redis and JSON Serialization',
        code: `import json, redis
from functools import wraps
from flask import request, jsonify

redis_client = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

def cache_response(timeout=300):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            # Generate cache key based on URL and query parameters
            cache_key = f"cache:{request.path}:{request.query_string.decode('utf-8')}"
            cached_data = redis_client.get(cache_key)
            
            if cached_data:
                # Cache HIT
                return jsonify(json.loads(cached_data)), 200, {'X-Cache': 'HIT'}
                
            # Cache MISS: execute route handler
            response = f(*args, **kwargs)
            if response[1] == 200:
                data = response[0].get_json() if hasattr(response[0], 'get_json') else response[0]
                redis_client.setex(cache_key, timeout, json.dumps(data))
                
            return response
        return wrapper
    return decorator`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w5-q1',
        questionText: 'What is "Cache Stampede" (or Thundering Herd) and how can it be mitigated?',
        options: ['When a popular cache key expires and thousands of concurrent requests simultaneously miss the cache and hit the database at once; mitigated using mutex locks or probabilistic early expiration', 'When Redis runs out of disk space', 'When Celery workers stop responding', 'When HTML templates fail to render'],
        correctOptionIndex: 0,
        solution: 'Cache Stampede happens when high-traffic keys expire, causing hundreds of concurrent queries to overwhelm the relational database. Mutex locking (single-flight) or probabilistic background refresh solves this.',
        hints: ['Simultaneous cache misses overwhelming database.']
      }
    ],
    examTips: [
      'Always namespace Redis keys (e.g. `user:101:profile`, `course:204:roster`).',
      'Never store sensitive unencrypted passwords or tokens in shared Redis caches.'
    ],
    handwrittenMnemonic: 'Check Cache -> on miss query DB -> setex with TTL; Invalidate on updates!'
  },
  {
    id: 'note-mad2-w6',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 6,
    title: 'Real-Time Web: Server-Sent Events (SSE) vs. WebSockets (Flask-SocketIO) & Webhooks',
    detailedNotes: `### Week 6: Real-Time Protocols: WebSockets, SSE & Webhooks

#### 1. Comparison of Real-Time Architectures
| Protocol | Direction | Transport | Connection | Best For |
| :--- | :--- | :--- | :--- | :--- |
| **Short/Long Polling** | Client $\\to$ Server | HTTP | Repeated TCP handshakes | Legacy fallbacks |
| **Server-Sent Events (SSE)** | Server $\\to$ Client (Unidirectional) | HTTP/1.1 or HTTP/2 | Persistent HTTP stream (\`text/event-stream\`) | Stock tickers, live sports scores, progress bars |
| **WebSockets** | Full-Duplex (Bidirectional) | TCP (\`ws://\` / \`wss://\`) | HTTP 101 Protocol Upgrade | Collaborative whiteboards, real-time chat, multiplayer games |
| **Webhooks** | Server $\\to$ Server | HTTP POST | Event-driven HTTP push | Payment notifications (Stripe/Razorpay), GitHub pushes |

#### 2. Flask-SocketIO & WebSocket Rooms
\`\`\`python
from flask_socketio import SocketIO, emit, join_room, leave_room

socketio = SocketIO(app, cors_allowed_origins="*")

@socketio.on('join_study_room')
def on_join(data):
    room = data['room_id']
    join_room(room)
    emit('status', {'msg': f"{data['username']} entered room"}, to=room)

@socketio.on('send_chat_message')
def handle_message(data):
    # Broadcast to all clients inside the specific room
    emit('receive_message', data, to=data['room_id'])
\`\`\``,
    quickRevisionNotes: [
      'SSE is lightweight unidirectional (Server -> Client) over standard HTTP `text/event-stream`.',
      'WebSockets provide full-duplex bidirectional TCP communication after HTTP 101 upgrade.',
      'Flask-SocketIO supports "Rooms" for targeted multi-user pub/sub channels.',
      'Webhooks are asynchronous server-to-server HTTP POST event notifications.'
    ],
    formulaSheets: [
      {
        name: 'WebSocket Handshake Header',
        formula: '\\text{GET /chat HTTP/1.1} \\quad | \\quad \\text{Upgrade: websocket} \\quad | \\quad \\text{Connection: Upgrade} \\implies \\text{101 Switching Protocols}',
        description: 'HTTP protocol upgrade handshake establishing persistent WebSocket connection.'
      }
    ],
    definitions: [
      {
        term: 'Full-Duplex Communication',
        explanation: 'A communication channel that allows simultaneous two-way transmission of data between client and server over a single persistent connection.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Client-Side Socket.IO Event Listener in Vue / JavaScript',
        code: `import { io } from 'socket.io-client';
import { ref, onMounted, onUnmounted } from 'vue';

export function useLiveChat(roomId, username) {
  const socket = ref(null);
  const messages = ref([]);

  onMounted(() => {
    socket.value = io('https://api.university.org', { transports: ['websocket'] });

    socket.value.emit('join_study_room', { room_id: roomId, username });

    socket.value.on('receive_message', (payload) => {
      messages.value.push(payload);
    });
  });

  const sendMessage = (text) => {
    socket.value.emit('send_chat_message', { room_id: roomId, sender: username, text });
  };

  onUnmounted(() => {
    if (socket.value) socket.value.disconnect();
  });

  return { messages, sendMessage };
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w6-q1',
        questionText: 'When building a one-way live server CPU monitoring dashboard or live progress bar, why is Server-Sent Events (SSE) often chosen over WebSockets?',
        options: ['SSE runs over standard HTTP, natively supports automatic client reconnection, and requires no complex WebSocket handshake or special server upgrade protocols', 'SSE supports video streaming', 'WebSockets cannot transmit JSON', 'SSE is written in C++'],
        correctOptionIndex: 0,
        solution: 'SSE operates over standard HTTP/HTTPS, passes through firewalls and corporate proxies easily, and includes built-in browser reconnection mechanisms.',
        hints: ['SSE uses standard HTTP with automatic reconnection.']
      }
    ],
    examTips: [
      'Webhooks must verify cryptographic HMAC signatures (e.g. `X-Hub-Signature-256`) to ensure the request originated from the authentic third-party provider.',
      'Always respond with HTTP 200 OK to incoming Webhooks within 3 seconds before offloading processing to Celery.'
    ],
    handwrittenMnemonic: 'SSE = Server to Client (HTTP); WebSockets = Both directions (TCP); Webhooks = Server to Server!'
  },
  {
    id: 'note-mad2-w7',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 7,
    title: 'Advanced API Design: OpenAPI/Swagger, Cursor vs Offset Pagination & Rate Limiting',
    detailedNotes: `### Week 7: Production API Architecture & Scalability

#### 1. Offset-Based vs. Cursor-Based Pagination
- **Offset Pagination (\`LIMIT 20 OFFSET 10000\`):**
  - *Problem:* As offset grows large, database scans and discards 10,000 rows (slow $O(N)$ scan). Furthermore, inserting new rows during pagination causes **Page Drift** (duplicate or skipped items).
- **Cursor (Keyset) Pagination (\`WHERE id > last_seen_id LIMIT 20\`):**
  - *Advantage:* Fast $O(1)$ index seek. Deterministic; immune to page drift. Industry standard for infinite scrolling feeds!

#### 2. API Rate Limiting (Token Bucket & Leaky Bucket Algorithms)
Protects backends against Denial of Service (DoS) and abusive scraping:
- **Token Bucket Algorithm:** Bucket holds up to $B$ tokens. Tokens refill at rate $r$ per second. Each request consumes 1 token. Allows short bursts up to $B$.
- **HTTP 429 Too Many Requests:** Emitted with headers \`Retry-After: 60\`, \`X-RateLimit-Remaining: 0\`.
- Implemented in Flask using \`Flask-Limiter\` backed by Redis.

#### 3. API Contract Specification with OpenAPI / Swagger
- Standard machine-readable YAML/JSON contract describing endpoints, request schemas, validation rules, and error responses.`,
    quickRevisionNotes: [
      'Cursor pagination (`WHERE id > cursor`) is $O(1)$ index seek; offset pagination is $O(N)$ scan.',
      'Rate limiting uses Token Bucket to throttle abusive clients with HTTP 429 Too Many Requests.',
      'OpenAPI/Swagger provides interactive API documentation and automated SDK generation.'
    ],
    formulaSheets: [
      {
        name: 'Token Bucket Rate Limit Invariant',
        formula: '\\text{Tokens}(t) = \\min\\left(B, \\ \\text{Tokens}(t_{\\text{prev}}) + r \\cdot (t - t_{\\text{prev}})\\right)',
        description: 'Mathematical formulation of Token Bucket rate limiting.'
      }
    ],
    definitions: [
      {
        term: 'Cursor-Based Pagination',
        explanation: 'A pagination strategy using a unique sequential pointer (such as an auto-incrementing ID or timestamp) to fetch the next slice of data directly from index seeks.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Cursor-Based Pagination and Rate Limiting in Flask',
        code: `from flask import Flask, request, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
limiter = Limiter(get_remote_address, app=app, storage_uri="redis://localhost:6379")

@app.route('/api/v2/students', methods=['GET'])
@limiter.limit("100 per minute; 10 per second") # Token bucket rate limiting
def get_students_cursor():
    cursor = request.args.get('cursor', 0, type=int)
    limit = min(request.args.get('limit', 20, type=int), 100)
    
    # Efficient indexed query
    records = Student.query.filter(Student.id > cursor).order_by(Student.id.asc()).limit(limit + 1).all()
    
    has_more = len(records) > limit
    results = records[:limit]
    next_cursor = results[-1].id if results and has_more else None
    
    return jsonify({
        'data': [{'id': s.id, 'name': s.name} for s in results],
        'pagination': {'has_more': has_more, 'next_cursor': next_cursor}
    })`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w7-q1',
        questionText: 'Why is cursor-based pagination significantly faster than `LIMIT 50 OFFSET 500000` on a relational database table with millions of rows?',
        options: ['Cursor pagination utilizes a B-tree index seek to jump directly to the target record (`WHERE id > 500000`), whereas OFFSET forces the database to read and discard 500,000 index entries', 'Cursor pagination compresses the database', 'OFFSET pagination runs on the GPU', 'Cursor pagination disables transactions'],
        correctOptionIndex: 0,
        solution: 'OFFSET N requires the query planner to traverse and count N records before returning rows. Keyset cursor pagination seeks directly to the index key in logarithmic time.',
        hints: ['Index seek O(1) vs scanning and discarding N rows O(N).']
      }
    ],
    examTips: [
      'Always enforce a maximum `limit` parameter (e.g. `min(limit, 100)`) to prevent malicious queries requesting 1,000,000 rows.',
      'Return standard rate-limit headers (`X-RateLimit-Limit`, `X-RateLimit-Remaining`, `Retry-After`) on all API responses.'
    ],
    handwrittenMnemonic: 'Cursor pagination avoids offset drift; Rate limit with 429 Too Many Requests!'
  },
  {
    id: 'note-mad2-w8',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 8,
    title: 'Containerization with Docker: Dockerfile, Multi-Stage Builds, Images & Volumes',
    detailedNotes: `### Week 8: Docker Containerization Fundamentals

#### 1. Virtual Machines vs. Docker Containers
- **Virtual Machines (Hypervisor):** Emulates full hardware; runs a complete Guest OS kernel (GBs in size; minutes to boot).
- **Docker Containers (Container Engine):** Lightweight, isolated user-space processes sharing the **Host OS Kernel** via Linux \`cgroups\` (resource limits) and \`namespaces\` (process/network/filesystem isolation). (MBs in size; milliseconds to boot).

#### 2. Dockerfile Directives & Layer Caching
Each instruction in a \`Dockerfile\` creates a read-only immutable filesystem layer:
- \`FROM\`: Base image.
- \`WORKDIR\`: Sets working directory.
- \`COPY\` / \`ADD\`: Copies files from host to image.
- \`RUN\`: Executes command during image build time (e.g. \`pip install\`).
- \`ENV\`: Sets environment variables.
- \`EXPOSE\`: Documentation of listening port.
- \`CMD\` / \`ENTRYPOINT\`: Default command executed when container launches at runtime.

#### 3. Multi-Stage Builds (Optimizing Production Image Size)
Separates the build environment (Node, compilers) from the slim production runtime (NGINX/Alpine), slashing image sizes from $1.2\\text{ GB} \\to 25\\text{ MB}$!`,
    quickRevisionNotes: [
      'Containers share the host OS kernel using Linux namespaces and cgroups.',
      'Docker layer caching: Order instructions from least-changing (dependencies) to most-changing (code).',
      'Multi-stage builds produce ultra-compact production images by discarding build tools.',
      'Docker Volumes provide persistent data storage that outlives container deletion.'
    ],
    formulaSheets: [
      {
        name: 'Docker Layer Invalidation Rule',
        formula: '\\text{If Layer } L_i \\text{ changes} \\implies \\text{All subsequent layers } L_{i+1 \\dots n} \\text{ are invalidated and rebuilt}',
        description: 'Docker build cache optimization principle.'
      }
    ],
    definitions: [
      {
        term: 'Linux Namespaces',
        explanation: 'A kernel feature that isolates system resources (PID, Mount, Network, IPC, User) so a container sees only its own isolated environment.'
      }
    ],
    codeSnippets: [
      {
        language: 'dockerfile',
        title: 'Production Multi-Stage Dockerfile for Vue Frontend and Python Backend',
        code: `# Stage 1: Build Vue SPA
FROM node:18-alpine AS frontend-builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Stage 2: Production Python Flask & Gunicorn Server
FROM python:3.10-slim AS final-runtime
WORKDIR /srv/app

# Install system dependencies & python requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy backend code and compiled frontend assets from Stage 1
COPY . .
COPY --from=frontend-builder /app/dist ./static/dist

ENV PYTHONUNBUFFERED=1
EXPOSE 8000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:8000", "wsgi:app"]`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w8-q1',
        questionText: 'Why should `COPY requirements.txt .` and `RUN pip install ...` appear BEFORE `COPY . .` in a Dockerfile?',
        options: ['To leverage Docker layer caching, so dependencies are not reinstalled every time application source code changes', 'Because Docker cannot read Python files otherwise', 'It is a mandatory syntax rule in Docker', 'To make the image read-only'],
        correctOptionIndex: 0,
        solution: 'Docker caches layers sequentially. If source code changes, copying requirements first ensures that pip install layer is reused from cache unless requirements.txt was modified.',
        hints: ['Layer caching: copy requirements before source code.']
      }
    ],
    examTips: [
      'Always add a `.dockerignore` file containing `node_modules`, `__pycache__`, `.git`, and `.env`.',
      'Use explicit image version tags (e.g. `python:3.10-slim`) instead of `python:latest` for reproducible builds.'
    ],
    handwrittenMnemonic: 'Containers share kernel; Copy requirements before source for layer cache!'
  },
  {
    id: 'note-mad2-w9',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 9,
    title: 'Multi-Container Orchestration with Docker Compose: App, DB, Redis & Celery',
    detailedNotes: `### Week 9: Multi-Container Orchestration with Docker Compose

#### 1. What is Docker Compose?
A tool for defining and running multi-container Docker applications using a single YAML configuration file (\`docker-compose.yml\`).
It automates:
- Building multiple container images.
- Creating private bridge networks for automatic container DNS discovery.
- Mounting persistent volumes.
- Managing startup dependencies (\`depends_on\`).

#### 2. Architecture of a Complete Full-Stack Stack
A production full-stack application consists of multiple collaborating micro-containers:
1. **\`web\`:** NGINX Reverse Proxy serving Vue SPA and proxying API calls.
2. **\`api\`:** Flask Backend running Gunicorn.
3. **\`db\`:** PostgreSQL database container with mapped persistent volume.
4. **\`redis\`:** In-memory message broker & cache.
5. **\`celery_worker\`:** Background task processing workers.
6. **\`celery_beat\`:** Periodic cron scheduler.

#### 3. Automatic Service Discovery via Embedded DNS
In Docker Compose, containers reach each other by **service name** (e.g. Flask connects to \`postgresql://user:pw@db:5432/university\` where \`db\` is resolved by Docker's internal DNS!).`,
    quickRevisionNotes: [
      'Docker Compose defines multi-container stacks in `docker-compose.yml`.',
      'Containers on the same Compose network discover each other by service name (e.g. `redis:6379`).',
      'Persistent database volumes prevent data loss across container teardowns (`docker compose down`).'
    ],
    formulaSheets: [
      {
        name: 'Docker Compose CLI Commands',
        formula: '\\text{docker compose up -d --build} \\quad | \\quad \\text{docker compose logs -f} \\quad | \\quad \\text{docker compose down -v}',
        description: 'Standard lifecycle commands for multi-container orchestration.'
      }
    ],
    definitions: [
      {
        term: 'Container Network Discovery',
        explanation: 'The automatic internal DNS resolution mechanism where containers query other services by their declared service names within a shared bridge network.'
      }
    ],
    codeSnippets: [
      {
        language: 'yaml',
        title: 'Complete Production docker-compose.yml for Full-Stack Application',
        code: `version: '3.8'

services:
  api:
    build: .
    command: gunicorn -w 4 -b 0.0.0.0:8000 wsgi:app
    environment:
      - DATABASE_URL=postgresql://postgres:secret@db:5432/appdb
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - db
      - redis
    ports:
      - "8000:8000"

  celery_worker:
    build: .
    command: celery -A app.celery worker --loglevel=info
    environment:
      - DATABASE_URL=postgresql://postgres:secret@db:5432/appdb
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - redis

  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: appdb
      POSTGRES_PASSWORD: secret
    volumes:
      - pgdata:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

volumes:
  pgdata:`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w9-q1',
        questionText: 'How do containers running within the same `docker-compose.yml` communicate with each other over the network?',
        options: ['Using their declared service names as hostnames (e.g. `http://db:5432`), which are resolved automatically by Docker\'s embedded DNS server', 'By sharing the host machine\'s localhost loopback interface', 'Through public internet routing', 'Via shared USB connections'],
        correctOptionIndex: 0,
        solution: 'Docker creates a private user-defined bridge network and runs an embedded DNS server that resolves service names to their respective container IP addresses.',
        hints: ['Docker embedded DNS resolves service names.']
      }
    ],
    examTips: [
      '`docker compose down -v` removes persistent volumes; omit the `-v` flag to preserve database data.',
      'Use healthchecks in `docker-compose.yml` so dependent services wait for PostgreSQL to be ready before launching.'
    ],
    handwrittenMnemonic: 'docker-compose.yml coordinates containers; Service names act as hostnames in DNS!'
  },
  {
    id: 'note-mad2-w10',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 10,
    title: 'Continuous Integration & Continuous Deployment (CI/CD): GitHub Actions & Automated Testing',
    detailedNotes: `### Week 10: CI/CD Pipelines & Automated Quality Assurance

#### 1. What is CI/CD?
- **Continuous Integration (CI):** Developers merge code into shared branch frequently. Automated workflows build the app, run linter checks (\`flake8\`, \`eslint\`), and execute test suites (\`pytest\`, \`jest\`) on every pull request.
- **Continuous Deployment (CD):** Automatically packages verified code into Docker images and deploys them to staging/production servers upon merging to \`main\`.

#### 2. Test Automation Pyramid
- **Unit Tests ($70\\%$):** Fast, isolated testing of individual functions/classes in memory (mocking external DB/network).
- **Integration Tests ($20\\%$):** Tests API endpoints, database queries, and component interactions together.
- **End-to-End (E2E) Tests ($10\\%$):** Browser-driven user journey tests (Cypress/Playwright).

#### 3. GitHub Actions Workflow Configuration (\`.github/workflows/ci.yml\`)
Triggered automatically on \`git push\` or pull requests:
- **Matrix Builds:** Runs tests across multiple Python and Node versions concurrently.
- **Secrets Management:** Securely passes API keys and deployment credentials via \`\${{ secrets.PROD_SSH_KEY }}\`.`,
    quickRevisionNotes: [
      'CI runs automated builds, linters, and unit tests on every Git push/PR.',
      'CD automatically deploys passing artifacts to production environments.',
      'GitHub Actions configures pipelines in `.github/workflows/*.yml`.',
      'Test Pyramid: 70% Unit tests, 20% Integration tests, 10% E2E tests.'
    ],
    formulaSheets: [
      {
        name: 'CI/CD Pipeline Flow',
        formula: '\\text{Git Push} \\xrightarrow{\\text{Trigger}} \\text{Lint \\& Test} \\xrightarrow{\\text{Pass}} \\text{Build Docker Image} \\xrightarrow{\\text{CD}} \\text{Deploy to Cloud}',
        description: 'Automated release lifecycle pipeline.'
      }
    ],
    definitions: [
      {
        term: 'Continuous Integration',
        explanation: 'The software development practice of automatically building and running automated test suites on code changes to detect defects early.'
      }
    ],
    codeSnippets: [
      {
        language: 'yaml',
        title: 'Production GitHub Actions CI Pipeline with Pytest and Docker Build',
        code: `name: Full-Stack CI Pipeline

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test-and-lint:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
          cache: 'pip'

      - name: Install Dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt pytest flake8

      - name: Lint with Flake8
        run: flake8 . --max-line-length=120 --exclude=.venv,__pycache__

      - name: Run Test Suite with Pytest
        run: pytest --maxfail=1 --disable-warnings -q`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w10-q1',
        questionText: 'What is the primary benefit of running automated CI pipelines on every pull request before merging to main?',
        options: ['Catches regressions, syntax errors, and broken test cases immediately before defects enter the main production codebase', 'Deletes old Git branches automatically', 'Generates Bitcoin', 'Speeds up user internet speed'],
        correctOptionIndex: 0,
        solution: 'Continuous Integration ensures that newly committed code passes all tests and styling rules, preventing broken code from ever reaching the production branch.',
        hints: ['Prevents broken code from reaching production.']
      }
    ],
    examTips: [
      'Never commit API secrets, private keys, or passwords into `.github/workflows/` files; use repository GitHub Secrets.',
      'Use caching (`actions/setup-node with cache: "npm"`) to speed up CI execution times.'
    ],
    handwrittenMnemonic: 'Lint -> Test -> Build -> Deploy; CI prevents broken code in main!'
  },
  {
    id: 'note-mad2-w11',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 11,
    title: 'Observability & Monitoring: Metrics (Prometheus), Dashboards (Grafana) & Structured Logging',
    detailedNotes: `### Week 11: Production Observability, Metrics & Telemetry

#### 1. The Three Pillars of Observability
1. **Metrics (Aggregatable Numbers):** Counter, Gauge, Histogram (e.g. CPU load, HTTP request rate, response latency 99th percentile $P_{99}$).
2. **Logs (Discrete Events):** Structured JSON timestamped records (\`{"timestamp": "...", "level": "ERROR", "user_id": 12, "route": "/pay"}\`).
3. **Traces (Distributed Request Flow):** Tracks the lifecycle of a single request across multiple microservices (OpenTelemetry / Jaeger).

#### 2. Prometheus Metrics Types
- **Counter:** Monotonically increasing number (only resets to 0 on reboot): \`http_requests_total\`.
- **Gauge:** Numerical value that fluctuates up and down: \`active_db_connections\`, \`memory_used_bytes\`.
- **Histogram:** Samples observations into configurable buckets to compute percentiles ($P_{50}, P_{95}, P_{99}$ response times!).

#### 3. Structured Logging vs. Raw Text Logs
Raw text logs (\`print("User 12 logged in")\`) cannot be easily parsed or queried at scale.
Structured JSON logs allow log aggregation engines (Elasticsearch, Loki, CloudWatch) to execute instant index queries:
\`\`\`python
import logging, json_log_formatter

formatter = json_log_formatter.JSONFormatter()
json_handler = logging.StreamHandler()
json_handler.setFormatter(formatter)
logger = logging.getLogger('production_app')
logger.addHandler(json_handler)
\`\`\``,
    quickRevisionNotes: [
      'Three pillars of observability: Metrics (numbers), Logs (events), Traces (distributed paths).',
      'Prometheus collects metrics via periodic HTTP scraping (`/metrics` endpoint).',
      'Histograms compute $P_{95}$ and $P_{99}$ latency percentiles; Gauges measure fluctuating values.',
      'Always use Structured JSON logging in production for automated searchability in Elasticsearch/Loki.'
    ],
    formulaSheets: [
      {
        name: 'PromQL Rate Calculation',
        formula: '\\text{rate}(http\\_requests\\_total[5m]) = \\frac{\\Delta \\text{Counter}}{\\Delta t}',
        description: 'PromQL query computing per-second request rate over 5-minute window.'
      }
    ],
    definitions: [
      {
        term: 'P99 Latency (99th Percentile)',
        explanation: 'The response time threshold below which 99% of all user requests are served, highlighting worst-case tail latencies.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Exporting Prometheus Metrics from Flask with prometheus_client',
        code: `from flask import Flask, request, Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
import time

app = Flask(__name__)

REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP Requests', ['method', 'endpoint', 'status'])
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP Request Latency', ['endpoint'])

@app.before_request
def start_timer():
    request.start_time = time.time()

@app.after_request
def record_metrics(response):
    resp_time = time.time() - getattr(request, 'start_time', time.time())
    REQUEST_LATENCY.labels(endpoint=request.path).observe(resp_time)
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path, status=response.status_code).inc()
    return response

@app.route('/metrics')
def metrics():
    # Scraped periodically by Prometheus server
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w11-q1',
        questionText: 'Why is tracking the 99th percentile ($P_{99}$) latency significantly more informative than tracking average (mean) latency for web applications?',
        options: ['Average latency masks severe outliers and tail delays affecting 1% of users (often high-value power users), while P99 reveals true worst-case responsiveness', 'Average latency requires more CPU to calculate', 'P99 works only with integers', 'Average latency excludes database queries'],
        correctOptionIndex: 0,
        solution: 'In a service with 1 million daily requests, 1% represents 10,000 frustrated users experiencing timeouts or slowdowns that are completely hidden in the arithmetic mean.',
        hints: ['Tail latency and outlier visibility.']
      }
    ],
    examTips: [
      'Grafana connects to Prometheus as a data source to build real-time visual dashboards and alert rules.',
      'Never include high-cardinality values (e.g. user IDs or timestamps) as Prometheus label dimensions to prevent metric memory explosion.'
    ],
    handwrittenMnemonic: 'Metrics (numbers), Logs (JSON), Traces (paths); P99 catches tail latency!'
  },
  {
    id: 'note-mad2-w12',
    courseId: 'course-mad2',
    courseTitle: 'Modern Application Development 2',
    courseCode: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 12,
    title: 'Production Cloud Deployment, Horizontal Scaling, Load Balancers & Zero-Downtime Releases',
    detailedNotes: `### Week 12: Production Cloud Architecture & Zero-Downtime Deployment

#### 1. Vertical vs. Horizontal Scaling
- **Vertical Scaling (Scale Up):** Upgrading machine hardware (more CPU/RAM on single server). Has hard physical limits and single point of failure (SPOF).
- **Horizontal Scaling (Scale Out):** Adding more identical stateless server instances behind a Load Balancer (AWS ALB, NGINX, HAProxy). Enables infinite scale and high availability.

#### 2. Load Balancing Algorithms
- **Round Robin:** Sequential request distribution ($1 \\to 2 \\to 3 \\to 1$).
- **Least Connections:** Forwards traffic to the instance currently handling the fewest active connections (optimal for long transactions).
- **IP Hash:** Routes same client IP consistently to the same server (session affinity / sticky sessions).

#### 3. Zero-Downtime Deployment Strategies
- **Rolling Update:** Replaces instances incrementally ($1$ by $1$) behind the load balancer until all servers run the new version.
- **Blue-Green Deployment:**
  - **Blue Environment:** Live production cluster serving active user traffic.
  - **Green Environment:** Identical idle cluster where new version is deployed and smoke-tested.
  - **Cutover:** Load balancer router switches 100% of traffic from Blue to Green instantly. Instant rollback by switching router back if anomalies occur!
- **Canary Release:** Routes $5\\%$ of real traffic to new version; gradually increases to $100\\%$ if error rates remain low.`,
    quickRevisionNotes: [
      'Horizontal scaling adds stateless application instances behind a Load Balancer.',
      'Load balancing algorithms: Round Robin, Least Connections, IP Hash.',
      'Blue-Green deployment switches traffic instantly between live and updated environments with zero downtime.',
      'Canary deployment tests new releases on 5% of real traffic before wide rollout.'
    ],
    formulaSheets: [
      {
        name: 'High Availability (HA) Uptime Formula',
        formula: '\\text{Availability} = \\frac{\\text{MTTF}}{\\text{MTTF} + \\text{MTTR}} \\times 100\\% \\quad (\\text{e.g. \"Four Nines\" } = 99.99\\% \\implies 52\\text{ min downtime/year})',
        description: 'Mean Time To Failure (MTTF) and Mean Time To Repair (MTTR) reliability metric.'
      }
    ],
    definitions: [
      {
        term: 'Blue-Green Deployment',
        explanation: 'A release management technique that reduces downtime and risk by running two identical production environments (Blue and Green), with only one serving live traffic at any time.'
      }
    ],
    codeSnippets: [
      {
        language: 'text',
        title: 'NGINX Upstream Load Balancer Configuration with Health Checks',
        code: `upstream flask_backend_cluster {
    # Least connection load balancing algorithm
    least_conn;

    server backend1.internal:8000 max_fails=3 fail_timeout=10s;
    server backend2.internal:8000 max_fails=3 fail_timeout=10s;
    server backend3.internal:8000 max_fails=3 fail_timeout=10s;
}

server {
    listen 80;
    server_name api.production.org;

    location / {
        proxy_pass http://flask_backend_cluster;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_next_upstream error timeout http_502 http_503;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad2-w12-q1',
        questionText: 'What is the primary operational advantage of Blue-Green deployment over in-place server upgrades?',
        options: ['Zero downtime during cutover and the ability to instantly roll back to the previous stable Blue environment if production issues are detected in Green', 'It cuts hosting costs in half', 'It compiles Python code into C++', 'It disables database migrations'],
        correctOptionIndex: 0,
        solution: 'Because the existing Blue environment remains fully operational and untouched, routing traffic back to Blue takes seconds if the Green release encounters unexpected production errors.',
        hints: ['Instant rollback and zero downtime cutover.']
      }
    ],
    examTips: [
      'To enable zero-downtime database migrations with Blue-Green deployments, database schema changes must always be backward-compatible (expand-and-contract pattern).',
      'Never store session state in local server memory when horizontally scaling; use Redis or stateless JWTs.'
    ],
    handwrittenMnemonic: 'Scale horizontally with Load Balancers; Blue-Green provides zero downtime and instant rollback!'
  }
];

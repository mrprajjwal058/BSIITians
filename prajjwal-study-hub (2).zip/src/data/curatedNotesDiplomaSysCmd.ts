import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_SYSCMD_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-syscmd-w1',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 1,
    title: 'Linux Architecture, Filesystem Hierarchy Standard (FHS) & File Operations',
    detailedNotes: `### Week 1: Unix Architecture & Filesystem Hierarchy Standard

#### 1. Linux Kernel & Shell Architecture
- **Hardware Layer:** CPU, RAM, Disk, Peripherals.
- **Kernel Layer:** Monolithic kernel managing memory, process scheduling, virtual filesystems (VFS), and device drivers.
- **System Calls:** API boundary between user space and kernel space (\`read\`, \`write\`, \`fork\`, \`execve\`, \`open\`).
- **Shell Layer:** Command-line interpreter reading user instructions and invoking system calls (Bash, Zsh, Sh).

#### 2. Filesystem Hierarchy Standard (FHS)
- \`/\`: Root directory; top of single unified hierarchical tree.
- \`/bin\` & \`/usr/bin\`: Essential user binary executables.
- \`/sbin\` & \`/usr/sbin\`: System administration binaries (\`iptables\`, \`fdisk\`, \`reboot\`).
- \`/etc\`: System-wide configuration files (\`passwd\`, \`hosts\`, \`fstab\`, \`ssh/\`).
- \`/dev\`: Device special files representing hardware (\`/dev/sda\`, \`/dev/null\`, \`/dev/urandom\`, \`/dev/zero\`).
- \`/proc\` & \`/sys\`: Virtual pseudo-filesystems exposing kernel metrics and running process descriptors in memory (\`/proc/cpuinfo\`, \`/proc/meminfo\`, \`/proc/[pid]/\`).
- \`/var\`: Variable data files (log files \`/var/log/\`, mail spools, databases).
- \`/tmp\`: Temporary files cleared upon reboot.

#### 3. Navigation & File Inspection
- \`pwd\`: Print current working directory.
- \`ls -laht\`: Long listing (\`-l\`), all hidden files (\`-a\`), human-readable sizes (\`-h\`), sorted by modification time (\`-t\`).
- \`mkdir -p path/to/nested/dir\`: Create parent directories as needed without error.
- \`touch file.txt\`: Create empty file or update timestamp.
- \`cp -r src/ dest/\`: Recursive directory copy.
- \`mv old_name new_name\`: Rename or move files atomically.
- \`rm -rf dir/\`: Forceful recursive removal.`,
    quickRevisionNotes: [
      'Linux uses a single unified tree rooted at `/`.',
      '`/etc` stores configuration files; `/proc` and `/sys` are virtual kernel memory interfaces.',
      '`ls -laht` lists hidden files, permissions, sizes, and timestamps.',
      '`mkdir -p` creates nested directories safely.'
    ],
    formulaSheets: [
      {
        name: 'Essential Unix File Commands Reference',
        formula: '\\text{cp -r } \\text{src } \\text{dest} \\quad | \\quad \\text{mkdir -p } \\text{dir} \\quad | \\quad \\text{ls -laht}',
        description: 'Standard flags for file management and directory traversal.'
      }
    ],
    definitions: [
      {
        term: 'Virtual Filesystem (VFS)',
        explanation: 'A kernel abstraction layer that provides a uniform filesystem interface to user-space applications regardless of underlying storage formats (ext4, NFS, tmpfs).'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Inspecting System Hardware & Kernel via /proc Virtual Filesystem',
        code: `# Check CPU core count and model
grep -m 1 "model name" /proc/cpuinfo
grep -c "^processor" /proc/cpuinfo

# Check Total and Available RAM in human readable MB
awk '/MemTotal/ || /MemAvailable/ {printf "%s: %.2f GB\\n", $1, $2/1024/1024}' /proc/meminfo

# View Linux Kernel version and OS release
uname -a
cat /etc/os-release`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w1-q1',
        questionText: 'Which virtual directory in Linux provides runtime process information and kernel data structures stored directly in memory?',
        options: ['/proc', '/etc', '/var/log', '/bin'],
        correctOptionIndex: 0,
        solution: '/proc is a pseudo-filesystem generated dynamically by the Linux kernel containing real-time process metadata and hardware statistics.',
        hints: ['Think of process information filesystem.']
      }
    ],
    examTips: [
      '`/dev/null` acts as a black hole (discards all data written to it); `/dev/zero` outputs an infinite stream of zero bytes (useful for creating empty disk images with `dd`).',
      'The dot `.` represents the current directory, and double dots `..` represent the parent directory.'
    ],
    handwrittenMnemonic: 'Root / contains all; /etc configures; /proc exposes kernel memory!'
  },
  {
    id: 'note-syscmd-w2',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 2,
    title: 'Unix File Permissions (chmod, chown, umask, SUID/SGID) & Inodes vs Links',
    detailedNotes: `### Week 2: Permissions, Ownership, Inodes & Link Internals

#### 1. Unix Permission Model & Octal Representation
Every file has 9 standard permission bits divided into three sets: **User (Owner)**, **Group**, and **Others**:
- **Read ($r = 4$):** View file contents / list directory files.
- **Write ($w = 2$):** Modify file contents / create or delete files inside directory.
- **Execute ($x = 1$):** Run file as program / enter (\`cd\`) and traverse directory.

| Symbolic | Binary | Octal | Meaning |
| :--- | :--- | :--- | :--- |
| \`rwx\` | 111 | 7 | Read, Write, and Execute |
| \`rw-\` | 110 | 6 | Read and Write |
| \`r-x\` | 101 | 5 | Read and Execute |
| \`r--\` | 100 | 4 | Read Only |
| \`---\` | 000 | 0 | No Permissions |

- **Command:** \`chmod 755 script.sh\` $\\implies$ \`rwxr-xr-x\` (User: rwx, Group: r-x, Others: r-x).
- **Default \`umask\` Calculation:**
  $$\\text{File Default} = 666 - \\text{umask}, \\quad \\text{Dir Default} = 777 - \\text{umask}$$
  If \`umask = 022\`, new files get $644$ (\`rw-r--r--\`), new dirs get $755$ (\`rwxr-xr-x\`).

#### 2. Special Permissions
- **SUID ($4000$ / \`s\` on owner):** Executable runs with privileges of the file owner (e.g. \`/usr/bin/passwd\` owned by root).
- **SGID ($2000$ / \`s\` on group):** New files in directory inherit group ownership of the directory.
- **Sticky Bit ($1000$ / \`t\` on others):** In shared directories like \`/tmp\`, users can only delete their own files.

#### 3. Inodes, Hard Links & Symbolic (Soft) Links
- **Inode:** Metadata record storing file size, owner, timestamps, and disk block pointers (does NOT store filename!).
- **Hard Link (\`ln target link\`):** Additional directory entry pointing to the **same inode**. Increments inode link count. Cannot cross filesystem boundaries; cannot link directories.
- **Soft Link (\`ln -s target link\`):** Independent file containing the string path to target. Can cross filesystems; creates broken dangling links if target is deleted.`,
    quickRevisionNotes: [
      'Permissions: Read=4, Write=2, Execute=1. Total = 7 (rwx).',
      'umask subtracts default creation permissions (666 for files, 777 for directories).',
      'Hard links share the same inode number; Soft links (symlinks) point to file paths.',
      'SUID executes with file owner privileges; Sticky bit prevents deleting others files in shared dirs.'
    ],
    formulaSheets: [
      {
        name: 'Octal Permission Calculation',
        formula: '\\text{Perm} = (4 \\cdot r + 2 \\cdot w + 1 \\cdot x)_{\\text{user}} + (4r + 2w + x)_{\\text{group}} + (4r + 2w + x)_{\\text{others}}',
        description: 'Binary to octal mapping for Unix chmod operations.'
      }
    ],
    definitions: [
      {
        term: 'Inode',
        explanation: 'A filesystem data structure that stores all file metadata (permissions, owner, size, data block pointers) except its filename.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Inspecting Inodes and Creating Links',
        code: `# Inspect inode numbers of files
ls -li file.txt

# Create Hard Link (both share identical inode number)
ln file.txt hardlink.txt
ls -li file.txt hardlink.txt

# Create Soft Link (new inode pointing to target path)
ln -s file.txt symlink.txt
ls -li symlink.txt

# Change ownership and special sticky bit
chown user:developer_group project_dir
chmod 1777 /shared_folder # Set sticky bit`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w2-q1',
        questionText: 'If a user sets umask to 027, what will be the default permissions on a newly created regular text file?',
        options: ['640 (rw-r-----)', '750 (rwxr-x---)', '644 (rw-r--r--)', '777 (rwxrwxrwx)'],
        correctOptionIndex: 0,
        solution: 'Default file base permission is 666. Subtracting umask 027 (in binary mask terms: 666 & ~027): User: 6 - 0 = 6 (rw-), Group: 6 - 2 = 4 (r--), Others: 6 - 7 -> 0 (---). Result is 640.',
        hints: ['Base file permissions 666 minus umask 027.']
      }
    ],
    examTips: [
      'A file on disk is only truly deleted and freed when its inode link count reaches 0 AND no open process holds an active file descriptor.',
      'Execute permission on a directory is required to `cd` into it, while read permission is required to list its entries with `ls`.'
    ],
    handwrittenMnemonic: 'r=4, w=2, x=1; Hard links share inode; Symlinks store path strings!'
  },
  {
    id: 'note-syscmd-w3',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 3,
    title: 'Standard Streams (stdin, stdout, stderr), Redirection & Unix Pipelines',
    detailedNotes: `### Week 3: Unix Streams, File Descriptors & Pipeline Architecture

#### 1. Standard Streams & File Descriptors (FD)
Every running process opens three standard POSIX streams by default:
- **\`stdin\` (FD 0):** Standard input (Keyboard / upstream pipeline).
- **\`stdout\` (FD 1):** Standard output (Terminal display).
- **\`stderr\` (FD 2):** Standard error (Diagnostic/error logs).

#### 2. Stream Redirection Syntax
- \`cmd > file.txt\`: Overwrites \`stdout\` to \`file.txt\` (equivalent to \`1> file.txt\`).
- \`cmd >> file.txt\`: Appends \`stdout\` to \`file.txt\`.
- \`cmd < input.txt\`: Feeds file contents into \`stdin\`.
- \`cmd 2> error.log\`: Redirects \`stderr\` to \`error.log\`.
- \`cmd > output.log 2>&1\`: Redirects both \`stdout\` and \`stderr\` to the same file.
- \`cmd &> output.log\`: Modern Bash shorthand for redirecting both streams.
- \`cmd 2> /dev/null\`: Silences all error messages.

#### 3. Pipelines (\`|\`) & The Unix Philosophy
A pipe \`cmd1 | cmd2\` connects the \`stdout\` of \`cmd1\` directly to the \`stdin\` of \`cmd2\` using an in-memory kernel circular buffer (64KB), running both processes **concurrently in parallel**:
- \`tee output.txt\`: Duplicates stream, writing to file AND stdout simultaneously.
- \`xargs\`: Converts lines from standard input into command-line arguments.`,
    quickRevisionNotes: [
      'File descriptors: 0=stdin, 1=stdout, 2=stderr.',
      '`>` overwrites; `>>` appends; `<` inputs.',
      '`2>&1` redirects stderr to wherever stdout is currently pointing.',
      'Pipes `|` chain stdout to stdin in-memory without creating temporary files.'
    ],
    formulaSheets: [
      {
        name: 'Stream Redirection Quick Reference',
        formula: '\\text{cmd } > \\text{out.log } 2>\\&1 \\quad | \\quad \\text{cmd } 2> /\\text{dev/null} \\quad | \\quad \\text{cmd1 } | \\text{ cmd2}',
        description: 'Standard stream manipulation and process chaining primitives.'
      }
    ],
    definitions: [
      {
        term: 'Anonymous Pipe',
        explanation: 'A unidirectional kernel-managed FIFO buffer used for inter-process communication between two concurrently running commands.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Advanced Pipeline Combinations with xargs and tee',
        code: `# Redirect stdout and stderr to log file while viewing output live on terminal
./long_build_job.sh 2>&1 | tee build.log

# Find all .log files older than 7 days and delete them using xargs
find /var/log/app/ -type f -name "*.log" -mtime +7 -print0 | xargs -0 rm -f

# Count total unique IP addresses accessing web server
cat access.log | awk '{print $1}' | sort | uniq -c | sort -nr | head -n 10`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w3-q1',
        questionText: 'In the command `grep "ERROR" app.log > result.txt 2>&1`, what does `2>&1` accomplish?',
        options: ['It redirects standard error (file descriptor 2) to the same destination as standard output (file descriptor 1)', 'It multiplies output by 2', 'It runs two background jobs', 'It compares file 2 and file 1'],
        correctOptionIndex: 0,
        solution: '2>&1 instructs the shell to duplicate file descriptor 2 to file descriptor 1, sending error logs to result.txt alongside standard output.',
        hints: ['FD 2 is stderr, FD 1 is stdout.']
      }
    ],
    examTips: [
      'The order of redirection matters: `> file 2>&1` sends both to file; `2>&1 > file` sends stderr to original console and stdout to file!',
      '`sort | uniq` requires input to be sorted first because `uniq` only detects adjacent duplicate lines.'
    ],
    handwrittenMnemonic: '0=in, 1=out, 2=err; 2>&1 joins error stream to output stream!'
  },
  {
    id: 'note-syscmd-w4',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 4,
    title: 'Regular Expressions (BRE vs ERE) & Text Filtering with grep, egrep, fgrep',
    detailedNotes: `### Week 4: Regular Expressions & Text Search with grep

#### 1. Basic (BRE) vs. Extended (ERE) Regular Expressions
- **BRE (\`grep\`):** Meta-characters \`(? + { } | ( ))\` are treated as literals unless escaped with backslash \`\\(\\)\`, \`\\+\`, \`\\|\`.
- **ERE (\`grep -E\` / \`egrep\`):** Meta-characters are active by default:
  - \`^\`: Matches start of line (\`^Error\`).
  - \`$\`: Matches end of line (\`completed.$\`).
  - \`.\`: Matches any single character except newline.
  - \`*\`: Matches 0 or more occurrences of preceding element.
  - \`+\`: Matches 1 or more occurrences.
  - \`?\`: Matches 0 or 1 occurrence (optional).
  - \`[a-z0-9]\`: Character classes.
  - \`[^0-9]\`: Negated character class (non-digit).
  - \`a|b\`: Logical OR alternation.
  - \`{m,n}\`: Quantifier matching between $m$ and $n$ times.

#### 2. Essential \`grep\` Flags
- \`-i\`: Case-insensitive search.
- \`-v\`: Invert match (print lines that DO NOT match pattern).
- \`-n\`: Print line numbers.
- \`-c\`: Count matching lines.
- \`-r\` / \`-R\`: Recursive directory search.
- \`-l\`: Print only filenames containing matching lines.
- \`-w\`: Match whole words only.
- \`-o\`: Print ONLY the exact matching token, not the entire line.
- \`-E\`: Use Extended Regular Expressions.
- \`-F\` / \`fgrep\`: Fast fixed string search (disables all regex parsing).`,
    quickRevisionNotes: [
      '`grep -E` enables Extended Regular Expressions (+, ?, |, () without backslashes).',
      '`^` matches start of line; `$` matches end of line; `.` matches any single char.',
      '`grep -v` inverts matches; `grep -r` searches directories recursively; `grep -o` prints matching parts.'
    ],
    formulaSheets: [
      {
        name: 'Regex Metacharacters Reference',
        formula: '^ \\text{ (start)}, \\quad \$ \\text{ (end)}, \\quad . \\text{ (any)}, \\quad + \\text{ (1+)}, \\quad ? \\text{ (0/1)}, \\quad [0-9] \\text{ (range)}',
        description: 'Core regular expression anchoring and quantification tokens.'
      }
    ],
    definitions: [
      {
        term: 'Regular Expression',
        explanation: 'A formal sequence of characters defining a search pattern for text matching and validation.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'High-Yield grep Filtering Commands',
        code: `# Extract all valid email addresses from text file
grep -E -o '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}' users.csv

# Find all files in project containing 'TODO' or 'FIXME' case-insensitively
grep -r -i -E -n "TODO|FIXME" ./src/

# Filter out empty lines and comment lines starting with #
grep -v -E '^[[:space:]]*($|#)' config.conf`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w4-q1',
        questionText: 'Which regular expression pattern matches lines that are completely blank or contain only whitespace characters?',
        options: ['^[[:space:]]*$', '^blank$', '.*', '$^'],
        correctOptionIndex: 0,
        solution: '^ asserts start of line, [[:space:]]* matches zero or more spaces/tabs, and $ asserts end of line.',
        hints: ['^ for line start, $ for line end.']
      }
    ],
    examTips: [
      'Use POSIX character classes like `[[:digit:]]`, `[[:alpha:]]`, and `[[:space:]]` for locale-independent robust scripts.',
      '`fgrep` / `grep -F` is significantly faster than standard `grep` when searching for exact literal strings in large log files.'
    ],
    handwrittenMnemonic: '^ starts the line; $ ends the line; grep -v inverts; grep -E extends regex!'
  },
  {
    id: 'note-syscmd-w5',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 5,
    title: 'Stream Editing with sed: Substitutions, Line Addressing, Buffers & Scripting',
    detailedNotes: `### Week 5: The sed Stream Editor

#### 1. sed Execution Model
\`sed\` processes text line-by-line using a cycle:
1. Read next line from input into the **Pattern Space**.
2. Apply specified editing commands.
3. Print modified Pattern Space to stdout (unless \`-n\` is specified).
4. Repeat for subsequent lines.

#### 2. The Substitution Command (\`s\`)
Syntax: \`sed 's/pattern/replacement/flags' input.txt\`
- **Flags:**
  - \`g\`: Global substitution (replace all occurrences on the line, not just the first).
  - \`i\`: Case-insensitive match.
  - \`p\`: Print line only if substitution was made (often combined with \`-n\`).
  - \`w file\`: Write matching modified lines to external file.
- **In-Place File Editing (\`-i\`):** \`sed -i 's/old/new/g' file.txt\` (modifies file on disk directly).

#### 3. Line Addressing & Common Commands
- \`sed '3d' file.txt\`: Delete line 3.
- \`sed '1,10d' file.txt\`: Delete lines 1 through 10.
- \`sed '/^#/d' file.txt\`: Delete all lines starting with \`#\`.
- \`sed -n '5,10p' file.txt\`: Print lines 5 through 10 only (\`-n\` suppresses default output).
- \`sed 's/\\(.*\\)/[\\1]/'\`: Backreferencing captured group with \`\\1\`.
- **Hold Space Commands:** \`h\` (copy pattern to hold), \`H\` (append to hold), \`g\` (copy hold to pattern), \`x\` (exchange pattern and hold spaces).`,
    quickRevisionNotes: [
      '`sed s/old/new/g` substitutes all occurrences of old with new.',
      '`sed -i` performs in-place modification of files directly on disk.',
      '`sed -n 5,10p` prints lines 5 to 10 exclusively.',
      '`sed /pattern/d` deletes matching lines from output stream.'
    ],
    formulaSheets: [
      {
        name: 'sed Substitution Syntax',
        formula: '\\text{sed [address] s/regex/replacement/[g, i, p, w]}',
        description: 'Standard stream editing transformation syntax.'
      }
    ],
    definitions: [
      {
        term: 'Pattern Space',
        explanation: 'The temporary working memory buffer where sed holds and manipulates the current line of text.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Practical sed Recipes for Automation',
        code: `# Replace all occurrences of localhost with 127.0.0.1 in-place
sed -i 's/localhost/127.0.0.1/g' config.env

# Print only lines between start_block and end_block
sed -n '/<START>/,/<END>/p' application.log

# Delete all trailing whitespace at the end of lines
sed -i 's/[[:space:]]*$//' *.py

# Extract and reformat dates from YYYY-MM-DD to DD/MM/YYYY using backreferences
sed -E 's/([0-9]{4})-([0-9]{2})-([0-9]{2})/\\3\\/\\2\\/\\1/g' dates.txt`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w5-q1',
        questionText: 'What is the purpose of the `-n` option when executing sed commands like `sed -n "1,5p" file.txt`?',
        options: ['It suppresses the default automatic printing of the pattern space, printing only explicitly requested lines', 'It runs sed in dry-run mode without reading disk', 'It numbers the output lines', 'It converts uppercase characters to lowercase'],
        correctOptionIndex: 0,
        solution: '-n disables the default behavior of printing every line, so only lines with the p (print) command are output.',
        hints: ['Think of quiet/suppressed printing mode.']
      }
    ],
    examTips: [
      'You can use alternative delimiters (e.g. `sed "s|/usr/local/bin|/opt/bin|g"`) to avoid escaping slashes ("leaning toothpick syndrome").',
      'Always test `sed` commands without `-i` first before modifying production configuration files.'
    ],
    handwrittenMnemonic: 'sed s/find/replace/g; -i edits in place; -n suppresses default print!'
  },
  {
    id: 'note-syscmd-w6',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 6,
    title: 'Text Processing with awk: Fields ($0..$NF), Built-in Variables, Arrays & Math',
    detailedNotes: `### Week 6: Columnar Data Processing with awk

#### 1. awk Program Structure
An \`awk\` program consists of pattern-action blocks:
\`\`\`awk
BEGIN { /* Initialization code executed once before reading input */ }
pattern { /* Executed for each record matching pattern */ action }
END   { /* Cleanup/summary code executed once after EOF */ }
\`\`\`

#### 2. Built-in Variables
- \`$0\`: The entire current input record (line).
- \`$1, $2, \\dots, $NF\`: Individual fields (columns).
- \`NF\`: Number of Fields in the current record (\`$NF\` is the value of the **last field**!).
- \`NR\`: Number of Records (line number processed so far across all files).
- \`FNR\`: File-specific Record Number (resets to 1 for each new input file).
- \`FS\`: Input Field Separator (default is whitespace; change with \`-F','\` or \`FS=":"\`).
- \`OFS\`: Output Field Separator (default is space).
- \`RS\` & \`ORS\`: Input and Output Record Separators (default is newline \`\\n\`).

#### 3. Associative Arrays & Aggregations
\`awk\` supports powerful string-keyed associative arrays for aggregations (GROUP BY calculations):
\`\`\`bash
awk '{count[$1]++} END {for (item in count) print item, count[item]}' access.log
\`\`\``,
    quickRevisionNotes: [
      'awk pattern-action blocks: BEGIN -> [Pattern { Action }] -> END.',
      '`$1` is column 1; `$NF` is the last column; `NF` is column count; `NR` is line number.',
      '`awk -F\',\'` sets input field separator to comma for CSV processing.',
      'Associative arrays `count[$1]++` enable instant GROUP BY aggregations in memory.'
    ],
    formulaSheets: [
      {
        name: 'awk Built-in Variables Reference',
        formula: 'NF \\text{ (num fields)}, \\quad NR \\text{ (line num)}, \\quad \$NF \\text{ (last col)}, \\quad FS \\text{ (delimiter)}, \\quad OFS \\text{ (out delimiter)}',
        description: 'Core built-in variables for tabular text parsing in awk.'
      }
    ],
    definitions: [
      {
        term: 'Associative Array in awk',
        explanation: 'A hash table data structure where array indices are arbitrary strings rather than sequential integers.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Practical awk One-Liners for Data Analysis',
        code: `# Parse /etc/passwd and print username (col 1) and shell (col 7) with tab separator
awk -F':' 'BEGIN {OFS="\\t"} {print $1, $7}' /etc/passwd

# Compute average of scores in column 3 of CSV file
awk -F',' 'NR > 1 {sum += $3; count++} END {printf "Average: %.2f\\n", sum/count}' students.csv

# Group By: Count total HTTP requests per response status code
awk '{status[$9]++} END {for (code in status) printf "%s: %d\\n", code, status[code]}' access.log | sort -nr -k2`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w6-q1',
        questionText: 'In awk, what does the expression `$NF` evaluate to?',
        options: ['The value of the last field/column in the current record', 'The total number of fields in the file', 'The first column in uppercase', 'A null pointer'],
        correctOptionIndex: 0,
        solution: 'NF holds the integer count of fields in the line. Prepending the $ operator ($NF) references the value stored in that last column index.',
        hints: ['NF is number of fields, $NF dereferences that index.']
      }
    ],
    examTips: [
      '`NR==FNR` idiom is used to process a first lookup file into an array before processing a second data stream.',
      '`awk` treats uninitialized variables as 0 in numeric operations and empty string `""` in string operations.'
    ],
    handwrittenMnemonic: 'NF = field count; $NF = last field; NR = total row count!'
  },
  {
    id: 'note-syscmd-w7',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 7,
    title: 'Shell Scripting Fundamentals: Variables, Quotes, Conditionals & Loops',
    detailedNotes: `### Week 7: Bash Scripting Fundamentals & Control Flow

#### 1. Shebang & Variable Semantics
- **Shebang (\`#!/usr/bin/env bash\`):** Specifies interpreter binary path.
- **Assignment:** \`VAR="value"\` (No spaces around \`=\` sign!).
- **Quoting Rules:**
  - **Double Quotes (\`"..."\`):** Allows variable expansion (\`"$VAR"\`) and command substitution (\`"$(date)"\`).
  - **Single Quotes (\`'...'/'\`):** Preserves literal string; disables all interpolation.
  - **Backticks / \`$(cmd)\`:** Command substitution capturing standard output.

#### 2. Conditional Testing (\`test\` / \`[ ... ]\` / \`[[ ... ]]\`)
- Use modern double brackets \`[[ ... ]]\` in Bash (supports \`&&\`, \`||\`, regex matching \`=~\`, and avoids word-splitting bugs).
- **Comparison Operators:**
  - String: \`==\`, \`!=\`, \`-z "$str"\` (empty string), \`-n "$str"\` (non-empty).
  - Integer: \`-eq\`, \`-ne\`, \`-lt\`, \`-le\`, \`-gt\`, \`-ge\`.
  - File Tests: \`-f file\` (regular file), \`-d dir\` (directory), \`-e path\` (exists), \`-r\` (readable), \`-w\` (writable), \`-x\` (executable).

#### 3. Control Structures
- **If-Else:**
  \`\`\`bash
  if [[ $score -ge 90 ]]; then
      echo "Grade A"
  elif [[ $score -ge 75 ]]; then
      echo "Grade B"
  else
      echo "Grade C"
  fi
  \`\`\`
- **For Loop:** \`for f in *.txt; do echo "$f"; done\`
- **C-Style For Loop:** \`for ((i=0; i<10; i++)); do echo "$i"; done\`
- **While Loop (Reading line-by-line):**
  \`\`\`bash
  while IFS= read -r line; do
      echo "Processing: $line"
  done < input.txt
  \`\`\``,
    quickRevisionNotes: [
      'Variables must be assigned without spaces around = (VAR="val").',
      'Double quotes interpolate $VAR; single quotes are strictly literal.',
      'Use `[[ ... ]]` for robust conditionals with string, integer, and file operators.',
      'Read files safely line-by-line using `while IFS= read -r line; do ... done < file`.'
    ],
    formulaSheets: [
      {
        name: 'Bash Test Operators Summary',
        formula: '-f \\text{ (file)}, \\quad -d \\text{ (dir)}, \\quad -z \\text{ (empty)}, \\quad -eq/-lt \\text{ (numeric)}, \\quad == \\text{ (string)}',
        description: 'Conditional evaluation flags inside [[ ... ]] tests.'
      }
    ],
    definitions: [
      {
        term: 'Word Splitting',
        explanation: 'The process where unquoted shell variable expansions are automatically tokenized into separate arguments by spaces/tabs/newlines.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Robust File Processor Script',
        code: `#!/usr/bin/env bash

# Check if argument is supplied
if [[ $# -eq 0 ]]; then
    echo "Usage: $0 <filename>" >&2
    exit 1
fi

TARGET_FILE="$1"

if [[ ! -f "$TARGET_FILE" ]]; then
    echo "Error: File '$TARGET_FILE' does not exist." >&2
    exit 2
fi

echo "Processing file: $TARGET_FILE"
line_count=0

while IFS= read -r line || [[ -n "$line" ]]; do
    ((line_count++))
    echo "Line $line_count: $line"
done < "$TARGET_FILE"

echo "Completed. Total lines: $line_count"`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w7-q1',
        questionText: 'Why should variables always be wrapped in double quotes (e.g. "$filename") when referenced in Bash scripts?',
        options: ['To prevent word splitting and glob expansion if the variable contains spaces or special characters', 'To convert integers into floats', 'To make the script execute faster', 'To hide the variable value in process lists'],
        correctOptionIndex: 0,
        solution: 'Unquoted variables containing spaces (e.g. "my document.txt") get split into separate arguments ("my" and "document.txt"), causing command failures.',
        hints: ['Think of filenames containing spaces.']
      }
    ],
    examTips: [
      'Always use `read -r` in while loops: the `-r` flag prevents backslashes from acting as escape characters.',
      '`$?` captures the exit status of the last executed command ($0 is script name, $# is argument count, $@ is list of all args).'
    ],
    handwrittenMnemonic: 'Quote your variables "$VAR"; use [[ ... ]] for tests; -r in read loops!'
  },
  {
    id: 'note-syscmd-w8',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 8,
    title: 'Advanced Bash: Functions, Parameter Expansion, Error Trapping & set -euo pipefail',
    detailedNotes: `### Week 8: Advanced Bash Scripting & Defensive Engineering

#### 1. Parameter Expansion Modifiers
- \`\${VAR:-default}\`: Use default if VAR is unset or null (does not assign).
- \`\${VAR:=default}\`: Assign default to VAR if unset or null.
- \`\${VAR:?error_msg}\`: Throw error and exit if VAR is unset or null.
- \`\${#VAR}\`: String length of VAR.
- \`\${VAR#pattern}\`: Remove shortest matching prefix.
- \`\${VAR##pattern}\`: Remove longest matching prefix (e.g. \`\${path##*/}\` extracts filename!).
- \`\${VAR%pattern}\`: Remove shortest matching suffix (e.g. \`\${file%.*}\` strips extension!).
- \`\${VAR%%pattern}\`: Remove longest matching suffix.
- \`\${VAR/old/new}\`: Replace first match; \`\${VAR//old/new}\` replaces all matches.

#### 2. Defensive Scripting Boilerplate (\`set -euo pipefail\`)
Add at the top of every production Bash script:
\`\`\`bash
set -euo pipefail
\`\`\`
- \`-e\` (\`errexit\`): Exit immediately if any command returns a non-zero exit status.
- \`-u\` (\`nounset\`): Treat unset variables as an error and exit immediately.
- \`-o pipefail\`: A pipeline returns a failure status if **any** command in the pipeline fails (not just the last one!).

#### 3. Signal Traps & Cleanup Handlers
- \`trap cleanup_function EXIT INT TERM\`: Guarantees cleanup routine executes when script exits normally or receives \`SIGINT\` (\`Ctrl+C\`) / \`SIGTERM\`.`,
    quickRevisionNotes: [
      '`set -euo pipefail` enforces strict error handling, unset variable checks, and pipeline failures.',
      '`${path##*/}` strips directory paths to get filename; `${file%.*}` removes extension.',
      '`trap "rm -f $TMP" EXIT` ensures temporary cleanup on script termination.'
    ],
    formulaSheets: [
      {
        name: 'Parameter Expansion Reference',
        formula: '\${VAR:-def} \\text{ (fallback)}, \\quad \${VAR##*/} \\text{ (basename)}, \\quad \${VAR%.*} \\text{ (strip ext)}, \\quad \${#VAR} \\text{ (len)}',
        description: 'String manipulation syntax natively supported by the Bash parameter expansion engine.'
      }
    ],
    definitions: [
      {
        term: 'pipefail Option',
        explanation: 'A shell option causing a pipeline to return the exit status of the last failing command, rather than always returning the exit status of the rightmost command.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Production-Grade Defensive Script Template with Trap and Lockfile',
        code: `#!/usr/bin/env bash
set -euo pipefail

# Create temporary working directory
TMP_DIR=$(mktemp -d)

# Cleanup trap guaranteed to run on exit or crash
cleanup() {
    echo "Performing cleanup on exit..."
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT INT TERM

echo "Working directory created at: $TMP_DIR"

# Safe parameter expansion
BACKUP_DIR="\${1:-/backup/default}"
echo "Using backup destination: $BACKUP_DIR"`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w8-q1',
        questionText: 'What failure condition is prevented by including `set -o pipefail` in Bash scripts?',
        options: ['Pipelines returning exit status 0 (success) even when an upstream command in the chain failed with an error', 'Infinite loops in for loops', 'Memory allocation failures', 'Permission denied errors on chmod'],
        correctOptionIndex: 0,
        solution: 'By default, pipelines return the exit code of the final command only. `pipefail` ensures that if any command in the chain fails, the entire pipeline is marked as failed.',
        hints: ['Upstream pipeline errors are masked by default.']
      }
    ],
    examTips: [
      'To allow a specific command to fail under `set -e` without crashing the script, append `|| true` (e.g. `grep "pattern" file.txt || true`).',
      '`local` keyword should always be used for variables declared inside functions to avoid polluting global namespace.'
    ],
    handwrittenMnemonic: 'set -euo pipefail prevents silent bugs; trap cleanup on EXIT!'
  },
  {
    id: 'note-syscmd-w9',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 9,
    title: 'Process Management, Signals (SIGTERM, SIGKILL), Background Jobs & Cron Automation',
    detailedNotes: `### Week 9: Process States, Job Control & Automated Scheduling

#### 1. Process Lifecycle & State Transitions
- **PID:** Unique Process Identifier (\`PID 1\` is \`systemd\` / init).
- **PPID:** Parent Process ID. When parent dies without waiting, child becomes an **Orphan** (adopted by \`init\`).
- **Zombie Process (\`Z\` in \`ps\`):** A terminated child process whose exit status has not yet been read by parent via \`wait()\`.

#### 2. Unix Signals & Termination
- \`SIGINT\` (Signal 2 / \`Ctrl+C\`): Interrupt from keyboard (catchable).
- \`SIGQUIT\` (Signal 3 / \`Ctrl+\\\`): Quit with core dump.
- \`SIGKILL\` (Signal 9): Forceful immediate termination (handled directly by kernel; **cannot be caught, blocked, or ignored!**).
- \`SIGTERM\` (Signal 15): Graceful termination request (default for \`kill pid\`; gives application time to flush buffers and close connections).
- \`SIGHUP\` (Signal 1): Hangup signal sent when terminal closes (or used to reload daemon configs).
- \`SIGSTOP\` (Signal 19 / \`Ctrl+Z\`): Pause process execution (cannot be caught).

#### 3. Job Control & Daemonizing
- \`cmd &\`: Run command in background.
- \`jobs\`: List active background jobs.
- \`fg %1\`: Bring job 1 to foreground; \`bg %1\`: Resume job 1 in background.
- \`nohup cmd &> output.log &\`: Detaches command from terminal session, ignoring \`SIGHUP\`.

#### 4. Cron Job Automation (\`crontab -e\`)
Format: \`* * * * * command_to_execute\`
- Field 1: Minute ($0 - 59$)
- Field 2: Hour ($0 - 23$)
- Field 3: Day of Month ($1 - 31$)
- Field 4: Month ($1 - 12$)
- Field 5: Day of Week ($0 - 7$, where 0 & 7 = Sunday)
- Example: \`0 2 * * 1-5 /scripts/db_backup.sh\` (Runs at 2:00 AM, Monday to Friday).`,
    quickRevisionNotes: [
      'Signals: SIGTERM (15) for graceful exit; SIGKILL (9) for forceful uncatchable kill.',
      '`nohup` allows processes to continue running after closing terminal session (ignores SIGHUP).',
      'Crontab fields: Minute, Hour, Day of Month, Month, Day of Week (m h dom mon dow).'
    ],
    formulaSheets: [
      {
        name: 'Crontab Five-Field Syntax',
        formula: '\\underbrace{*}_{\\text{min (0-59)}} \\quad \\underbrace{*}_{\\text{hour (0-23)}} \\quad \\underbrace{*}_{\\text{dom (1-31)}} \\quad \\underbrace{*}_{\\text{month (1-12)}} \\quad \\underbrace{*}_{\\text{dow (0-7)}}',
        description: 'Standard cron time specification format.'
      }
    ],
    definitions: [
      {
        term: 'Zombie Process',
        explanation: 'A completed process that has released its memory and resources but retains an entry in the process table until its parent reads its exit status code.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Process Monitoring and Graceful Termination Script',
        code: `# Find PID of application listening on port 8080
APP_PID=$(lsof -t -i :8080)

if [[ -n "$APP_PID" ]]; then
    echo "Sending graceful SIGTERM to PID: $APP_PID"
    kill -15 "$APP_PID"
    
    # Wait up to 10 seconds for graceful shutdown
    sleep 10
    
    # Force kill if still running
    if ps -p "$APP_PID" > /dev/null; then
        echo "Process did not terminate; sending SIGKILL..."
        kill -9 "$APP_PID"
    fi
fi`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w9-q1',
        questionText: 'Which Unix signal CANNOT be caught, blocked, or ignored by any user-space application?',
        options: ['SIGKILL (Signal 9) and SIGSTOP (Signal 19)', 'SIGTERM (Signal 15)', 'SIGINT (Signal 2)', 'SIGHUP (Signal 1)'],
        correctOptionIndex: 0,
        solution: 'SIGKILL (9) and SIGSTOP (19) are handled directly and unconditionally by the Linux kernel, preventing the process from intercepting them.',
        hints: ['Kernel directly enforces Signal 9 and 19.']
      }
    ],
    examTips: [
      'Always provide absolute paths to executables and environment variables inside crontab scripts, as cron runs with a minimal `PATH` (`/usr/bin:/bin`).',
      '`killall process_name` and `pkill -f pattern` kill processes by name rather than PID.'
    ],
    handwrittenMnemonic: 'Crontab: Min Hour Dom Mon Dow; SIGTERM requests, SIGKILL enforces!'
  },
  {
    id: 'note-syscmd-w10',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 10,
    title: 'Networking Tools: curl, wget, SSH, SCP, rsync, ss, lsof & DNS (dig/nslookup)',
    detailedNotes: `### Week 10: Networking Utilities & Remote Server Management

#### 1. Transfer Utilities (\`curl\` vs \`wget\`)
- **\`curl\` (Client URL):** Highly versatile API query tool:
  - \`curl -X POST -H "Content-Type: application/json" -d '{"k":"v"}' https://api.site.com\`
  - \`-I\`: Fetch HTTP response headers only.
  - \`-s\`: Silent mode; \`-L\`: Follow HTTP redirects; \`-o file\`: Save to file.
- **\`wget\`:** Recursive batch file downloader (\`wget -r -np https://site.com/docs/\`).

#### 2. Secure Shell (\`ssh\`), \`scp\` & \`rsync\`
- **SSH Key Pair Authentication:** \`ssh-keygen -t ed25519\` $\\to$ \`ssh-copy-id user@host\`.
  - Public key is appended to \`~/.ssh/authorized_keys\` (permissions must be $600$!).
- **\`scp\` (Secure Copy):** \`scp -r ./dist user@host:/var/www/html/\`
- **\`rsync\` (Remote Synchronization):**
  - \`rsync -avz --delete ./src/ user@remote:/backup/src/\`
  - \`-a\` (archive: preserves permissions, timestamps, symlinks), \`-v\` (verbose), \`-z\` (compress in transit).
  - Uses the **rsync delta-transfer algorithm**, transmitting only binary diffs of modified files!

#### 3. Network Diagnostics (\`ss\`, \`lsof\`, \`dig\`)
- \`ss -tulpn\`: List all active TCP/UDP listening ports and associated PIDs (\`-t\` TCP, \`-u\` UDP, \`-l\` listening, \`-p\` process, \`-n\` numeric).
- \`lsof -i :port\`: Identify which process is bound to a specific port.
- \`dig example.com +short\`: Perform DNS A-record query; \`dig example.com MX\` for mail records.`,
    quickRevisionNotes: [
      '`curl` makes HTTP requests with headers and JSON payloads; `wget` downloads files recursively.',
      '`rsync -avz` synchronizes directories efficiently using delta diff transfers.',
      '`ss -tulpn` lists listening network ports with associated process IDs.',
      'SSH public keys reside in `~/.ssh/authorized_keys` with strict 600 permissions.'
    ],
    formulaSheets: [
      {
        name: 'rsync Archive Synchronization Syntax',
        formula: '\\text{rsync -avz --progress --delete } \\text{src/ } \\text{user@remote:/dest/}',
        description: 'Delta-transfer synchronization preserving metadata.'
      }
    ],
    definitions: [
      {
        term: 'Delta-Transfer Algorithm',
        explanation: 'A synchronization mechanism in rsync that breaks files into chunk hashes and transmits only changed binary blocks.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Network Port Audit and Health Check Script',
        code: `# Check if web service responds with HTTP 200 OK
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://api.myproject.org/health)

if [[ "$HTTP_STATUS" -eq 200 ]]; then
    echo "Service is HEALTHY (HTTP 200)"
else
    echo "ALERT: Service returned HTTP $HTTP_STATUS" >&2
fi

# Audit all processes currently listening on TCP ports
echo "Active Listening TCP Ports:"
ss -tlnp`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w10-q1',
        questionText: 'Why is `rsync` significantly faster than `scp` when synchronizing an existing large directory of files where only a few files were updated?',
        options: ['rsync uses delta-compression to compare file timestamps/checksums and transmits only modified blocks/files', 'rsync runs without encryption', 'rsync uses UDP instead of TCP', 'rsync bypasses the filesystem'],
        correctOptionIndex: 0,
        solution: 'rsync inspects file metadata and transmits only the difference (deltas) of changed files, whereas scp re-transmits the entire dataset blindly.',
        hints: ['Think of delta-transfer algorithm.']
      }
    ],
    examTips: [
      'Trailing slash matters in `rsync`: `rsync -a src/ dest/` copies contents of `src`; `rsync -a src dest/` creates directory `dest/src`.',
      'The `~/.ssh/` folder must have `700` permissions and `authorized_keys` must have `600` permissions, or OpenSSH server will reject logins.'
    ],
    handwrittenMnemonic: 'curl for APIs; rsync -avz for efficient file transfers; ss -tulpn for open ports!'
  },
  {
    id: 'note-syscmd-w11',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 11,
    title: 'Archiving (tar, gzip), Package Management (apt/dpkg) & Shell Environment Setup',
    detailedNotes: `### Week 11: Archiving, Compression, Packaging & Environment Variables

#### 1. Archiving & Compression (\`tar\`)
\`tar\` (Tape Archive) bundles multiple files and directories into a single file (\`.tar\`), which is then compressed:
- **Create Gzipped Tarball (\`.tar.gz\` / \`.tgz\`):**
  \`tar -czvf archive.tar.gz /path/to/folder/\`
  - \`-c\`: Create archive.
  - \`-z\`: Filter archive through \`gzip\`.
  - \`-v\`: Verbose listing.
  - \`-f\`: Output filename (must immediately precede archive name!).
- **Extract Archive:**
  \`tar -xzvf archive.tar.gz -C /extract/destination/\`
  - \`-x\`: Extract files.
  - \`-C\`: Change to target directory before extracting.
- **Compression Algorithms Comparison:**
  - \`gzip\` (\`-z\`, \`.tar.gz\`): Fast compression/decompression; industry standard.
  - \`bzip2\` (\`-j\`, \`.tar.bz2\`): Higher compression ratio; slower speed.
  - \`xz\` (\`-J\`, \`.tar.xz\`): Maximum compression ratio; high CPU usage.

#### 2. Package Management (Debian/Ubuntu \`apt\` & \`dpkg\`)
- \`sudo apt update\`: Synchronizes package index from remote repositories (\`/etc/apt/sources.list\`).
- \`sudo apt upgrade -y\`: Installs latest available versions of all installed packages.
- \`sudo apt install -y pkg_name\`: Installs package and resolves dependencies automatically.
- \`dpkg -i package.deb\`: Low-level install of downloaded Debian package.
- \`dpkg -l\`: List all installed packages.

#### 3. Shell Environment Configuration
- \`/etc/profile\` & \`/etc/bash.bashrc\`: System-wide environment configs.
- \`~/.bashrc\`: User-specific interactive non-login shell config (aliases, custom functions, prompt \`PS1\`).
- \`~/.profile\` / \`~/.bash_profile\`: User login shell configuration.
- **\`export PATH="$PATH:/new/bin"\`:** Adds directory to executable lookup search path.`,
    quickRevisionNotes: [
      '`tar -czvf archive.tar.gz folder/` creates compressed tarball; `tar -xzvf archive.tar.gz` extracts it.',
      '`apt update` refreshes repository lists; `apt upgrade` installs package updates.',
      '`~/.bashrc` configures aliases and functions for interactive bash sessions.',
      '`export PATH="$PATH:/custom/dir"` appends custom binaries to shell execution path.'
    ],
    formulaSheets: [
      {
        name: 'Tar Flags Reference',
        formula: '\\text{tar -czvf } \\text{out.tar.gz } \\text{src/} \\quad (\\text{create}) \\quad | \\quad \\text{tar -xzvf } \\text{in.tar.gz} \\quad (\\text{extract})',
        description: 'Common flag combinations for tar archive manipulation.'
      }
    ],
    definitions: [
      {
        term: 'PATH Environment Variable',
        explanation: 'A colon-separated list of directories searched by the shell to locate executable commands when typed without a path prefix.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Automated Directory Backup and Archive Script',
        code: `#!/usr/bin/env bash
set -euo pipefail

SRC_DIR="/var/www/app"
BACKUP_DIR="/backup/archives"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ARCHIVE_NAME="app_backup_\${TIMESTAMP}.tar.gz"

mkdir -p "$BACKUP_DIR"

echo "Creating compressed backup: $ARCHIVE_NAME..."
tar -czf "\${BACKUP_DIR}/\${ARCHIVE_NAME}" -C "$(dirname "$SRC_DIR")" "$(basename "$SRC_DIR")"

echo "Backup created successfully. File size:"
ls -lh "\${BACKUP_DIR}/\${ARCHIVE_NAME}"

# Keep only the 5 most recent backups, delete older ones
cd "$BACKUP_DIR"
ls -t app_backup_*.tar.gz | tail -n +6 | xargs -r rm -f`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w11-q1',
        questionText: 'What is the crucial difference between executing `sudo apt update` and `sudo apt upgrade`?',
        options: ['`apt update` refreshes the package metadata index from repositories; `apt upgrade` actually installs the newer package binaries', '`apt update` restarts the computer', '`apt upgrade` uninstalls all software', 'They are completely identical'],
        correctOptionIndex: 0,
        solution: '`apt update` downloads the latest package versions and dependency information from repository servers without modifying installed software. `apt upgrade` reads this index and installs the updates.',
        hints: ['Update fetches metadata; upgrade installs binaries.']
      }
    ],
    examTips: [
      'Always place the `-f` flag as the last option before the archive name in `tar` commands.',
      'Remember to run `source ~/.bashrc` to immediately reload configuration changes in current terminal session without logging out.'
    ],
    handwrittenMnemonic: 'tar -czvf creates; tar -xzvf extracts; export PATH appends binaries!'
  },
  {
    id: 'note-syscmd-w12',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    courseCode: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 12,
    title: 'System Performance Profiling, Storage (df/du, iostat, vmstat) & Log Management (journalctl)',
    detailedNotes: `### Week 12: System Performance Profiling & Production Troubleshooting

#### 1. System Load Average & CPU Profiling
- \`uptime\`: Displays system load averages over the last 1, 5, and 15 minutes.
  - Load average represents the average number of processes in a **Runnable** (\`R\`) or **Uninterruptible Disk Sleep** (\`D\`) state.
  - On a 4-core CPU, load average $> 4.0$ indicates CPU saturation / queue backlog.
- \`top\` / \`htop\`: Interactive real-time process viewer.
- \`vmstat 1 5\`: Reports virtual memory statistics, page ins/outs (\`si\`/\`so\`), and CPU utilization (\`us\` user, \`sy\` system, \`id\` idle, \`wa\` I/O wait).
  - High \`wa\` (I/O wait) indicates a disk/storage bottleneck!

#### 2. Storage & Disk Usage Analysis
- \`df -h\`: Shows filesystem disk space usage (total, used, available, mount points) in human-readable GB/MB.
- \`du -sh /var/* | sort -hr | head -n 10\`: Calculates disk space consumed by directories, sorted by largest first.
- \`iostat -xz 1 5\`: Reports disk device read/write throughput (MB/s) and utilization percentage (\`%util\`).

#### 3. Modern System Logging with \`journalctl\` & \`systemctl\`
- \`systemctl status nginx\`: Check daemon service status.
- \`systemctl restart nginx\`: Restart service.
- \`journalctl -u nginx.service -f\`: Follow live systemd service logs.
- \`journalctl -p err -b\`: View all error-level messages from current boot.
- \`journalctl --since "1 hour ago"\`: Query logs within specific time range.`,
    quickRevisionNotes: [
      'Load average indicates queue depth across 1, 5, and 15 minutes; load > CPU cores means saturation.',
      'High `wa` (I/O wait) in `vmstat` points to storage/disk bottlenecks.',
      '`df -h` inspects filesystem capacity; `du -sh` calculates folder size.',
      '`journalctl -u service -f` streams live systemd logs in real time.'
    ],
    formulaSheets: [
      {
        name: 'CPU Saturation Metric',
        formula: '\\text{CPU Utilization} = \\frac{\\text{Load Average}}{\\text{Number of CPU Cores}} \\quad (\\text{Healthy if } \\le 1.0)',
        description: 'Normalized load average across multi-core systems.'
      }
    ],
    definitions: [
      {
        term: 'I/O Wait (wa)',
        explanation: 'Percentage of CPU time spent waiting for outstanding disk or network I/O requests to complete.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Production Server Health & Storage Triage Script',
        code: `#!/usr/bin/env bash
echo "=== System Overview ==="
uptime

echo -e "\\n=== Filesystem Capacity (df -h) ==="
df -h | grep -E '^Filesystem|/dev/'

echo -e "\\n=== Memory and Swap Utilization ==="
free -h

echo -e "\\n=== Top 5 Memory-Consuming Processes ==="
ps aux --sort=-%mem | awk 'NR<=6 {printf "%-10s %-8s %-6s %-6s %s\\n", $1, $2, $3, $4, $11}'

echo -e "\\n=== Recent System Errors (journalctl) ==="
journalctl -p err -b --no-pager -n 5`
      }
    ],
    practiceQuestions: [
      {
        id: 'syscmd-w12-q1',
        questionText: 'When running `vmstat`, what does a consistently high value in the `wa` (I/O wait) column indicate?',
        options: ['The CPU is idle while waiting for disk I/O operations to complete, indicating a storage bottleneck', 'The CPU is executing complex mathematical code', 'The network interface is disconnected', 'The RAM is defective'],
        correctOptionIndex: 0,
        solution: 'I/O wait (wa) represents the percentage of time CPU cores are idle because all runnable tasks are blocked waiting for disk read/write requests.',
        hints: ['wa stands for wait on I/O.']
      }
    ],
    examTips: [
      'If disk is 100% full but `du` doesn\'t account for the space, deleted files held open by running processes may be holding disk blocks (check with `lsof +L1`).',
      'Use `htop` for visual process tree exploration and quick interactive signal dispatching.'
    ],
    handwrittenMnemonic: 'df checks filesystem disks; du checks folder sizes; vmstat wa reveals disk bottlenecks!'
  }
];

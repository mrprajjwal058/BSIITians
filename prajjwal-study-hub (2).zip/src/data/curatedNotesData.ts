import { WeeklyStudyMaterial } from "../types";

// Foundation Level Modules (12 Weeks Each)
import { FOUNDATION_MATH_1_NOTES } from "./curatedNotesFoundationMath1";
import { FOUNDATION_MATH_2_NOTES } from "./curatedNotesFoundationMath2";
import { FOUNDATION_STATS_1_NOTES } from "./curatedNotesFoundationStats1";
import { FOUNDATION_STATS_2_NOTES } from "./curatedNotesFoundationStats2";
import { FOUNDATION_CT_NOTES } from "./curatedNotesFoundationCT";
import { FOUNDATION_PYTHON_NOTES } from "./curatedNotesFoundationPython";
import { FOUNDATION_ENGLISH_1_NOTES } from "./curatedNotesFoundationEnglish1";
import { FOUNDATION_ENGLISH_2_NOTES } from "./curatedNotesFoundationEnglish2";

// Diploma in Programming Modules (12 Weeks Each)
import { DIPLOMA_PROGRAMMING_PDSA_NOTES } from "./curatedNotesDiplomaProgramming";
import { DIPLOMA_JAVA_NOTES } from "./curatedNotesDiplomaJava";
import { DIPLOMA_DBMS_NOTES } from "./curatedNotesDiplomaDBMS";
import { DIPLOMA_SYSCMD_NOTES } from "./curatedNotesDiplomaSysCmd";
import { DIPLOMA_MAD1_NOTES } from "./curatedNotesDiplomaMAD1";
import { DIPLOMA_MAD2_NOTES } from "./curatedNotesDiplomaMAD2";

// Diploma in Data Science Modules (12 Weeks Each)
import { DIPLOMA_DS_MLF_NOTES } from "./curatedNotesDiplomaMLF";
import { DIPLOMA_MLP_NOTES } from "./curatedNotesDiplomaMLP";
import { DIPLOMA_TDS_NOTES } from "./curatedNotesDiplomaTDS";
import { DIPLOMA_BA_NOTES } from "./curatedNotesDiplomaBA";

// Degree / BS Level Modules (12 Weeks Each)
import { DEGREE_DEEP_LEARNING_NOTES } from "./curatedNotesDegreeDL";
import { DEGREE_AI_NOTES } from "./curatedNotesDegreeAI";
import { DEGREE_RL_NOTES } from "./curatedNotesDegreeRL";
import { DEGREE_LLM_NOTES } from "./curatedNotesDegreeLLM";

export {
  FOUNDATION_MATH_1_NOTES,
  FOUNDATION_MATH_2_NOTES,
  FOUNDATION_STATS_1_NOTES,
  FOUNDATION_STATS_2_NOTES,
  FOUNDATION_CT_NOTES,
  FOUNDATION_PYTHON_NOTES,
  FOUNDATION_ENGLISH_1_NOTES,
  FOUNDATION_ENGLISH_2_NOTES,
  DIPLOMA_PROGRAMMING_PDSA_NOTES,
  DIPLOMA_JAVA_NOTES,
  DIPLOMA_DBMS_NOTES,
  DIPLOMA_SYSCMD_NOTES,
  DIPLOMA_MAD1_NOTES,
  DIPLOMA_MAD2_NOTES,
  DIPLOMA_DS_MLF_NOTES,
  DIPLOMA_MLP_NOTES,
  DIPLOMA_TDS_NOTES,
  DIPLOMA_BA_NOTES,
  DEGREE_DEEP_LEARNING_NOTES,
  DEGREE_AI_NOTES,
  DEGREE_RL_NOTES,
  DEGREE_LLM_NOTES,
};

export type WeeklyChapterNote = WeeklyStudyMaterial;

export const CURATED_WEEKLY_NOTES: WeeklyStudyMaterial[] = [
  // ========================================================
  // 1. FOUNDATION LEVEL (ALL 8 COURSES x 12 WEEKS = 96 WEEKS)
  // ========================================================
  ...FOUNDATION_MATH_1_NOTES,
  ...FOUNDATION_MATH_2_NOTES,
  ...FOUNDATION_STATS_1_NOTES,
  ...FOUNDATION_STATS_2_NOTES,
  ...FOUNDATION_CT_NOTES,
  ...FOUNDATION_PYTHON_NOTES,
  ...FOUNDATION_ENGLISH_1_NOTES,
  ...FOUNDATION_ENGLISH_2_NOTES,

  // ========================================================
  // 2. DIPLOMA IN PROGRAMMING (6 COURSES x 12 WEEKS = 72 WEEKS)
  // ========================================================
  ...DIPLOMA_PROGRAMMING_PDSA_NOTES,
  ...DIPLOMA_JAVA_NOTES,
  ...DIPLOMA_DBMS_NOTES,
  ...DIPLOMA_SYSCMD_NOTES,
  ...DIPLOMA_MAD1_NOTES,
  ...DIPLOMA_MAD2_NOTES,

  // ========================================================
  // 3. DIPLOMA IN DATA SCIENCE (4 COURSES x 12 WEEKS = 48 WEEKS)
  // ========================================================
  ...DIPLOMA_DS_MLF_NOTES,
  ...DIPLOMA_MLP_NOTES,
  ...DIPLOMA_TDS_NOTES,
  ...DIPLOMA_BA_NOTES,

  // ========================================================
  // 4. DEGREE / BS LEVEL (4 CORE ADVANCED COURSES x 12 WEEKS = 48 WEEKS)
  // ========================================================
  ...DEGREE_DEEP_LEARNING_NOTES,
  ...DEGREE_AI_NOTES,
  ...DEGREE_RL_NOTES,
  ...DEGREE_LLM_NOTES,
];

import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_STATS_1_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-stats1-w1',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Data Types, Scales of Measurement & Sampling Methodologies',
    detailedNotes: `### Week 1: Typology of Data & Sampling Strategies

#### 1. Data Classification
- **Qualitative (Categorical):** Descriptive attributes non-measurable on a continuous numeric scale.
- **Quantitative (Numerical):** Numeric values representing counts or measurements.
  - **Discrete:** Countable finite or countably infinite values (e.g. number of defective items).
  - **Continuous:** Uncountably infinite values over an interval continuum (e.g. temperature, weight).

#### 2. Stevens\' Four Scales of Measurement
1. **Nominal:** Categorical identifiers with no intrinsic order (e.g. Blood type $A, B, AB, O$, Gender). Operations allowed: Mode, Equality ($=$ or $\\ne$).
2. **Ordinal:** Ranked categories with order, but intervals between ranks are undefined (e.g. Education level, Likert scale $1-5$). Operations: Median, Percentiles, Rank correlation.
3. **Interval:** Ordered numeric scale with meaningful differences, but **arbitrary zero** (no true absence) (e.g. Temperature in Celsius/Fahrenheit, Calendar years). Operations: Addition, Subtraction, Mean, Standard Deviation (Ratios are meaningless: $20^\\circ\\text{C}$ is not "twice as hot" as $10^\\circ\\text{C}$).
4. **Ratio:** Numeric scale with a **true absolute zero** representing absence (e.g. Height, Weight, Salary, Kelvin temperature). Operations: Multiplication, Division, Geometric Mean, Ratios.

#### 3. Sampling Methodologies
- **Simple Random Sampling (SRS):** Every subset of size $n$ has an equal probability of selection.
- **Stratified Sampling:** Divide population into homogeneous mutually exclusive subgroups (strata) and sample randomly within each stratum.
- **Cluster Sampling:** Divide population into heterogeneous naturally occurring clusters; randomly select whole clusters.
- **Systematic Sampling:** Select every $k$-th individual from an ordered list ($k = N/n$).`,
    quickRevisionNotes: [
      'Measurement scales hierarchy: Nominal (Identity) < Ordinal (Rank) < Interval (Equal spacing, arbitrary zero) < Ratio (Absolute true zero).',
      'Temperature in Celsius is Interval; Kelvin is Ratio.',
      'Stratified sampling reduces variance between heterogeneous groups by ensuring proportional representation.',
      'Cluster sampling samples all units in randomly picked clusters.'
    ],
    formulaSheets: [
      {
        name: 'Systematic Sampling Interval',
        formula: 'k = \\left\\lfloor \\frac{N}{n} \\right\\rfloor',
        description: 'Skip step size for systematic sampling from population of size N to sample size n.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w1-p1',
        questionText: 'What is the scale of measurement for IQ scores and temperature in Celsius?',
        options: ['Interval scale', 'Ratio scale', 'Ordinal scale', 'Nominal scale'],
        correctOptionIndex: 0,
        solution: 'Both IQ scores and Celsius temperatures have equal intervals between units, but lack an absolute zero point (0 degrees does not mean absence of heat). Hence, they are Interval scale.',
        hints: ['Does zero represent the absolute total absence of the quantity?']
      },
      {
        id: 'stats1-w1-p2',
        questionText: 'Which sampling method is best suited when the population is composed of distinct, non-overlapping groups with very different characteristics?',
        options: ['Stratified Random Sampling', 'Simple Random Sampling', 'Convenience Sampling', 'Snowball Sampling'],
        correctOptionIndex: 0,
        solution: 'Stratified sampling ensures every homogeneous subgroup (stratum) is adequately represented, minimizing sampling variance.',
        hints: ['Look for the technique that partitions into homogeneous strata.']
      },
      {
        id: 'stats1-w1-p3',
        questionText: 'A survey asks participants to rank customer service satisfaction as "Poor", "Average", "Good", "Excellent". What is the measurement scale?',
        options: ['Ordinal', 'Nominal', 'Interval', 'Ratio'],
        correctOptionIndex: 0,
        solution: 'The categories have an inherent ordering/ranking, but the numerical difference between "Average" and "Good" cannot be precisely measured. Hence it is Ordinal.',
        hints: ['There is a clear order, but no exact numerical distance.']
      }
    ],
    keyTakeaways: [
      'Scale of measurement dictates which statistical summary operations and tests are mathematically valid.',
      'Stratified sampling guarantees representation across minority population demographics.'
    ],
    markdownContent: `### Week 1: Data Types & Sampling\nNominal, ordinal, interval, ratio scales and probabilistic sampling designs.`,
    examTips: ['Remember: ratios are only valid on Ratio scales (which possess true absolute zero)!']
  },
  {
    id: 'note-stats1-w2',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Frequency Distributions, Histograms & Exploratory Data Visualization',
    detailedNotes: `### Week 2: Frequency Tabulations & Visual Representations

#### 1. Frequency Distributions
- **Class Interval / Bin Width:** $h = \\frac{\\text{Max} - \\text{Min}}{k}$.
- **Sturges\' Rule for Optimal Number of Bins:**
  $$k = 1 + 3.322 \\log_{10}(n) = 1 + \\log_2(n)$$
- **Cumulative Frequency:**
  - *Less-than Ogive:* Monotonically increasing curve showing proportion $\\le x$.
  - *More-than Ogive:* Monotonically decreasing curve showing proportion $\\ge x$.
  - **Intersection of Ogives:** Intersects exactly at the **Median** value!

#### 2. Visualizations
- **Histogram:** For continuous quantitative data where area of each bar is proportional to frequency.
- **Bar Chart:** For discrete categorical variables (bars have gaps between them).
- **Stem-and-Leaf Display:** Retains exact numerical values while displaying distribution shape.`,
    quickRevisionNotes: [
      'Sturges\' Rule: $k = 1 + \\log_2(n) = 1 + 3.322 \\log_{10}(n)$.',
      'In a histogram, the area of the bar (not just height) is proportional to class frequency.',
      'Intersection of "Less-than" and "More-than" ogive curves gives the Median.',
      'Bar charts have spaces between bars; histograms for continuous data have touching bars.'
    ],
    formulaSheets: [
      {
        name: 'Sturges\' Rule for Bin Count',
        formula: 'k = 1 + 3.322 \\log_{10}(n) = 1 + \\log_2(n)',
        description: 'Empirical formula for choosing optimal number of histogram bins.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w2-p1',
        questionText: 'For a dataset of size $n = 1024$, how many bins are recommended by Sturges\' rule?',
        options: ['11', '10', '12', '9'],
        correctOptionIndex: 0,
        solution: '$k = 1 + \\log_2(1024) = 1 + 10 = 11$.',
        hints: ['Use $k = 1 + \\log_2(n)$ where $\\log_2(1024) = 10$.']
      },
      {
        id: 'stats1-w2-p2',
        questionText: 'The $x$-coordinate of the intersection point of the "less than" and "more than" ogives gives what statistic?',
        options: ['Median', 'Mean', 'Mode', 'Standard Deviation'],
        correctOptionIndex: 0,
        solution: 'The 50th percentile (where cumulative less-than equals cumulative more-than frequency at $N/2$) is by definition the Median.',
        hints: ['Recall which measure splits the distribution into equal 50% halves.']
      },
      {
        id: 'stats1-w2-p3',
        questionText: 'In a histogram with unequal class widths, the height of each rectangle must be proportional to what?',
        options: ['Frequency Density (Frequency / Class Width)', 'Raw Frequency', 'Cumulative Frequency', 'Class Midpoint'],
        correctOptionIndex: 0,
        solution: 'To ensure area represents frequency when widths vary, height must be Frequency Density $= \\frac{\\text{Frequency}}{\\text{Width}}$.',
        hints: ['Area must be proportional to frequency: $\\text{Area} = \\text{Width} \\times \\text{Height} \\propto \\text{Frequency}$.']
      }
    ],
    keyTakeaways: [
      'Frequency density preserves area interpretations when visualizing unequal histogram bins.',
      'Ogives provide a graphical method to estimate percentiles and medians.'
    ],
    markdownContent: `### Week 2: Frequency Distributions & Ogives\nSturges\' rule, histograms, and cumulative frequency analysis.`,
    examTips: ['Check if class widths are equal before reading histogram bar heights directly as frequencies!']
  },
  {
    id: 'note-stats1-w3',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Measures of Central Tendency: Mean, Median, Mode, Geometric & Harmonic Means',
    detailedNotes: `### Week 3: Central Tendency & Mathematical Averages

#### 1. Arithmetic Mean
$$\\bar{x} = \\frac{1}{n} \\sum_{i=1}^n x_i$$
- **Algebraic Property:** $\\sum_{i=1}^n (x_i - \\bar{x}) = 0$ (Sum of deviations from the mean is always zero).
- **Sum of Squared Deviations:** $\\sum (x_i - c)^2$ is strictly minimized when $c = \\bar{x}$.
- **Linear Transformation:** If $y_i = a x_i + b$, then $\\bar{y} = a \\bar{x} + b$.

#### 2. Median & Mode
- **Median:** 50th percentile value minimizing $\\sum |x_i - c|$ (L1 norm). Robust to extreme outliers.
- **Mode:** Most frequently occurring value. Can be unimodal, bimodal, or multimodal.

#### 3. Geometric Mean (GM) & Harmonic Mean (HM)
- **Geometric Mean:** $\\text{GM} = \\left( \\prod_{i=1}^n x_i \\right)^{1/n} = \\exp\\left( \\frac{1}{n} \\sum \\ln x_i \\right)$ (ideal for growth rates and compounding).
- **Harmonic Mean:** $\\text{HM} = \\frac{n}{\\sum_{i=1}^n \\frac{1}{x_i}}$ (ideal for rates, speeds over fixed distances).
- **Fundamental Inequality:**
  $$\\text{AM} \\ge \\text{GM} \\ge \\text{HM}$$
  *(Equality holds iff all sample observations are identical: $x_1 = x_2 = \\dots = x_n$).*`,
    quickRevisionNotes: [
      '$\\sum (x_i - \\bar{x}) = 0$; $\\sum (x_i - c)^2$ is minimized at $c = \\bar{x}$.',
      'Median minimizes sum of absolute deviations $\\sum |x_i - c|$.',
      'For positive numbers: $\\text{AM} \\ge \\text{GM} \\ge \\text{HM}$.',
      'Use Harmonic Mean for average speeds over equal distances; Geometric Mean for annual growth rates.'
    ],
    formulaSheets: [
      {
        name: 'AM-GM-HM Inequality',
        formula: '\\text{AM} \\ge \\text{GM} \\ge \\text{HM} \\quad \\iff \\frac{\\sum x_i}{n} \\ge \\left(\\prod x_i\\right)^{1/n} \\ge \\frac{n}{\\sum \\frac{1}{x_i}}',
        description: 'Universal Pythagorean mean ordering inequality.'
      },
      {
        name: 'Harmonic Mean for Rates',
        formula: '\\text{HM} = \\frac{n}{\\sum_{i=1}^n \\frac{1}{x_i}}',
        description: 'Reciprocal mean for speed and rate aggregation.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w3-p1',
        questionText: 'A car travels from A to B at 60 km/h and returns from B to A along the same route at 40 km/h. What is the average speed for the round trip?',
        options: ['48 km/h', '50 km/h', '52 km/h', '45 km/h'],
        correctOptionIndex: 0,
        solution: 'Since distances are equal, average speed is the Harmonic Mean: $\\text{HM} = \\frac{2}{\\frac{1}{60} + \\frac{1}{40}} = \\frac{2}{\\frac{2 + 3}{120}} = \\frac{2 \\times 120}{5} = 48$ km/h.',
        hints: ['Use the Harmonic Mean formula $\\frac{2ab}{a+b}$.']
      },
      {
        id: 'stats1-w3-p2',
        questionText: 'If the mean of 10 observations is 25, and every observation is multiplied by 3 and then increased by 4, what is the new mean?',
        options: ['79', '75', '85', '29'],
        correctOptionIndex: 0,
        solution: 'By linearity of the mean: $\\bar{y} = 3\\bar{x} + 4 = 3(25) + 4 = 75 + 4 = 79$.',
        hints: ['Mean scales linearly: $\\bar{y} = a\\bar{x} + b$.']
      },
      {
        id: 'stats1-w3-p3',
        questionText: 'The value of $c$ that minimizes $\\sum_{i=1}^n (x_i - c)^2$ is:',
        options: ['Arithmetic Mean', 'Median', 'Mode', 'Geometric Mean'],
        correctOptionIndex: 0,
        solution: 'Differentiating $\\sum (x_i - c)^2$ with respect to $c$ and setting to zero yields $-2\\sum (x_i - c) = 0 \\implies nc = \\sum x_i \\implies c = \\bar{x}$.',
        hints: ['Differentiate with respect to $c$ to find the minimum.']
      }
    ],
    keyTakeaways: [
      'The mean is the center of gravity minimizing squared loss (L2 regression).',
      'The median minimizes absolute deviation (L1 quantile regression).'
    ],
    markdownContent: `### Week 3: Central Tendency Measures\nArithmetic, Geometric, Harmonic means and minimization properties.`,
    examTips: ['Do not compute simple arithmetic average for speeds over equal distances — always use harmonic mean!']
  },
  {
    id: 'note-stats1-w4',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Measures of Dispersion: Variance, Standard Deviation & Coefficient of Variation',
    detailedNotes: `### Week 4: Dispersion, Variance & Relative Variability

#### 1. Sample Variance & Bessel\'s Correction
- **Population Variance:** $\\sigma^2 = \\frac{1}{N} \\sum_{i=1}^N (x_i - \\mu)^2 = \\frac{1}{N}\\sum x_i^2 - \\mu^2$.
- **Sample Variance ($s^2$):**
  $$s^2 = \\frac{1}{n - 1} \\sum_{i=1}^n (x_i - \\bar{x})^2 = \\frac{\\sum x_i^2 - \\frac{(\\sum x_i)^2}{n}}{n - 1}$$
  *(Dividing by $n - 1$ removes degrees-of-freedom bias, ensuring $E[s^2] = \\sigma^2$).*
- **Standard Deviation:** $s = \\sqrt{s^2}$.

#### 2. Linear Transformation Effects on Dispersion
If $y_i = a x_i + b$:
- $\\text{Var}(y) = a^2 \\text{Var}(x)$
- $\\text{SD}(y) = |a| \\text{SD}(x)$ *(Shift $b$ does NOT affect variance or SD).*

#### 3. Coefficient of Variation (CV) - Relative Dispersion
$$\\text{CV} = \\frac{s}{\\bar{x}} \\times 100\\%$$
- Used to compare variability between datasets with different units or widely differing means (e.g. stock volatility vs bond yields).
- Dataset with lower CV is termed **more consistent / stable**.`,
    quickRevisionNotes: [
      'Sample variance uses $n - 1$ in denominator to guarantee an unbiased estimator ($E[s^2] = \\sigma^2$).',
      'Adding a constant $b$ does not change variance: $\\text{Var}(ax + b) = a^2 \\text{Var}(x)$.',
      'Standard deviation: $\\text{SD}(ax + b) = |a| \\text{SD}(x)$.',
      'Coefficient of Variation: $\\text{CV} = \\frac{s}{\\bar{x}} \\times 100\\%$; lower CV means greater consistency.'
    ],
    formulaSheets: [
      {
        name: 'Sample Variance (Bessel-Corrected)',
        formula: 's^2 = \\frac{1}{n - 1} \\sum_{i=1}^n (x_i - \\bar{x})^2 = \\frac{\\sum x_i^2 - \\frac{(\\sum x_i)^2}{n}}{n - 1}',
        description: 'Unbiased estimator of population variance.'
      },
      {
        name: 'Coefficient of Variation',
        formula: '\\text{CV} = \\frac{s}{\\bar{x}} \\times 100\\%',
        description: 'Unitless ratio of relative dispersion.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w4-p1',
        questionText: 'If the standard deviation of a dataset $X$ is 6, what is the standard deviation of $Y = -3X + 15$?',
        options: ['18', '-18', '33', '6'],
        correctOptionIndex: 0,
        solution: '$\\text{SD}(Y) = |-3| \\times \\text{SD}(X) = 3 \\times 6 = 18$. The constant shift $+15$ has zero effect on dispersion.',
        hints: ['$\\text{SD}(aX + b) = |a| \\text{SD}(X)$.']
      },
      {
        id: 'stats1-w4-p2',
        questionText: 'Player A has mean score 50 with SD 5. Player B has mean score 80 with SD 6. Which player is more consistent?',
        options: ['Player B (CV = 7.5%)', 'Player A (CV = 10%)', 'Both are equally consistent', 'Cannot be determined'],
        correctOptionIndex: 0,
        solution: '$\\text{CV}_A = (5/50) \\times 100\\% = 10\\%$. $\\text{CV}_B = (6/80) \\times 100\\% = 7.5\\%$. Lower CV indicates higher consistency, so Player B is more consistent.',
        hints: ['Compute $\\text{CV} = (s / \\bar{x}) \\times 100\\%$.']
      },
      {
        id: 'stats1-w4-p3',
        questionText: 'Why do we divide by $n - 1$ instead of $n$ when computing sample variance $s^2$?',
        options: ['To correct for downward bias because sample deviations are measured from sample mean rather than population mean', 'Because one data point is always discarded as an outlier', 'To make standard deviation equal to variance', 'To force variance to be positive'],
        correctOptionIndex: 0,
        solution: 'Because $\\bar{x}$ minimizes $\\sum (x_i - c)^2$, deviations from $\\bar{x}$ are systematically smaller than deviations from true population mean $\\mu$. Dividing by $n-1$ (Bessel\'s correction) yields an unbiased estimator.',
        hints: ['Recall degrees of freedom and unbiased estimators.']
      }
    ],
    keyTakeaways: [
      'Standard deviation is in the same physical units as the original data.',
      'CV is indispensable for comparing risk-adjusted return ratios in finance.'
    ],
    markdownContent: `### Week 4: Dispersion & Variance\nBessel\'s correction, linear scaling of dispersion, and CV comparison.`,
    examTips: ['SD can NEVER be negative! $|a|$ must be taken when scaling.']
  },
  {
    id: 'note-stats1-w5',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Box Plots, Skewness, Kurtosis & Outlier Detection Rules',
    detailedNotes: `### Week 5: Distribution Shape, Moments & Tukey\'s Outlier Rule

#### 1. Five-Number Summary & Box-and-Whisker Plot
$$\\{\\text{Min}, Q_1, Q_2 (\\text{Median}), Q_3, \\text{Max}\\}$$
- **Interquartile Range (IQR):** $\\text{IQR} = Q_3 - Q_1$.
- **Tukey\'s 1.5 $\\times$ IQR Outlier Fences:**
  - **Lower Inner Fence:** $\\text{LIF} = Q_1 - 1.5 \\times \\text{IQR}$
  - **Upper Inner Fence:** $\\text{UIF} = Q_3 + 1.5 \\times \\text{IQR}$
  - Any point outside $[\\text{LIF}, \\text{UIF}]$ is classified as an **outlier**.

#### 2. Skewness (Asymmetry of Distribution)
- **Karl Pearson\'s Skewness:** $S_k = \\frac{\\text{Mean} - \\text{Mode}}{\\sigma} \\approx \\frac{3(\\text{Mean} - \\text{Median})}{\\sigma}$.
- **Positively Skewed (Right-tailed):** Long tail to the right; $\\text{Mean} > \\text{Median} > \\text{Mode}$.
- **Negatively Skewed (Left-tailed):** Long tail to the left; $\\text{Mean} < \\text{Median} < \\text{Mode}$.
- **Symmetric:** $\\text{Mean} = \\text{Median} = \\text{Mode} \\implies \\text{Skewness} = 0$.

#### 3. Kurtosis (Tail Heaviness)
$$\\beta_2 = \\frac{\\mu_4}{\\mu_2^2}, \\quad \\gamma_2 = \\beta_2 - 3 \\text{ (Excess Kurtosis)}$$
- **Mesokurtic (Normal distribution):** $\\beta_2 = 3$ (Excess $= 0$).
- **Leptokurtic (Heavy-tailed / Sharp peak):** $\\beta_2 > 3$ (Excess $> 0$).
- **Platykurtic (Light-tailed / Flat peak):** $\\beta_2 < 3$ (Excess $< 0$).`,
    quickRevisionNotes: [
      'Tukey\'s outlier fences: $[Q_1 - 1.5 \\times \\text{IQR}, Q_3 + 1.5 \\times \\text{IQR}]$.',
      'Right-skewed (positive): $\\text{Mean} > \\text{Median} > \\text{Mode}$.',
      'Left-skewed (negative): $\\text{Mean} < \\text{Median} < \\text{Mode}$.',
      'Normal distribution has Kurtosis $\\beta_2 = 3$ and Excess Kurtosis $\\gamma_2 = 0$.',
      'Leptokurtic distributions (excess $> 0$) have heavier tails and higher risk of extreme events.'
    ],
    formulaSheets: [
      {
        name: 'Tukey\'s Outlier Boundaries',
        formula: '[Q_1 - 1.5 \\times \\text{IQR}, \\; Q_3 + 1.5 \\times \\text{IQR}]',
        description: 'Inner fences for boxplot outlier detection.'
      },
      {
        name: 'Excess Kurtosis',
        formula: '\\gamma_2 = \\frac{\\mu_4}{\\sigma^4} - 3',
        description: 'Standardized 4th moment measure of tail heaviness relative to normal.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w5-p1',
        questionText: 'For a dataset with $Q_1 = 20$ and $Q_3 = 35$, which value is an outlier by Tukey\'s rule?',
        options: ['60', '55', '10', '0'],
        correctOptionIndex: 0,
        solution: '$\\text{IQR} = 35 - 20 = 15$. $\\text{UIF} = Q_3 + 1.5(\\text{IQR}) = 35 + 1.5(15) = 35 + 22.5 = 57.5$. $\\text{LIF} = 20 - 22.5 = -2.5$. Value $60 > 57.5$, so 60 is an outlier.',
        hints: ['Compute $\\text{IQR} = Q_3 - Q_1$ and $\\text{UIF} = Q_3 + 1.5 \\times \\text{IQR}$.']
      },
      {
        id: 'stats1-w5-p2',
        questionText: 'In a salary distribution, Mean = $75,000, Median = $52,000, Mode = $45,000. What is the shape of this distribution?',
        options: ['Positively (Right) Skewed', 'Negatively (Left) Skewed', 'Symmetric (Normal)', 'Uniform'],
        correctOptionIndex: 0,
        solution: 'Since $\\text{Mean} (75k) > \\text{Median} (52k) > \\text{Mode} (45k)$, the distribution has a long right tail driven by high earners, which is Positively Skewed.',
        hints: ['Compare the relative positions of Mean, Median, and Mode.']
      },
      {
        id: 'stats1-w5-p3',
        questionText: 'What is the excess kurtosis of a standard normal distribution?',
        options: ['0', '3', '1', '-3'],
        correctOptionIndex: 0,
        solution: 'Standard normal distribution has kurtosis $\\beta_2 = 3$. Excess kurtosis is $\\gamma_2 = \\beta_2 - 3 = 3 - 3 = 0$.',
        hints: ['Excess kurtosis subtracts 3 from raw kurtosis.']
      }
    ],
    keyTakeaways: [
      'Box plots are resistant to extreme values because they rely on medians and quartiles.',
      'Financial asset return distributions are frequently leptokurtic (fat-tailed).'
    ],
    markdownContent: `### Week 5: Box Plots, Skewness & Kurtosis\nFive-number summaries, outlier fences, and tail heaviness metrics.`,
    examTips: ['Remember the ordering for right-skewed distributions: Mean > Median > Mode!']
  },
  {
    id: 'note-stats1-w6',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Axiomatic Probability, Conditional Probability & Independence',
    detailedNotes: `### Week 6: Axiomatic Probability & Conditional Structures

#### 1. Kolmogorov\'s Axioms of Probability
For sample space $S$ and events $A, B \\subseteq S$:
1. **Non-negativity:** $P(A) \\ge 0$ for all $A$.
2. **Certainty:** $P(S) = 1$.
3. **Countable Additivity:** If $A_1, A_2, \\dots$ are mutually exclusive ($A_i \\cap A_j = \\emptyset$), then:
   $$P\\left( \\bigcup_{i=1}^\\infty A_i \\right) = \\sum_{i=1}^\\infty P(A_i)$$

#### 2. Addition Rule of Probability
$$P(A \\cup B) = P(A) + P(B) - P(A \\cap B)$$

#### 3. Conditional Probability
$$P(A \\mid B) = \\frac{P(A \\cap B)}{P(B)} \\quad (P(B) > 0)$$
- **Multiplication Rule:** $P(A \\cap B) = P(B) \\cdot P(A \\mid B) = P(A) \\cdot P(B \\mid A)$.

#### 4. Independence of Events
Events $A$ and $B$ are **statistically independent** if and only if:
$$P(A \\cap B) = P(A) \\cdot P(B) \\iff P(A \\mid B) = P(A)$$
- *Caution:* Mutually exclusive events with $P(A), P(B) > 0$ can NEVER be independent (since $P(A \\cap B) = 0 \\ne P(A)P(B)$).`,
    quickRevisionNotes: [
      'Axioms: $0 \\le P(A) \\le 1$, $P(S) = 1$, $P(A \\cup B) = P(A) + P(B)$ for disjoint events.',
      'General addition rule: $P(A \\cup B) = P(A) + P(B) - P(A \\cap B)$.',
      'Conditional probability: $P(A \\mid B) = \\frac{P(A \\cap B)}{P(B)}$.',
      'Independence condition: $P(A \\cap B) = P(A) P(B)$.',
      'Mutually exclusive events ($A \\cap B = \\emptyset$) are dependent if probabilities are non-zero.'
    ],
    formulaSheets: [
      {
        name: 'Conditional Probability',
        formula: 'P(A \\mid B) = \\frac{P(A \\cap B)}{P(B)} \\quad \\text{for } P(B) > 0',
        description: 'Probability of event A given that event B has occurred.'
      },
      {
        name: 'Statistical Independence',
        formula: 'P(A \\cap B) = P(A) \\cdot P(B)',
        description: 'Multiplicative factorization condition for independent events.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w6-p1',
        questionText: 'If $P(A) = 0.6, P(B) = 0.5$, and $P(A \\cup B) = 0.8$, what is $P(A \\mid B)$?',
        options: ['0.6', '0.3', '0.5', '0.75'],
        correctOptionIndex: 0,
        solution: '$P(A \\cap B) = P(A) + P(B) - P(A \\cup B) = 0.6 + 0.5 - 0.8 = 0.3$. $P(A \\mid B) = \\frac{P(A \\cap B)}{P(B)} = \\frac{0.3}{0.5} = 0.6$. (Note that $P(A|B) = P(A) = 0.6$, so $A$ and $B$ are independent).',
        hints: ['Find $P(A \\cap B)$ using addition rule first, then divide by $P(B)$.']
      },
      {
        id: 'stats1-w6-p2',
        questionText: 'If two events $A$ and $B$ are mutually exclusive with $P(A) = 0.4$ and $P(B) = 0.3$, what is $P(A \\cap B)$ and are they independent?',
        options: ['P(A \\cap B) = 0, Dependent', 'P(A \\cap B) = 0.12, Independent', 'P(A \\cap B) = 0, Independent', 'P(A \\cap B) = 0.7, Dependent'],
        correctOptionIndex: 0,
        solution: 'Mutually exclusive means $A \\cap B = \\emptyset \\implies P(A \\cap B) = 0$. For independence, we would need $P(A \\cap B) = P(A)P(B) = 0.4 \\times 0.3 = 0.12 \\ne 0$. Hence they are dependent.',
        hints: ['Mutually exclusive means intersection is empty.']
      },
      {
        id: 'stats1-w6-p3',
        questionText: 'Two fair dice are rolled. What is the probability that the sum is 7 given that the first die shows an odd number?',
        options: ['1/6', '1/12', '1/3', '1/4'],
        correctOptionIndex: 0,
        solution: 'First die odd: $\\{1, 3, 5\\}$ (18 outcomes out of 36). Favorable pairs summing to 7 with first die odd: $(1, 6), (3, 4), (5, 2)$ (3 outcomes). $P = 3/18 = 1/6$.',
        hints: ['Count pairs with odd first number that sum to 7.']
      }
    ],
    keyTakeaways: [
      'Conditional probability forms the foundation for Bayesian statistics and Markov models.',
      'Independence simplifies joint distribution factorization into marginal products.'
    ],
    markdownContent: `### Week 6: Axiomatic & Conditional Probability\nKolmogorov axioms, multiplication rules, and statistical independence.`,
    examTips: ['Do not confuse mutually exclusive ($P(A \\cap B) = 0$) with independent ($P(A \\cap B) = P(A)P(B)$)!']
  },
  {
    id: 'note-stats1-w7',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Law of Total Probability & Bayes\' Theorem',
    detailedNotes: `### Week 7: Total Probability Law & Bayesian Inversion

#### 1. Partition of Sample Space
A collection of events $\\{B_1, B_2, \\dots, B_k\\}$ forms a **partition** of $S$ if:
1. $B_i \\cap B_j = \\emptyset$ for $i \\ne j$ (Pairwise mutually exclusive).
2. $\\bigcup_{i=1}^k B_i = S$ (Collectively exhaustive).
3. $P(B_i) > 0$ for all $i$.

#### 2. Law of Total Probability (LTP)
For any event $A \\subseteq S$:
$$P(A) = \\sum_{i=1}^k P(A \\cap B_i) = \\sum_{i=1}^k P(B_i) \\cdot P(A \\mid B_i)$$

#### 3. Bayes\' Theorem (Posterior Inversion)
Given prior probabilities $P(B_i)$ and likelihoods $P(A \\mid B_i)$:
$$P(B_j \\mid A) = \\frac{P(B_j) \\cdot P(A \\mid B_j)}{P(A)} = \\frac{P(B_j) \\cdot P(A \\mid B_j)}{\\sum_{i=1}^k P(B_i) \\cdot P(A \\mid B_i)}$$
- **Terminology:**
  - $P(B_j)$: **Prior Probability**
  - $P(A \\mid B_j)$: **Likelihood**
  - $P(A)$: **Evidence / Marginal Likelihood**
  - $P(B_j \\mid A)$: **Posterior Probability**`,
    quickRevisionNotes: [
      'Law of Total Probability sums over all partition paths: $P(A) = \\sum P(B_i) P(A \\mid B_i)$.',
      'Bayes\' Theorem updates prior beliefs to posterior probabilities: $\\text{Posterior} \\propto \\text{Prior} \\times \\text{Likelihood}$.',
      'Base rate fallacy occurs when rare event priors $P(B)$ are ignored despite high test sensitivity.',
      'Denominator in Bayes formula is the total marginal probability $P(A)$.'
    ],
    formulaSheets: [
      {
        name: 'Bayes\' Theorem',
        formula: 'P(B_j \\mid A) = \\frac{P(B_j) P(A \\mid B_j)}{\\sum_{i=1}^k P(B_i) P(A \\mid B_i)}',
        description: 'Inverse probability update rule from prior to posterior.'
      },
      {
        name: 'Law of Total Probability',
        formula: 'P(A) = \\sum_{i=1}^k P(B_i) P(A \\mid B_i)',
        description: 'Marginal probability reconstruction over a partition.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w7-p1',
        questionText: 'A medical test is 99% sensitive and 95% specific. Disease prevalence is 1% ($P(D) = 0.01$). What is the probability a person has the disease given a positive test result $P(D \\mid +)$?',
        options: ['\\approx 16.6%', '\\approx 99%', '\\approx 95%', '\\approx 50%'],
        correctOptionIndex: 0,
        solution: '$P(D) = 0.01, P(D^c) = 0.99$. $P(+ \\mid D) = 0.99, P(+ \\mid D^c) = 1 - 0.95 = 0.05$. Total $P(+) = (0.01)(0.99) + (0.99)(0.05) = 0.0099 + 0.0495 = 0.0594$. $P(D \\mid +) = \\frac{0.0099}{0.0594} = \\frac{1}{6} \\approx 16.67\\%$.',
        hints: ['Apply Bayes\' formula with prevalence $P(D) = 0.01$.']
      },
      {
        id: 'stats1-w7-p2',
        questionText: 'Factory machines A and B produce 60% and 40% of bolts. Defect rates are 2% for A and 5% for B. A randomly chosen bolt is defective. What is the probability it came from machine A?',
        options: ['0.375 (3/8)', '0.625 (5/8)', '0.50', '0.24'],
        correctOptionIndex: 0,
        solution: '$P(A) = 0.6, P(B) = 0.4$. $P(D|A) = 0.02, P(D|B) = 0.05$. Total $P(D) = (0.6)(0.02) + (0.4)(0.05) = 0.012 + 0.020 = 0.032$. $P(A|D) = \\frac{0.012}{0.032} = \\frac{12}{32} = \\frac{3}{8} = 0.375$.',
        hints: ['Compute $P(D)$ using total probability, then $P(A \\cap D)/P(D)$.']
      },
      {
        id: 'stats1-w7-p3',
        questionText: 'What constitutes a valid partition of sample space $S$?',
        options: ['Pairwise disjoint sets whose union equals S', 'Any collection of independent events', 'Any collection of overlapping events', 'A set containing the empty set'],
        correctOptionIndex: 0,
        solution: 'A partition requires events to be mutually exclusive ($B_i \\cap B_j = \\emptyset$) and collectively exhaustive ($\\cup B_i = S$).',
        hints: ['Mutually exclusive and collectively exhaustive.']
      }
    ],
    keyTakeaways: [
      'Bayesian thinking powers Naive Bayes classification and spam filtering.',
      'Prevalence (base rate) heavily dominates posterior probabilities of rare phenomena.'
    ],
    markdownContent: `### Week 7: Total Probability & Bayes\' Rule\nPartitions, likelihood updates, and medical diagnostic testing calculations.`,
    examTips: ['Always draw a probability tree diagram to visualize the prior branches and conditional likelihoods!']
  },
  {
    id: 'note-stats1-w8',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Discrete Random Variables, Probability Mass Functions & CDFs',
    detailedNotes: `### Week 8: Discrete Random Variables & Cumulative Distribution Functions

#### 1. Discrete Random Variable ($X$)
A real-valued function $X: S \\to \\mathbb{R}$ mapping sample space outcomes to a discrete set of numbers $\\{x_1, x_2, \\dots\\}$.

#### 2. Probability Mass Function (PMF)
$$p_X(x) = P(X = x)$$
- **Properties:**
  1. $p_X(x) \\ge 0$ for all $x$.
  2. $\\sum_{x} p_X(x) = 1$.

#### 3. Cumulative Distribution Function (CDF)
$$F_X(x) = P(X \\le x) = \\sum_{t \\le x} p_X(t)$$
- **Properties of any CDF:**
  1. Non-decreasing: $x_1 < x_2 \\implies F_X(x_1) \\le F_X(x_2)$.
  2. Limits: $\\lim_{x \\to -\\infty} F_X(x) = 0$ and $\\lim_{x \\to \\infty} F_X(x) = 1$.
  3. Right-continuous: $\\lim_{h \\to 0^+} F_X(x + h) = F_X(x)$.
  4. Step height at jump $x_0$ equals $P(X = x_0) = F_X(x_0) - F_X(x_0^-)$.
  5. Interval probability: $P(a < X \\le b) = F_X(b) - F_X(a)$.`,
    quickRevisionNotes: [
      'PMF valid conditions: $p(x) \\ge 0$ and $\\sum p(x) = 1$.',
      'CDF $F(x) = P(X \\le x)$ is non-decreasing, right-continuous, goes from 0 to 1.',
      'For discrete variables, $P(X = k) = F(k) - F(k^-)$ (height of the CDF jump step).',
      'Interval probability: $P(a < X \\le b) = F(b) - F(a)$.'
    ],
    formulaSheets: [
      {
        name: 'Discrete CDF Definition',
        formula: 'F_X(x) = P(X \\le x) = \\sum_{t \\le x} p_X(t)',
        description: 'Cumulative sum probability distribution function.'
      },
      {
        name: 'Discrete Interval Probability',
        formula: 'P(a < X \\le b) = F_X(b) - F_X(a)',
        description: 'Probability calculation using CDF boundaries.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w8-p1',
        questionText: 'Let PMF of $X$ be $p(x) = c \\cdot x$ for $x \\in \\{1, 2, 3, 4\\}$. Find $c$.',
        options: ['1/10', '1/4', '1/16', '1/6'],
        correctOptionIndex: 0,
        solution: '$\\sum_{x=1}^4 p(x) = 1 \\implies c(1 + 2 + 3 + 4) = 1 \\implies 10c = 1 \\implies c = 1/10$.',
        hints: ['Sum of all PMF values must equal 1.']
      },
      {
        id: 'stats1-w8-p2',
        questionText: 'If $F(x) = \\begin{cases} 0 & x < 1 \\\\ 0.3 & 1 \\le x < 3 \\\\ 0.8 & 3 \\le x < 5 \\\\ 1.0 & x \\ge 5 \\end{cases}$, find $P(X = 3)$.',
        options: ['0.5', '0.8', '0.3', '0.2'],
        correctOptionIndex: 0,
        solution: '$P(X = 3) = F(3) - F(3^-) = 0.8 - 0.3 = 0.5$.',
        hints: ['Compute the jump size at $x = 3$.']
      },
      {
        id: 'stats1-w8-p3',
        questionText: 'Which of the following is NOT a necessary mathematical property of a valid CDF $F(x)$?',
        options: ['It must be strictly differentiable everywhere', 'It must be non-decreasing', '$\\lim_{x \\to \\infty} F(x) = 1$', 'It must be right-continuous'],
        correctOptionIndex: 0,
        solution: 'A discrete CDF has step discontinuities (jumps) and is not differentiable at those jump points. Hence differentiability is not required.',
        hints: ['Discrete CDFs are step functions.']
      }
    ],
    keyTakeaways: [
      'PMFs represent point probability mass; CDFs represent accumulated probability.',
      'CDFs provide a unified mathematical framework for discrete, continuous, and mixed variables.'
    ],
    markdownContent: `### Week 8: Discrete Variables & CDFs\nProbability mass functions, step functions, and cumulative properties.`,
    examTips: ['Be careful with inequality signs for discrete variables: $P(X < 3) \\ne P(X \\le 3)$!']
  },
  {
    id: 'note-stats1-w9',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Mathematical Expectation, Variance, Moments & MGFs',
    detailedNotes: `### Week 9: Expectation Operator, Variance & Moment Generating Functions

#### 1. Mathematical Expectation (Expected Value)
$$E[X] = \\mu = \\sum_{x} x \\cdot p_X(x)$$
- **LOTUS (Law of the Unconscious Statistician):** $E[g(X)] = \\sum g(x) p_X(x)$.
- **Linearity of Expectation (Always holds, even for dependent variables):**
  $$E[aX + bY + c] = a E[X] + b E[Y] + c$$

#### 2. Variance & Covariance
$$\\text{Var}(X) = \\sigma^2 = E[(X - \\mu)^2] = E[X^2] - (E[X])^2$$
- **Properties:**
  - $\\text{Var}(aX + b) = a^2 \\text{Var}(X)$
  - If $X$ and $Y$ are independent: $\\text{Var}(X + Y) = \\text{Var}(X) + \\text{Var}(Y)$.
  - In general: $\\text{Var}(X + Y) = \\text{Var}(X) + \\text{Var}(Y) + 2\\text{Cov}(X, Y)$.

#### 3. Moment Generating Function (MGF)
$$M_X(t) = E[e^{tX}] = \\sum_x e^{tx} p_X(x)$$
- **Moment Extraction:** $E[X^k] = M_X^{(k)}(0) = \\left. \\frac{d^k M_X(t)}{dt^k} \\right|_{t=0}$.
- **Uniqueness Theorem:** If two random variables have identical MGFs in an open neighborhood around $t=0$, they have identical probability distributions.
- **Sum of Independent Variables:** $M_{X+Y}(t) = M_X(t) \\cdot M_Y(t)$.`,
    quickRevisionNotes: [
      'Linearity of expectation holds unconditionally: $E[aX + bY] = aE[X] + bE[Y]$.',
      'Variance formula: $\\text{Var}(X) = E[X^2] - (E[X])^2$; $\\text{Var}(aX+b) = a^2\\text{Var}(X)$.',
      'MGF generates moments: $E[X^k] = M_X^{(k)}(0)$.',
      'For independent variables: $M_{X+Y}(t) = M_X(t) M_Y(t)$.'
    ],
    formulaSheets: [
      {
        name: 'Variance Computation Formula',
        formula: '\\text{Var}(X) = E[X^2] - (E[X])^2',
        description: 'Standard shortcut formula for variance from raw moments.'
      },
      {
        name: 'MGF Moment Derivative',
        formula: 'E[X^k] = \\left. \\frac{d^k M_X(t)}{dt^k} \\right|_{t=0}',
        description: 'Generating raw k-th moments via t-derivatives at t=0.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w9-p1',
        questionText: 'If $E[X] = 3$ and $E[X^2] = 13$, what is $\\text{Var}(2X - 5)$?',
        options: ['16', '4', '8', '11'],
        correctOptionIndex: 0,
        solution: '$\\text{Var}(X) = E[X^2] - (E[X])^2 = 13 - 3^2 = 13 - 9 = 4$. $\\text{Var}(2X - 5) = 2^2 \\text{Var}(X) = 4 \\times 4 = 16$.',
        hints: ['Calculate $\\text{Var}(X)$ first, then multiply by $2^2$.']
      },
      {
        id: 'stats1-w9-p2',
        questionText: 'If $X$ and $Y$ are independent random variables with $\\text{Var}(X) = 4$ and $\\text{Var}(Y) = 9$, what is $\\text{Var}(3X - 2Y)$?',
        options: ['72', '0', '36', '45'],
        correctOptionIndex: 0,
        solution: 'Since $X, Y$ are independent, covariance is 0: $\\text{Var}(3X - 2Y) = 3^2 \\text{Var}(X) + (-2)^2 \\text{Var}(Y) = 9(4) + 4(9) = 36 + 36 = 72$.',
        hints: ['$\\text{Var}(aX - bY) = a^2\\text{Var}(X) + b^2\\text{Var}(Y)$ for independent variables.']
      },
      {
        id: 'stats1-w9-p3',
        questionText: 'If the MGF of $X$ is $M_X(t) = \\frac{1}{1 - 2t}$, find $E[X]$.',
        options: ['2', '1', '4', '1/2'],
        correctOptionIndex: 0,
        solution: '$M\'_X(t) = \\frac{d}{dt}(1 - 2t)^{-1} = -1(1 - 2t)^{-2}(-2) = \\frac{2}{(1 - 2t)^2}$. $E[X] = M\'_X(0) = \\frac{2}{(1 - 0)^2} = 2$.',
        hints: ['Differentiate $M(t)$ with respect to $t$ and evaluate at $t=0$.']
      }
    ],
    keyTakeaways: [
      'Expectation operator is linear across all joint probability dependencies.',
      'MGFs uniquely characterize probability laws and convert convolution into product multiplication.'
    ],
    markdownContent: `### Week 9: Expectation & Moment Generating Functions\nLOTUS theorem, variance scaling, and MGF moment expansions.`,
    examTips: ['Remember that $\\text{Var}(X - Y) = \\text{Var}(X) + \\text{Var}(Y)$ when $X$ and $Y$ are independent (NOT minus)!']
  },
  {
    id: 'note-stats1-w10',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Bernoulli, Binomial, Geometric & Hypergeometric Distributions',
    detailedNotes: `### Week 10: Standard Discrete Parametric Distributions

#### 1. Bernoulli Distribution: $X \\sim \\text{Bernoulli}(p)$
- PMF: $P(X = x) = p^x (1-p)^{1-x}, \\quad x \\in \\{0, 1\\}$.
- $E[X] = p, \\quad \\text{Var}(X) = p(1-p)$.

#### 2. Binomial Distribution: $X \\sim \\text{Bin}(n, p)$
Number of successes in $n$ independent Bernoulli trials:
- **PMF:** $P(X = k) = \\binom{n}{k} p^k (1-p)^{n-k}, \\quad k \\in \\{0, 1, \\dots, n\\}$.
- **Moments:** $E[X] = n p, \\quad \\text{Var}(X) = n p (1 - p)$.
- **MGF:** $M_X(t) = (1 - p + p e^t)^n$.

#### 3. Geometric Distribution: $X \\sim \\text{Geom}(p)$
Number of Bernoulli trials until the *first* success:
- **PMF:** $P(X = k) = (1 - p)^{k - 1} p, \\quad k \\in \\{1, 2, 3, \\dots\\}$.
- **Moments:** $E[X] = \\frac{1}{p}, \\quad \\text{Var}(X) = \\frac{1 - p}{p^2}$.
- **Memoryless Property:** $P(X > s + t \\mid X > s) = P(X > t)$.

#### 4. Hypergeometric Distribution: $X \\sim \\text{HyperGeom}(N, K, n)$
Sampling $n$ items **without replacement** from population $N$ with $K$ successes:
- **PMF:** $P(X = k) = \\frac{\\binom{K}{k} \\binom{N - K}{n - k}}{\\binom{N}{n}}$.
- $E[X] = n \\frac{K}{N}$.`,
    quickRevisionNotes: [
      'Binomial: $E[X] = np$, $\\text{Var}(X) = np(1-p)$.',
      'Geometric is the ONLY discrete distribution with the memoryless property.',
      'Geometric: $E[X] = 1/p$ (trials until 1st success).',
      'Hypergeometric models sampling WITHOUT replacement (finite population correction).'
    ],
    formulaSheets: [
      {
        name: 'Binomial PMF',
        formula: 'P(X = k) = \\binom{n}{k} p^k (1-p)^{n-k}',
        description: 'Probability of exactly k successes in n independent Bernoulli trials.'
      },
      {
        name: 'Geometric Memoryless Property',
        formula: 'P(X > s + t \\mid X > s) = P(X > t)',
        description: 'Memoryless probability law unique to geometric discrete distribution.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w10-p1',
        questionText: 'A fair coin is tossed 6 times. What is the probability of getting exactly 4 heads?',
        options: ['15/64', '20/64', '6/64', '1/4'],
        correctOptionIndex: 0,
        solution: '$n = 6, p = 1/2, k = 4$. $P(X = 4) = \\binom{6}{4} (1/2)^4 (1/2)^2 = 15 \\times (1/2)^6 = 15 / 64$.',
        hints: ['Use Binomial formula $\\binom{n}{k} p^k (1-p)^{n-k}$.']
      },
      {
        id: 'stats1-w10-p2',
        questionText: 'If $X \\sim \\text{Geom}(p = 0.2)$, what is the expected number of trials to achieve the first success?',
        options: ['5', '0.2', '25', '4'],
        correctOptionIndex: 0,
        solution: '$E[X] = 1/p = 1 / 0.2 = 5$.',
        hints: ['Expected value of geometric distribution is $1/p$.']
      },
      {
        id: 'stats1-w10-p3',
        questionText: 'A deck of 52 cards has 4 Aces. If 5 cards are drawn WITHOUT replacement, which distribution describes the number of Aces drawn?',
        options: ['Hypergeometric(N=52, K=4, n=5)', 'Binomial(n=5, p=4/52)', 'Poisson(\\lambda=4)', 'Geometric(p=4/52)'],
        correctOptionIndex: 0,
        solution: 'Drawing without replacement from a finite population changes trial probabilities, which is modeled by the Hypergeometric distribution.',
        hints: ['Sampling without replacement $\\implies$ Hypergeometric.']
      }
    ],
    keyTakeaways: [
      'Binomial models A/B testing conversion counts.',
      'Geometric distribution models time-to-first-failure in reliability engineering.'
    ],
    markdownContent: `### Week 10: Discrete Distributions\nBinomial, Geometric memorylessness, and Hypergeometric sampling.`,
    examTips: ['Check if sampling is WITH replacement (Binomial) or WITHOUT replacement (Hypergeometric)!']
  },
  {
    id: 'note-stats1-w11',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Poisson Distribution, Poisson Process & Limiting Approximations',
    detailedNotes: `### Week 11: The Poisson Law & Rare Event Modeling

#### 1. Poisson Distribution: $X \\sim \\text{Poisson}(\\lambda)$
Models the count of independent events occurring in a fixed interval of time or space with average rate $\\lambda > 0$:
- **PMF:**
  $$P(X = k) = \\frac{e^{-\\lambda} \\lambda^k}{k!}, \\quad k \\in \\{0, 1, 2, \\dots\\}$$
- **Moments:**
  $$E[X] = \\lambda, \\quad \\text{Var}(X) = \\lambda$$
  *(Defining hallmark: Mean equals Variance = $\\lambda$).*
- **MGF:** $M_X(t) = \\exp\\left( \\lambda (e^t - 1) \\right)$.

#### 2. Poisson Approximation to Binomial (Law of Rare Events)
When $n$ is large ($n \\ge 20$) and $p$ is small ($p \\le 0.05$) such that $\\lambda = n p$ is moderate:
$$\\binom{n}{k} p^k (1-p)^{n-k} \\approx \\frac{e^{-\\lambda} \\lambda^k}{k!}$$

#### 3. Additivity Property of Poisson Variables
If $X_1 \\sim \\text{Poisson}(\\lambda_1)$ and $X_2 \\sim \\text{Poisson}(\\lambda_2)$ are independent:
$$X_1 + X_2 \\sim \\text{Poisson}(\\lambda_1 + \\lambda_2)$$`,
    quickRevisionNotes: [
      'Poisson PMF: $P(X = k) = \\frac{e^{-\\lambda}\\lambda^k}{k!}$.',
      'Equidispersion property: $E[X] = \\text{Var}(X) = \\lambda$.',
      'Sum of independent Poisson variables is Poisson: $\\lambda_{\\text{sum}} = \\sum \\lambda_i$.',
      'Binomial converges to Poisson when $n \\to \\infty, p \\to 0$ with $\\lambda = np$.'
    ],
    formulaSheets: [
      {
        name: 'Poisson PMF',
        formula: 'P(X = k) = \\frac{e^{-\\lambda} \\lambda^k}{k!} \\quad (k = 0, 1, 2, \\dots)',
        description: 'Probability mass for discrete count events with rate lambda.'
      },
      {
        name: 'Poisson Additivity',
        formula: 'X_1 + X_2 \\sim \\text{Poisson}(\\lambda_1 + \\lambda_2)',
        description: 'Closure under addition of independent Poisson variables.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w11-p1',
        questionText: 'A website receives on average 2 requests per minute ($X \\sim \\text{Poisson}(2)$). What is the probability of receiving 0 requests in a given minute?',
        options: ['e^{-2} \\approx 0.1353', '2e^{-2}', '1 - e^{-2}', '0'],
        correctOptionIndex: 0,
        solution: '$P(X = 0) = \\frac{e^{-2} 2^0}{0!} = \\frac{e^{-2} \\times 1}{1} = e^{-2} \\approx 0.1353$.',
        hints: ['Set $k = 0$ in the Poisson PMF formula.']
      },
      {
        id: 'stats1-w11-p2',
        questionText: 'If a random variable $X$ has $E[X] = 5$ and $\\text{Var}(X) = 5$, what is the most likely distribution of $X$?',
        options: ['Poisson(\\lambda = 5)', 'Binomial(n=10, p=0.5)', 'Geometric(p=0.2)', 'Uniform(0, 10)'],
        correctOptionIndex: 0,
        solution: 'The equality of mean and variance ($E[X] = \\text{Var}(X) = 5$) is the signature characteristic of a Poisson distribution with $\\lambda = 5$.',
        hints: ['Recall which distribution has Mean = Variance.']
      },
      {
        id: 'stats1-w11-p3',
        questionText: 'Calls arrive at support center A at rate 3/hr and at center B at rate 4/hr independently. What is the probability that both centers receive a total of 0 calls in an hour?',
        options: ['e^{-7}', 'e^{-3} + e^{-4}', 'e^{-12}', '1 - e^{-7}'],
        correctOptionIndex: 0,
        solution: 'Total calls $T = A + B \\sim \\text{Poisson}(3 + 4 = 7)$. $P(T = 0) = \\frac{e^{-7} 7^0}{0!} = e^{-7}$.',
        hints: ['Use the additivity property $\\lambda_{\\text{total}} = 3 + 4 = 7$.']
      }
    ],
    keyTakeaways: [
      'Poisson processes model server request arrivals, call centers, and defect densities.',
      'Mean-variance equality enables rapid diagnostic identification of Poisson processes.'
    ],
    markdownContent: `### Week 11: The Poisson Distribution\nCount processes, rare event limits, and independent rate addition.`,
    examTips: ['Remember: $0! = 1$ and $\\lambda^0 = 1$ in Poisson calculations!']
  },
  {
    id: 'note-stats1-w12',
    courseId: 'course-stats-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Continuous Random Variables, Probability Density Functions & Uniform/Exponential Models',
    detailedNotes: `### Week 12: Continuous Random Variables & Fundamental Continuous Models

#### 1. Probability Density Function (PDF)
A continuous random variable $X$ is characterized by PDF $f_X(x)$ where:
1. $f_X(x) \\ge 0$ for all $x \\in \\mathbb{R}$.
2. Total Area: $\\int_{-\\infty}^\\infty f_X(x) \\, dx = 1$.
3. **Point Probability is Zero:** $P(X = c) = \\int_c^c f_X(x) \\, dx = 0$ for any singleton $c$.
4. **Interval Probability:** $P(a \\le X \\le b) = \\int_a^b f_X(x) \\, dx = F_X(b) - F_X(a)$.

#### 2. Continuous Uniform Distribution: $X \\sim U(a, b)$
- **PDF:** $f(x) = \\frac{1}{b - a}, \\quad a \\le x \\le b$.
- **CDF:** $F(x) = \\frac{x - a}{b - a}$.
- **Moments:** $E[X] = \\frac{a + b}{2}, \\quad \\text{Var}(X) = \\frac{(b - a)^2}{12}$.

#### 3. Exponential Distribution: $X \\sim \\text{Exp}(\\lambda)$
Models continuous waiting time between Poisson arrivals:
- **PDF:** $f(x) = \\lambda e^{-\\lambda x}, \\quad x \\ge 0$.
- **CDF:** $F(x) = 1 - e^{-\\lambda x}$.
- **Survival Function:** $P(X > x) = e^{-\\lambda x}$.
- **Moments:** $E[X] = \\frac{1}{\\lambda}, \\quad \\text{Var}(X) = \\frac{1}{\\lambda^2}$.
- **Continuous Memoryless Property:** $P(X > s + t \\mid X > s) = P(X > t)$.`,
    quickRevisionNotes: [
      'For any continuous variable, the probability of an exact point $P(X = c) = 0$.',
      'Uniform $U(a, b)$: $E[X] = \\frac{a+b}{2}$, $\\text{Var}(X) = \\frac{(b-a)^2}{12}$.',
      'Exponential $\\text{Exp}(\\lambda)$: $E[X] = 1/\\lambda$, $\\text{Var}(X) = 1/\\lambda^2$, CDF $F(x) = 1 - e^{-\\lambda x}$.',
      'Exponential distribution is the continuous counterpart of the discrete Geometric distribution (both possess memorylessness).'
    ],
    formulaSheets: [
      {
        name: 'Continuous PDF Normalization',
        formula: '\\int_{-\\infty}^\\infty f_X(x) \\, dx = 1 \\quad \\text{and} \\quad P(a \\le X \\le b) = \\int_a^b f_X(x) \\, dx',
        description: 'Integral probability rules for continuous random variables.'
      },
      {
        name: 'Exponential Distribution Law',
        formula: 'f(x) = \\lambda e^{-\\lambda x} \\implies F(x) = 1 - e^{-\\lambda x}, \\quad P(X > x) = e^{-\\lambda x}',
        description: 'Density and survival function for exponential lifetime modeling.'
      }
    ],
    practiceQuestions: [
      {
        id: 'stats1-w12-p1',
        questionText: 'Find $k$ such that $f(x) = k x^2$ for $0 \\le x \\le 3$ is a valid continuous PDF.',
        options: ['1/9', '1/27', '3', '1/3'],
        correctOptionIndex: 0,
        solution: '$\\int_0^3 k x^2 dx = 1 \\implies k \\left[ \\frac{x^3}{3} \\right]_0^3 = 1 \\implies k \\left( \\frac{27}{3} \\right) = 1 \\implies 9k = 1 \\implies k = 1/9$.',
        hints: ['Set the definite integral over $[0, 3]$ equal to 1.']
      },
      {
        id: 'stats1-w12-p2',
        questionText: 'If $X \\sim \\text{Exp}(\\lambda = 0.5)$, what is $P(X > 4)$?',
        options: ['e^{-2} \\approx 0.135', '1 - e^{-2}', 'e^{-0.5}', '0.5'],
        correctOptionIndex: 0,
        solution: 'Using the survival function: $P(X > x) = e^{-\\lambda x} = e^{-(0.5)(4)} = e^{-2} \\approx 0.1353$.',
        hints: ['Use the survival formula $P(X > x) = e^{-\\lambda x}$.']
      },
      {
        id: 'stats1-w12-p3',
        questionText: 'What is the variance of a continuous uniform random variable $X \\sim U(2, 8)$?',
        options: ['3', '36', '6', '12'],
        correctOptionIndex: 0,
        solution: '$\\text{Var}(X) = \\frac{(b - a)^2}{12} = \\frac{(8 - 2)^2}{12} = \\frac{6^2}{12} = \\frac{36}{12} = 3$.',
        hints: ['Use $\\text{Var}(X) = \\frac{(b-a)^2}{12}$.']
      }
    ],
    keyTakeaways: [
      'Continuous probabilities are computed via integration over intervals rather than summation.',
      'Exponential distributions are standard for server latency and component lifetime modeling.'
    ],
    markdownContent: `### Week 12: Continuous Random Variables\nProbability density integrals, Uniform distributions, and Exponential decay.`,
    examTips: ['In continuous distributions, strict inequalities and non-strict inequalities have identical probabilities: $P(X \\le a) = P(X < a)$!']
  }
];

import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_MAD1_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-mad1-w1',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 1,
    title: 'Web Architecture, HTTP Protocol (Methods, Headers, Status Codes) & RESTful Principles',
    detailedNotes: `### Week 1: Web Architecture, HTTP Protocols & REST Design

#### 1. Client-Server Architecture & The HTTP Protocol
The Web operates on a stateless Request-Response architecture over TCP/IP (Port 80 for HTTP, Port 443 for HTTPS/TLS):
- **HTTP Request Anatomy:**
  - Request Line: \`METHOD /path/resource HTTP/1.1\`
  - Headers: \`Host\`, \`User-Agent\`, \`Accept\`, \`Authorization\`, \`Content-Type\`
  - Body: JSON, Form-data, or binary payload.
- **HTTP Methods & Idempotency:**
  - \`GET\`: Safe and Idempotent (retrieve resource representation).
  - \`POST\`: Neither Safe nor Idempotent (create new resource / trigger processing).
  - \`PUT\`: Idempotent (replace resource entirely).
  - \`PATCH\`: Not strictly idempotent by RFC, but typically used for partial updates.
  - \`DELETE\`: Idempotent (remove resource).

#### 2. HTTP Status Code Taxonomy
- **1xx (Informational):** \`100 Continue\`, \`101 Switching Protocols\`
- **2xx (Success):** \`200 OK\`, \`201 Created\` (returns resource URI), \`204 No Content\` (successful DELETE)
- **3xx (Redirection):** \`301 Moved Permanently\`, \`302 Found\`, \`304 Not Modified\` (cached)
- **4xx (Client Error):** \`400 Bad Request\`, \`401 Unauthorized\` (missing auth), \`403 Forbidden\` (insufficient permissions), \`404 Not Found\`, \`422 Unprocessable Entity\`
- **5xx (Server Error):** \`500 Internal Server Error\`, \`502 Bad Gateway\`, \`503 Service Unavailable\`

#### 3. REST (Representational State Transfer) Architectural Constraints (Roy Fielding)
1. **Client-Server Separation:** UI concerns separated from data storage.
2. **Statelessness:** Each request from client must contain all context needed to process it.
3. **Cacheability:** Responses must define themselves as cacheable or non-cacheable.
4. **Uniform Interface:** Resource identification in requests (URIs), resource manipulation through representations, self-descriptive messages, and HATEOAS.`,
    quickRevisionNotes: [
      'GET and DELETE are idempotent; POST is non-idempotent.',
      '201 Created indicates successful resource creation; 204 No Content returned for empty body success.',
      '401 Unauthorized means unauthenticated; 403 Forbidden means authenticated but unauthorized.',
      'REST constraints: Statelessness, Client-Server separation, Cacheability, Uniform Interface.'
    ],
    formulaSheets: [
      {
        name: 'Idempotency Definition',
        formula: 'f(f(x)) = f(x) \\implies \\text{Executing request multiple times produces identical state on server}',
        description: 'Mathematical property of HTTP GET, PUT, and DELETE methods.'
      }
    ],
    definitions: [
      {
        term: 'Idempotent HTTP Method',
        explanation: 'An HTTP method where making multiple identical requests has the same intended effect on the server state as a single request.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Raw HTTP Request and Response Parsing in Python',
        code: `import requests

# Standard RESTful API Interaction
response = requests.post(
    "https://api.myapp.com/v1/students",
    headers={"Content-Type": "application/json", "Authorization": "Bearer token123"},
    json={"name": "Anita Roy", "roll_number": "21f10001", "department": "Data Science"}
)

print(f"Status Code: {response.status_code}") # Expect 201 Created
if response.status_code == 201:
    created_student = response.json()
    print("New Resource URI:", response.headers.get("Location"))
    print("Student ID:", created_student["id"])`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w1-q1',
        questionText: 'Which HTTP status code should a RESTful API return when a client makes a request without providing an authentication token?',
        options: ['401 Unauthorized', '403 Forbidden', '404 Not Found', '500 Internal Server Error'],
        correctOptionIndex: 0,
        solution: '401 Unauthorized is used when authentication credentials are missing or invalid. 403 Forbidden is used when the user is authenticated but lacks permission.',
        hints: ['Authentication missing = 401.']
      }
    ],
    examTips: [
      'Use plural nouns for REST endpoints (e.g. `/api/v1/users/12` instead of `/api/v1/getUser?id=12`).',
      'Never put verbs in REST endpoint URLs (use HTTP methods to express actions).'
    ],
    handwrittenMnemonic: '201 Created, 204 No Content; 401 = Who are you? 403 = You cannot enter!'
  },
  {
    id: 'note-mad1-w2',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 2,
    title: 'HTML5 Semantic Structure & Modern CSS (CSS Grid, Flexbox, Responsive Design)',
    detailedNotes: `### Week 2: Semantic HTML5 & Modern Responsive CSS Layouts

#### 1. HTML5 Semantic Elements
Replace generic \`<div>\` soup with semantic tags for accessibility (a11y) and SEO:
- \`<header>\`, \`<nav>\`, \`<main>\`, \`<section>\`, \`<article>\`, \`<aside>\`, \`<footer>\`.
- Forms: \`<input type="email">\`, \`pattern\`, \`required\`, \`<label for="id">\`.

#### 2. CSS Flexbox (1D Layouts - Row or Column)
- **Container Properties:**
  - \`display: flex;\`
  - \`flex-direction: row | column | row-reverse;\`
  - \`justify-content: flex-start | center | space-between | space-around | space-evenly;\` (Main axis)
  - \`align-items: stretch | center | flex-start | flex-end;\` (Cross axis)
  - \`flex-wrap: nowrap | wrap;\`
- **Item Properties:**
  - \`flex: flex-grow flex-shrink flex-basis;\` (e.g. \`flex: 1 1 auto;\`).

#### 3. CSS Grid (2D Layouts - Rows and Columns)
- \`display: grid;\`
- \`grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));\` (Responsive grid with zero media queries!).
- \`gap: 1.5rem;\` (Gutters between rows and columns).
- \`grid-template-areas\`: Visual layout mapping.

#### 4. Responsive CSS Media Queries
- Mobile-first approach:
  \`\`\`css
  /* Mobile Base Styles */
  .container { width: 100%; padding: 1rem; }
  
  /* Tablet Breakpoint */
  @media (min-width: 768px) {
    .container { max-width: 720px; margin: 0 auto; }
  }
  
  /* Desktop Breakpoint */
  @media (min-width: 1024px) {
    .container { max-width: 960px; }
  }
  \`\`\``,
    quickRevisionNotes: [
      'Semantic HTML improves accessibility (a11y) and search engine indexing.',
      'Flexbox handles 1D linear layouts; CSS Grid handles 2D row/column layouts.',
      '`repeat(auto-fit, minmax(250px, 1fr))` creates automatic responsive grid cards.',
      'Mobile-first responsive design uses `@media (min-width: ...)` breakpoints.'
    ],
    formulaSheets: [
      {
        name: 'Auto-Fit Responsive CSS Grid',
        formula: '\\text{grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));}',
        description: 'Fluid card grid layout adapting to arbitrary screen widths without media queries.'
      }
    ],
    definitions: [
      {
        term: 'CSS Box Model',
        explanation: 'The rectangular layout model consisting of Content, Padding, Border, and Margin. Setting box-sizing: border-box includes padding and border within element width.'
      }
    ],
    codeSnippets: [
      {
        language: 'css',
        title: 'Modern CSS Reset & Responsive Card Grid Layout',
        code: `/* Box Model Reset */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* Responsive Dashboard Grid */
.dashboard-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
  padding: 2rem;
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background: #ffffff;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  padding: 1.5rem;
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w2-q1',
        questionText: 'What is the key benefit of setting `box-sizing: border-box` globally in CSS?',
        options: ['The element\'s declared width and height include padding and borders, preventing layout overflow surprises', 'It makes fonts bold automatically', 'It removes all margins from text', 'It converts all divs to flex containers'],
        correctOptionIndex: 0,
        solution: 'Under standard content-box, padding and border are added to width, causing element dimensions to exceed intended sizes. border-box absorbs padding and border within the specified width.',
        hints: ['Padding and border are absorbed inside width.']
      }
    ],
    examTips: [
      'Always set `<meta name="viewport" content="width=device-width, initial-scale=1.0">` in HTML head for mobile responsive scaling.',
      'Use `rem` units for font sizes and spacing to respect user browser accessibility preferences.'
    ],
    handwrittenMnemonic: 'Flexbox for 1D rows/columns; Grid for 2D boards; border-box includes padding!'
  },
  {
    id: 'note-mad1-w3',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 3,
    title: 'JavaScript ES6+, DOM Manipulation, Event Loop, Promises & Async/Await',
    detailedNotes: `### Week 3: JavaScript Engine, Asynchrony & DOM API

#### 1. JavaScript Engine & The Event Loop
JavaScript is a single-threaded runtime with a non-blocking asynchronous event loop:
- **Call Stack:** Executes synchronous functions (LIFO).
- **Web APIs:** Browser background threads handling \`setTimeout\`, \`fetch\`, and DOM events.
- **Microtask Queue:** Highest priority asynchronous queue for **Promise callbacks** (\`.then()\`, \`async/await\`) and \`queueMicrotask\`.
- **Macrotask Queue (Callback Queue):** \`setTimeout\`, \`setInterval\`, UI rendering.
- **Event Loop Rule:** Microtasks are ALWAYS drained completely before the next Macrotask is executed!

#### 2. Modern ES6+ Features
- \`const\` / \`let\` (block-scoped) vs \`var\` (function-scoped, hoisted).
- Arrow Functions: \`const add = (a, b) => a + b;\` (lexical \`this\` binding).
- Destructuring: \`const { name, email } = user;\`
- Spread/Rest Operators: \`const copy = { ...user, active: true };\`
- Array Methods: \`.map()\`, \`.filter()\`, \`.reduce()\`, \`.find()\`, \`.some()\`.

#### 3. Asynchronous JavaScript: Promises & Async/Await
\`\`\`javascript
async function fetchUserData(userId) {
  try {
    const res = await fetch(\`https://api.site.com/users/\${userId}\`);
    if (!res.ok) throw new Error(\`HTTP \${res.status}\`);
    const data = await res.json();
    return data;
  } catch (err) {
    console.error("Network error:", err.message);
  }
}
\`\`\``,
    quickRevisionNotes: [
      'Event loop processes all Microtasks (Promises) before Macrotasks (setTimeout).',
      'Arrow functions capture `this` from surrounding lexical scope.',
      '`async/await` provides clean synchronous-looking syntax over Promises.',
      'Use `const` by default; `let` only for reassigned variables; avoid `var`.'
    ],
    formulaSheets: [
      {
        name: 'Promise State Transitions',
        formula: '\\text{Pending} \\implies \\begin{cases} \\text{Fulfilled (resolved with value)} \\\\ \\text{Rejected (rejected with error)} \\end{cases}',
        description: 'Lifecycle states of ECMAScript Promises.'
      }
    ],
    definitions: [
      {
        term: 'Event Loop',
        explanation: 'The runtime coordination mechanism in JavaScript that continuously checks the call stack and transfers callbacks from task queues to the execution stack.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Concurrent API Requests with Promise.all in Modern JavaScript',
        code: `async function loadDashboardData(studentId) {
  try {
    // Execute multiple independent network requests in parallel
    const [profileRes, gradesRes, noticesRes] = await Promise.all([
      fetch(\`/api/students/\${studentId}\`),
      fetch(\`/api/students/\${studentId}/grades\`),
      fetch('/api/notices/latest')
    ]);

    if (!profileRes.ok || !gradesRes.ok) {
      throw new Error('Failed to load student records');
    }

    const [profile, grades, notices] = await Promise.all([
      profileRes.json(),
      gradesRes.json(),
      noticesRes.json()
    ]);

    return { profile, grades, notices };
  } catch (error) {
    console.error('Dashboard load failure:', error);
    throw error;
  }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w3-q1',
        questionText: 'In what order will the following execute: `console.log("1"); setTimeout(() => console.log("2"), 0); Promise.resolve().then(() => console.log("3")); console.log("4");`?',
        options: ['1, 4, 3, 2', '1, 2, 3, 4', '1, 3, 4, 2', '4, 3, 2, 1'],
        correctOptionIndex: 0,
        solution: 'Synchronous logs (1, 4) execute on Call Stack. Microtask queue (Promise -> 3) executes next before Macrotask queue (setTimeout -> 2). Result is 1, 4, 3, 2.',
        hints: ['Sync -> Microtask (Promise) -> Macrotask (setTimeout).']
      }
    ],
    examTips: [
      '`Promise.all()` fails fast if any promise rejects; use `Promise.allSettled()` if you want all results regardless of individual failures.',
      'Event Delegation: Attach single event listener to a parent element and use `event.target` to handle dynamically added child clicks.'
    ],
    handwrittenMnemonic: 'Sync runs first -> Microtasks (Promises) -> Macrotasks (Timers)!'
  },
  {
    id: 'note-mad1-w4',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 4,
    title: 'Python Flask Backend: Routing, Jinja2 Templates & Request/Response Lifecycle',
    detailedNotes: `### Week 4: Python Flask Web Framework & Server-Side Rendering

#### 1. Flask Micro-Framework Architecture
Flask is a WSGI (Web Server Gateway Interface) compliant micro-framework built on Werkzeug (routing/HTTP) and Jinja2 (templating):
\`\`\`python
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = "super_secret_session_key"

@app.route("/students/<int:student_id>", methods=["GET"])
def get_student(student_id):
    # Route variable converter <int:id>
    return render_template("student_detail.html", student_id=student_id)
\`\`\`

#### 2. Request & Context Objects
- **Application Context:** \`current_app\`, \`g\` (global request-scoped storage).
- **Request Context:**
  - \`request.args\`: Query string parameters (\`?search=python\`).
  - \`request.form\`: Submitted HTML form data (\`POST\`).
  - \`request.json\`: Parsed JSON body.
  - \`request.headers\` & \`request.cookies\`.

#### 3. Jinja2 Templating Engine
- Template Inheritance (\`{% extends "base.html" %}\` and \`{% block content %} ... {% endblock %}\`).
- Control Flow: \`{% for item in list %}\`, \`{% if condition %}\`.
- Variable Expression: \`{{ student.name | upper }}\` (Jinja2 filters).
- URL Generation: \`{{ url_for('static', filename='css/style.css') }}\`.`,
    quickRevisionNotes: [
      'Flask routes use decorators `@app.route("/path", methods=["GET", "POST"])`.',
      '`request.form` parses form inputs; `request.json` parses JSON payloads; `request.args` parses query strings.',
      'Jinja2 uses `{{ ... }}` for variables and `{% ... %}` for control blocks (extends, for, if).'
    ],
    formulaSheets: [
      {
        name: 'Jinja2 Syntax Quick Reference',
        formula: '{{ \\text{variable | filter} }} \\quad | \\quad \\{% \\text{for item in list} \\%\\} \\dots \\{% \\text{endfor} \\%\\} \\quad | \\quad \\{% \\text{extends \"base.html\"} \\%\\}',
        description: 'Template syntax for server-side HTML rendering in Flask.'
      }
    ],
    definitions: [
      {
        term: 'WSGI (Web Server Gateway Interface)',
        explanation: 'The standard calling convention for web servers (Gunicorn, uWSGI) to forward requests to Python web applications.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Complete Flask Form Handling Application with Flash Messages',
        code: `from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key-123'

# In-memory storage for demonstration
students_db = []

@app.route('/students/create', methods=['GET', 'POST'])
def create_student():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        
        if not name or not email:
            flash('Name and Email are mandatory fields!', 'error')
            return redirect(url_for('create_student'))
            
        student_id = len(students_db) + 1
        students_db.append({'id': student_id, 'name': name, 'email': email})
        flash(f'Student {name} created successfully!', 'success')
        return redirect(url_for('list_students'))
        
    return render_template('create_student.html')

@app.route('/students', methods=['GET'])
def list_students():
    return render_template('students.html', students=students_db)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w4-q1',
        questionText: 'In Flask, how should you dynamically generate the URL for a view function named `view_profile` that takes an argument `user_id`?',
        options: ['url_for("view_profile", user_id=42)', 'href="/view_profile/42"', 'get_url(view_profile, 42)', 'route.url("view_profile")'],
        correctOptionIndex: 0,
        solution: 'Flask\'s url_for function generates URLs based on the function name and keyword arguments, ensuring that URL changes in decorators do not break templates.',
        hints: ['Use url_for with function name as string.']
      }
    ],
    examTips: [
      'Never hardcode URLs in templates; always use `url_for("function_name")` to allow URL path refactoring.',
      '`render_template` automatically looks for HTML files in the `templates/` folder and assets in `static/`.'
    ],
    handwrittenMnemonic: 'request.form for POST; request.args for GET; url_for for links!'
  },
  {
    id: 'note-mad1-w5',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 5,
    title: 'Flask-SQLAlchemy ORM: Models, Relationships (1:N, M:N) & Migrations',
    detailedNotes: `### Week 5: Relational Database Modeling with Flask-SQLAlchemy

#### 1. Object-Relational Mapping (ORM) Setup
Flask-SQLAlchemy maps Python classes to database tables:
\`\`\`python
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
# Configure SQLite / PostgreSQL URI
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///university.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)
\`\`\`

#### 2. Defining Models & Relationships
- **One-to-Many ($1:N$) Relationship (e.g. Department $\\to$ Students):**
  \`\`\`python
  class Department(db.Model):
      __tablename__ = 'departments'
      id = db.Column(db.Integer, primary_key=True)
      name = db.Column(db.String(100), nullable=False, unique=True)
      # Relationship backref adds 'department' property to Student
      students = db.relationship('Student', backref='department', lazy=True)

  class Student(db.Model):
      __tablename__ = 'students'
      id = db.Column(db.Integer, primary_key=True)
      name = db.Column(db.String(100), nullable=False)
      department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=False)
  \`\`\`
- **Many-to-Many ($M:N$) Relationship (e.g. Students $\\leftrightarrow$ Courses):**
  Requires an **Association Table** containing composite foreign keys:
  \`\`\`python
  enrollments = db.Table('enrollments',
      db.Column('student_id', db.Integer, db.ForeignKey('students.id'), primary_key=True),
      db.Column('course_id', db.Integer, db.ForeignKey('courses.id'), primary_key=True)
  )
  \`\`\`

#### 3. SQLAlchemy CRUD & Query API
- **Create:** \`db.session.add(obj)\` $\\to$ \`db.session.commit()\`
- **Read:** \`Student.query.filter_by(department_id=1).all()\`, \`Student.query.get_or_404(id)\`
- **Update:** Modify attributes on loaded instance $\\to$ \`db.session.commit()\`
- **Delete:** \`db.session.delete(obj)\` $\\to$ \`db.session.commit()\``,
    quickRevisionNotes: [
      'ORM maps Python classes to SQL tables and class instances to database rows.',
      '1:N relationships use `db.ForeignKey("parent.id")` in child and `db.relationship` in parent.',
      'M:N relationships require an auxiliary Association Table with composite primary keys.',
      'Always invoke `db.session.commit()` to persist changes or `db.session.rollback()` on error.'
    ],
    formulaSheets: [
      {
        name: 'SQLAlchemy Session Lifecycle',
        formula: '\\text{db.session.add(entity)} \\implies \\text{Pending} \\xrightarrow{\\text{commit()}} \\text{Persisted in Database}',
        description: 'Session unit-of-work transaction pipeline in SQLAlchemy.'
      }
    ],
    definitions: [
      {
        term: 'Lazy Loading (lazy=True)',
        explanation: 'A query execution strategy where related child objects are not loaded from database until the attribute is explicitly accessed in Python code.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Full Database CRUD and Many-to-Many Query Execution',
        code: `def enroll_student_in_course(student_id, course_code):
    student = Student.query.get_or_404(student_id)
    course = Course.query.filter_by(code=course_code).first_or_404()
    
    if course not in student.courses:
        student.courses.append(course)
        try:
            db.session.commit()
            return True, "Enrolled successfully"
        except Exception as e:
            db.session.rollback()
            return False, str(e)
    return False, "Already enrolled"`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w5-q1',
        questionText: 'What occurs if an unhandled database exception is raised during a transaction and `db.session.rollback()` is NOT invoked?',
        options: ['The session remains in a broken/dirty state, causing subsequent queries on the connection to fail', 'The database deletes all tables', 'The application compiles to C++', 'The transaction commits automatically'],
        correctOptionIndex: 0,
        solution: 'When a database error occurs, the active transaction is aborted. Calling rollback() resets the session to a clean state so new queries can execute.',
        hints: ['Dirty sessions must be rolled back.']
      }
    ],
    examTips: [
      'Always catch database exceptions inside a `try...except` block and invoke `db.session.rollback()`.',
      'Use `db.relationship(..., cascade="all, delete-orphan")` to automatically delete child records when the parent is removed.'
    ],
    handwrittenMnemonic: 'ForeignKey on child; relationship on parent; commit to save, rollback on error!'
  },
  {
    id: 'note-mad1-w6',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 6,
    title: 'User Authentication, Password Hashing (bcrypt) & JSON Web Tokens (JWT)',
    detailedNotes: `### Week 6: Authentication, Cryptographic Hashing & JWT

#### 1. Password Security & Cryptographic Hashing
- **Plaintext / MD5 / SHA-256:** Vulnerable to Rainbow Tables and GPU brute-force attacks.
- **Adaptive Key Derivation (bcrypt / Argon2):**
  - Uses a **Cryptographic Salt** (random unique bytes per user to defeat precomputed tables).
  - Uses an adjustable **Work Factor (Cost)** to deliberately slow down computation, thwarting GPU cluster attacks.
  \`\`\`python
  from werkzeug.security import generate_password_hash, check_password_hash
  hashed_pw = generate_password_hash("StudentSecret123", method="pbkdf2:sha256")
  is_valid = check_password_hash(hashed_pw, "StudentSecret123") # True
  \`\`\`

#### 2. Session-Based Auth vs. Token-Based Auth (JWT)
- **Session-Based:** Server stores session state in memory/Redis; client holds \`session_id\` in Cookie. (Stateful; hard to scale across server farms).
- **JSON Web Token (JWT - Stateless Auth):**
  - Self-contained cryptographically signed token held by client:
  $$\\text{JWT} = \\underbrace{\\text{Base64(Header)}}_{\\text{alg, typ}} . \\underbrace{\\text{Base64(Payload)}}_{\\text{user\\_id, role, exp}} . \\underbrace{\\text{Signature}}_{\\text{HMAC-SHA256(Header.Payload, Secret)}}$$
  - **Verification:** Server checks signature using secret key; no database lookup required for identity verification!`,
    quickRevisionNotes: [
      'Passwords must never be stored in plaintext; use salted adaptive hashing (bcrypt/Argon2).',
      'JWT consists of 3 parts separated by dots: Header.Payload.Signature.',
      'JWT payload is Base64URL-encoded (NOT encrypted); do not store sensitive secrets in payload.',
      'Signature HMACSHA256(Header.Payload, Secret) prevents client-side tampering.'
    ],
    formulaSheets: [
      {
        name: 'JWT Structure Invariant',
        formula: '\\text{JWT} = \\text{Base64URL}(\\text{Header}) \\ . \\ \\text{Base64URL}(\\text{Payload}) \\ . \\ \\text{HMAC}_{\\text{SHA256}}(\\text{Header}.\\text{Payload}, K)',
        description: 'Stateless digital signature token generation.'
      }
    ],
    definitions: [
      {
        term: 'Cryptographic Salt',
        explanation: 'Random data added to a password before hashing to ensure that identical passwords produce distinct hash values, defeating rainbow table attacks.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'JWT Generation and Custom Auth Decorator in Flask',
        code: `import jwt, datetime
from functools import wraps
from flask import request, jsonify, current_app

def generate_jwt_token(user_id, role):
    payload = {
        'sub': user_id,
        'role': role,
        'iat': datetime.datetime.utcnow(),
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=2)
    }
    return jwt.encode(payload, current_app.config['SECRET_KEY'], algorithm='HS256')

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'message': 'Bearer Token is missing!'}), 401
            
        token = auth_header.split(' ')[1]
        try:
            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = payload['sub']
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token has expired!'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Invalid token signature!'}), 401
            
        return f(current_user_id, *args, **kwargs)
    return decorated`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w6-q1',
        questionText: 'Can a user read the contents of the payload inside their JWT token in browser localStorage?',
        options: ['Yes, because the JWT payload is only Base64URL-encoded (not encrypted), though they cannot tamper with it without invalidating the signature', 'No, JWT is 256-bit AES encrypted', 'No, only the backend can read it', 'Yes, but only if they know the secret key'],
        correctOptionIndex: 0,
        solution: 'JWT payload is Base64URL encoded text. Anyone can decode and inspect its fields, which is why passwords and secrets must never be placed inside the payload.',
        hints: ['Base64 is encoding, not encryption.']
      }
    ],
    examTips: [
      'Store JWTs in `HttpOnly`, `Secure`, `SameSite=Strict` cookies to protect against Cross-Site Scripting (XSS) token theft.',
      'Include an expiration timestamp (`exp`) in every JWT to minimize the exposure window of compromised tokens.'
    ],
    handwrittenMnemonic: 'Salt your hashes; JWT = Header.Payload.Signature; Base64 is not encrypted!'
  },
  {
    id: 'note-mad1-w7',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 7,
    title: 'Building RESTful APIs with Flask-RESTful: Resources, Request Parsing & Marshaling',
    detailedNotes: `### Week 7: API Development with Flask-RESTful

#### 1. Flask-RESTful Resource Architecture
Flask-RESTful structures endpoints around **Resource Classes** inheriting from \`Resource\`, mapping HTTP verbs to class methods:
\`\`\`python
from flask import Flask
from flask_restful import Api, Resource, reqparse, fields, marshal_with

app = Flask(__name__)
api = Api(app)

class StudentResource(Resource):
    def get(self, student_id):
        # Maps to GET /api/students/<id>
        pass
    def put(self, student_id):
        # Maps to PUT /api/students/<id>
        pass
    def delete(self, student_id):
        # Maps to DELETE /api/students/<id>
        pass

api.add_resource(StudentResource, '/api/students/<int:student_id>')
\`\`\`

#### 2. Request Parsing with \`reqparse\`
Validates and sanitizes incoming request arguments automatically:
\`\`\`python
parser = reqparse.RequestParser()
parser.add_argument('name', type=str, required=True, help="Name is required!")
parser.add_argument('gpa', type=float, required=False, default=0.0)
args = parser.parse_args() # Automatically returns 400 Bad Request on failure!
\`\`\`

#### 3. Response Marshaling with \`fields\` & \`@marshal_with\`
Formats and filters internal ORM objects into controlled JSON response schemas:
\`\`\`python
student_fields = {
    'id': fields.Integer,
    'name': fields.String,
    'department': fields.String(attribute='department.name'), # Nested attribute traversal!
    'created_at': fields.DateTime(dt_format='iso8601')
}
\`\`\``,
    quickRevisionNotes: [
      'Flask-RESTful maps HTTP verbs directly to class methods (`get`, `post`, `put`, `delete`).',
      '`reqparse` validates input types and automatically responds with HTTP 400 on error.',
      '`@marshal_with(fields)` structures outgoing JSON responses and strips internal sensitive attributes.'
    ],
    formulaSheets: [
      {
        name: 'RESTful Resource Route Mapping',
        formula: '\\text{api.add\\_resource(ResourceClass, \"/endpoint/<converter:param>\")}',
        description: 'Class-based view binding in Flask-RESTful.'
      }
    ],
    definitions: [
      {
        term: 'Response Marshaling',
        explanation: 'The automatic transformation and filtering of internal Python objects into structured, serializable JSON schemas according to predefined field definitions.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Complete Flask-RESTful CRUD Resource Implementation',
        code: `from flask_restful import Resource, reqparse, fields, marshal_with, abort

student_output = {
    'id': fields.Integer,
    'name': fields.String,
    'email': fields.String,
    'gpa': fields.Float
}

parser = reqparse.RequestParser()
parser.add_argument('name', type=str, required=True, help='Name is mandatory')
parser.add_argument('email', type=str, required=True, help='Email is mandatory')
parser.add_argument('gpa', type=float, default=0.0)

class StudentAPI(Resource):
    @marshal_with(student_output)
    def get(self, student_id):
        student = Student.query.get(student_id)
        if not student:
            abort(404, message=f"Student {student_id} not found")
        return student

    @marshal_with(student_output)
    def put(self, student_id):
        args = parser.parse_args()
        student = Student.query.get_or_404(student_id)
        student.name = args['name']
        student.email = args['email']
        student.gpa = args['gpa']
        db.session.commit()
        return student, 200

    def delete(self, student_id):
        student = Student.query.get_or_404(student_id)
        db.session.delete(student)
        db.session.commit()
        return {'message': 'Deleted successfully'}, 204`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w7-q1',
        questionText: 'What HTTP status code does Flask-RESTful automatically return when `parser.parse_args()` encounters a missing required argument?',
        options: ['400 Bad Request', '404 Not Found', '500 Internal Server Error', '422 Unprocessable Entity'],
        correctOptionIndex: 0,
        solution: 'reqparse automatically terminates request execution and emits HTTP 400 Bad Request with the configured error message.',
        hints: ['Invalid/missing input returns 400.']
      }
    ],
    examTips: [
      'Always return `204 No Content` for successful `delete` operations with empty payload.',
      'Use `abort(404, message="...")` inside resource methods to halt execution and return standardized error payloads.'
    ],
    handwrittenMnemonic: 'Resource classes map GET/POST/PUT/DELETE; reqparse validates inputs!'
  },
  {
    id: 'note-mad1-w8',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 8,
    title: 'Frontend Component Architecture: Vue.js 3 / React Basics, Reactive State & Props',
    detailedNotes: `### Week 8: Modern Frontend Component Paradigms

#### 1. Declarative UI & The Virtual DOM
Traditional imperative DOM manipulation (\`document.getElementById().appendChild()\`) is slow and error-prone. Modern frameworks use a **Declarative Paradigm**:
- You declare how the UI should look given current state: $\\text{UI} = f(\\text{State})$.
- **Virtual DOM (VDOM) Reconciliation:** When state changes, framework creates a lightweight JavaScript VDOM tree, computes the minimal diff against previous tree, and batch-updates the real browser DOM!

#### 2. Vue.js 3 Composition API vs. React Hooks
- **Vue.js 3 (\`ref\`, \`reactive\`, \`computed\`):**
  \`\`\`javascript
  import { ref, computed } from 'vue';
  export default {
    setup() {
      const count = ref(0);
      const doubleCount = computed(() => count.value * 2);
      function increment() { count.value++; }
      return { count, doubleCount, increment };
    }
  }
  \`\`\`
- **React Functional Component (\`useState\`, \`useMemo\`):**
  \`\`\`javascript
  import React, { useState, useMemo } from 'react';
  export function Counter() {
    const [count, setCount] = useState(0);
    const double = useMemo(() => count * 2, [count]);
    return <button onClick={() => setCount(c => c + 1)}>Count: {count}</button>;
  }
  \`\`\`

#### 3. Component Communication: Props Down, Events Up
- **Parent to Child:** Passed via read-only **Props**.
- **Child to Parent:** Communicated via custom **Events** (\`emit('event-name', data)\` in Vue, callback props in React).
- **Unidirectional Data Flow:** Data flows down; events flow up (ensures predictable state updates).`,
    quickRevisionNotes: [
      'UI = f(State): Declarative frameworks update DOM automatically via Virtual DOM diffing.',
      'Unidirectional Data Flow: Props flow down to children; events flow up to parents.',
      'Vue `ref(0)` wraps primitives in reactive getters/setters (`count.value`).',
      'React `useState` triggers component re-render upon state dispatch.'
    ],
    formulaSheets: [
      {
        name: 'Declarative UI Equation',
        formula: '\\text{View} = f(\\text{State}) \\quad | \\quad \\Delta \\text{DOM} = \\text{Diff}(\\text{VDOM}_{t}, \\text{VDOM}_{t-1})',
        description: 'Core functional reactive UI rendering principle.'
      }
    ],
    definitions: [
      {
        term: 'Unidirectional Data Flow',
        explanation: 'The architectural pattern where data flows strictly in one direction from parent components to child components via props.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Parent-Child Component Communication in Vue 3 (SFC)',
        code: `<!-- StudentCard.vue (Child) -->
<template>
  <div class="student-card">
    <h3>{{ student.name }}</h3>
    <p>Roll: {{ student.roll }}</p>
    <button @click="$emit('delete-student', student.id)">Delete</button>
  </div>
</template>

<script setup>
defineProps({
  student: { type: Object, required: true }
});
defineEmits(['delete-student']);
</script>`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w8-q1',
        questionText: 'Why should a child component never directly mutate a prop received from its parent component?',
        options: ['Direct prop mutation breaks unidirectional data flow and causes hard-to-debug state side-effects across parent re-renders', 'It causes the browser tab to freeze', 'Props are stored on disk', 'It deletes the child component'],
        correctOptionIndex: 0,
        solution: 'Props are strictly read-only inputs owned by the parent. Mutating props directly creates state desynchronization. The child must emit an event requesting the parent to update the state.',
        hints: ['Props are read-only; emit events to request changes.']
      }
    ],
    examTips: [
      '`computed()` properties in Vue are cached based on reactive dependencies, re-evaluating only when dependencies change.',
      'Always provide a unique `:key` prop when rendering lists (`v-for`) to optimize VDOM diffing.'
    ],
    handwrittenMnemonic: 'Props down, Events up; UI is a function of State!'
  },
  {
    id: 'note-mad1-w9',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 9,
    title: 'Single Page Applications (SPA), Client-Side Routing & Navigation Guards',
    detailedNotes: `### Week 9: SPA Architecture & Client-Side Routing (Vue Router / React Router)

#### 1. Single Page Application (SPA) Mechanics
- **Traditional Multi-Page App (MPA):** Every link click requests a full new HTML page from server, causing full-page flash/reload.
- **SPA:** Loads single \`index.html\` once. When user navigates, the **Client-Side Router** intercepts URL changes using HTML5 History API (\`pushState\`, \`replaceState\`), dynamically swapping components without reloading the browser!

#### 2. Vue Router Configuration
\`\`\`javascript
import { createRouter, createWebHistory } from 'vue-router';
import HomeView from './views/HomeView.vue';
import DashboardView from './views/DashboardView.vue';

const routes = [
  { path: '/', component: HomeView },
  { 
    path: '/dashboard', 
    component: DashboardView, 
    meta: { requiresAuth: true } // Route Metadata
  },
  { path: '/students/:id', component: () => import('./views/StudentDetail.vue') } // Lazy Loading!
];

const router = createRouter({
  history: createWebHistory(),
  routes
});
\`\`\`

#### 3. Global Navigation Guards (Authentication Checks)
Intersects every route transition before rendering:
\`\`\`javascript
router.beforeEach((to, from, next) => {
  const isAuthenticated = !!localStorage.getItem('token');
  if (to.meta.requiresAuth && !isAuthenticated) {
    next({ path: '/login', query: { redirect: to.fullPath } });
  } else {
    next(); // Proceed to route
  }
});
\`\`\``,
    quickRevisionNotes: [
      'SPAs load single HTML page and swap components client-side via HTML5 History API.',
      'Route Lazy Loading (`() => import(...)`) splits bundle for faster initial page load.',
      'Navigation guards intercept route transitions to enforce login authentication checks.'
    ],
    formulaSheets: [
      {
        name: 'Client-Side Route Guard Logic',
        formula: '\\text{beforeEach(to, from, next)}: \\quad \\text{if } (\\text{to.requiresAuth } \\land \\neg \\text{isAuth}) \\implies \\text{next(\"/login\")}',
        description: 'Authentication verification gatekeeper pattern.'
      }
    ],
    definitions: [
      {
        term: 'HTML5 History API',
        explanation: 'Browser API (history.pushState) that allows JavaScript to modify the browser URL and history stack without triggering a full page reload.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Dynamic Nested Routes with Route Guards in Vue Router',
        code: `import { createRouter, createWebHistory } from 'vue-router';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/admin',
      component: () => import('./views/AdminLayout.vue'),
      meta: { requiresAuth: true, role: 'admin' },
      children: [
        { path: 'users', component: () => import('./views/UserManagement.vue') },
        { path: 'analytics', component: () => import('./views/Analytics.vue') }
      ]
    }
  ]
});

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('auth_token');
  const userRole = localStorage.getItem('user_role');
  
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!token) return next('/login');
    if (to.meta.role && to.meta.role !== userRole) return next('/forbidden');
  }
  next();
});`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w9-q1',
        questionText: 'Why is Route Lazy Loading (dynamic imports `() => import(...)`) recommended for large SPA applications?',
        options: ['It breaks JavaScript code into separate on-demand chunks, dramatically reducing initial page load time and bundle size', 'It eliminates all backend API calls', 'It converts JavaScript into WebAssembly', 'It makes routing synchronous'],
        correctOptionIndex: 0,
        solution: 'Lazy loading uses Webpack/Vite code-splitting to download component code only when the user actually navigates to that specific route.',
        hints: ['Code-splitting reduces initial bundle download size.']
      }
    ],
    examTips: [
      'In production SPAs served via NGINX, configure `try_files $uri $uri/ /index.html;` so direct URL refreshes route to the SPA fallback.',
      'Always call `next()` exactly once inside a navigation guard.'
    ],
    handwrittenMnemonic: 'History pushState changes URL without reload; Lazy load routes to save bandwidth!'
  },
  {
    id: 'note-mad1-w10',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 10,
    title: 'Client-Server API Integration: Fetch / Axios, JWT Auth Headers & Interceptors',
    detailedNotes: `### Week 10: Asynchronous Client-Server Integration & Axios

#### 1. Fetch API vs. Axios HTTP Client
| Feature | Native Fetch API | Axios HTTP Client |
| :--- | :--- | :--- |
| JSON Serialization | Manual (\`res.json()\`, \`JSON.stringify\`) | Automatic request/response parsing |
| Error Handling | Rejects only on network failure (200 & 500 resolve!) | Automatically rejects on HTTP $4xx/5xx$ errors |
| Interceptors | Not supported natively | Native Request and Response Interceptors |
| Request Cancellation | AbortController | CancelToken / AbortController |

#### 2. Axios Request & Response Interceptors
- **Request Interceptor:** Automatically attaches \`Authorization: Bearer <token>\` header to every outgoing request.
- **Response Interceptor:** Intercepts incoming $401$ Unauthorized errors globally to refresh tokens or redirect user to login!

\`\`\`javascript
import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'https://api.university.org/v1',
  timeout: 10000
});

// Request Interceptor: Attach JWT
apiClient.interceptors.request.use(config => {
  const token = localStorage.getItem('jwt_token');
  if (token) {
    config.headers.Authorization = \`Bearer \${token}\`;
  }
  return config;
});

// Response Interceptor: Global 401 Handler
apiClient.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('jwt_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);
\`\`\``,
    quickRevisionNotes: [
      'Axios automatically serializes JSON and rejects Promise on HTTP 4xx/5xx error status.',
      'Request interceptors attach Authorization Bearer tokens to all outgoing calls automatically.',
      'Response interceptors catch global 401 Unauthorized errors to trigger logout/redirects.'
    ],
    formulaSheets: [
      {
        name: 'Axios Interceptor Pipeline',
        formula: '\\text{App Request} \\xrightarrow{\\text{Req Interceptor}} \\text{Network} \\xrightarrow{\\text{Res Interceptor}} \\text{App Response / Error}',
        description: 'Middleware pipeline for HTTP network traffic.'
      }
    ],
    definitions: [
      {
        term: 'HTTP Interceptor',
        explanation: 'A middleware function that intercepts and transforms HTTP requests before they are sent or responses before they are delivered to application logic.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Centralized API Service Module with Axios in Vue/React',
        code: `import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = \`Bearer \${token}\`;
  return config;
});

export const StudentService = {
  getAll: (params) => api.get('/students', { params }),
  getById: (id) => api.get(\`/students/\${id}\`),
  create: (data) => api.post('/students', data),
  update: (id, data) => api.put(\`/students/\${id}\`, data),
  delete: (id) => api.delete(\`/students/\${id}\`)
};`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w10-q1',
        questionText: 'Why does native JavaScript `fetch()` NOT reject a promise when the server responds with an HTTP 404 or 500 error?',
        options: ['`fetch()` rejects only on complete network/DNS failures; HTTP error status codes are valid HTTP responses and resolve with `res.ok = false`', 'Because fetch only works with HTTP 200', 'Because 404 is considered a success in fetch', 'Fetch converts 500 errors to 200'],
        correctOptionIndex: 0,
        solution: 'From fetch\'s perspective, receiving an HTTP 404/500 from a server is a successful network exchange. You must explicitly check `if (!response.ok)` to handle HTTP errors.',
        hints: ['Fetch only rejects on network failures.']
      }
    ],
    examTips: [
      'Always set an explicit request timeout (e.g. `timeout: 10000` ms) in Axios instances to prevent zombie hanging connections.',
      'Store base API URL in environment variables (`import.meta.env.VITE_API_URL`) to allow seamless switching between development and production.'
    ],
    handwrittenMnemonic: 'Axios auto-parses JSON; Interceptors inject JWTs and handle 401s!'
  },
  {
    id: 'note-mad1-w11',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 11,
    title: 'State Management: Pinia / Vuex & Redux Architecture (Store, Actions, Getters)',
    detailedNotes: `### Week 11: Global State Management (Pinia & Redux)

#### 1. Why Centralized State Management?
In complex SPAs, passing props down deeply nested component trees (**Prop Drilling**) or sharing state between sibling components becomes unmaintainable.
A **Centralized Store** acts as a single source of truth accessible by any component.

#### 2. Pinia (Modern Vue State Management)
Pinia replaces Vuex with a clean, modular, fully TypeScript-typed API:
- **State:** Reactive data source: \`state: () => ({ user: null, cart: [] })\`.
- **Getters:** Computed properties derived from state: \`cartTotal: (state) => ...\`
- **Actions:** Methods containing synchronous OR asynchronous business logic (API calls):

\`\`\`javascript
import { defineStore } from 'pinia';
import { StudentService } from '@/services/StudentService';

export const useStudentStore = defineStore('students', {
  state: () => ({
    students: [],
    loading: false,
    error: null
  }),
  getters: {
    topPerformers: (state) => state.students.filter(s => s.gpa >= 3.8),
    totalCount: (state) => state.students.length
  },
  actions: {
    async fetchStudents() {
      this.loading = true;
      try {
        const res = await StudentService.getAll();
        this.students = res.data;
      } catch (err) {
        this.error = err.message;
      } finally {
        this.loading = false;
      }
    }
  }
});
\`\`\``,
    quickRevisionNotes: [
      'Centralized stores eliminate Prop Drilling in deep component hierarchies.',
      'Pinia store structure: State (data), Getters (computed), Actions (methods & async API calls).',
      'Pinia allows direct state mutations and async actions without cumbersome Vuex mutations.'
    ],
    formulaSheets: [
      {
        name: 'Flux / Store Architecture Data Flow',
        formula: '\\text{Component} \\xrightarrow{\\text{Dispatch Action}} \\text{Store Action} \\xrightarrow{\\text{Update}} \\text{State} \\xrightarrow{\\text{Reactivity}} \\text{Component View}',
        description: 'Unidirectional data flow in centralized state stores.'
      }
    ],
    definitions: [
      {
        term: 'Prop Drilling',
        explanation: 'The anti-pattern of passing data through multiple intermediate components that do not need the data themselves, purely to deliver it to a deeply nested child.'
      }
    ],
    codeSnippets: [
      {
        language: 'javascript',
        title: 'Consuming Pinia Store inside a Vue 3 Component',
        code: `<template>
  <div class="student-list">
    <h2>Enrolled Students ({{ studentStore.totalCount }})</h2>
    <div v-if="studentStore.loading">Loading records...</div>
    <div v-else-if="studentStore.error" class="error">{{ studentStore.error }}</div>
    <ul v-else>
      <li v-for="s in studentStore.topPerformers" :key="s.id">
        {{ s.name }} - GPA: {{ s.gpa }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import { onMounted } from 'vue';
import { useStudentStore } from '@/stores/studentStore';

const studentStore = useStudentStore();

onMounted(() => {
  studentStore.fetchStudents();
});
</script>`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w11-q1',
        questionText: 'What is the primary conceptual difference between Pinia and the older Vuex 3/4 state management library in Vue?',
        options: ['Pinia completely eliminates the need for separate Mutations, allowing synchronous and asynchronous logic directly inside Actions', 'Pinia only works with local SQLite databases', 'Pinia does not support computed getters', 'Pinia requires full page refreshes'],
        correctOptionIndex: 0,
        solution: 'Vuex required separate verbose Mutations for synchronous state updates and Actions for async calls. Pinia simplifies this by allowing direct mutations and placing all logic in Actions.',
        hints: ['Pinia removes mutations and unifies actions.']
      }
    ],
    examTips: [
      'In Pinia, you can modify state directly (`store.count++`) or use `$patch({ count: 5 })` for grouped atomic updates.',
      'Pinia stores support hot-module reloading and devtools time-travel debugging out of the box.'
    ],
    handwrittenMnemonic: 'State holds data; Getters compute; Actions fetch APIs and mutate State!'
  },
  {
    id: 'note-mad1-w12',
    courseId: 'course-mad1',
    courseTitle: 'Modern Application Development 1',
    courseCode: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 12,
    title: 'Application Security (CORS, CSRF, XSS, SQLi), Testing & Production Deployment (Gunicorn/NGINX)',
    detailedNotes: `### Week 12: Web Security Hardening & Production Deployment

#### 1. The OWASP Top Web Security Vulnerabilities
1. **Cross-Origin Resource Sharing (CORS):**
   - Browser Same-Origin Policy (SOP) blocks frontend at \`http://localhost:5173\` from fetching \`http://api.site.com\` unless the backend emits headers:
   - \`Access-Control-Allow-Origin: https://app.site.com\`
   - \`Access-Control-Allow-Methods: GET, POST, PUT, DELETE\`
   - Handle pre-flight \`OPTIONS\` requests using \`flask-cors\`.
2. **Cross-Site Scripting (XSS):**
   - Attacker injects malicious JavaScript into webpage (\`<script>stealCookie()</script>\`).
   - **Defense:** Auto-escaping in Jinja2/Vue; Content Security Policy (CSP); \`HttpOnly\` cookies.
3. **Cross-Site Request Forgery (CSRF):**
   - Tricking user browser into making unauthorized requests to an authenticated site using stored session cookies.
   - **Defense:** CSRF Tokens (\`Flask-WTF\`) and \`SameSite=Strict\` cookies.
4. **SQL Injection (SQLi):**
   - Concatenating unescaped user input into SQL strings (\`SELECT * WHERE user = '\` + input).
   - **Defense:** Use ORM parameterization (\`db.session\`) exclusively!

#### 2. Production Deployment Stack (NGINX + Gunicorn + Flask)
- **NGINX (Reverse Proxy & Static Server):**
  - Listens on public Port 80/443; handles SSL/TLS termination; serves static assets (\`/static/\`, \`dist/\`); buffers slow clients; reverse-proxies API calls to Gunicorn.
- **Gunicorn (WSGI Application Server):**
  - Master process managing worker processes (\`gunicorn -w 4 -b 127.0.0.1:8000 wsgi:app\`).
  - Worker Count Formula: $\\text{Workers} = 2 \\times \\text{CPU Cores} + 1$.`,
    quickRevisionNotes: [
      'CORS protects users from unauthorized cross-origin requests; enable via Flask-CORS.',
      'Prevent SQL Injection using SQLAlchemy ORM parameterization (never string concatenation).',
      'Prevent XSS via auto-escaping and HttpOnly cookies; prevent CSRF using CSRF tokens and SameSite cookies.',
      'Production stack: NGINX (Reverse Proxy/SSL) -> Gunicorn (WSGI Workers) -> Flask App.'
    ],
    formulaSheets: [
      {
        name: 'Gunicorn Worker Allocation Formula',
        formula: 'N_{\\text{workers}} = 2 \\times N_{\\text{CPU Cores}} + 1',
        description: 'Recommended WSGI worker process count for CPU-bound web applications.'
      }
    ],
    definitions: [
      {
        term: 'Reverse Proxy',
        explanation: 'An intermediate server (like NGINX) positioned in front of web servers to handle SSL termination, load balancing, caching, and client request forwarding.'
      }
    ],
    codeSnippets: [
      {
        language: 'text',
        title: 'Production NGINX Configuration for SPA and Flask Backend',
        code: `server {
    listen 80;
    server_name myapp.university.org;

    # Serve Vue SPA Frontend
    location / {
        root /var/www/myapp/dist;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Proxy API Requests to Gunicorn Backend
    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}`
      }
    ],
    practiceQuestions: [
      {
        id: 'mad1-w12-q1',
        questionText: 'What is the purpose of the `try_files $uri $uri/ /index.html;` directive in the NGINX configuration for a Single Page Application?',
        options: ['It directs all unknown client route requests to index.html, allowing the client-side JavaScript router to handle the page view instead of throwing a 404', 'It restarts the NGINX server on errors', 'It encrypts the HTML file with SSL', 'It compiles Vue templates to bytecode'],
        correctOptionIndex: 0,
        solution: 'When users refresh a route like `/dashboard` in an SPA, NGINX searches for a physical `/dashboard` folder on disk. When not found, try_files falls back to `/index.html`, letting the SPA router handle the URL.',
        hints: ['Enables client-side SPA routing fallback on direct URL refresh.']
      }
    ],
    examTips: [
      'Never run the Flask built-in development server (`flask run` or `app.run()`) in production; it is single-threaded and not hardened for production traffic.',
      'Always set `DEBUG = False` in production to prevent leaking interactive debug tracebacks to potential attackers.'
    ],
    handwrittenMnemonic: 'NGINX proxies to Gunicorn (2*Cores + 1); Parameterize SQL to kill injection!'
  }
];

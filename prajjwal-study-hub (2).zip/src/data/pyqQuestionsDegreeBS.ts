import { Question } from '../types';

export const DEGREE_BS_QUESTIONS: Question[] = [
  // ==========================================
  // BSc DEGREE LEVEL: DEEP LEARNING
  // ==========================================
  {
    id: 'pyq-dl-backprop-relu-nat',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning (DL)',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    subject: 'Deep Learning (DL)',
    type: 'NAT',
    questionText: 'In a neural network hidden neuron with linear pre-activation $z = \\mathbf{w}^T \\mathbf{x} + b = -3.5$, followed by a standard ReLU activation function $a = \\max(0, z)$. If the incoming gradient of the loss with respect to activation is $\\frac{\\partial \\mathcal{L}}{\\partial a} = 4.2$, what is the gradient of the loss with respect to pre-activation $\\frac{\\partial \\mathcal{L}}{\\partial z}$?',
    options: [],
    correctNumericAnswer: 0,
    numericTolerance: 0,
    toleranceRange: [0, 0],
    explanation: `ReLU Backpropagation Gradient Calculation:
1. ReLU derivative:
   $$\\frac{\\partial a}{\\partial z} = \\begin{cases} 1 & \\text{if } z > 0 \\\\ 0 & \\text{if } z < 0 \\end{cases}$$
2. Chain rule:
   $$\\frac{\\partial \\mathcal{L}}{\\partial z} = \\frac{\\partial \\mathcal{L}}{\\partial a} \\cdot \\frac{\\partial a}{\\partial z}$$
3. Since $z = -3.5 < 0$, $\\frac{\\partial a}{\\partial z} = 0$.
4. Therefore, $\\frac{\\partial \\mathcal{L}}{\\partial z} = 4.2 \\times 0 = 0$ (illustrating the "dying ReLU" gradient deactivation effect).`,
    hints: [
      'What is the derivative of $\\text{ReLU}(z)$ when $z < 0$?',
      'Apply the chain rule $\\frac{\\partial \\mathcal{L}}{\\partial z} = \\frac{\\partial \\mathcal{L}}{\\partial a} \\cdot \\frac{d a}{d z}$.'
    ],
    formulaRef: '\\frac{\\partial a}{\\partial z} = \\mathbb{I}(z > 0)',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 6',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['Deep Learning', 'Backpropagation', 'ReLU', 'Gradients'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-ai-alphabeta-pruning-nat',
    courseId: 'course-ai-search',
    courseTitle: 'Artificial Intelligence: Search Methods',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    subject: 'Artificial Intelligence: Search Methods',
    type: 'MCQ',
    questionText: 'In a zero-sum two-player game tree evaluated using Minimax with Alpha-Beta Pruning, which condition triggers a Beta Cutoff (pruning remaining children of a MIN node)?',
    options: [
      'When the current MIN node evaluation $\\beta$ becomes less than or equal to the ancestor MAX value $\\alpha$ (i.e. $\\beta \\le \\alpha$)',
      'When $\\alpha > \\beta + 10$',
      'When the depth of the game tree exceeds 10 plies',
      'When the heuristic score at the leaf node is zero'
    ],
    correctOptionIndex: 0,
    explanation: `Alpha-Beta Pruning Invariant:
- $\\alpha$: Best value found so far for the MAX player along the path (lower bound on score).
- $\\beta$: Best value found so far for the MIN player along the path (upper bound on score).
- At a MIN node, if an action results in a score $\\le \\alpha$, the MAX ancestor already has a better alternative elsewhere and will never choose to enter this branch.
- Thus, the condition $\\beta \\le \\alpha$ triggers an immediate Beta-cutoff.`,
    hints: [
      'Alpha is the lower bound for MAX, Beta is the upper bound for MIN.',
      'Cutoff occurs when $\\alpha \\ge \\beta$.'
    ],
    formulaRef: '\\beta \\le \\alpha \\implies \\text{Prune branch}',
    difficulty: 'Medium',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 6',
    pyqYear: 'Jan 2025 (Quiz 2)',
    tags: ['AI Search', 'Minimax', 'Alpha-Beta Pruning', 'Game Trees'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // BS DEGREE LEVEL: GENERATIVE AI & ADVANCED ML
  // ==========================================
  {
    id: 'pyq-bs-lora-params-nat',
    courseId: 'course-bs-genai',
    courseTitle: 'Deep Learning & Advanced Generative AI',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Deep Learning & Advanced Generative AI',
    type: 'NAT',
    questionText: 'In Low-Rank Adaptation (LoRA) parameter-efficient fine-tuning of an LLM linear projection layer $W_0 \\in \\mathbb{R}^{4096 \\times 4096}$, we represent the update as $\\Delta W = B A$ where $A \\in \\mathbb{R}^{r \\times 4096}$ and $B \\in \\mathbb{R}^{4096 \\times r}$. If the rank is chosen as $r = 8$, what is the TOTAL number of trainable parameters in matrices $A$ and $B$ combined (without biases)?',
    options: [],
    correctNumericAnswer: 65536,
    numericTolerance: 0,
    toleranceRange: [65536, 65536],
    explanation: `LoRA Trainable Parameter Math:
1. Matrix $A$ has dimensions $r \\times d = 8 \\times 4096 = 32768$ parameters.
2. Matrix $B$ has dimensions $d \\times r = 4096 \\times 8 = 32768$ parameters.
3. Total trainable parameters:
   $$32768 + 32768 = 65536$$
(Compared to full fine-tuning of $4096 \\times 4096 = 16,777,216$ parameters, LoRA trains only $0.39\\%$ of original weights!).`,
    hints: [
      'Calculate parameters in $A$: $r \\times d$.',
      'Calculate parameters in $B$: $d \\times r$.',
      'Add both: $2 \\times (8 \\times 4096)$.'
    ],
    formulaRef: '\\text{LoRA Params} = 2 \\cdot d \\cdot r',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 9',
    pyqYear: 'Jan 2025 (Quiz 1)',
    tags: ['Generative AI', 'LLMs', 'LoRA', 'PEFT', 'Transformers'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bs-vae-elbo-msq',
    courseId: 'course-bs-genai',
    courseTitle: 'Deep Learning & Advanced Generative AI',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Deep Learning & Advanced Generative AI',
    type: 'MSQ',
    questionText: 'In Variational Autoencoders (VAEs), which of the following statements regarding the Evidence Lower Bound (ELBO) and the Reparameterization Trick are mathematically ACCURATE?',
    options: [
      'The ELBO objective $\\mathcal{L}_{\\text{ELBO}}(\\theta, \\phi; x) = \\mathbb{E}_{q_\\phi(z|x)}[\\log p_\\theta(x|z)] - D_{\\text{KL}}(q_\\phi(z|x) \\parallel p(z))$ is a strict lower bound on the marginal log-likelihood $\\log p(x)$.',
      'The Kullback-Leibler (KL) divergence term $D_{\\text{KL}}(q_\\phi(z|x) \\parallel p(z))$ acts as a regularizer pushing the variational posterior towards the prior standard normal distribution $\\mathcal{N}(0, I)$.',
      'The Reparameterization Trick $z = \\mu_\\phi(x) + \\sigma_\\phi(x) \\odot \\epsilon$ where $\\epsilon \\sim \\mathcal{N}(0, I)$ enables backpropagation of gradients with respect to encoder parameters $\\phi$.',
      'If $q_\\phi(z|x)$ matches the true posterior $p(z|x)$ perfectly, the KL divergence gap becomes zero and the ELBO equals the true marginal data log-likelihood $\\log p(x)$.'
    ],
    correctOptionIndices: [0, 1, 2, 3],
    explanation: `Variational Autoencoder (VAE) Derivations:
- Statement A is TRUE: By Jensen's Inequality, $\\log p(x) = \\mathcal{L}_{\\text{ELBO}} + D_{\\text{KL}}(q(z|x) \\parallel p(z|x)) \\ge \\mathcal{L}_{\\text{ELBO}}$.
- Statement B is TRUE: The closed-form Gaussian KL loss penalizes deviations from prior $p(z) = \\mathcal{N}(0, I)$.
- Statement C is TRUE: Moving the stochastic sampling node outside the computation graph ($z = \\mu + \\sigma \\odot \\epsilon$) allows pathwise derivative / backpropagation through $\\mu$ and $\\sigma$.
- Statement D is TRUE: The gap is exactly $D_{\\text{KL}}(q(z|x) \\parallel p(z|x))$, which vanishes when $q = p$.
All 4 statements are foundational VAE principles!`,
    hints: [
      'Review Jensen\'s inequality derivation for $\\log p(x)$.',
      'Recall why the reparameterization trick is necessary for backprop.'
    ],
    formulaRef: '\\log p(x) = \\mathcal{L}_{\\text{ELBO}} + D_{\\text{KL}}(q_\\phi(z|x) \\parallel p(z|x))',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 9',
    pyqYear: 'May 2025 (Quiz 2)',
    tags: ['Generative AI', 'VAEs', 'ELBO', 'Reparameterization Trick', 'KL Divergence'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

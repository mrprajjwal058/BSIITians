import { AcademicLevel } from '../types';

export interface GrammarRule {
  id: string;
  category: 'Subject-Verb Agreement' | 'Tenses & Conditionals' | 'Active & Passive Voice' | 'Direct & Indirect Speech' | 'Modifiers & Parallelism' | 'Prepositions & Articles';
  title: string;
  ruleStatement: string;
  handwrittenTip: string;
  correctExamples: string[];
  incorrectExamples: string[];
  examTrap: string;
  mnemonic?: string;
}

export interface CommonErrorEntry {
  id: string;
  topic: string;
  incorrectSentence: string;
  correctSentence: string;
  explanation: string;
  ruleCategory: string;
}

export interface AcademicVocabWord {
  id: string;
  word: string;
  partOfSpeech: 'noun' | 'verb' | 'adjective' | 'adverb';
  definition: string;
  synonyms: string[];
  antonyms: string[];
  academicUsage: string;
  collocations: string[];
  handwrittenMnemonic?: string;
}

export interface ReadingComprehensionStrategy {
  id: string;
  strategyName: string;
  description: string;
  steps: string[];
  questionTypes: string[];
  handwrittenShortcut: string;
}

export const ENGLISH_GRAMMAR_RULES: GrammarRule[] = [
  {
    id: 'gr-sva-1',
    category: 'Subject-Verb Agreement',
    title: 'Intervening Phrases & Prepositional Modifiers',
    ruleStatement: 'Words between the subject and verb (such as "along with", "as well as", "in addition to", "accompanied by") do not alter the grammatical number of the subject.',
    handwrittenTip: 'Ignore all prepositional clauses between commas! Find the true first subject before "along with" or "as well as".',
    correctExamples: [
      'The professor, along with her graduate research students, **is** attending the symposium.',
      'Neither the dataset nor the algorithmic models **have** reached optimal convergence.'
    ],
    incorrectExamples: [
      'The professor, along with her graduate research students, are attending the symposium. (Incorrect plural verb)',
      'A series of empirical benchmarks have confirmed our hypothesis. (Should be "has confirmed")'
    ],
    examTrap: 'IITM English tests frequently put a plural noun right before the verb inside a prepositional phrase to trick you.',
    mnemonic: 'Rule of First Subject: Subject + [Parenthetical phrase] + Verb matches Subject!'
  },
  {
    id: 'gr-sva-2',
    category: 'Subject-Verb Agreement',
    title: 'Correlative Conjunctions (Either...Or, Neither...Nor, Not only...But also)',
    ruleStatement: 'When subjects are joined by "or", "nor", "either...or", "neither...nor", or "not only...but also", the verb agrees with the closer (proximate) subject.',
    handwrittenTip: 'Proximity Rule: Look strictly at the noun closest to the verb slot!',
    correctExamples: [
      'Neither the GPU clusters nor the central server **was** rebooted last night.',
      'Either the database administrator or the software engineers **are** responsible for the migration.'
    ],
    incorrectExamples: [
      'Neither the GPU clusters nor the central server were rebooted. (Server is singular and closer)',
      'Not only the students but also the instructor were surprised. (Instructor is singular)'
    ],
    examTrap: 'Do not compute a plural sum when using "either/or" or "neither/nor". Only the adjacent noun dictates the verb.',
    mnemonic: 'Closest Subject Wins the Verb!'
  },
  {
    id: 'gr-cond-1',
    category: 'Tenses & Conditionals',
    title: 'The Third (Unreal Past) & Mixed Conditionals',
    ruleStatement: 'Hypothetical past conditions use the Past Perfect in the "if" clause and "would have + past participle" in the main result clause.',
    handwrittenTip: 'If + had + V3 ---> would have + V3! Never put "would have" inside the "if" clause.',
    correctExamples: [
      'If the neural network **had been trained** with regularization, it **would not have overfitted** the validation set.',
      'Had we sanitized the raw query inputs, the SQL injection vulnerability **would have been averted**.'
    ],
    incorrectExamples: [
      'If the neural network would have been trained with regularization, it would not have overfitted. (Never use "would have" in If-clause)',
      'If he knew the formula yesterday, he would pass the exam. (Tense clash: past context requires "had known")'
    ],
    examTrap: 'Inversion without "if": "Had I known..." is equivalent to "If I had known...". Both are grammatically pristine.',
    mnemonic: 'Past Unreal: Had + V3 ==> Would Have + V3'
  },
  {
    id: 'gr-voice-1',
    category: 'Active & Passive Voice',
    title: 'Academic Objectivity & Agentless Passive Voice',
    ruleStatement: 'In scientific and academic writing, passive voice is utilized to maintain objective focus on experimental results, data transformations, and methodologies rather than the investigator.',
    handwrittenTip: 'In scientific abstracts: "The samples were centrifuged" is preferred over "We centrifuged the samples".',
    correctExamples: [
      'The raw time-series telemetry **was normalized** prior to Fourier decomposition.',
      'Statistically significant deviations **were observed** in cohort B ($p < 0.01$).'
    ],
    incorrectExamples: [
      'The data was analyzed by us and we concluded the results. (Weak, informal academic register)',
      'A mistake was made of which nobody took responsibility. (Ambiguous passive phrasing)'
    ],
    examTrap: 'Ensure the helping verb "be" matches tense and number: Data (plural in formal academic English) -> "Data were collected".',
    mnemonic: 'Scientific Voice: Focus on the Method & Data, not the Person!'
  },
  {
    id: 'gr-mod-1',
    category: 'Modifiers & Parallelism',
    title: 'Dangling & Misplaced Participial Modifiers',
    ruleStatement: 'An introductory participial phrase must modify the subject immediately following the comma. If the subject cannot logically perform the action, the modifier is dangling.',
    handwrittenTip: 'Ask: WHO is doing the action in the opening -ing/-ed phrase? That entity MUST be the very next word after the comma!',
    correctExamples: [
      'Having compiled the C++ backend binary, **the developer** executed the load tests.',
      'To evaluate algorithmic convergence, **we plotted** the loss trajectory.'
    ],
    incorrectExamples: [
      'Having compiled the C++ backend binary, the load tests were executed. (Dangling: tests did not compile the binary)',
      'Walking into the server room, the temperature felt freezing. (Dangling: temperature wasn\'t walking)'
    ],
    examTrap: 'Watch out for passive sentences following participial phrases—they almost always create dangling modifiers.',
    mnemonic: 'Modifier Check: Opening Phrase Actor == Word After Comma!'
  },
  {
    id: 'gr-par-1',
    category: 'Modifiers & Parallelism',
    title: 'Faulty Parallelism in Lists and Comparisons',
    ruleStatement: 'Items in a series, list, or coordinate structure must share the exact same grammatical structure (all gerunds, all infinitives, all noun phrases, or all prepositional phrases).',
    handwrittenTip: 'Balance the sentence like an algebraic equation! (A, B, and C must all have the same grammatical type).',
    correctExamples: [
      'The data science pipeline involves **extracting** raw features, **cleaning** noisy records, and **training** predictive models.',
      'She prefers **to write** clean code rather than **to debug** legacy scripts.'
    ],
    incorrectExamples: [
      'The pipeline involves extracting raw features, data cleaning, and to train models. (Mismatched gerunds and infinitives)',
      'The algorithm is fast, reliable, and performs with accuracy. (Adjective, Adjective, and Verb Phrase clash)'
    ],
    examTrap: 'Correlative pairs (not only...but also) must precede identical grammatical structures.',
    mnemonic: 'Grammatical symmetry: Gerund with Gerund, Noun with Noun, Infinitive with Infinitive!'
  }
];

export const ENGLISH_COMMON_ERRORS: CommonErrorEntry[] = [
  {
    id: 'err-1',
    topic: 'Data Countability',
    incorrectSentence: 'The dataset has less observations than expected.',
    correctSentence: 'The dataset has fewer observations than expected.',
    explanation: '"Fewer" is used for countable nouns (observations, rows, samples); "Less" is reserved for uncountable quantities (memory, time, noise).',
    ruleCategory: 'Quantifiers & Countability'
  },
  {
    id: 'err-2',
    topic: 'Subject-Verb Agreement',
    incorrectSentence: 'Each of the machine learning algorithms require hyperparameter tuning.',
    correctSentence: 'Each of the machine learning algorithms requires hyperparameter tuning.',
    explanation: '"Each", "Everyone", "Neither", and "Either" are grammatically singular and require singular verbs ("requires").',
    ruleCategory: 'Subject-Verb Agreement'
  },
  {
    id: 'err-3',
    topic: 'Tense Harmony in Relative Clauses',
    incorrectSentence: 'The researcher discovered that gravity was pulling objects at 9.8 m/s².',
    correctSentence: 'The researcher discovered that gravity pulls objects at 9.8 m/s².',
    explanation: 'Universal scientific truths and physical laws remain in the Simple Present tense even when introduced by a past-tense reporting verb.',
    ruleCategory: 'Tenses & Universal Truths'
  },
  {
    id: 'err-4',
    topic: 'Dangling Gerund',
    incorrectSentence: 'Upon entering the terminal, an error message appeared on the screen.',
    correctSentence: 'Upon entering the terminal, the engineer noticed an error message on the screen.',
    explanation: 'The error message was not the entity entering the terminal. The true actor (the engineer) must immediately succeed the comma.',
    ruleCategory: 'Modifiers'
  },
  {
    id: 'err-5',
    topic: 'Idiomatic Prepositions',
    incorrectSentence: 'The neural architecture is capable to classify multimodal inputs.',
    correctSentence: 'The neural architecture is capable of classifying multimodal inputs.',
    explanation: '"Capable" takes the preposition "of" + gerund ("capable of classifying"); "Able" takes the infinitive "to" ("able to classify").',
    ruleCategory: 'Idioms & Prepositions'
  },
  {
    id: 'err-6',
    topic: 'Redundancy & Wordiness',
    incorrectSentence: 'The two algorithms reverted back to their previous initial state.',
    correctSentence: 'The two algorithms reverted to their initial state.',
    explanation: '"Revert" already encapsulates the meaning of going back. "Revert back" is a tautological redundancy.',
    ruleCategory: 'Conciseness & Style'
  },
  {
    id: 'err-7',
    topic: 'Affect vs Effect',
    incorrectSentence: 'The learning rate hyperparameter had a significant affect on loss convergence.',
    correctSentence: 'The learning rate hyperparameter had a significant effect on loss convergence.',
    explanation: '"Effect" is typically a noun meaning result/impact; "Affect" is typically a verb meaning to influence.',
    ruleCategory: 'Word Choice & Homophones'
  },
  {
    id: 'err-8',
    topic: 'Comprising vs Composed of',
    incorrectSentence: 'The convolutional network is comprised of twelve residual layers.',
    correctSentence: 'The convolutional network comprises twelve residual layers (or is composed of twelve residual layers).',
    explanation: 'The whole comprises the parts. "Comprise" never takes "of" in standard formal academic English.',
    ruleCategory: 'Academic Phrasing'
  }
];

export const ACADEMIC_VOCABULARY_LIST: AcademicVocabWord[] = [
  {
    id: 'vocab-1',
    word: 'Juxtapose',
    partOfSpeech: 'verb',
    definition: 'To place two or more concepts, data distributions, or arguments side by side to compare or contrast them.',
    synonyms: ['Collocate', 'Contrast', 'Compare', 'Appose'],
    antonyms: ['Isolate', 'Separate', 'Disperse'],
    academicUsage: 'We juxtaposed the confusion matrices of the Random Forest and SVM models to isolate false positive tendencies.',
    collocations: ['Juxtapose data against theory', 'Juxtapose contrasting viewpoints'],
    handwrittenMnemonic: 'Jux- = next to (junction) + pose = put in place!'
  },
  {
    id: 'vocab-2',
    word: 'Empirical',
    partOfSpeech: 'adjective',
    definition: 'Originating in or based on direct observation, physical measurement, or scientific experiment rather than pure theoretical conjecture.',
    synonyms: ['Experiential', 'Observational', 'Evidence-based', 'Pragmatic'],
    antonyms: ['Hypothetical', 'Theoretical', 'Speculative', 'Unsubstantiated'],
    academicUsage: 'Our empirical benchmark results corroborates the asymptotic runtime predictions made in chapter 3.',
    collocations: ['Empirical evidence', 'Empirical validation', 'Empirical study'],
    handwrittenMnemonic: 'Empirical = Evidence + Measurement + Proven!'
  },
  {
    id: 'vocab-3',
    word: 'Corroborate',
    partOfSpeech: 'verb',
    definition: 'To confirm, authenticate, or support with additional evidence, experimental trials, or mathematical proof.',
    synonyms: ['Substantiate', 'Validate', 'Verify', 'Authenticate'],
    antonyms: ['Refute', 'Contradict', 'Disprove', 'Undermine'],
    academicUsage: 'The telemetry logs corroborated the diagnostic report, confirming a memory leak in the Redis cache cluster.',
    collocations: ['Corroborate findings', 'Corroborate a hypothesis', 'Independently corroborated'],
    handwrittenMnemonic: 'Co- (together) + Robur (strength in Latin) = Make strong together!'
  },
  {
    id: 'vocab-4',
    word: 'Salient',
    partOfSpeech: 'adjective',
    definition: 'Most noticeable, prominent, or conspicuous; having paramount importance in an analytical context.',
    synonyms: ['Prominent', 'Conspicuous', 'Pivotal', 'Striking'],
    antonyms: ['Inconsequential', 'Obscure', 'Negligible', 'Insignificant'],
    academicUsage: 'The attention mechanism in Transformers assigns higher weights to the most salient tokens across the context window.',
    collocations: ['Salient features', 'Salient characteristic', 'Salient point'],
    handwrittenMnemonic: 'Salient leaps out at you (from Latin salire = to leap)!'
  },
  {
    id: 'vocab-5',
    word: 'Parsimonious',
    partOfSpeech: 'adjective',
    definition: 'Extremely frugal or concise; in data science, choosing the simplest viable statistical model with the fewest parameters (Occam\'s Razor).',
    synonyms: ['Concise', 'Frugal', 'Minimalist', 'Spare'],
    antonyms: ['Extravagant', 'Convoluted', 'Redundant', 'Overparameterized'],
    academicUsage: 'Lasso regularization yields a parsimonious model by zeroing out non-essential feature coefficients.',
    collocations: ['Parsimonious explanation', 'Parsimonious parameterization', 'Parsimonious model'],
    handwrittenMnemonic: 'Parsimony = Occam\'s Razor in mathematical modeling!'
  },
  {
    id: 'vocab-6',
    word: 'Ubiquitous',
    partOfSpeech: 'adjective',
    definition: 'Present, appearing, or found everywhere simultaneously; omnipresent in modern software ecosystems.',
    synonyms: ['Omnipresent', 'Pervasive', 'Universal', 'Prevalent'],
    antonyms: ['Rare', 'Scarce', 'Localized', 'Infrequent'],
    academicUsage: 'Relational databases and SQL remain ubiquitous across enterprise backend architectures.',
    collocations: ['Ubiquitous computing', 'Ubiquitous presence', 'Become ubiquitous'],
    handwrittenMnemonic: 'Ubiquitous = Universal + Bit + Quick (Everywhere)!'
  },
  {
    id: 'vocab-7',
    word: 'Anomalous',
    partOfSpeech: 'adjective',
    definition: 'Deviating from what is standard, normal, expected, or theoretically forecasted.',
    synonyms: ['Atypical', 'Aberrant', 'Abnormal', 'Outlying'],
    antonyms: ['Conforming', 'Standard', 'Typical', 'Regular'],
    academicUsage: 'Isolation Forests detect anomalous data points by evaluating their path depth across randomized decision trees.',
    collocations: ['Anomalous behavior', 'Anomalous reading', 'Anomalous outlier'],
    handwrittenMnemonic: 'A- (not) + nomal (normal) = Outlier!'
  },
  {
    id: 'vocab-8',
    word: 'Efficacy',
    partOfSpeech: 'noun',
    definition: 'The capacity or ability to produce a desired, intended result under controlled benchmark conditions.',
    synonyms: ['Effectiveness', 'Potency', 'Utility', 'Success rate'],
    antonyms: ['Inefficacy', 'Futility', 'Impotence', 'Uselessness'],
    academicUsage: 'The research paper evaluated the computational efficacy of AdamW optimizer versus standard SGD with momentum.',
    collocations: ['Demonstrate efficacy', 'Therapeutic efficacy', 'Efficacy evaluation'],
    handwrittenMnemonic: 'Efficacy = Efficiency + Accuracy in reaching the goal!'
  }
];

export const READING_COMPREHENSION_STRATEGIES: ReadingComprehensionStrategy[] = [
  {
    id: 'rc-1',
    strategyName: 'SQ3R Method (Survey, Question, Read, Recite, Review)',
    description: 'Systematic approach for dense technical passages in IITM English comprehension tests.',
    steps: [
      'Survey: Scan title, headings, opening sentence of each paragraph, and conclusion.',
      'Question: Turn headings and thesis statements into targeted inquiry questions.',
      'Read: Read actively with pencil/cursor, tracking evidence answering your questions.',
      'Recite: Mentally summarize key arguments at the end of each paragraph in 5 words.',
      'Review: Cross-verify author\'s tone and main intent before answering questions.'
    ],
    questionTypes: ['Main Idea / Primary Purpose', 'Tone & Attitude', 'Paragraph Function'],
    handwrittenShortcut: 'First & Last sentences of each paragraph hold 75% of the passage thesis!'
  },
  {
    id: 'rc-2',
    strategyName: 'Tone & Attitude Heuristic Matrix',
    description: 'Framework for instantly classifying the author\'s stance in academic discourse.',
    steps: [
      'Look for adjectives and adverbs that carry emotional valence (e.g., "flawed", "remarkable", "disputable").',
      'Distinguish between Objective/Analytical (neutral, data-driven) and Critical/Skeptical (questioning assumptions).',
      'Eliminate extreme options (e.g., "Enraged", "Euphoric") as academic passages are almost never extreme.'
    ],
    questionTypes: ['Author Tone', 'Inference Questions', 'Author Opinion'],
    handwrittenShortcut: 'Academic passages are almost always: Analytical, Critical, Pragmatic, or Objective.'
  },
  {
    id: 'rc-3',
    strategyName: 'Contextual Clue Decryption for Unfamiliar Words',
    description: 'Strategy to infer meanings of complex vocabulary words without an external dictionary.',
    steps: [
      'Identify Contrast Transition words (e.g., "However", "Whereas", "In contrast to") which signal antonyms.',
      'Identify Restatement Transition words (e.g., "In other words", "Namely", "That is to say") which give definitions.',
      'Inspect Latin/Greek prefixes and roots (e.g., "bene-" = good, "mal-" = bad, "poly-" = many).'
    ],
    questionTypes: ['Vocabulary in Context', 'Sentence Equivalence'],
    handwrittenShortcut: 'Check the transition word right before the unknown term!'
  }
];

import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_TDS_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-tds-w1',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 1,
    title: 'Development Environment, Bash Automation & Advanced Git (DAGs, Rebase vs Merge)',
    detailedNotes: `### Week 1: Unix CLI Automation & Advanced Git Internals

#### 1. Command Line Productivity & Pipelines for Data Science
- Text streams processing: \`grep\`, \`sed\`, \`awk\`, \`cut\`, \`sort\`, \`uniq -c\`, and \`xargs\`.
- Inspecting multi-gigabyte CSVs without loading into RAM:
  - \`head -n 5 data.csv\` & \`tail -n 5 data.csv\`
  - \`wc -l large_dataset.csv\` (Count total rows in milliseconds)
  - \`awk -F',' '{print $1, $5}' large_dataset.csv | head -n 10\`

#### 2. Git Under the Hood: The Directed Acyclic Graph (DAG)
Git tracks filesystem snapshots using a content-addressable SHA-1 object database:
- **Blobs:** File contents.
- **Trees:** Directory listings mapping filenames to blob/tree SHAs and permissions.
- **Commits:** Author, timestamp, commit message, tree pointer, and zero or more parent commit pointers.
- **Branches:** Lightweight, movable 41-byte pointers pointing to a commit hash.

#### 3. Rebase vs. Merge in Team Collaboration
- **\`git merge feature\`:** Creates an explicit 2-parent **Merge Commit**, preserving true chronological branch history.
- **\`git rebase main\`:** Unwinds your branch commits and reapplies them sequentially on top of the tip of \`main\`, producing a **clean linear commit history**. (Golden Rule: *Never rebase a shared public branch!*).
- **Interactive Rebase (\`git rebase -i HEAD~4\`):** Squash (\`s\`), fixup (\`f\`), reword (\`r\`), and drop messy local commits.`,
    quickRevisionNotes: [
      'Git objects: Blobs (files), Trees (dirs), Commits (metadata + tree pointer), Tags.',
      'Branches are mutable pointers to commit SHA hashes.',
      '`git rebase` creates a clean linear history; `git merge` preserves true branch ancestry.',
      '`wc -l` and `awk` enable instant line counting and columnar filtering without RAM overhead.'
    ],
    formulaSheets: [
      {
        name: 'Git Commit Hash Generation',
        formula: '\\text{SHA-1}(\\text{\"commit \"} + \\text{size} + \\backslash 0 + \\text{tree SHA} + \\text{parent SHA} + \\text{author} + \\text{message})',
        description: 'Cryptographic content addressing invariant in Git.'
      }
    ],
    definitions: [
      {
        term: 'Content-Addressable Storage',
        explanation: 'A storage mechanism where data is retrieved and addressed exclusively by its cryptographic hash rather than a designated storage path.'
      }
    ],
    codeSnippets: [
      {
        language: 'bash',
        title: 'Git Workflow: Feature Branching, Rebasing and Interactive Squash',
        code: `# Create and switch to new feature branch
git checkout -b feature/data-ingestion

# Make changes, stage and commit
git add src/ingest.py
git commit -m "feat: add chunked parquet loader"

# Rebase feature branch on top of latest remote main
git fetch origin
git rebase origin/main

# Squash last 3 messy commits into one clean commit before opening PR
git rebase -i HEAD~3`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w1-q1',
        questionText: 'What is the primary risk of running `git rebase` on a branch that has already been pushed to a remote shared repository used by other team members?',
        options: ['It rewrites commit SHA hashes, causing divergence and forced-push conflicts for collaborators who branched off the original commits', 'It deletes the local Git repository', 'It turns all Python files into binary blobs', 'It prevents GitHub from compiling markdown'],
        correctOptionIndex: 0,
        solution: 'Rebasing creates brand-new commit hashes for existing commits. If collaborators based work on the old commits, their Git history will diverge, requiring painful manual reconciliation.',
        hints: ['Rebase rewrites commit history and hashes.']
      }
    ],
    examTips: [
      'Use `git cherry-pick <commit-hash>` to selectively apply a specific isolated bugfix from another branch without merging the entire branch.',
      'Always configure a `.gitignore` containing `__pycache__/`, `.env`, `.ipynb_checkpoints/`, and raw data folders (`data/*.csv`).'
    ],
    handwrittenMnemonic: 'Blobs = Files, Trees = Folders, Commits = History; Never rebase shared public branches!'
  },
  {
    id: 'note-tds-w2',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 2,
    title: 'Python Package Management (Poetry/Conda), Virtual Environments, Pytest & Formatting (Ruff/Black)',
    detailedNotes: `### Week 2: Modern Python Tooling, Packaging & Automated Testing

#### 1. Virtual Environments & Dependency Resolvers
- **Problem:** Installing global Python packages causes dependency version conflicts between projects (e.g. Project A requires NumPy 1.24; Project B requires NumPy 2.0).
- **\`venv\` / \`virtualenv\`:** Isolates \`site-packages\` directory per project.
- **Poetry (Modern Packaging & Dependency Locking):**
  - \`pyproject.toml\`: Declares dependencies and build system metadata (PEP 517/518).
  - \`poetry.lock\`: Pins exact transitive sub-dependency versions and cryptographic hashes for $100\\%$ deterministic, reproducible builds across developer machines.

#### 2. Automated Testing with Pytest
\`pytest\` provides clean, assert-based test execution:
- **Fixtures (\`@pytest.fixture\`):** Setup/teardown reusable dependencies (e.g. database connections, test datasets).
- **Parametrization (\`@pytest.mark.parametrize\`):** Run single test function against multiple input/output tuples.
- **Mocking (\`unittest.mock\`):** Isolates tests by mocking external HTTP calls or heavy disk I/O.

#### 3. Modern Python Quality Tooling: Ruff & Black
- **Ruff (Written in Rust):** $10-100\\times$ faster than Flake8, isort, and Pylint; auto-fixes syntax errors and imports.
- **Black / Ruff Formatter:** Uncompromising, deterministic Python code formatter.`,
    quickRevisionNotes: [
      'Virtual environments isolate site-packages preventing dependency conflicts.',
      'Poetry uses `poetry.lock` for deterministic, reproducible installs across machines.',
      'Pytest fixtures provide reusable test data setup; `@pytest.mark.parametrize` tests multiple cases.',
      'Ruff replaces Flake8/isort with lightning-fast Rust-based linting and code formatting.'
    ],
    formulaSheets: [
      {
        name: 'Deterministic Dependency Resolution',
        formula: '\\text{pyproject.toml (constraints)} \\xrightarrow{\\text{Poetry Resolver}} \\text{poetry.lock (pinned hashes)} \\xrightarrow{\\text{Deterministic Install}} \\text{Environment}',
        description: 'Modern Python dependency locking pipeline.'
      }
    ],
    definitions: [
      {
        term: 'Pytest Fixture',
        explanation: 'A decorated function that provides a fixed baseline of test data, database state, or mock services to one or more test functions.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Pytest Suite with Fixtures and Parametrization for Data Processing',
        code: `import pytest
import pandas as pd

@pytest.fixture
def sample_student_dataframe():
    """Provides standard test dataframe."""
    return pd.DataFrame({
        'student_id': [1, 2, 3, 4],
        'score': [85.0, 92.5, None, 78.0],
        'passed': [True, True, False, True]
    })

@pytest.mark.parametrize("strategy,expected_null_count", [
    ('drop', 0),
    ('fill_zero', 0)
])
def test_clean_missing_scores(sample_student_dataframe, strategy, expected_null_count):
    df = sample_student_dataframe.copy()
    if strategy == 'drop':
        cleaned = df.dropna(subset=['score'])
    else:
        cleaned = df.fillna({'score': 0})
        
    assert cleaned['score'].isnull().sum() == expected_null_count`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w2-q1',
        questionText: 'What is the primary purpose of committing the `poetry.lock` file into your Git version control repository alongside `pyproject.toml`?',
        options: ['To guarantee that all developers and CI/CD deployment servers install the exact identical pinned sub-dependency versions', 'To compile Python into machine code', 'To execute tests automatically', 'To format code with Black'],
        correctOptionIndex: 0,
        solution: '`pyproject.toml` specifies allowable version ranges, while `poetry.lock` records the exact resolved package versions, hashes, and transitive dependencies, ensuring reproducible environments.',
        hints: ['Ensures identical dependency versions across machines.']
      }
    ],
    examTips: [
      'Never commit `.venv/` directories to Git; commit only `pyproject.toml` and `poetry.lock`.',
      'Run `pytest -v --cov=src` to view detailed test pass rates alongside code coverage percentages.'
    ],
    handwrittenMnemonic: 'Lockfile pins exact versions; Fixtures provide test data; Ruff formats fast in Rust!'
  },
  {
    id: 'note-tds-w3',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 3,
    title: 'Web Scraping, HTML DOM Parsing (BeautifulSoup4, Playwright) & API Ingestion',
    detailedNotes: `### Week 3: Web Scraping & Data Extraction Pipelines

#### 1. Web Scraping Protocols & Ethical Guidelines
- **\`robots.txt\`:** Standard protocol located at \`domain.com/robots.txt\` specifying allowed and disallowed paths for crawlers (\`User-agent: *\`, \`Disallow: /admin/\`).
- **HTTP Rate Limiting & Politeness:** Always insert random delays (\`time.sleep(random.uniform(1, 3))\`) and identify your bot with a custom \`User-Agent\` header.

#### 2. Static HTML Parsing: BeautifulSoup4
Best for static web pages where HTML is fully rendered on server:
\`\`\`python
from bs4 import BeautifulSoup
import requests

res = requests.get('https://news.ycombinator.com', headers={'User-Agent': 'ResearchBot/1.0'})
soup = BeautifulSoup(res.text, 'html.parser')

# Find elements via CSS Selectors
titles = [item.text for item in soup.select('span.titleline > a')]
\`\`\`

#### 3. Dynamic JavaScript SPAs: Headless Browsers (Playwright / Selenium)
Many modern sites load content asynchronously via React/Vue client-side rendering. Headless browser automation runs an actual Chromium instance:
\`\`\`python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://spa-dataset.org')
    page.wait_for_selector('.data-row') # Wait for React to render!
    content = page.content()
    browser.close()
\`\`\``,
    quickRevisionNotes: [
      'Check `robots.txt` before scraping to respect site crawling policies.',
      'BeautifulSoup4 parses static HTML via CSS selectors and DOM traversal.',
      'Playwright / Selenium automates headless Chromium browsers to scrape JavaScript SPAs.',
      'Always set custom `User-Agent` headers and insert delays to avoid IP rate-limit bans.'
    ],
    formulaSheets: [
      {
        name: 'DOM CSS Selector Query',
        formula: '\\text{soup.select(\"table.rankings > tbody > tr.row[data-active=\'true\']\")}',
        description: 'Hierarchical CSS selector targeting specific structured tabular rows.'
      }
    ],
    definitions: [
      {
        term: 'Headless Browser',
        explanation: 'A web browser without a graphical user interface (GUI), controlled programmatically to render JavaScript, navigate pages, and extract data.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Robust Scraping Pipeline with Retries, Delays & CSV Export',
        code: `import requests, time, random, csv
from bs4 import BeautifulSoup

def scrape_course_catalog(base_url, total_pages=3):
    headers = {'User-Agent': 'UniversityDataCollector/1.0 (academic research)'}
    extracted_records = []

    for page_num in range(1, total_pages + 1):
        url = f"{base_url}?page={page_num}"
        try:
            res = requests.get(url, headers=headers, timeout=10)
            res.raise_for_status()
            soup = BeautifulSoup(res.text, 'html.parser')
            
            cards = soup.select('.course-card')
            for card in cards:
                title = card.select_one('.course-title').get_text(strip=True)
                code = card.select_one('.course-code').get_text(strip=True)
                credits = int(card.select_one('.credits').get_text(strip=True))
                extracted_records.append({'code': code, 'title': title, 'credits': credits})
                
            time.sleep(random.uniform(1.0, 2.5)) # Politeness delay
        except Exception as err:
            print(f"Error scraping page {page_num}: {err}")
            
    return extracted_records`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w3-q1',
        questionText: 'When attempting to scrape a modern website built with React or Vue, `requests.get()` returns empty `<div id="root"></div>` tags with no data. Why does this occur, and how is it resolved?',
        options: ['The site renders content client-side via JavaScript after initial HTML load; resolved by using a headless browser like Playwright or directly reverse-engineering the site\'s backend JSON API', 'The site is encrypted with quantum keys', 'requests library is outdated', 'HTML tags cannot contain data'],
        correctOptionIndex: 0,
        solution: '`requests.get()` only downloads the raw initial HTML file without executing JavaScript scripts. Using Playwright spins up a real browser engine to execute client-side JS, or you can inspect Network devtools to call the JSON API directly.',
        hints: ['Client-side JS rendering requires a browser engine or API calls.']
      }
    ],
    examTips: [
      'Before writing a scraper, check Network DevTools (Fetch/XHR tab) — often a clean JSON REST API exists that you can query directly without parsing HTML!',
      'Store raw downloaded HTML payloads on disk before parsing, so parsing bugs don\'t require re-scraping the web server.'
    ],
    handwrittenMnemonic: 'Static HTML -> BeautifulSoup; Dynamic JS -> Playwright; Check Network tab for raw JSON APIs!'
  },
  {
    id: 'note-tds-w4',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 4,
    title: 'High-Performance Data Wrangling: Pandas vs. Polars (Rust Engine, Lazy Evaluation) & Parquet',
    detailedNotes: `### Week 4: Tabular Data Engines: Pandas vs. Polars & Apache Arrow

#### 1. The Limitations of Pandas
- **Single-Threaded:** Operates on a single CPU core by default.
- **Eager Execution:** Every intermediate operation creates full temporary DataFrame copies in memory ($5-10\\times$ RAM overhead relative to dataset size).
- **Memory Inefficiency:** Relies on NumPy object dtypes with pointer indirection for string columns.

#### 2. Polars: Next-Generation DataFrames (Written in Rust)
- **Multi-Threaded & SIMD:** Automatically parallelizes execution across all available CPU cores.
- **Apache Arrow Columnar Memory:** Zero-copy data sharing, native null bitmaps, and compact memory layout.
- **Lazy Evaluation (\`pl.scan_parquet()\` / \`lazy()\`):**
  - Builds an **Abstract Syntax Tree (AST)** of transformations.
  - **Query Optimizer:**
    - *Predicate Pushdown:* Filters rows at the storage level before loading columns into RAM.
    - *Projection Pushdown:* Loads only the specific requested columns from disk (skipping unneeded columns!).
  - Executes only when \`.collect()\` is explicitly called!

#### 3. Storage Formats: CSV vs. Apache Parquet
- **CSV:** Text-based, uncompressed, row-oriented, slow to parse, no schema preservation.
- **Parquet:** Binary, columnar-oriented, dictionary-encoded, Snappy/Zstd-compressed, includes embedded column statistics (min/max per row-group for fast filtering).`,
    quickRevisionNotes: [
      'Pandas is eager and single-threaded; Polars is multi-threaded and built on Rust/Arrow.',
      'Polars LazyFrame builds an execution plan and optimizes via Predicate & Projection Pushdown.',
      'Parquet is a columnar binary format with high compression and instant column-selective reads.',
      '`pl.scan_parquet().filter(...).select(...).collect()` achieves maximum speed and minimal RAM.'
    ],
    formulaSheets: [
      {
        name: 'Query Optimization Pushdown',
        formula: '\\text{Scan}(\\text{Data}) \\xrightarrow{\\text{Filter (Predicate Pushdown)}} \\text{Pruned Row Groups} \\xrightarrow{\\text{Select (Projection Pushdown)}} \\text{Loaded Columns}',
        description: 'Polars storage-level optimization reducing I/O and memory.'
      }
    ],
    definitions: [
      {
        term: 'Predicate Pushdown',
        explanation: 'A query optimization technique where filtering conditions (WHERE clauses) are pushed down directly to the storage layer to avoid reading irrelevant data blocks into memory.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Polars Lazy Query Optimization on Multi-Million Row Dataset',
        code: `import polars as pl

# Lazy Scan on Parquet dataset (reads zero data into RAM initially)
lazy_query = (
    pl.scan_parquet("transactions_*.parquet")
    .filter(pl.col("amount") > 500.0)             # Predicate Pushdown
    .filter(pl.col("status") == "SUCCESS")
    .group_by("merchant_category")
    .agg([
        pl.col("amount").sum().alias("total_revenue"),
        pl.col("amount").mean().alias("avg_ticket_size"),
        pl.col("transaction_id").count().alias("transaction_count")
    ])
    .sort("total_revenue", descending=True)
)

# View the optimized query plan
print(lazy_query.explain())

# Trigger actual multi-threaded computation
result_df = lazy_query.collect()`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w4-q1',
        questionText: 'Why is reading a 10 GB Parquet file significantly faster in Polars/DuckDB when only 2 out of 50 columns are queried, compared to reading a CSV file?',
        options: ['Parquet stores data column-by-column (columnar), allowing the reader to seek and read ONLY the 2 requested byte streams while completely skipping the other 48 columns from disk', 'Parquet disables data validation', 'CSV files are encrypted', 'Polars converts CSV to JSON'],
        correctOptionIndex: 0,
        solution: 'In columnar storage like Parquet, each column is stored in contiguous disk blocks. Projection pushdown allows the engine to load only the exact bytes for the 2 columns, skipping 96% of disk I/O.',
        hints: ['Columnar format allows skipping unread columns entirely.']
      }
    ],
    examTips: [
      'Always save large analytical tables as `.parquet` with `snappy` or `zstd` compression instead of `.csv`.',
      'Use `df.write_parquet("file.parquet", compression="zstd")` for optimal balance of compression ratio and write speed.'
    ],
    handwrittenMnemonic: 'Pandas = Eager/Single-Core; Polars = Lazy/Rust/Multi-Core; Parquet = Fast Columnar Storage!'
  },
  {
    id: 'note-tds-w5',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 5,
    title: 'Relational & NoSQL Systems: PostgreSQL (psycopg3), SQLite, MongoDB & In-Memory Redis',
    detailedNotes: `### Week 5: Polyglot Persistence: SQL, Document Stores & Key-Value Caches

#### 1. Relational Databases (PostgreSQL / SQLite)
- **ACID Transactions:** Strong consistency; strict schemas; B-Tree indexes; complex multi-table SQL joins.
- **psycopg3 (Modern Python Driver):** Native connection pooling, async I/O support, and binary data transfers.
- **JSONB in PostgreSQL:** Allows querying semi-structured documents with GIN indexes inside relational tables!

#### 2. Document Store: MongoDB (PyMongo)
- Schema-less JSON-like BSON documents.
- Best for nested, hierarchical data structures (e.g. user profiles, product catalogs with varying attributes).
- Aggregation Pipeline: \`$match\` $\\to$ \`$group\` $\\to$ \`$project\` $\\to$ \`$sort\`.

#### 3. In-Memory Key-Value: Redis
- Sub-millisecond read/write latency.
- Data Structures: Strings, Hashes, Lists, Sets, Sorted Sets (ZSET for leaderboards).
- Pub/Sub messaging and distributed locking (\`SET key value NX PX 10000\`).`,
    quickRevisionNotes: [
      'PostgreSQL provides ACID compliance, relation joins, and indexed JSONB columns.',
      'MongoDB stores flexible schema BSON documents queryable via Aggregation Pipelines.',
      'Redis operates in-memory for caching, session stores, and rate limiting.',
      'Choose storage based on data access patterns: Relational for consistency, Mongo for nested documents, Redis for speed.'
    ],
    formulaSheets: [
      {
        name: 'MongoDB Aggregation Pipeline Flow',
        formula: '\\text{Collection} \\xrightarrow{\\$match} \\text{Filtered Docs} \\xrightarrow{\\$group} \\text{Aggregated Docs} \\xrightarrow{\\$sort} \\text{Output}',
        description: 'Multi-stage transformation pipeline in MongoDB.'
      }
    ],
    definitions: [
      {
        term: 'Polyglot Persistence',
        explanation: 'The practice of using different data storage technologies (RDBMS, NoSQL, In-Memory) within a single application architecture, choosing the optimal engine for each specific data requirement.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Querying PostgreSQL with Connection Pooling and MongoDB Aggregations',
        code: `from psycopg_pool import ConnectionPool
from pymongo import MongoClient

# PostgreSQL Connection Pool
pg_pool = ConnectionPool("postgresql://user:pass@localhost:5432/analytics_db", min_size=2, max_size=10)

with pg_pool.connection() as conn:
    with conn.cursor() as cur:
        cur.execute("SELECT student_id, AVG(score) FROM grades GROUP BY student_id HAVING AVG(score) > %s", (80.0,))
        top_students = cur.fetchall()

# MongoDB Aggregation Pipeline
mongo_client = MongoClient("mongodb://localhost:27017/")
db = mongo_client["university"]
pipeline = [
    {"$match": {"status": "enrolled"}},
    {"$group": {"_id": "$department", "total_students": {"$sum": 1}, "avg_gpa": {"$avg": "$gpa"}}},
    {"$sort": {"total_students": -1}}
]
dept_summary = list(db.students.aggregate(pipeline))`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w5-q1',
        questionText: 'In what scenario is Redis Sorted Sets (ZSET) preferred over a traditional SQL database query for a gaming or student leaderboard?',
        options: ['Redis ZSET maintains an in-memory skip-list that allows O(log N) score updates and O(log N + M) retrieval of top-ranked users with sub-millisecond latency under massive concurrency', 'Redis saves data on magnetic tapes', 'SQL cannot sort numbers', 'Redis disables encryption'],
        correctOptionIndex: 0,
        solution: 'Redis Sorted Sets are specifically engineered for real-time ranked leaderboards, allowing instant retrieval of top ranks (ZRANGEBYSCORE) without expensive SQL table scans.',
        hints: ['In-memory skip-list provides O(log N) real-time ranking.']
      }
    ],
    examTips: [
      'Always use parameterized queries (`cur.execute("SELECT * WHERE id = %s", (user_id,))`) to prevent SQL Injection.',
      'In MongoDB, index fields used in `$match` filters to ensure high aggregation performance.'
    ],
    handwrittenMnemonic: 'Postgres for Relations; Mongo for Documents; Redis for In-Memory Speed!'
  },
  {
    id: 'note-tds-w6',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 6,
    title: 'High-Performance Numerical Computing: Vectorized NumPy, Numba JIT & Cython',
    detailedNotes: `### Week 6: Python Performance Optimization: Vectorization, Numba & Cython

#### 1. Why Pure Python Loops are Slow
- Dynamic type checking on every iteration.
- Object pointer indirection in memory (Python integers are full C structures with reference counts and type pointers).
- Global Interpreter Lock (GIL) preventing CPU-bound multi-threading.

#### 2. NumPy Vectorization & Broadcasting
NumPy executes operations in compiled C/Fortran routines over contiguous memory buffers (**Strided Arrays**):
- **Broadcasting Rules:** Two dimensions are compatible when they are equal, or one of them is $1$.
- Eliminates Python for-loop overhead by executing at raw C-speed.

#### 3. Numba: Just-In-Time (JIT) Compiler
Numba translates pure Python numerical code into optimized native machine instructions at runtime using LLVM:
\`\`\`python
import numba

@numba.jit(nopython=True, fastmath=True, parallel=True)
def monte_carlo_pi(num_samples):
    count = 0
    for i in numba.prange(num_samples): # Parallel multi-core loop!
        x = np.random.random()
        y = np.random.random()
        if x*x + y*y <= 1.0:
            count += 1
    return 4.0 * count / num_samples
\`\`\`
- \`nopython=True\` (\`@numba.njit\`): Guarantees the code runs with zero Python C-API overhead (throws error if fallback to Python object mode occurs).`,
    quickRevisionNotes: [
      'Python loops are slow due to dynamic typing and memory pointer indirection.',
      'NumPy uses C-contiguous arrays and SIMD vectorization for high throughput.',
      '`@numba.njit(parallel=True)` compiles Python loops to native machine code via LLVM.',
      '`nopython=True` ensures zero Python interpreter overhead in compiled JIT loops.'
    ],
    formulaSheets: [
      {
        name: 'NumPy Array Stride Calculation',
        formula: '\\text{Address}(i, j) = \\text{Base} + i \\times \\text{stride}_0 + j \\times \\text{stride}_1',
        description: 'Pointer arithmetic for 2D strided array memory access.'
      }
    ],
    definitions: [
      {
        term: 'Just-In-Time (JIT) Compilation',
        explanation: 'A compilation method where Python bytecode is compiled into native CPU machine code during program execution rather than prior to execution.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Benchmarking Vectorized NumPy vs Numba Parallel JIT',
        code: `import numpy as np
import numba

# Pure NumPy Vectorized Euclidean Distance Matrix
def numpy_pairwise_distance(X):
    # (N, 1, D) - (1, N, D) broadcasting
    diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
    return np.sqrt(np.sum(diff**2, axis=-1))

# Numba Parallel JIT implementation (avoids large intermediate 3D broadcast matrix!)
@numba.njit(parallel=True, fastmath=True)
def numba_pairwise_distance(X):
    N, D = X.shape
    dist = np.zeros((N, N), dtype=np.float64)
    for i in numba.prange(N):
        for j in range(i + 1, N):
            s = 0.0
            for d in range(D):
                diff = X[i, d] - X[j, d]
                s += diff * diff
            d_val = np.sqrt(s)
            dist[i, j] = d_val
            dist[j, i] = d_val
    return dist`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w6-q1',
        questionText: 'Why does `@numba.njit(parallel=True)` with `numba.prange()` often outperform standard NumPy broadcasting for computing pairwise distances on large arrays?',
        options: ['Broadcasting creates massive intermediate 3D tensors that saturate RAM bandwidth and cache, whereas Numba computes values in CPU L1/L2 cache in parallel without allocating extra memory', 'Numba converts calculations to string operations', 'NumPy cannot calculate square roots', 'Numba deletes memory automatically'],
        correctOptionIndex: 0,
        solution: 'Broadcasting (N, 1, D) - (1, N, D) allocates an $N \\times N \\times D$ array in RAM, creating memory bandwidth bottlenecks. Numba calculates the scalar values in CPU cache in parallel across multiple cores.',
        hints: ['Avoids huge intermediate tensor allocations in RAM.']
      }
    ],
    examTips: [
      'Always test Numba functions with a small dummy warmup call before running benchmarks to exclude one-time compilation latency.',
      'Use `numba.prange` instead of standard `range` to distribute loop iterations across multi-core CPUs.'
    ],
    handwrittenMnemonic: 'Vectorize with NumPy; JIT-compile custom loops with @numba.njit(parallel=True)!'
  },
  {
    id: 'note-tds-w7',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 7,
    title: 'Building Production Data APIs with FastAPI: Pydantic V2, Dependency Injection & OpenAPI',
    detailedNotes: `### Week 7: Production Machine Learning APIs with FastAPI

#### 1. Why FastAPI for Data Science & ML?
- Built on **Starlette** (high-performance ASGI engine) and **Pydantic V2** (Rust-based data validation).
- Native support for Python \`async\` / \`await\` non-blocking I/O.
- Automatic interactive documentation generation at \`/docs\` (Swagger UI) and \`/redoc\`.
- Strong type hints provide compile-time safety and automatic JSON serialization/deserialization.

#### 2. Pydantic V2 Schemas & Validation
\`\`\`python
from pydantic import BaseModel, Field, EmailStr, field_validator

class PredictionRequest(BaseModel):
    student_id: int = Field(..., gt=0, description="Positive Student ID")
    study_hours_per_week: float = Field(..., ge=0.0, le=100.0)
    attendance_rate: float = Field(..., ge=0.0, le=1.0)
    email: EmailStr

    @field_validator('study_hours_per_week')
    def validate_realistic_hours(cls, v):
        if v > 80:
            raise ValueError("Study hours exceeds realistic weekly limits")
        return v
\`\`\`

#### 3. FastAPI Dependency Injection (\`Depends\`)
Centralizes shared logic (database connections, auth validation, ML model artifact loading):
\`\`\`python
def get_ml_model():
    return global_model_registry["churn_v2"]

@app.post("/predict")
def predict_churn(payload: PredictionRequest, model=Depends(get_ml_model)):
    prediction = model.predict([payload.features()])
    return {"prediction": int(prediction[0])}
\`\`\``,
    quickRevisionNotes: [
      'FastAPI uses Starlette (ASGI) and Pydantic V2 for high-speed schema validation.',
      'Auto-generates OpenAPI / Swagger interactive documentation at `/docs`.',
      'Pydantic `Field(ge=0, le=1)` enforces input bounds and returns HTTP 422 on bad data.',
      '`Depends()` provides dependency injection for database sessions and ML model singletons.'
    ],
    formulaSheets: [
      {
        name: 'FastAPI Validation Pipeline',
        formula: '\\text{Raw JSON} \\xrightarrow{\\text{Pydantic V2 (Rust)}} \\begin{cases} \\text{Valid Typed Object} \\to \\text{Route Handler} \\\\ \\text{Invalid Data} \\to \\text{HTTP 422 Unprocessable Entity} \\end{cases}',
        description: 'Request validation lifecycle in FastAPI.'
      }
    ],
    definitions: [
      {
        term: 'ASGI (Asynchronous Server Gateway Interface)',
        explanation: 'A standardized interface between async-capable Python web servers (Uvicorn) and Python web frameworks (FastAPI).'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Production ML Model Inference API with FastAPI and Lifespan Manager',
        code: `from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, Field
from contextlib import asynccontextmanager
import joblib

ml_models = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load ML Model into RAM once during server startup
    print("Loading serialized XGBoost model into memory...")
    ml_models["grade_predictor"] = joblib.load("model_v1.pkl")
    yield
    # Cleanup resources on shutdown
    ml_models.clear()

app = FastAPI(title="Academic Grade Prediction API", version="2.0", lifespan=lifespan)

class FeatureInput(BaseModel):
    attendance_rate: float = Field(..., ge=0.0, le=1.0, example=0.92)
    assignment_avg: float = Field(..., ge=0.0, le=100.0, example=88.5)
    quiz_score: float = Field(..., ge=0.0, le=100.0, example=91.0)

class PredictionResponse(BaseModel):
    predicted_grade: str
    pass_probability: float

@app.post("/api/v1/predict", response_model=PredictionResponse)
async def predict_student_grade(data: FeatureInput):
    model = ml_models.get("grade_predictor")
    if not model:
        raise HTTPException(status_code=503, detail="Model artifact not ready")
        
    features = [[data.attendance_rate, data.assignment_avg, data.quiz_score]]
    pred = model.predict(features)[0]
    prob = float(model.predict_proba(features)[0][1])
    
    return PredictionResponse(predicted_grade=pred, pass_probability=round(prob, 4))`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w7-q1',
        questionText: 'Why should ML model artifacts (like `joblib.load("model.pkl")`) be loaded inside the FastAPI `lifespan` context manager rather than inside the `/predict` route handler function?',
        options: ['Loading models takes seconds and allocates memory; loading once on startup avoids reloading the model from disk on every single incoming HTTP prediction request', 'FastAPI forbids loading files in routes', 'joblib only runs before port binding', 'It encrypts the model file'],
        correctOptionIndex: 0,
        solution: 'Loading model weights from disk takes hundreds of milliseconds. Loading once at startup retains the model in RAM, reducing individual inference latency to single-digit milliseconds.',
        hints: ['Load once at startup to keep model in memory.']
      }
    ],
    examTips: [
      'Run FastAPI applications in production using `uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4`.',
      'Use Pydantic `response_model` to guarantee that internal sensitive fields are filtered out before sending JSON responses.'
    ],
    handwrittenMnemonic: 'FastAPI = Starlette + Pydantic; Load models in lifespan; Auto /docs via Swagger!'
  },
  {
    id: 'note-tds-w8',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 8,
    title: 'Asynchronous Python & Concurrency: asyncio, aiohttp, ThreadPools & Multiprocessing',
    detailedNotes: `### Week 8: Asynchronous I/O & Parallel Concurrency in Python

#### 1. Concurrency vs. Parallelism & The Global Interpreter Lock (GIL)
- **Concurrency (I/O Bound):** Interleaving multiple tasks on a single thread while waiting for network/disk responses (\`asyncio\`, \`aiohttp\`).
- **Parallelism (CPU Bound):** Executing tasks simultaneously on multiple physical CPU cores (\`multiprocessing\`, \`concurrent.futures.ProcessPoolExecutor\`).
- **GIL:** CPython lock ensuring only one thread executes Python bytecode at any instant. (Multi-threading does NOT speed up CPU-bound code, but accelerates I/O-bound code!).

#### 2. The \`asyncio\` Architecture
- **Event Loop:** Single-threaded loop coordinating task scheduling.
- **Coroutines (\`async def\`):** Functions whose execution can be paused (\`await\`) and resumed.
- **Tasks (\`asyncio.create_task\`):** Wraps coroutine for concurrent execution.
- **\`asyncio.gather(*tasks)\`:** Runs multiple asynchronous network requests concurrently.

#### 3. Concurrent Web Fetching with \`aiohttp\`
Fetch 1,000 API endpoints in 3 seconds instead of 5 minutes:
\`\`\`python
import asyncio, aiohttp

async def fetch_item(session, item_id):
    async with session.get(f"https://api.site.com/items/{item_id}") as res:
        return await res.json()

async def main():
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_item(session, i) for i in range(100)]
        results = await asyncio.gather(*tasks)
\`\`\``,
    quickRevisionNotes: [
      'Asyncio handles I/O-bound concurrency on a single thread via the Event Loop.',
      'Multiprocessing bypasses the GIL to execute CPU-bound workloads across multiple cores.',
      'Multi-threading helps I/O-bound tasks but cannot parallelize CPU bytecode due to the GIL.',
      '`asyncio.gather(*tasks)` executes independent network coroutines concurrently.'
    ],
    formulaSheets: [
      {
        name: 'Amdahl\'s Law of Parallel Speedup',
        formula: 'S_{\\text{latency}}(s) = \\frac{1}{(1 - p) + \\frac{p}{s}} \\quad (p = \\text{parallel fraction}, s = \\text{cores})',
        description: 'Theoretical maximum speedup achievable through multi-core parallelization.'
      }
    ],
    definitions: [
      {
        term: 'Global Interpreter Lock (GIL)',
        explanation: 'A mutex mechanism in CPython preventing multiple native OS threads from executing Python bytecode simultaneously within a single process.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Hybrid Concurrency: Async I/O Ingestion with Multiprocessing CPU Pool',
        code: `import asyncio, aiohttp
from concurrent.futures import ProcessPoolExecutor
import numpy as np

def cpu_heavy_feature_engineering(raw_data_chunk):
    # Runs in separate process to bypass GIL and utilize 100% CPU core
    arr = np.array(raw_data_chunk)
    return np.linalg.svd(arr)[1] # Singular Value Decomposition

async def fetch_data(session, url):
    async with session.get(url) as response:
        return await response.json()

async def pipeline():
    # Step 1: Async I/O batch network fetching
    async with aiohttp.ClientSession() as session:
        urls = [f"https://api.sensor.org/data/{i}" for i in range(10)]
        raw_chunks = await asyncio.gather(*[fetch_data(session, u) for u in urls])
        
    # Step 2: Offload CPU-heavy computation to ProcessPoolExecutor
    loop = asyncio.get_running_loop()
    with ProcessPoolExecutor() as pool:
        tasks = [loop.run_in_executor(pool, cpu_heavy_feature_engineering, chunk) for chunk in raw_chunks]
        results = await asyncio.gather(*tasks)
        
    return results`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w8-q1',
        questionText: 'When should you use `multiprocessing` instead of `asyncio` or `threading` in Python?',
        options: ['When performing CPU-intensive computations (like matrix math or image transformations) that require parallel execution on multiple CPU cores to bypass the CPython GIL', 'When downloading 500 web pages over network', 'When reading small JSON files', 'When writing HTML templates'],
        correctOptionIndex: 0,
        solution: '`asyncio` and `threading` are designed for I/O-bound waiting. CPU-bound computation blocks the event loop and is limited to 1 core by the GIL; `multiprocessing` spawns separate OS processes to use all cores.',
        hints: ['CPU-bound calculations need multiprocessing to bypass the GIL.']
      }
    ],
    examTips: [
      'Never call blocking synchronous code (like `time.sleep()` or `requests.get()`) inside an `async def` function; it blocks the entire event loop!',
      'Use `asyncio.to_thread()` or `loop.run_in_executor()` when invoking unavoidable blocking synchronous libraries.'
    ],
    handwrittenMnemonic: 'I/O-Bound -> asyncio / aiohttp; CPU-Bound -> multiprocessing to break the GIL!'
  },
  {
    id: 'note-tds-w9',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 9,
    title: 'Containerization for Data Science: Docker, Multi-Stage Builds & GPU Acceleration',
    detailedNotes: `### Week 9: Docker Containerization for Data Science & ML Workloads

#### 1. Why Docker in Data Science?
- Eliminates "Works on my machine" bugs by packaging Python runtime, exact C-libraries (CUDA, cuDNN, OpenBLAS, GDAL), and source code into an immutable, portable container.

#### 2. Production Multi-Stage Dockerfile for Data Applications
Separates heavyweight compiler tools from the final lean runtime:
\`\`\`dockerfile
# Stage 1: Build & Dependencies
FROM python:3.10-slim AS builder
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends build-essential gcc
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# Stage 2: Minimal Runtime
FROM python:3.10-slim AS runner
WORKDIR /app
COPY --from=builder /root/.local /root/.local
COPY src/ ./src/
ENV PATH=/root/.local/bin:$PATH PYTHONUNBUFFERED=1
EXPOSE 8000
CMD ["uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
\`\`\`

#### 3. GPU Acceleration in Docker (NVIDIA Container Toolkit)
To expose host GPUs to PyTorch/TensorFlow containers:
\`\`\`bash
docker run --gpus all --rm -it nvidia/cuda:11.8.0-runtime-ubuntu22.04 nvidia-smi
\`\`\``,
    quickRevisionNotes: [
      'Docker packages Python, system libraries (CUDA/OpenBLAS), and code into immutable images.',
      'Multi-stage Docker builds separate heavy compilers from lean runtime images.',
      'NVIDIA Container Toolkit (`--gpus all`) exposes physical GPUs to PyTorch/TensorFlow containers.',
      'Always set `PYTHONUNBUFFERED=1` so logs stream live to container stdout.'
    ],
    formulaSheets: [
      {
        name: 'Docker GPU Allocation Syntax',
        formula: '\\text{docker run --gpus \'\"device=0,1\"\' -v \\$(pwd):/app -p 8000:8000 image\\_name}',
        description: 'Exposing specific hardware GPU devices to containerized environments.'
      }
    ],
    definitions: [
      {
        term: 'NVIDIA Container Toolkit',
        explanation: 'A container runtime extension that allows Docker containers to access host NVIDIA GPUs and CUDA drivers for accelerated deep learning inference and training.'
      }
    ],
    codeSnippets: [
      {
        language: 'yaml',
        title: 'docker-compose.yml for ML API with Redis Cache and GPU Support',
        code: `version: '3.8'

services:
  ml_api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - REDIS_URL=redis://cache:6379/0
      - MODEL_PATH=/models/model_v2.onnx
    volumes:
      - ./models:/models:ro
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    depends_on:
      - cache

  cache:
    image: redis:7-alpine
    ports:
      - "6379:6379"`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w9-q1',
        questionText: 'What is the purpose of mounting the model directory as read-only (`:ro`) in Docker (`- ./models:/models:ro`)?',
        options: ['It prevents the running container application from accidentally modifying or corrupting the trained serialized model weights during runtime inference', 'It speeds up GPU calculations by 50%', 'It encrypts the model files', 'It allows Docker to delete the files'],
        correctOptionIndex: 0,
        solution: 'Mounting model artifacts with read-only permissions (:ro) enforces security and immutability, ensuring inference containers cannot alter production model files.',
        hints: ['Protects model weights from accidental runtime modification.']
      }
    ],
    examTips: [
      'Always include `.git`, `.venv`, `__pycache__`, and raw large training datasets in `.dockerignore`.',
      'Never run container processes as the `root` user in enterprise production; create and use a dedicated `appuser`.'
    ],
    handwrittenMnemonic: 'Multi-stage keeps images slim; --gpus all passes CUDA; Mount models :ro for safety!'
  },
  {
    id: 'note-tds-w10',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 10,
    title: 'Data Pipelines & Workflow Orchestration: Apache Airflow (DAGs, Operators, Sensors)',
    detailedNotes: `### Week 10: Workflow Orchestration with Apache Airflow

#### 1. Why Workflow Orchestrators instead of Cron Scripts?
- **Cron Limitations:** No dependency management, no automatic failure retries with backoff, no web UI for pipeline monitoring, no historical backfilling, no distributed task execution.
- **Apache Airflow:** Programmatically author, schedule, and monitor workflows as **Directed Acyclic Graphs (DAGs)** of tasks written in pure Python.

#### 2. Airflow Core Architecture
- **Webserver:** UI for monitoring DAG runs, task logs, and triggering runs.
- **Scheduler:** Heartbeat daemon monitoring DAG definitions and task dependencies, queueing runnable tasks.
- **Metastore (PostgreSQL):** Stores state of all DAGs, task instances, variables, and connections.
- **Executor:** Worker pool executing tasks (Sequential, Local, Celery, or KubernetesExecutor).

#### 3. Airflow DAG Design & Operators
- **Operators:** \`PythonOperator\`, \`BashOperator\`, \`PostgresOperator\`.
- **Sensors:** \`HttpSensor\`, \`S3KeySensor\` (Wait for external conditions/files to arrive before proceeding).
- **Task Dependencies:** \`extract_task >> transform_task >> [load_db, load_s3]\``,
    quickRevisionNotes: [
      'Airflow models data pipelines as Directed Acyclic Graphs (DAGs) in Python.',
      'Core components: Webserver, Scheduler, Metastore (Postgres), and Executor (Celery/K8s).',
      'Task dependencies configured using bitshift operators (`t1 >> t2 >> [t3, t4]`).',
      'Sensors block and wait for external events/files before triggering downstream tasks.'
    ],
    formulaSheets: [
      {
        name: 'Airflow Bitshift Dependency Syntax',
        formula: '\\text{extract\\_data} \\gg \\text{clean\\_data} \\gg [\\text{train\\_model}, \\text{generate\\_report}]',
        description: 'Branching DAG task execution graph definition.'
      }
    ],
    definitions: [
      {
        term: 'Directed Acyclic Graph (DAG)',
        explanation: 'A finite directed graph with no directed cycles, ensuring data pipelines have a definitive start, unidirectional flow, and guaranteed completion without infinite loops.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Complete Airflow ETL DAG with Failure Retries and Slack Notification',
        code: `from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'data_platform_team',
    'depends_on_past': False,
    'email_on_failure': True,
    'email': ['alerts@university.org'],
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
}

def extract_sensor_data():
    print("Extracting batch sensor logs from S3...")

def transform_and_validate():
    print("Executing Polars validation pipeline...")

with DAG(
    dag_id='daily_iot_sensor_etl',
    default_args=default_args,
    description='Daily ingestion and aggregation of IoT telemetry',
    schedule_interval='0 3 * * *', # Daily at 3:00 AM UTC
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=['production', 'etl']
) as dag:

    t1_check_system = BashOperator(
        task_id='check_storage_capacity',
        bash_command='df -h /data'
    )

    t2_extract = PythonOperator(
        task_id='extract_sensor_data',
        python_callable=extract_sensor_data
    )

    t3_transform = PythonOperator(
        task_id='transform_and_validate',
        python_callable=transform_and_validate
    )

    t1_check_system >> t2_extract >> t3_transform`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w10-q1',
        questionText: 'What is the function of the `catchup=False` parameter when defining a DAG in Apache Airflow?',
        options: ['It prevents Airflow from executing historic backfill DAG runs for past intervals between start_date and current date when the DAG is first unpaused', 'It prevents tasks from failing', 'It disables logging', 'It makes the scheduler synchronous'],
        correctOptionIndex: 0,
        solution: 'By default (`catchup=True`), Airflow triggers DAG runs for every past schedule interval between start_date and today. Setting `catchup=False` runs only the most recent scheduled interval upon activating the DAG.',
        hints: ['Prevents automatic historical backfilling of old intervals.']
      }
    ],
    examTips: [
      'Keep top-level Python code outside operators minimal in DAG files, as the Airflow Scheduler parses all DAG files every few seconds.',
      'Use XComs only for passing small metadata (like S3 file paths or row counts), never for passing large multi-gigabyte dataframes directly.'
    ],
    handwrittenMnemonic: 'DAGs must be acyclic; Set catchup=False to prevent historic runaway runs; Use XCom for metadata only!'
  },
  {
    id: 'note-tds-w11',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 11,
    title: 'Model Serving & Optimization: ONNX Runtime, Quantization & Microservice Deployment',
    detailedNotes: `### Week 11: Production Model Serving & Inference Optimization

#### 1. The Model Serving Latency Challenge
Serving raw Python PyTorch/TensorFlow models directly in production creates latency and resource overhead:
- Framework overhead (loading full 800MB PyTorch binary for 2MB model).
- High inference latency.
- High memory footprint.

#### 2. Open Neural Network Exchange (ONNX) & ONNX Runtime
- **ONNX:** An open standard format representing machine learning computation graphs across frameworks (PyTorch, TensorFlow, Scikit-learn, XGBoost).
- **ONNX Runtime (ORT):** A high-performance C++ inference engine with graph optimizations (constant folding, node fusing) and hardware acceleration (TensorRT, DirectML, OpenVINO, CPU SIMD):
\`\`\`python
import torch
import onnxruntime as ort

# Export PyTorch model to ONNX
torch.onnx.export(
    model, dummy_input, "model.onnx",
    input_names=["input_features"], output_names=["output_logits"],
    dynamic_axes={"input_features": {0: "batch_size"}}
)

# High-speed Inference via C++ ONNX Runtime Session
ort_session = ort.InferenceSession("model.onnx", providers=["CPUExecutionProvider"])
outputs = ort_session.run(None, {"input_features": np_input})
\`\`\`

#### 3. Model Quantization (FP32 $\\to$ INT8)
Converts 32-bit floating point weights to 8-bit integers:
- Reduces model disk and RAM size by $75\\%$ ($4\\times$ smaller!).
- Accelerates CPU integer instruction throughput with $< 0.5\\%$ loss in accuracy.`,
    quickRevisionNotes: [
      'ONNX provides a cross-framework standard computational graph representation.',
      'ONNX Runtime (C++) performs graph optimizations and kernel fusing for low-latency inference.',
      'INT8 Quantization reduces model memory footprint by 75% while boosting throughput.',
      'Dynamic axes allow ONNX models to process arbitrary batch sizes dynamically.'
    ],
    formulaSheets: [
      {
        name: 'Uniform Symmetric INT8 Quantization',
        formula: 'q = \\text{round}\\left(\\frac{x}{S}\\right) \\quad \\text{where } S = \\frac{\\max(|x|)}{127}',
        description: 'Linear mapping from 32-bit float to 8-bit signed integer.'
      }
    ],
    definitions: [
      {
        term: 'Graph Constant Folding',
        explanation: 'An ONNX graph optimization that evaluates and replaces constant sub-expressions at compile time, eliminating redundant runtime calculations.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Optimized ONNX Runtime Inference Pipeline with Quantization',
        code: `import onnxruntime as ort
import numpy as np
from onnxruntime.quantization import quantize_dynamic, QuantType

# Step 1: Quantize FP32 model to INT8 (4x smaller!)
quantize_dynamic(
    model_input="student_model_fp32.onnx",
    model_output="student_model_int8.onnx",
    weight_type=QuantType.QInt8
)

# Step 2: Initialize optimized inference session
opts = ort.SessionOptions()
opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
opts.intra_op_num_threads = 4

session = ort.InferenceSession("student_model_int8.onnx", opts, providers=["CPUExecutionProvider"])

def run_fast_inference(feature_vector: np.ndarray) -> np.ndarray:
    # Ensure float32 contiguous array
    input_data = np.ascontiguousarray(feature_vector, dtype=np.float32)
    raw_output = session.run(["output_logits"], {"input_features": input_data})
    return raw_output[0]`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w11-q1',
        questionText: 'What is the primary operational advantage of converting trained Scikit-learn/PyTorch models into ONNX Runtime format for production web microservices?',
        options: ['Drastically reduced inference latency, minimal memory usage, and independence from heavy PyTorch/TF Python dependencies in production Docker containers', 'It generates synthetic training datasets', 'It allows models to run on quantum computers', 'It converts supervised models to unsupervised'],
        correctOptionIndex: 0,
        solution: 'ONNX Runtime is a lightweight C++ engine that executes optimized computational graphs without needing full 800MB PyTorch dependencies installed in the production container.',
        hints: ['Lowers latency, memory, and eliminates heavy Python framework dependencies.']
      }
    ],
    examTips: [
      'Always specify `dynamic_axes={"input": {0: "batch_size"}}` when exporting PyTorch models to ONNX to allow variable inference batch sizes.',
      'Warm up the ONNX Runtime session by executing a single dummy inference pass during container startup.'
    ],
    handwrittenMnemonic: 'Export to ONNX; Quantize to INT8 (4x smaller); Serve with C++ ONNX Runtime!'
  },
  {
    id: 'note-tds-w12',
    courseId: 'course-tds',
    courseTitle: 'Tools in Data Science',
    courseCode: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 12,
    title: 'MLOps, Experiment Tracking (MLflow), Data Versioning (DVC) & Model Observability',
    detailedNotes: `### Week 12: MLOps: Reproducibility, Experiment Tracking & Drift Monitoring

#### 1. The MLOps Lifecycle
Extends DevOps principles to machine learning: Code Versioning + Data Versioning + Model Versioning + Pipeline CI/CD + Model Monitoring.

#### 2. Data Version Control (DVC)
- Git cannot efficiently store multi-gigabyte datasets (causes repository bloat).
- **DVC:** Tracks large datasets and model files using lightweight \`.dvc\` pointer files stored in Git, while backing up actual binary blobs in remote cloud storage (S3, GCS, MinIO):
  - \`dvc add data/training.csv\` $\\implies$ Creates \`data/training.csv.dvc\`.
  - \`git add data/training.csv.dvc && git commit -m "track dataset v2"\`
  - \`dvc push\` & \`dvc pull\`.

#### 3. Experiment Tracking with MLflow
Tracks hyperparameters, metrics, code versions, and artifacts across training runs:
\`\`\`python
import mlflow

with mlflow.start_run(run_name="xgboost_depth_6"):
    mlflow.log_param("max_depth", 6)
    mlflow.log_param("learning_rate", 0.05)
    
    # Train model
    model.fit(X_train, y_train)
    val_auc = roc_auc_score(y_val, model.predict_proba(X_val)[:, 1])
    
    mlflow.log_metric("val_auc", val_auc)
    mlflow.sklearn.log_model(model, "model_artifact")
\`\`\`

#### 4. Model Drift & Degradation Monitoring
- **Data Drift (Covariate Shift):** $P(X)$ changes while $P(Y|X)$ remains constant (e.g. population demographics shift).
  - Detected using Kolmogorov-Smirnov (KS) test or Population Stability Index (PSI).
- **Concept Drift:** $P(Y|X)$ changes (e.g. consumer purchasing habits alter post-crisis). Requires automated retraining pipelines!`,
    quickRevisionNotes: [
      'DVC tracks large datasets via pointer files in Git while storing binaries in S3/GCS.',
      'MLflow logs hyperparameters, validation metrics, and model artifacts for reproducibility.',
      'Data drift is change in feature distribution P(X); Concept drift is change in relationship P(Y|X).',
      'Population Stability Index (PSI > 0.2) indicates significant dataset drift triggering retraining.'
    ],
    formulaSheets: [
      {
        name: 'Population Stability Index (PSI)',
        formula: '\\text{PSI} = \\sum_{i=1}^{k} \\left( \\text{Actual}\\%_i - \\text{Expected}\\%_i \\right) \\times \\ln\\left( \\frac{\\text{Actual}\\%_i}{\\text{Expected}\\%_i} \\right)',
        description: 'Metric quantifying shift between baseline and production feature distributions.'
      }
    ],
    definitions: [
      {
        term: 'Covariate Shift (Data Drift)',
        explanation: 'The scenario where the distribution of input features P(X) changes between training and production environments, while the conditional probability P(Y|X) remains unchanged.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Complete MLflow Experiment Logging & Model Registry Promotion',
        code: `import mlflow
import mlflow.sklearn
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, f1_score

mlflow.set_tracking_uri("http://localhost:5000")
mlflow.set_experiment("Student_Retention_Model")

with mlflow.start_run(run_name="gbdt_tuned_lr01") as run:
    params = {"n_estimators": 150, "learning_rate": 0.05, "max_depth": 4}
    mlflow.log_params(params)
    
    clf = GradientBoostingClassifier(**params)
    clf.fit(X_train, y_train)
    
    preds = clf.predict(X_test)
    acc = accuracy_score(y_test, preds)
    f1 = f1_score(y_test, preds)
    
    mlflow.log_metric("accuracy", acc)
    mlflow.log_metric("f1_score", f1)
    
    # Register model to MLflow Model Registry
    mlflow.sklearn.log_model(
        sk_model=clf,
        artifact_path="model",
        registered_model_name="StudentRetentionModel"
    )
    print(f"Logged run: {run.info.run_id} | Accuracy: {acc:.4f}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'tds-w12-q1',
        questionText: 'What is the primary difference between Data Drift (Covariate Shift) and Concept Drift in production ML systems?',
        options: ['Data Drift is a change in the input feature distribution P(X), while Concept Drift is a change in the statistical relationship between input features and target labels P(Y|X)', 'Data Drift means the server lost power', 'Concept Drift means Python was upgraded', 'They are completely identical terms'],
        correctOptionIndex: 0,
        solution: 'In Data Drift, the characteristics of incoming inputs change (e.g. new user demographics). In Concept Drift, the fundamental definition of the target variable shifts (e.g. fraud patterns evolve).',
        hints: ['P(X) shift vs P(Y|X) relationship shift.']
      }
    ],
    examTips: [
      'In MLflow, promote models through stages (`Staging` -> `Production` -> `Archived`) to manage release lifecycles cleanly.',
      'Automate retraining pipelines using Airflow triggers whenever PSI exceeds 0.25 or production accuracy degrades.'
    ],
    handwrittenMnemonic: 'DVC versions data; MLflow tracks metrics & artifacts; Monitor PSI for drift!'
  }
];

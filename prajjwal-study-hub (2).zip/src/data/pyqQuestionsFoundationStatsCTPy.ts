import { Question } from '../types';

export const FOUNDATION_STATS_CT_PY_QUESTIONS: Question[] = [
  // ==========================================
  // STATISTICS FOR DATA SCIENCE 1
  // ==========================================
  {
    id: 'pyq-s1-poisson-dist-nat',
    courseId: 'course-stat-1',
    courseTitle: 'Statistics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Statistics for Data Science 1',
    type: 'NAT',
    questionText: 'Customers arrive at a bank teller counter according to a Poisson process with an average rate of $\\lambda = 2$ customers per minute. What is the exact probability that at least 1 customer arrives in a given 1-minute interval? (Given $e^{-2} \\approx 0.1353$. Enter your answer rounded to 4 decimal places).',
    options: [],
    correctNumericAnswer: 0.8647,
    numericTolerance: 0.001,
    toleranceRange: [0.8637, 0.8657],
    explanation: `Poisson Distribution Complement Rule:
1. Poisson PMF: $P(X = k) = \\frac{e^{-\\lambda} \\lambda^k}{k!}$.
2. The probability of at least 1 arrival:
   $$P(X \\ge 1) = 1 - P(X = 0)$$
3. Calculate $P(X = 0)$:
   $$P(X = 0) = \\frac{e^{-2} 2^0}{0!} = e^{-2} \\approx 0.135335$$
4. Therefore:
   $$P(X \\ge 1) = 1 - 0.135335 = 0.864665 \\approx 0.8647$$`,
    hints: [
      'Use the complement rule: $P(X \\ge 1) = 1 - P(X = 0)$.',
      'For a Poisson distribution, $P(X = 0) = e^{-\\lambda}$.'
    ],
    formulaRef: 'P(X = k) = \\frac{e^{-\\lambda} \\lambda^k}{k!}',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Jan 2024 (Quiz 1)',
    tags: ['Statistics 1', 'Probability', 'Poisson Distribution'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-s1-normal-standardization-mcq',
    courseId: 'course-stat-1',
    courseTitle: 'Statistics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Statistics for Data Science 1',
    type: 'MCQ',
    questionText: 'Scores on an aptitude exam follow a normal distribution $X \\sim \\mathcal{N}(\\mu = 500, \\sigma^2 = 100^2)$. If a student scored $650$, what is the standardized $Z$-score, and what percentage of candidates scored below this student (given standard normal CDF $\\Phi(1.5) \\approx 0.9332$)?',
    options: [
      '$Z = +1.50$, and approximately $93.32\\%$ of candidates scored below this student',
      '$Z = +1.25$, and approximately $89.44\\%$ of candidates scored below this student',
      '$Z = +1.50$, and approximately $6.68\\%$ of candidates scored below this student',
      '$Z = -1.50$, and approximately $93.32\\%$ of candidates scored below this student'
    ],
    correctOptionIndex: 0,
    explanation: `Standard Normal Transformation:
1. $Z$-score calculation:
   $$Z = \\frac{X - \\mu}{\\sigma} = \\frac{650 - 500}{100} = \\frac{150}{100} = +1.50$$
2. Percentile below score:
   $$P(X < 650) = P(Z < 1.50) = \\Phi(1.50) = 0.9332 = 93.32\\%$$`,
    hints: [
      'Compute $Z = \\frac{X - \\mu}{\\sigma}$.',
      'The cumulative distribution function $\\Phi(Z)$ gives the fraction of the population below that $Z$.'
    ],
    formulaRef: 'Z = \\frac{X - \\mu}{\\sigma}',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'Sept 2024 (Quiz 2)',
    tags: ['Statistics 1', 'Normal Distribution', 'Z-Score', 'CDF'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // STATISTICS FOR DATA SCIENCE 2
  // ==========================================
  {
    id: 'pyq-s2-clt-sample-mean-nat',
    courseId: 'course-stat-2',
    courseTitle: 'Statistics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Statistics for Data Science 2',
    type: 'NAT',
    questionText: 'A random sample of size $n = 64$ is drawn from a population with mean $\\mu = 100$ and standard deviation $\\sigma = 16$. What is the standard error of the sample mean $\\sigma_{\\bar{X}} = \\frac{\\sigma}{\\sqrt{n}}$?',
    options: [],
    correctNumericAnswer: 2,
    numericTolerance: 0.01,
    toleranceRange: [1.99, 2.01],
    explanation: `Central Limit Theorem Standard Error:
$$\\sigma_{\\bar{X}} = \\frac{\\sigma}{\\sqrt{n}} = \\frac{16}{\\sqrt{64}} = \\frac{16}{8} = 2.0$$`,
    hints: [
      'Standard error is the population standard deviation divided by the square root of sample size.'
    ],
    formulaRef: '\\sigma_{\\bar{X}} = \\frac{\\sigma}{\\sqrt{n}}',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 2',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['Statistics 2', 'Central Limit Theorem', 'Standard Error'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-s2-confidence-interval-msq',
    courseId: 'course-stat-2',
    courseTitle: 'Statistics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Statistics for Data Science 2',
    type: 'MSQ',
    questionText: 'Which of the following statements regarding Confidence Intervals (CI) and Hypothesis Testing are statistically accurate?',
    options: [
      'A $95\\%$ confidence interval means that in repeated independent sampling, approximately $95\\%$ of such constructed intervals will contain the true population parameter $\\mu$.',
      'Increasing the sample size $n$ by a factor of 4 reduces the width of the confidence interval by a factor of 2, holding confidence level constant.',
      'A Type I error occurs when the true null hypothesis $H_0$ is incorrectly rejected (False Positive).',
      'The $p$-value represents the probability that the null hypothesis $H_0$ is true given the observed data.'
    ],
    correctOptionIndices: [0, 1, 2],
    explanation: `Statistical Interpretation Audit:
1. Statement A is TRUE: Frequentist definition of confidence intervals.
2. Statement B is TRUE: Margin of error $E = z^* \\frac{\\sigma}{\\sqrt{n}}$. Quadrupling $n$ multiplies denominator by $\\sqrt{4} = 2$, halving the interval width.
3. Statement C is TRUE: $\\alpha = P(\\text{Reject } H_0 \\mid H_0 \\text{ is True})$.
4. Statement D is FALSE: The $p$-value is $P(\\text{Data as or more extreme} \\mid H_0 \\text{ is True})$, NOT the probability that $H_0$ is true (common statistical trap!).`,
    hints: [
      'Recall the precise frequentist definition of $p$-value: $P(\\text{observed or more extreme} \\mid H_0)$.'
    ],
    formulaRef: '\\text{CI} = \\bar{x} \\pm z_{\\alpha/2} \\frac{\\sigma}{\\sqrt{n}}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 2',
    pyqYear: 'Jan 2025 (Quiz 2)',
    tags: ['Statistics 2', 'Confidence Intervals', 'Type I Error', 'p-value'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // COMPUTATIONAL THINKING
  // ==========================================
  {
    id: 'pyq-ct-recursion-trace-nat',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Computational Thinking',
    type: 'NAT',
    questionText: 'Consider the recursive algorithm `Foo(n)`:\n```\nProcedure Foo(n)\n  If n <= 1 then\n    Return 1\n  Else\n    Return Foo(n - 1) + 2 * Foo(n - 2)\n  End If\nEnd Procedure\n```\nWhat is the exact integer value returned by `Foo(4)`?',
    options: [],
    correctNumericAnswer: 11,
    numericTolerance: 0,
    toleranceRange: [11, 11],
    explanation: `Step-by-step Recursion Tree:
- Base cases:
  - Foo(0) = 1
  - Foo(1) = 1
- For n = 2:
  - Foo(2) = Foo(1) + 2 * Foo(0) = 1 + 2(1) = 3
- For n = 3:
  - Foo(3) = Foo(2) + 2 * Foo(1) = 3 + 2(1) = 5
- For n = 4:
  - Foo(4) = Foo(3) + 2 * Foo(2) = 5 + 2(3) = 5 + 6 = 11`,
    hints: [
      'Build values bottom-up from base cases $n=0$ and $n=1$.',
      'Compute $\\text{Foo}(2)$, then $\\text{Foo}(3)$, then $\\text{Foo}(4)$.'
    ],
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'May 2024 (End Term)',
    tags: ['Computational Thinking', 'Recursion', 'Trace Tables'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // PYTHON PROGRAMMING
  // ==========================================
  {
    id: 'pyq-py-dict-comprehension-mcq',
    courseId: 'course-python',
    courseTitle: 'Introduction to Python Programming',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Introduction to Python Programming',
    type: 'CODE_OUTPUT',
    questionText: 'What is the output of the following Python snippet?',
    codeSnippet: `words = ['apple', 'bat', 'cherry', 'date']
lengths = {w: len(w) for w in words if len(w) % 2 == 0}
print(sorted(lengths.values()))`,
    options: [
      '[4, 6]',
      '[3, 4, 5, 6]',
      '[4, 4]',
      '[6]'
    ],
    correctOptionIndex: 0,
    explanation: `Execution Analysis:
1. \`len('apple') = 5\` (odd, skipped)
2. \`len('bat') = 3\` (odd, skipped)
3. \`len('cherry') = 6\` (even, included $\\implies$ \`'cherry': 6\`)
4. \`len('date') = 4\` (even, included $\\implies$ \`'date': 4\`)
5. \`lengths.values()\` are $6$ and $4$.
6. \`sorted([6, 4]) = [4, 6]\`.`,
    hints: [
      'Filter selects words whose length is even (\`len(w) % 2 == 0\`).',
      'Check lengths of cherry (6) and date (4).'
    ],
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'Sept 2024 (Quiz 1)',
    tags: ['Python', 'Dictionaries', 'Comprehensions', 'Builtins'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

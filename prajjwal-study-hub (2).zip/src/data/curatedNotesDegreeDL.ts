import { WeeklyStudyMaterial } from '../types';

export const DEGREE_DEEP_LEARNING_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-dl-w1',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 1,
    title: 'Biological to Artificial Neurons, Perceptron Convergence & Multilayer Perceptrons (MLP)',
    detailedNotes: `### Week 1: Foundations of Artificial Neural Networks

#### 1. The McCulloch-Pitts & Rosenblatt Perceptron
A single artificial neuron computes affine combination followed by activation $\\phi$:
$$z = \\mathbf{w}^T \\mathbf{x} + b = \\sum_{i=1}^d w_i x_i + b, \\quad y = \\phi(z)$$
- **Perceptron Learning Rule:** For step activation $\\phi(z) = \\text{sgn}(z)$ with target $y \\in \\{-1, +1\\}$:
$$\\text{If } y_i (\\mathbf{w}^T \\mathbf{x}_i) \\le 0 \\implies \\mathbf{w} \\leftarrow \\mathbf{w} + \\eta y_i \\mathbf{x}_i$$
- **Novikoff\'s Perceptron Convergence Theorem:** If data is linearly separable with margin $\\gamma > 0$ and $\\|\\mathbf{x}_i\\| \\le R$, the perceptron algorithm makes at most $k \\le \\left( \\frac{R}{\\gamma} \\right)^2$ mistakes before converging!

#### 2. Multilayer Perceptrons (MLP) & The XOR Problem
- A single perceptron cannot learn non-linearly separable functions (like XOR).
- MLPs with at least one non-linear hidden layer can represent arbitrary Boolean functions.
- **Universal Approximation Theorem (Cybenko, Hornik):** A feedforward network with a single hidden layer containing a finite number of non-linear neurons (e.g., Sigmoid, ReLU) can approximate any continuous function on compact subsets of $\\mathbb{R}^d$ to arbitrary precision.`,
    quickRevisionNotes: [
      'Perceptron mistake bound: $k \\le (R / \\gamma)^2$ for margin $\\gamma$.',
      'Non-linear activation functions are ESSENTIAL; stacking linear layers collapses to a single linear layer $W_2(W_1 x) = (W_2 W_1)x$.',
      'Universal Approximation Theorem guarantees representational capacity, but does NOT guarantee optimization tractability via SGD.'
    ],
    formulaSheets: [
      {
        name: 'Perceptron Convergence Mistake Bound',
        formula: 'k \\le \\left( \\frac{R}{\\gamma} \\right)^2',
        description: 'Maximum misclassification updates before reaching zero training error on linearly separable data.'
      }
    ],
    definitions: [
      {
        term: 'Universal Approximation Theorem',
        explanation: 'Guarantees that a feedforward network with one non-linear hidden layer can approximate any continuous function arbitrarily well.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Single Perceptron Binary Classifier from Scratch',
        code: `import numpy as np

class Perceptron:
    def __init__(self, lr=0.1, epochs=100):
        self.lr = lr
        self.epochs = epochs
        
    def fit(self, X, y):
        self.w = np.zeros(X.shape[1])
        self.b = 0.0
        for _ in range(self.epochs):
            for xi, target in zip(X, y):
                pred = 1 if (np.dot(xi, self.w) + self.b) >= 0 else -1
                if pred != target:
                    self.w += self.lr * target * xi
                    self.b += self.lr * target`
      }
    ],
    examTips: [
      'Stacking multiple linear layers without activation functions produces NO additional expressiveness: $y = W_3 W_2 W_1 x = W_{\\text{combined}} x$.',
      'Perceptron cycling: If data is NOT linearly separable, the standard perceptron learning rule will loop forever without terminating.'
    ],
    handwrittenMnemonic: 'Non-linear activations break linear collapse; $k \\le (R/\\gamma)^2$ bounds mistakes!'
  },
  {
    id: 'note-dl-w2',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 2,
    title: 'Backpropagation Derivation, Computational Graphs & Automatic Differentiation',
    detailedNotes: `### Week 2: Analytical Backpropagation & Gradient Flow

#### 1. Forward Pass Formulation
For layer $l \\in \\{1, \\dots, L\\}$:
$$\\mathbf{z}^{[l]} = W^{[l]} \\mathbf{a}^{[l-1]} + \\mathbf{b}^{[l]}, \\quad \\mathbf{a}^{[l]} = g^{[l]}(\\mathbf{z}^{[l]})$$
where $\\mathbf{a}^{[0]} = \\mathbf{x}$ and $\\hat{\\mathbf{y}} = \\mathbf{a}^{[L]}$.

#### 2. Analytical Backpropagation Equations (Chain Rule)
Define error vector at output layer $L$:
$$\\boldsymbol{\\delta}^{[L]} = \\nabla_{\\mathbf{z}^{[L]}} \\mathcal{L} = \\nabla_{\\mathbf{a}^{[L]}} \\mathcal{L} \\odot {g^{[L]}}\'(\\mathbf{z}^{[L]})$$
For Softmax with Cross-Entropy Loss: $\\boldsymbol{\\delta}^{[L]} = \\hat{\\mathbf{y}} - \\mathbf{y}$.

**Backward Recursion for Hidden Layers ($l = L-1, \\dots, 1$):**
$$\\boldsymbol{\\delta}^{[l]} = \\left( (W^{[l+1]})^T \\boldsymbol{\\delta}^{[l+1]} \\right) \\odot {g^{[l]}}\'(\\mathbf{z}^{[l]})$$
**Weight & Bias Gradients:**
$$\\frac{\\partial \\mathcal{L}}{\\partial W^{[l]}} = \\boldsymbol{\\delta}^{[l]} (\\mathbf{a}^{[l-1]})^T, \\quad \\frac{\\partial \\mathcal{L}}{\\partial \\mathbf{b}^{[l]}} = \\boldsymbol{\\delta}^{[l]}$$`,
    quickRevisionNotes: [
      'Backpropagation is reverse-mode automatic differentiation applying the multivariable chain rule.',
      'Softmax output with Cross-Entropy loss gives the clean gradient $\\boldsymbol{\\delta}^{[L]} = \\hat{\\mathbf{y}} - \\mathbf{y}$.',
      'Gradients with respect to weights: $\\frac{\\partial \\mathcal{L}}{\\partial W^{[l]}} = \\boldsymbol{\\delta}^{[l]} (\\mathbf{a}^{[l-1]})^T$.'
    ],
    formulaSheets: [
      {
        name: 'The Four Fundamental Backpropagation Equations',
        formula: '\\boldsymbol{\\delta}^{[l]} = \\left( (W^{[l+1]})^T \\boldsymbol{\\delta}^{[l+1]} \\right) \\odot g\'(\\mathbf{z}^{[l]}), \\quad \\frac{\\partial \\mathcal{L}}{\\partial W^{[l]}} = \\boldsymbol{\\delta}^{[l]} (\\mathbf{a}^{[l-1]})^T',
        description: 'Error propagation and parameter derivative calculations.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Full 2-Layer Neural Network Backpropagation in NumPy',
        code: `def forward_backward_pass(X, y, W1, b1, W2, b2):
    # Forward Pass
    Z1 = np.dot(X, W1) + b1
    A1 = np.maximum(0, Z1) # ReLU activation
    Z2 = np.dot(A1, W2) + b2
    # Softmax
    exp_Z2 = np.exp(Z2 - np.max(Z2, axis=1, keepdims=True))
    A2 = exp_Z2 / np.sum(exp_Z2, axis=1, keepdims=True)
    
    # Backward Pass
    N = X.shape[0]
    dZ2 = (A2 - y) / N
    dW2 = np.dot(A1.T, dZ2)
    db2 = np.sum(dZ2, axis=0, keepdims=True)
    
    dA1 = np.dot(dZ2, W2.T)
    dZ1 = dA1 * (Z1 > 0) # ReLU derivative
    dW1 = np.dot(X.T, dZ1)
    db1 = np.sum(dZ1, axis=0, keepdims=True)
    
    return dW1, db1, dW2, db2`
      }
    ],
    examTips: [
      'Vanishing Gradients: When using Sigmoid activations $\\sigma\'(z) \\le 0.25$. Multiplying $L$ such small fractions causes gradients in early layers to vanish exponentially towards 0. Use ReLU instead!',
      'Exploding Gradients: Prevented using **Gradient Clipping** ($\\|\\mathbf{g}\\| \\leftarrow \\min(1, \\frac{\\text{threshold}}{\\|\\mathbf{g}\\|}) \\mathbf{g}$).'
    ],
    handwrittenMnemonic: 'Error propagates backward via $(W^{[l+1]})^T \\delta^{[l+1]}$; scale by activation derivative!'
  },
  {
    id: 'note-dl-w3',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 3,
    title: 'Activation Functions, Weight Initializations (He & Xavier) & Batch Normalization',
    detailedNotes: `### Week 3: Deep Architecture Stabilization

#### 1. Modern Activation Functions
- **ReLU (Rectified Linear Unit):** $f(z) = \\max(0, z)$. Derivative is $1$ for $z > 0$. Eliminates vanishing gradients in positive regime. Problem: "Dying ReLU" for $z < 0$.
- **Leaky ReLU:** $f(z) = \\max(\\alpha z, z)$ with $\\alpha \\approx 0.01$.
- **GELU (Gaussian Error Linear Unit):** $f(z) = z \\Phi(z) = z P(X \\le z)$ where $X \\sim \\mathcal{N}(0, 1)$ (standard in Transformers).

#### 2. Weight Initialization Schemes
- **Xavier / Glorot Initialization (for Tanh / Sigmoid):**
$$W \\sim \\mathcal{N}\\left(0, \\frac{2}{n_{\\text{in}} + n_{\\text{out}}}\\right)$$
- **He / Kaiming Initialization (for ReLU / Leaky ReLU):**
$$W \\sim \\mathcal{N}\\left(0, \\frac{2}{n_{\\text{in}}}\\right)$$
- *Why:* Keeps variance of layer activations and gradients constant across all depth levels!

#### 3. Batch Normalization (Ioffe & Szegedy)
Normalizes mini-batch inputs $\\mathcal{B} = \\{z_1, \\dots, z_m\\}$:
$$\\mu_\\mathcal{B} = \\frac{1}{m} \\sum_{i=1}^m z_i, \\quad \\sigma_\\mathcal{B}^2 = \\frac{1}{m} \\sum_{i=1}^m (z_i - \\mu_\\mathcal{B})^2$$
$$\\hat{z}_i = \\frac{z_i - \\mu_\\mathcal{B}}{\\sqrt{\\sigma_\\mathcal{B}^2 + \\epsilon}}, \\quad y_i = \\gamma \\hat{z}_i + \\beta$$
where $\\gamma$ (scale) and $\\beta$ (shift) are learnable parameters.`,
    quickRevisionNotes: [
      'Use He initialization with ReLU; Xavier initialization with Sigmoid/Tanh.',
      'Batch Normalization reduces internal covariate shift and smooths optimization loss landscape.',
      'At test/inference time, BatchNorm replaces mini-batch stats with exponential running averages (no dependency on batch size!).'
    ],
    formulaSheets: [
      {
        name: 'He (Kaiming) Weight Variance & BatchNorm',
        formula: '\\text{Var}(W) = \\frac{2}{n_{\\text{in}}}, \\quad y_i = \\gamma \\left( \\frac{z_i - \\mu_\\mathcal{B}}{\\sqrt{\\sigma_\\mathcal{B}^2 + \\epsilon}} \\right) + \\beta',
        description: 'Variance stabilization for deep ReLU networks and learnable batch scaling.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'PyTorch Layer with He Initialization & BatchNorm',
        code: `import torch
import torch.nn as nn

class StableBlock(nn.Module):
    def __init__(self, in_features, out_features):
        super().__init__()
        self.fc = nn.Linear(in_features, out_features)
        # He (Kaiming) Normal Initialization
        nn.init.kaiming_normal_(self.fc.weight, nonlinearity='relu')
        self.bn = nn.BatchNorm1d(out_features)
        self.relu = nn.ReLU()
        
    def forward(self, x):
        return self.relu(self.bn(self.fc(x)))`
      }
    ],
    examTips: [
      'Never initialize weights to all zeros ($W = 0$)! All neurons in a layer will compute identical gradients and fail to break symmetry.',
      'Biases can safely be initialized to zero ($b = 0$).'
    ],
    handwrittenMnemonic: 'He for ReLU (Var=$2/n_{\\text{in}}$); Xavier for Tanh (Var=$2/(n_{\\text{in}}+n_{\\text{out}})$)!'
  },
  {
    id: 'note-dl-w4',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 4,
    title: 'Convolutional Neural Networks (CNNs): Convolutions, Pooling & Receptive Fields',
    detailedNotes: `### Week 4: Spatial Inductive Biases & Computer Vision

#### 1. 2D Convolution Operation
For input feature map $X \\in \\mathbb{R}^{H \\times W \\times C_{\\text{in}}}$ and filter kernel $K \\in \\mathbb{R}^{K_h \\times K_w \\times C_{\\text{in}}}$:
$$S(i, j) = (X * K)(i, j) = \\sum_{m} \\sum_{n} \\sum_{c} X(i+m, j+n, c) \\cdot K(m, n, c) + b$$
- **Output Spatial Dimensions Formula:**
$$H_{\\text{out}} = \\left\\lfloor \\frac{H_{\\text{in}} - K_h + 2P}{S} \\right\\rfloor + 1, \\quad W_{\\text{out}} = \\left\\lfloor \\frac{W_{\\text{in}} - K_w + 2P}{S} \\right\\rfloor + 1$$
where $P$ is padding and $S$ is stride.
- **"Same" Padding:** $P = \\frac{K - 1}{2}$ (for odd kernel size $K$ and stride $S=1$) keeps $H_{\\text{out}} = H_{\\text{in}}$.

#### 2. Key CNN Properties
1. **Local Connectivity (Sparse Interactions):** Each neuron connects only to a small spatial patch.
2. **Parameter Sharing (Equivariance to Translation):** The same kernel weights slide across the entire image.
3. **Pooling (Max / Average):** Reduces spatial dimension and provides invariance to small local shifts.`,
    quickRevisionNotes: [
      'Output size formula: $\\lfloor \\frac{N + 2P - F}{S} \\rfloor + 1$.',
      'Parameter count of Conv layer: $(\\text{Filter Height} \\times \\text{Filter Width} \\times C_{\\text{in}} + 1) \\times C_{\\text{out}}$.',
      'Two consecutive $3\\times3$ convolutions have the same effective receptive field as a single $5\\times5$ convolution, with fewer parameters!'
    ],
    formulaSheets: [
      {
        name: 'CNN Output Dimension & Parameter Count',
        formula: 'O = \\left\\lfloor \\frac{W - F + 2P}{S} \\right\\rfloor + 1, \\quad \\text{Params} = (F_h \\cdot F_w \\cdot C_{\\text{in}} + 1) \\cdot C_{\\text{out}}',
        description: 'Spatial transform math and weight complexity calculation.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'PyTorch Convolutional Block',
        code: `import torch.nn as nn

class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        # Kernel 3x3, Padding 1 keeps spatial dimensions unchanged for Stride 1
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.bn = nn.BatchNorm2d(out_channels)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.relu = nn.ReLU()
        
    def forward(self, x):
        return self.pool(self.relu(self.bn(self.conv(x))))`
      }
    ],
    examTips: [
      'Pooling layers have ZERO learnable parameters (weights); they only perform fixed downsampling (Max or Average).',
      'Watch out: Padding $P$ is added to BOTH sides of the image (hence $2P$ in the numerator!).'
    ],
    handwrittenMnemonic: 'Conv output: $\\lfloor (N + 2P - F)/S \\rfloor + 1$!'
  },
  {
    id: 'note-dl-w5',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 5,
    title: 'Modern CNN Architectures: ResNet Residual Connections, DenseNet & EfficientNet',
    detailedNotes: `### Week 5: Deep Residual Learning & Scaling Laws

#### 1. The Degradation Problem & ResNet (He et al.)
As networks get deeper, accuracy saturates and degrades rapidly not due to overfitting (training error also increases!).
- **Residual Block formulation:** Instead of fitting underlying mapping $\\mathcal{H}(\\mathbf{x})$, fit residual $\\mathcal{F}(\\mathbf{x}) = \\mathcal{H}(\\mathbf{x}) - \\mathbf{x}$:
$$\\mathbf{y} = \\mathcal{F}(\\mathbf{x}, \\{W_i\\}) + \\mathbf{x}$$
- **Gradient Highway:** $\\frac{\\partial \\mathcal{E}}{\\partial \\mathbf{x}} = \\frac{\\partial \\mathcal{E}}{\\partial \\mathbf{y}} \\left( \\frac{\\partial \\mathcal{F}}{\\partial \\mathbf{x}} + I \\right)$. The identity term $I$ guarantees gradients flow directly to early layers without vanishing!

#### 2. Advanced Vision Backbones
- **DenseNet:** Connects each layer to every other layer in a feedforward fashion: $\\mathbf{x}_l = H_l([\\mathbf{x}_0, \\mathbf{x}_1, \\dots, \\mathbf{x}_{l-1}])$ (feature concatenation).
- **Depthwise Separable Convolutions (MobileNet):** Splits standard convolution into Depthwise ($3\\times3$ per channel) + Pointwise ($1\\times1$ across channels). Reduces computation cost by $\\approx \\frac{1}{N} + \\frac{1}{K^2} \\approx 8-9\\times$!`,
    quickRevisionNotes: [
      'ResNet identity shortcut provides an uninterrupted gradient superhighway: $\\frac{\\partial \\mathcal{L}}{\\partial \\mathbf{x}} = \\frac{\\partial \\mathcal{L}}{\\partial \\mathbf{y}} (\\frac{\\partial \\mathcal{F}}{\\partial \\mathbf{x}} + I)$.',
      'DenseNet uses feature concatenation ($\`torch.cat\`); ResNet uses element-wise addition (\`+\`).',
      'Depthwise separable convolution reduces operations from $D_K^2 \\cdot M \\cdot N$ to $D_K^2 \\cdot M + M \\cdot N$.'
    ],
    formulaSheets: [
      {
        name: 'ResNet Skip Connection & Gradient Flow',
        formula: '\\mathbf{y} = \\mathcal{F}(\\mathbf{x}) + \\mathbf{x} \\implies \\frac{\\partial \\mathcal{E}}{\\partial \\mathbf{x}} = \\frac{\\partial \\mathcal{E}}{\\partial \\mathbf{y}} \\left( \\frac{\\partial \\mathcal{F}}{\\partial \\mathbf{x}} + I \\right)',
        description: 'Identity shortcut preventing vanishing gradient in 100+ layer architectures.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'ResNet BasicBlock in PyTorch',
        code: `class ResNetBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(channels)
        self.relu = nn.ReLU()
        
    def forward(self, x):
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += identity  # Skip connection
        return self.relu(out)`
      }
    ],
    examTips: [
      'If spatial dimensions or channel counts change across layers, the identity shortcut must use a $1\\times1$ convolution: $\\mathbf{y} = \\mathcal{F}(\\mathbf{x}) + W_s \\mathbf{x}$.',
      'ResNet does not just solve vanishing gradient; it allows the model to learn identity mappings trivially if extra layers are redundant.'
    ],
    handwrittenMnemonic: 'Residual skip connection: $\\mathbf{y} = \\mathcal{F}(\\mathbf{x}) + \\mathbf{x}$; $+I$ keeps gradient alive!'
  },
  {
    id: 'note-dl-w6',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 6,
    title: 'Recurrent Neural Networks (RNNs), Backpropagation Through Time (BPTT) & Gated Architectures (LSTM & GRU)',
    detailedNotes: `### Week 6: Sequential Modeling & Gated Recurrence

#### 1. Standard RNN & Hidden State Updates
For time step $t \\in \\{1, \\dots, T\\}$:
$$\\mathbf{h}_t = \\tanh(W_{hh} \\mathbf{h}_{t-1} + W_{xh} \\mathbf{x}_t + \\mathbf{b}_h), \\quad \\hat{\\mathbf{y}}_t = \\text{softmax}(W_{hy} \\mathbf{h}_t + \\mathbf{b}_y)$$
- **Backpropagation Through Time (BPTT):** Gradients contain products $\\prod_{k=t}^T \\frac{\\partial \\mathbf{h}_k}{\\partial \\mathbf{h}_{k-1}} = \\prod W_{hh}^T \\text{diag}(1 - \\tanh^2(\\dots))$. Long sequences cause severe vanishing/exploding gradients!

#### 2. Long Short-Term Memory (LSTM - Hochreiter & Schmidhuber)
Maintains internal cell state $\\mathbf{c}_t$ governed by three multiplicative gates:
1. **Forget Gate:** $\\mathbf{f}_t = \\sigma(W_f [\\mathbf{h}_{t-1}, \\mathbf{x}_t] + \\mathbf{b}_f)$ (what to discard from cell).
2. **Input Gate & Candidate:** $\\mathbf{i}_t = \\sigma(W_i [\\mathbf{h}_{t-1}, \\mathbf{x}_t] + \\mathbf{b}_i), \\quad \\tilde{\\mathbf{c}}_t = \\tanh(W_c [\\mathbf{h}_{t-1}, \\mathbf{x}_t] + \\mathbf{b}_c)$.
3. **Cell State Update:** $\\mathbf{c}_t = \\mathbf{f}_t \\odot \\mathbf{c}_{t-1} + \\mathbf{i}_t \\odot \\tilde{\\mathbf{c}}_t$.
4. **Output Gate & Hidden State:** $\\mathbf{o}_t = \\sigma(W_o [\\mathbf{h}_{t-1}, \\mathbf{x}_t] + \\mathbf{b}_o), \\quad \\mathbf{h}_t = \\mathbf{o}_t \\odot \\tanh(\\mathbf{c}_t)$.`,
    quickRevisionNotes: [
      'LSTM cell state $\\mathbf{c}_t$ acts as a linear conveyor belt: $\\mathbf{c}_t = \\mathbf{f}_t \\odot \\mathbf{c}_{t-1} + \\dots$, preventing vanishing gradients.',
      'GRU has only 2 gates (Reset and Update) with NO separate cell state (faster training).',
      'Standard RNNs cannot capture dependencies beyond 10-20 steps.'
    ],
    formulaSheets: [
      {
        name: 'LSTM Cell State & Gate Equations',
        formula: '\\mathbf{c}_t = \\mathbf{f}_t \\odot \\mathbf{c}_{t-1} + \\mathbf{i}_t \\odot \\tilde{\\mathbf{c}}_t, \\quad \\mathbf{h}_t = \\mathbf{o}_t \\odot \\tanh(\\mathbf{c}_t)',
        description: 'Gated linear conveyor belt preserving long-range sequence context.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'PyTorch LSTM Sequence Classifier',
        code: `import torch
import torch.nn as nn

class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_classes):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, num_classes)
        
    def forward(self, x):
        embedded = self.embedding(x)
        out, (hn, cn) = self.lstm(embedded)
        # Use final hidden state hn[-1] for classification
        return self.fc(hn[-1])`
      }
    ],
    examTips: [
      'In LSTM, initialize the Forget Gate bias to $1.0$ ($b_f = 1$) to prevent forgetting everything at the start of training!',
      'Gradients can flow through cell state $\\mathbf{c}_t$ with no attenuation when forget gate $f_t \\approx 1$.'
    ],
    handwrittenMnemonic: 'Forget Gate decides what to drop; Cell State is the uninterrupted memory highway!'
  },
  {
    id: 'note-dl-w7',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 7,
    title: 'Attention Mechanism & Transformers: Scaled Dot-Product & Multi-Head Self-Attention',
    detailedNotes: `### Week 7: Attention Mechanisms & The Transformer Architecture

#### 1. Scaled Dot-Product Attention (Vaswani et al.)
Given Queries $Q \\in \\mathbb{R}^{N \\times d_k}$, Keys $K \\in \\mathbb{R}^{M \\times d_k}$, and Values $V \\in \\mathbb{R}^{M \\times d_v}$:
$$\\text{Attention}(Q, K, V) = \\text{softmax}\\left( \\frac{Q K^T}{\\sqrt{d_k}} + M \\right) V$$
- **Why Scale by $\\frac{1}{\\sqrt{d_k}}$:** For large $d_k$, dot products grow large in magnitude, pushing softmax into regions with extremely small gradients. Dividing by $\\sqrt{d_k}$ preserves unit variance.
- $M$ is the causal attention mask (sets future positions to $-\\infty$ in autoregressive decoders).

#### 2. Multi-Head Attention (MHA)
Allows the model to jointly attend to information from different representation subspaces:
$$\\text{MultiHead}(Q, K, V) = \\text{Concat}(\\text{head}_1, \\dots, \\text{head}_h) W^O$$
$$\\text{where } \\text{head}_i = \\text{Attention}(Q W_i^Q, K W_i^K, V W_i^V)$$

#### 3. Positional Encoding
Since self-attention is permutation-equivariant, positional information is injected using sinusoids:
$$PE_{(pos, 2i)} = \\sin\\left( \\frac{pos}{10000^{2i/d_{\\text{model}}}} \\right), \\quad PE_{(pos, 2i+1)} = \\cos\\left( \\frac{pos}{10000^{2i/d_{\\text{model}}}} \\right)$$`,
    quickRevisionNotes: [
      'Self-attention computational complexity is $O(N^2 d)$ with respect to sequence length $N$.',
      'Scaling factor $\\frac{1}{\\sqrt{d_k}}$ prevents softmax saturation and vanishing gradients.',
      'Positional encodings provide sequence order information to permutation-invariant attention matrices.'
    ],
    formulaSheets: [
      {
        name: 'Scaled Dot-Product Attention',
        formula: '\\text{Attention}(Q, K, V) = \\text{softmax}\\left( \\frac{Q K^T}{\\sqrt{d_k}} \\right) V',
        description: 'Core mechanism of Transformer models.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Scaled Dot-Product Attention in Pure PyTorch',
        code: `import torch
import torch.nn.functional as F

def scaled_dot_product_attention(Q, K, V, mask=None):
    d_k = Q.size(-1)
    # Compute attention scores: (batch, heads, seq_len, seq_len)
    scores = torch.matmul(Q, K.transpose(-2, -1)) / (d_k ** 0.5)
    if mask is not None:
        scores = scores.masked_fill(mask == 0, -1e9)
    weights = F.softmax(scores, dim=-1)
    output = torch.matmul(weights, V)
    return output, weights`
      }
    ],
    examTips: [
      'Self-attention has constant path length $O(1)$ between any two sequence positions regardless of distance (unlike RNNs which require $O(N)$ steps).',
      'Causal attention mask in decoder must be an upper-triangular matrix filled with $-\\infty$.'
    ],
    handwrittenMnemonic: 'Queries match Keys $\\to$ Softmax weights $\\to$ Blend Values!'
  },
  {
    id: 'note-dl-w8',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 8,
    title: 'Generative Adversarial Networks (GANs): Minimax Game, Wasserstein Distance & Mode Collapse',
    detailedNotes: `### Week 8: Adversarial Generative Modeling

#### 1. The Minimax Game Formulation (Goodfellow et al.)
Two competing networks:
- **Generator $G(\\mathbf{z}; \\theta_g)$:** Maps latent noise $\\mathbf{z} \\sim p_z$ to synthetic samples.
- **Discriminator $D(\\mathbf{x}; \\theta_d)$:** Outputs probability that $\\mathbf{x}$ came from real data rather than $G$.
$$\\min_G \\max_D V(D, G) = \\mathbb{E}_{\\mathbf{x} \\sim p_{\\text{data}}}[\\ln D(\\mathbf{x})] + \\mathbb{E}_{\\mathbf{z} \\sim p_z}[\\ln(1 - D(G(\\mathbf{z})))]$$

#### 2. Optimal Discriminator & Jensen-Shannon Divergence
- For fixed $G$, optimal discriminator is: $D^*(\\mathbf{x}) = \\frac{p_{\\text{data}}(\\mathbf{x})}{p_{\\text{data}}(\\mathbf{x}) + p_g(\\mathbf{x})}$.
- Substituting $D^*$ into objective yields:
$$V(D^*, G) = -\\ln 4 + 2 \\cdot D_{\\text{JS}}(p_{\\text{data}} \\parallel p_g)$$
- When distributions have disjoint supports in high dimensions, $D_{\\text{JS}} = \\ln 2$ (constant!), leading to **vanishing gradients for Generator**.

#### 3. Wasserstein GAN (WGAN - Arjovsky et al.)
Uses Earth Mover\'s (Wasserstein-1) Distance via Kantorovich-Rubinstein Duality:
$$W(p_r, p_g) = \\sup_{\\|f\\|_L \\le 1} \\mathbb{E}_{\\mathbf{x} \\sim p_r}[f(\\mathbf{x})] - \\mathbb{E}_{\\tilde{\\mathbf{x}} \\sim p_g}[f(\\tilde{\\mathbf{x}})]$$
- Replaces Discriminator with a 1-Lipschitz **Critic** enforced via Gradient Penalty (WGAN-GP). Eliminates mode collapse!`,
    quickRevisionNotes: [
      'Standard GAN objective is equivalent to minimizing Jensen-Shannon Divergence $D_{\\text{JS}}$.',
      'Mode collapse occurs when Generator produces samples from only a few narrow modes of the real data distribution.',
      'Wasserstein GAN provides smooth, continuous gradients everywhere by using Earth Mover\'s Distance.'
    ],
    formulaSheets: [
      {
        name: 'GAN Minimax Objective & Wasserstein Distance',
        formula: '\\min_G \\max_D \\mathbb{E}_{x}[\\ln D(x)] + \\mathbb{E}_{z}[\\ln(1 - D(G(z)))], \\quad W(p_r, p_g) = \\sup_{\\|f\\|_L \\le 1} \\mathbb{E}[f(x)] - \\mathbb{E}[f(G(z))]',
        description: 'Adversarial training loss and Kantorovich-Rubinstein dual.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'WGAN Gradient Penalty Loss in PyTorch',
        code: `def compute_gradient_penalty(critic, real_samples, fake_samples, device):
    alpha = torch.rand((real_samples.size(0), 1, 1, 1), device=device)
    interpolates = (alpha * real_samples + ((1 - alpha) * fake_samples)).requires_grad_(True)
    d_interpolates = critic(interpolates)
    
    gradients = torch.autograd.grad(
        outputs=d_interpolates,
        inputs=interpolates,
        grad_outputs=torch.ones_like(d_interpolates),
        create_graph=True,
        retain_graph=True
    )[0]
    
    gradients = gradients.view(gradients.size(0), -1)
    gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
    return gradient_penalty`
      }
    ],
    examTips: [
      'In standard GAN, training Generator with $\\min_G \\ln(1 - D(G(z)))$ causes vanishing gradient when Discriminator is winning. Use non-saturating heuristic $\\max_G \\ln D(G(z))$ instead.',
      'Critic in WGAN does NOT have a sigmoid activation at the output (outputs unbounded real scores).'
    ],
    handwrittenMnemonic: 'WGAN Critic needs 1-Lipschitz condition $\\to$ Gradient Penalty near 1!'
  },
  {
    id: 'note-dl-w9',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 9,
    title: 'Variational Autoencoders (VAEs), Reparameterization Trick & Evidence Lower Bound (ELBO)',
    detailedNotes: `### Week 9: Latent Variable Models & Variational Inference

#### 1. Generative Modeling with Latent Variables
Given observed data $\\mathbf{x}$ and unobserved latent vector $\\mathbf{z} \\sim p(\\mathbf{z}) = \\mathcal{N}(\\mathbf{0}, I)$:
- True marginal log-likelihood: $\\ln p_\\theta(\\mathbf{x}) = \\ln \\int p_\\theta(\\mathbf{x} \\mid \\mathbf{z}) p(\\mathbf{z}) d\\mathbf{z}$ (intractable integral).
- Introduce variational posterior $q_\\phi(\\mathbf{z} \\mid \\mathbf{x})$ parameterized by an encoder neural network.

#### 2. Derivation of Evidence Lower Bound (ELBO)
Using Jensen\'s Inequality:
$$\\ln p_\\theta(\\mathbf{x}) = \\mathbb{E}_{q_\\phi(\\mathbf{z}\\mid\\mathbf{x})}\\left[ \\ln \\frac{p_\\theta(\\mathbf{x}, \\mathbf{z})}{q_\\phi(\\mathbf{z}\\mid\\mathbf{x})} \\right] + D_{\\text{KL}}(q_\\phi(\\mathbf{z}\\mid\\mathbf{x}) \\parallel p_\\theta(\\mathbf{z}\\mid\\mathbf{x}))$$
$$\\text{ELBO}(\\theta, \\phi; \\mathbf{x}) = \\underbrace{\\mathbb{E}_{q_\\phi(\\mathbf{z}\\mid\\mathbf{x})}[\\ln p_\\theta(\\mathbf{x}\\mid\\mathbf{z})]}_{\\text{Reconstruction Loss (Decoder)}} - \\underbrace{D_{\\text{KL}}(q_\\phi(\\mathbf{z}\\mid\\mathbf{x}) \\parallel p(\\mathbf{z}))}_{\\text{KL Divergence Regularizer (Encoder)}}$$

#### 3. The Reparameterization Trick
Backpropagation cannot flow through stochastic node $\\mathbf{z} \\sim \\mathcal{N}(\\boldsymbol{\\mu}_\\phi(\\mathbf{x}), \\boldsymbol{\\Sigma}_\\phi(\\mathbf{x}))$.
- **Reparameterize:** Isolate randomness into deterministic transformation:
$$\\mathbf{z} = \\boldsymbol{\\mu} + \\boldsymbol{\\sigma} \\odot \\boldsymbol{\\epsilon}, \\quad \\text{where } \\boldsymbol{\\epsilon} \\sim \\mathcal{N}(\\mathbf{0}, I)$$`,
    quickRevisionNotes: [
      'ELBO maximizes reconstruction quality while forcing posterior $q(\\mathbf{z}|\\mathbf{x})$ close to prior $\\mathcal{N}(\\mathbf{0}, I)$.',
      'Closed-form KL divergence for diagonal Gaussians: $-\\frac{1}{2} \\sum (1 + \\ln \\sigma_j^2 - \\mu_j^2 - \\sigma_j^2)$.',
      'Reparameterization trick allows gradients to flow directly through encoder network parameters.'
    ],
    formulaSheets: [
      {
        name: 'ELBO & Reparameterization Trick',
        formula: '\\text{ELBO} = \\mathbb{E}_{q}[\\ln p(\\mathbf{x}\\mid\\mathbf{z})] - D_{\\text{KL}}(q(\\mathbf{z}\\mid\\mathbf{x}) \\parallel p(\\mathbf{z})), \\quad \\mathbf{z} = \\boldsymbol{\\mu} + \\boldsymbol{\\sigma} \\odot \\boldsymbol{\\epsilon}',
        description: 'Variational objective and differentiable stochastic sampling.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'VAE Latent Sampling & Reparameterization in PyTorch',
        code: `class VAE(nn.Module):
    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
        
    def loss_function(self, recon_x, x, mu, logvar):
        BCE = F.binary_cross_entropy(recon_x, x, reduction='sum')
        # KL divergence analytical form
        KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        return BCE + KLD`
      }
    ],
    examTips: [
      'Standard Autoencoders learn an unconstrained discrete latent code (cannot interpolate smoothly); VAEs enforce a smooth continuous Gaussian latent space suitable for generation.',
      'Log-variance \`logvar\` $= \\ln(\\sigma^2)$ is predicted by neural networks instead of $\\sigma$ directly to ensure numerical stability and strictly positive standard deviation.'
    ],
    handwrittenMnemonic: 'Reparameterization trick: Pull stochasticity out into $\\epsilon \\sim \\mathcal{N}(0, I)$!'
  },
  {
    id: 'note-dl-w10',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 10,
    title: 'Diffusion Models (DDPM): Forward Noising SDE, Reverse Denoising & Score Matching',
    detailedNotes: `### Week 10: Diffusion Probabilistic Models

#### 1. Forward Noising Process (Markov Chain)
Gradually destroys image structure by adding Gaussian noise over $T$ timesteps according to schedule $\\beta_1, \\dots, \\beta_T$:
$$q(\\mathbf{x}_t \\mid \\mathbf{x}_{t-1}) = \\mathcal{N}(\\mathbf{x}_t; \\sqrt{1 - \\beta_t} \\mathbf{x}_{t-1}, \\beta_t I)$$
- **Closed-Form Direct Sampling at arbitrary step $t$:**
$$\\mathbf{x}_t = \\sqrt{\\bar{\\alpha}_t} \\mathbf{x}_0 + \\sqrt{1 - \\bar{\\alpha}_t} \\boldsymbol{\\epsilon}, \\quad \\boldsymbol{\\epsilon} \\sim \\mathcal{N}(\\mathbf{0}, I)$$
where $\\alpha_t = 1 - \\beta_t$ and $\\bar{\\alpha}_t = \\prod_{s=1}^t \\alpha_s$.

#### 2. Reverse Denoising Process & Simplified Training Objective
Train neural network $\\boldsymbol{\\epsilon}_\\theta(\\mathbf{x}_t, t)$ (typically a U-Net with attention) to predict added noise $\\boldsymbol{\\epsilon}$:
$$\\mathcal{L}_{\\text{simple}}(\\theta) = \\mathbb{E}_{t, \\mathbf{x}_0, \\boldsymbol{\\epsilon}}\\left[ \\|\\boldsymbol{\\epsilon} - \\boldsymbol{\\epsilon}_\\theta(\\sqrt{\\bar{\\alpha}_t} \\mathbf{x}_0 + \\sqrt{1 - \\bar{\\alpha}_t} \\boldsymbol{\\epsilon}, t)\\|_2^2 \\right]$$

#### 3. Classifier-Free Guidance (CFG)
During inference, blend conditional and unconditional predictions to control generation fidelity:
$$\\tilde{\\boldsymbol{\\epsilon}}_\\theta(\\mathbf{x}_t, c) = \\boldsymbol{\\epsilon}_\\theta(\\mathbf{x}_t, \\emptyset) + s \\cdot (\\boldsymbol{\\epsilon}_\\theta(\\mathbf{x}_t, c) - \\boldsymbol{\\epsilon}_\\theta(\\mathbf{x}_t, \\emptyset))$$
where $s > 1$ is the guidance scale factor.`,
    quickRevisionNotes: [
      'Forward process requires NO training; $\\mathbf{x}_t$ can be sampled in one step using $\\sqrt{\\bar{\\alpha}_t} \\mathbf{x}_0 + \\sqrt{1 - \\bar{\\alpha}_t} \\boldsymbol{\\epsilon}$.',
      'The network $\\boldsymbol{\\epsilon}_\\theta$ predicts the added Gaussian noise vector $\\boldsymbol{\\epsilon}$.',
      'Classifier-Free Guidance (CFG) boosts prompt adherence at the cost of diversity.'
    ],
    formulaSheets: [
      {
        name: 'DDPM Direct Sampling & Simplified Objective',
        formula: '\\mathbf{x}_t = \\sqrt{\\bar{\\alpha}_t} \\mathbf{x}_0 + \\sqrt{1 - \\bar{\\alpha}_t} \\boldsymbol{\\epsilon}, \\quad \\mathcal{L}(\\theta) = \\mathbb{E}_{t, \\mathbf{x}_0, \\boldsymbol{\\epsilon}}[\\|\\boldsymbol{\\epsilon} - \\boldsymbol{\\epsilon}_\\theta(\\mathbf{x}_t, t)\\|^2]',
        description: 'One-step noising formula and noise-prediction training objective.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'DDPM Closed-Form Noising Step',
        code: `def q_sample(x_start, t, noise, sqrt_alphas_cumprod, sqrt_one_minus_alphas_cumprod):
    # x_t = sqrt(alpha_bar_t) * x_0 + sqrt(1 - alpha_bar_t) * eps
    sqrt_alpha_bar = sqrt_alphas_cumprod[t].view(-1, 1, 1, 1)
    sqrt_one_minus_alpha_bar = sqrt_one_minus_alphas_cumprod[t].view(-1, 1, 1, 1)
    return sqrt_alpha_bar * x_start + sqrt_one_minus_alpha_bar * noise`
      }
    ],
    examTips: [
      'At step $T$ (e.g., $T=1000$), $\\bar{\\alpha}_T \\approx 0$, so $\\mathbf{x}_T \\approx \\mathcal{N}(\\mathbf{0}, I)$ is pure isotropic Gaussian noise.',
      'Diffusion models avoid mode collapse because they are trained by maximizing likelihood (via ELBO).'
    ],
    handwrittenMnemonic: 'Diffusion = Noise prediction over $T$ steps; sample $x_t$ instantly via $\\sqrt{\\bar{\\alpha}_t}$!'
  },
  {
    id: 'note-dl-w11',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 11,
    title: 'Reinforcement Learning: Markov Decision Processes (MDP), Q-Learning, Policy Gradients (REINFORCE) & PPO',
    detailedNotes: `### Week 11: Deep Reinforcement Learning Paradigms

#### 1. Markov Decision Process (MDP)
Tuple $(\\mathcal{S}, \\mathcal{A}, \\mathcal{P}, \\mathcal{R}, \\gamma)$ where $\\gamma \\in [0, 1)$ is discount factor:
- **Bellman Optimality Equation for $Q^*(s, a)$:**
$$Q^*(s, a) = \\mathcal{R}(s, a) + \\gamma \\sum_{s\'} P(s\' \\mid s, a) \\max_{a\'} Q^*(s\', a\')$$

#### 2. Deep Q-Networks (DQN - Mnih et al.)
Approximates $Q(s, a; \\theta)$ with neural network using two stability innovations:
1. **Experience Replay Buffer:** Breaks temporal correlation between consecutive transition samples.
2. **Target Network $\\theta^-$:** Decouples action evaluation from target value update:
$$\\mathcal{L}(\\theta) = \\mathbb{E}\\left[ \\left( r + \\gamma \\max_{a\'} Q(s\', a\'; \\theta^-) - Q(s, a; \\theta) \\right)^2 \\right]$$

#### 3. Policy Gradients & PPO (Proximal Policy Optimization)
- **Policy Gradient Theorem (REINFORCE):**
$$\\nabla_\\theta J(\\theta) = \\mathbb{E}_{\\tau \\sim \\pi_\\theta} \\left[ \\sum_{t=0}^T \\nabla_\\theta \\ln \\pi_\\theta(a_t \\mid s_t) G_t \\right]$$
- **PPO Clipped Surrogate Objective:** Prevents catastrophically large policy updates:
$$L^{\\text{CLIP}}(\\theta) = \\hat{\\mathbb{E}}_t \\left[ \\min\\left( r_t(\\theta) \\hat{A}_t, \\text{clip}(r_t(\\theta), 1-\\epsilon, 1+\\epsilon) \\hat{A}_t \\right) \\right]$$
where $r_t(\\theta) = \\frac{\\pi_\\theta(a_t \\mid s_t)}{\\pi_{\\theta_{\\text{old}}}(a_t \\mid s_t)}$.`,
    quickRevisionNotes: [
      'DQN is value-based (off-policy); REINFORCE and PPO are policy-based (actor-critic).',
      'Experience replay buffer ensures i.i.d. training samples for deep neural network stability.',
      'PPO clips probability ratio to $[1-\\epsilon, 1+\\epsilon]$, making it the industry standard for RLHF.'
    ],
    formulaSheets: [
      {
        name: 'Bellman Optimality & PPO Clipped Objective',
        formula: 'Q^*(s, a) = r + \\gamma \\max_{a\'} Q^*(s\', a\'), \\quad L^{\\text{CLIP}}(\\theta) = \\hat{\\mathbb{E}}[\\min(r_t \\hat{A}_t, \\text{clip}(r_t, 1-\\epsilon, 1+\\epsilon) \\hat{A}_t)]',
        description: 'Value iteration foundation and stable policy optimization objective.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'DQN Loss with Target Network in PyTorch',
        code: `def compute_dqn_loss(model, target_model, states, actions, rewards, next_states, dones, gamma=0.99):
    # Current Q-values
    q_values = model(states).gather(1, actions.unsqueeze(1)).squeeze(1)
    
    # Target Q-values using Target Network (no gradient)
    with torch.no_grad():
        max_next_q = target_model(next_states).max(1)[0]
        target_q = rewards + gamma * max_next_q * (1 - dones)
        
    loss = F.mse_loss(q_values, target_q)
    return loss`
      }
    ],
    examTips: [
      'Target network weights $\\theta^-$ are held fixed and only synchronized with active network $\\theta$ every $C$ steps or via Polyak averaging: $\\theta^- \\leftarrow \\tau \\theta + (1-\\tau)\\theta^-$.',
      'Standard Policy Gradient has high variance; subtracting a baseline $V(s)$ ($A(s, a) = Q(s, a) - V(s)$) reduces variance without introducing bias!'
    ],
    handwrittenMnemonic: 'DQN uses replay buffer + target network; PPO clips probability ratios!'
  },
  {
    id: 'note-dl-w12',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning & Neural Networks',
    courseCode: 'CS3001',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 12,
    title: 'Model Compression: Pruning, Knowledge Distillation & Quantization (INT8 / FP4)',
    detailedNotes: `### Week 12: Efficient Deep Learning & Edge Deployment

#### 1. Knowledge Distillation (Hinton et al.)
Transfers dark knowledge from a large Teacher network ($T$) to a lightweight Student network ($S$):
$$\\mathcal{L}_{\\text{KD}} = (1 - \\alpha) \\mathcal{L}_{\\text{CE}}(y, \\sigma(z_S)) + \\alpha T^2 \\mathcal{L}_{\\text{KL}}(\\sigma(z_S / T) \\parallel \\sigma(z_T / T))$$
- **Temperature $T > 1$:** Softens probability distributions, revealing relative correlations between non-target classes (e.g. BMW looks closer to Audi than to Carrot).

#### 2. Network Pruning & Lottery Ticket Hypothesis (Frankle & Carbin)
- **Magnitude-Based Pruning:** Remove weights with $|w_{ij}| < \\theta$ (structured vs unstructured).
- **Lottery Ticket Hypothesis:** Dense, randomly initialized feedforward networks contain subnetworks ("winning tickets") that, when trained in isolation from their original initializations, reach test accuracy comparable to the full network in similar training steps.

#### 3. Quantization (Post-Training & QAT)
Mapping continuous 32-bit floating point weights ($x \\in [\\alpha, \\beta]$) to low-precision 8-bit integers ($q \\in [0, 255]$):
$$q = \\text{round}\\left( \\frac{x}{S} \\right) + Z, \\quad \\text{where } S = \\frac{\\beta - \\alpha}{2^b - 1} \\text{ (Scale)}, \\quad Z = \\text{round}\\left( -\\frac{\\alpha}{S} \\right) \\text{ (Zero-Point)}$$`,
    quickRevisionNotes: [
      'Knowledge Distillation uses soft targets with Temperature $T > 1$ to transfer inter-class relationships.',
      'INT8 quantization reduces memory footprint by $4\\times$ (from 4 bytes/FP32 to 1 byte/INT8).',
      'Lottery Ticket Hypothesis: Winning subnetworks MUST be re-trained from their original initialization weights, not random new initializations!'
    ],
    formulaSheets: [
      {
        name: 'Distillation Loss & Affine Quantization',
        formula: '\\mathcal{L}_{\\text{KD}} = \\alpha T^2 D_{\\text{KL}}(\\sigma(z_S/T) \\parallel \\sigma(z_T/T)) + (1-\\alpha) \\mathcal{L}_{\\text{CE}}, \\quad x \\approx S (q - Z)',
        description: 'Dark knowledge transfer and integer quantization formulas.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Knowledge Distillation Loss in PyTorch',
        code: `import torch.nn.functional as F

def distillation_loss(student_logits, teacher_logits, labels, T=4.0, alpha=0.7):
    # Soft loss with softened probabilities
    loss_soft = F.kl_div(
        F.log_softmax(student_logits / T, dim=1),
        F.softmax(teacher_logits / T, dim=1),
        reduction='batchmean'
    ) * (T * T)
    
    # Hard loss on true ground-truth labels
    loss_hard = F.cross_entropy(student_logits, labels)
    return alpha * loss_soft + (1.0 - alpha) * loss_hard`
      }
    ],
    examTips: [
      'In Distillation loss, you MUST multiply the KL divergence term by $T^2$ because scaling inputs by $1/T$ shrinks gradients by $1/T^2$!',
      'Unstructured pruning creates sparse weight matrices that require specialized sparse tensor acceleration hardware to yield practical wall-clock speedups.'
    ],
    handwrittenMnemonic: 'Distill with Temperature $T$ (scale gradients by $T^2$); Quantize $x = S(q - Z)$!'
  }
];

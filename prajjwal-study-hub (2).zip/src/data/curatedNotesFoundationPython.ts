import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_PYTHON_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-py-w1',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Python Core Basics: Dynamic Typing, Built-in Types & Expressions',
    detailedNotes: `### Week 1: Python Fundamentals & Data Types

#### 1. Python\'s Execution Model & Dynamic Typing
- **Interpreted & Dynamically Typed:** Variables in Python are references/pointers to objects in heap memory. Types are bound to objects, not variable names.
- **Garbage Collection:** Automatic memory management via reference counting and cyclic garbage collector.

#### 2. Fundamental Built-in Scalar Types
- **Integers (\`int\`):** Arbitrary-precision integers (no 32-bit/64-bit overflow limit in Python 3).
- **Floating-point (\`float\`):** IEEE 754 double precision (64-bit).
- **Booleans (\`bool\`):** Subclass of \`int\` (\`True == 1\`, \`False == 0\`).
- **Strings (\`str\`):** Immutable sequences of Unicode characters.
- **NoneType (\`None\`):** Singleton representing absence of value.

#### 3. Arithmetic & Logical Operators
- Floor Division (\`//\`): Quotient rounded down toward negative infinity (\`7 // 2 == 3\`, \`-7 // 2 == -4\`).
- Modulo (\`%\`): Remainder (\`7 % 2 == 1\`, \`-7 % 2 == 1\`).
- Exponentiation (\`**\`): Right-associative (\`2 ** 3 ** 2 == 2 ** 9 == 512\`).`,
    quickRevisionNotes: [
      'Python integers have arbitrary precision (no integer overflow limit).',
      'Floor division \`//\` rounds toward negative infinity (\`-5 // 2 == -3\`).',
      'Exponentiation \`**\` is right-associative (\`2 ** 3 ** 2 = 2 ** 9 = 512\`).',
      'Variables are labels/references to heap-allocated objects.'
    ],
    formulaSheets: [
      {
        name: 'Floor Division & Modulo Invariant',
        formula: 'a = (a // b) \\cdot b + (a \\% b)',
        description: 'Fundamental algebraic identity governing Python division.'
      },
      {
        name: 'Exponentiation Right-Associativity',
        formula: 'a ** b ** c = a ** (b ** c)',
        description: 'Evaluation order of chained power operators.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w1-p1',
        questionText: 'What is the output of `print(-11 // 3, -11 % 3)` in Python 3?',
        options: ['-4, 1', '-3, -2', '-3, 1', '-4, -2'],
        correctOptionIndex: 0,
        solution: 'Floor division rounds down towards negative infinity: $-11 / 3 = -3.666... \\to -4$. Then $-11 = (-4 \\times 3) + r \\implies -11 = -12 + r \\implies r = 1$. Hence `-4, 1`.',
        hints: ['Floor division always rounds DOWN toward negative infinity.']
      },
      {
        id: 'py-w1-p2',
        questionText: 'What is the evaluated result of `2 ** 3 ** 2` in Python?',
        options: ['512', '64', '36', '12'],
        correctOptionIndex: 0,
        solution: 'Exponentiation is right-associative: $2 ** (3 ** 2) = 2 ** 9 = 512$.',
        hints: ['Evaluate from right to left: $3^2$ first.']
      },
      {
        id: 'py-w1-p3',
        questionText: 'Which Python built-in function returns the unique identity/memory address of an object?',
        options: ['id()', 'type()', 'hash()', 'mem()'],
        correctOptionIndex: 0,
        solution: '`id(obj)` returns the unique integer memory address of the object in CPython.',
        hints: ['Built-in function starting with `i`.']
      }
    ],
    keyTakeaways: [
      'Understanding Python\'s object model prevents unexpected mutation bugs in data structures.',
      'Floor division and modulo consistently satisfy $a = (a // b) * b + a % b$.'
    ],
    markdownContent: `### Week 1: Python Core Fundamentals\nDynamic typing, scalar types, operators, and memory reference models.`,
    examTips: ['Remember that floor division on negative numbers rounds away from zero: `-7 // 2` is `-4`!']
  },
  {
    id: 'note-py-w2',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Conditionals, Boolean Expressions & Branching Logic',
    detailedNotes: `### Week 2: Control Flow & Boolean Logic

#### 1. Truthy and Falsy Values
In Python, all objects evaluate to a boolean truth value in conditional statements:
- **Falsy Values:** \`False\`, \`None\`, \`0\`, \`0.0\`, \`""\` (empty string), \`[]\` (empty list), \`()\` (empty tuple), \`{}\` (empty dict), \`set()\`.
- **Truthy Values:** Everything else.

#### 2. Logical Operators & Short-Circuiting
- \`and\`: Returns the first falsy operand, or the last operand if all are truthy.
  - \`"hello" and 0 and [1, 2]\` $\\implies$ evaluates to \`0\`.
- \`or\`: Returns the first truthy operand, or the last operand if all are falsy.
  - \`"" or "default" or 42\` $\\implies$ evaluates to \`"default"\`.
- \`not\`: Unary negation yielding boolean \`True\` or \`False\`.

#### 3. Conditional Expressions (Ternary Operator)
\`result = x if condition else y\``,
    quickRevisionNotes: [
      'Falsy values: \`False, None, 0, 0.0, "", [], (), {}, set()\`.',
      '\`and\` returns the first falsy value or the last truthy value.',
      '\`or\` returns the first truthy value or the last falsy value.',
      'Ternary syntax: \`value_if_true if condition else value_if_false\`.'
    ],
    formulaSheets: [
      {
        name: 'Short-Circuit Return Rule',
        formula: 'A \\; \\text{or} \\; B = A \\; (\\text{if } A \\text{ is truthy}) \\; \\text{else} \\; B',
        description: 'Exact return evaluation of Python boolean or.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w2-p1',
        questionText: 'What is the evaluated output of `[] or "IITM" or 0` in Python?',
        options: ['"IITM"', 'True', '[]', '0'],
        correctOptionIndex: 0,
        solution: '`[]` is falsy, so it moves to `"IITM"`. `"IITM"` is truthy, so the `or` expression short-circuits and immediately returns `"IITM"`.',
        hints: ['`or` returns the first truthy value itself.']
      },
      {
        id: 'py-w2-p2',
        questionText: 'What does the expression `5 < 10 < 15 < 12` evaluate to in Python?',
        options: ['False', 'True', 'SyntaxError', '12'],
        correctOptionIndex: 0,
        solution: 'Python supports chained comparisons: `5 < 10 and 10 < 15 and 15 < 12`. Because `15 < 12` is False, the entire chain evaluates to False.',
        hints: ['Chained comparisons expand with implicit `and`.']
      },
      {
        id: 'py-w2-p3',
        questionText: 'What is the value of `x` after: `x = 10 if False else (20 if True else 30)`?',
        options: ['20', '10', '30', 'False'],
        correctOptionIndex: 0,
        solution: 'Since the outer condition is False, the else branch `(20 if True else 30)` executes, returning 20.',
        hints: ['Evaluate the nested ternary expression.']
      }
    ],
    keyTakeaways: [
      'Short-circuit boolean returns enable concise default fallback idioms.',
      'Chained comparisons simplify multi-variable range checks.'
    ],
    markdownContent: `### Week 2: Conditionals & Boolean Logic\nTruthy/falsy objects, short-circuit evaluation, and ternary branching.`,
    examTips: ['Remember that `and` and `or` return the actual operand value, not just `True` or `False`!']
  },
  {
    id: 'note-py-w3',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Loops, Iteration Patterns, Enumerate, Zip & Loop Control',
    detailedNotes: `### Week 3: Iteration Mechanics & Loop Utilities

#### 1. The \`for\` Loop & The \`range()\` Function
- \`range(start, stop, step)\`: Generates integers in $[\\text{start}, \\text{stop})$ incrementing by $\\text{step}$.
- Memory efficient: \`range\` is a generator-like lazy sequence requiring $O(1)$ memory.

#### 2. Loop Control Keywords
- \`break\`: Immediately terminates the innermost enclosing loop.
- \`continue\`: Skips the remainder of the current iteration and jumps to the next cycle.
- \`pass\`: Null statement (placeholder).
- **The \`else\` Clause on Loops:** Executes ONLY if the loop completes normally without encountering a \`break\`.

#### 3. Iteration Helpers: \`enumerate()\` and \`zip()\`
- \`enumerate(iterable, start=0)\`: Yields \`(index, value)\` tuples.
- \`zip(*iterables)\`: Pairs elements across iterables until the shortest iterable is exhausted.`,
    quickRevisionNotes: [
      '\`range(start, stop, step)\` produces values up to \`stop - 1\`.',
      '\`loop ... else\` block executes ONLY if the loop completes without hitting a \`break\`.',
      '\`enumerate(seq)\` provides index-value pairs.',
      '\`zip(a, b)\` pairs items from both collections and terminates at the shortest.'
    ],
    formulaSheets: [
      {
        name: 'Range Element Count',
        formula: 'N = \\max\\left(0, \\left\\lceil \\frac{\\text{stop} - \\text{start}}{\\text{step}} \\right\\rceil\\right)',
        description: 'Total number of integers generated by range().'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w3-p1',
        questionText: 'When does the `else` block attached to a `for` loop execute?',
        options: ['Only when the loop terminates naturally without hitting a `break`', 'Every time after the loop finishes', 'Only if an exception occurs', 'Only if the loop condition was False initially'],
        correctOptionIndex: 0,
        solution: 'In Python, a `for-else` or `while-else` construct executes the `else` clause only if the loop terminates without encountering a `break` statement.',
        hints: ['Consider how search loops use `else` when a key is not found.']
      },
      {
        id: 'py-w3-p2',
        questionText: 'What is the output of `list(range(10, 2, -3))`?',
        options: ['[10, 7, 4]', '[10, 7, 4, 1]', '[10, 7]', '[]'],
        correctOptionIndex: 0,
        solution: 'Starts at 10, subtracts 3: 10, 7, 4. The next value 1 is $\\le 2$ (stop bound), so it stops. Result: `[10, 7, 4]`.',
        hints: ['Step backwards by 3 until greater than stop bound 2.']
      },
      {
        id: 'py-w3-p3',
        questionText: 'What does `list(zip([1, 2, 3], ["a", "b"]))` return?',
        options: ['[(1, "a"), (2, "b")]', '[(1, "a"), (2, "b"), (3, None)]', '[(1, "a"), (2, "b"), (3, "")]', 'TypeError'],
        correctOptionIndex: 0,
        solution: 'Standard `zip()` truncates at the length of the shortest input iterable, producing two paired tuples.',
        hints: ['`zip()` terminates when the shorter list ends.']
      }
    ],
    keyTakeaways: [
      'The loop-else construct elegantly eliminates the need for flag variables in search routines.',
      '`enumerate` and `zip` eliminate manual index tracking and index-out-of-bounds errors.'
    ],
    markdownContent: `### Week 3: Loops & Iteration\nFor/while loops, range generation, loop-else constructs, enumerate, and zip.`,
    examTips: ['Remember that hitting a `break` inside a loop will SKIP the `else:` block entirely!']
  },
  {
    id: 'note-py-w4',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Functions, Parameter Passing, *args, **kwargs & LEGB Scope',
    detailedNotes: `### Week 4: Functions & Variable Scopes

#### 1. Function Definition & Parameter Mechanics
- **Positional vs Keyword Arguments.**
- **Default Arguments:** Must follow non-default parameters.
  - **CRITICAL PITFALL:** *Never use mutable objects (like \`[]\` or \`{}\`) as default argument values!* Default arguments are evaluated once at function definition time.
- **Variadic Arguments:**
  - \`*args\`: Packs arbitrary positional arguments into a \`tuple\`.
  - \`**kwargs\`: Packs arbitrary keyword arguments into a \`dict\`.

#### 2. The LEGB Scope Resolution Hierarchy
When resolving a variable name, Python searches scopes in strict order:
1. **L - Local:** Names assigned within the current function body.
2. **E - Enclosing:** Names in the local scope of any enclosing/parent functions.
3. **G - Global:** Names assigned at the top level of the module/script.
4. **B - Built-in:** Pre-defined built-in names (e.g. \`len\`, \`range\`, \`print\`).

#### 3. \`global\` and \`nonlocal\` Keywords
- \`global x\`: Declares that assignments to \`x\` modify the module-level global variable.
- \`nonlocal x\`: Modifies variable \`x\` in the nearest enclosing non-global scope (used in closures).`,
    quickRevisionNotes: [
      'LEGB search order: Local $\\to$ Enclosing $\\to$ Global $\\to$ Built-in.',
      'Never use mutable default arguments (\`def f(x=[]):\`); use \`None\` sentinel instead.',
      '\`*args\` collects positional arguments as a tuple; \`**kwargs\` collects keyword arguments as a dict.',
      '\`nonlocal\` modifies variables in the enclosing function scope (closures).'
    ],
    formulaSheets: [
      {
        name: 'LEGB Scope Hierarchy',
        formula: '\\text{Local} \\subset \\text{Enclosing} \\subset \\text{Global} \\subset \\text{Built-in}',
        description: 'Resolution precedence for Python identifier lookup.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w4-p1',
        questionText: 'What is the output of running `def append_to(val, lst=[]): lst.append(val); return lst; print(append_to(1)); print(append_to(2))`?',
        options: ['[1] then [1, 2]', '[1] then [2]', '[1, 2] then [1, 2]', 'TypeError'],
        correctOptionIndex: 0,
        solution: 'Because default parameter `lst=[]` is created once when the function is defined, both calls share and mutate the same list object in memory, yielding `[1]` then `[1, 2]`.',
        hints: ['Default mutable arguments persist across calls.']
      },
      {
        id: 'py-w4-p2',
        questionText: 'What is the type of `args` inside a function defined as `def func(*args):`?',
        options: ['tuple', 'list', 'dict', 'set'],
        correctOptionIndex: 0,
        solution: '`*args` packages variable positional arguments into an immutable `tuple`.',
        hints: ['Positional args pack into a tuple.']
      },
      {
        id: 'py-w4-p3',
        questionText: 'Which keyword allows modifying a variable in an outer enclosing (non-global) function scope?',
        options: ['nonlocal', 'global', 'outer', 'parent'],
        correctOptionIndex: 0,
        solution: 'The `nonlocal` keyword binds an identifier to the nearest enclosing scope variable.',
        hints: ['Used inside closures.']
      }
    ],
    keyTakeaways: [
      'Using `None` as default argument avoids mutable default shared-state bugs.',
      'LEGB scope rules govern variable lookup and closures in functional Python.'
    ],
    markdownContent: `### Week 4: Functions & Variable Scopes\nParameter packing, mutable defaults, LEGB resolution, and closures.`,
    examTips: ['Always use `def f(x=None): if x is None: x = []` to avoid the mutable default argument trap!']
  },
  {
    id: 'note-py-w5',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Strings, Immutability, Slicing Mechanics & Formatting (f-strings)',
    detailedNotes: `### Week 5: String Manipulation & Text Processing

#### 1. String Immutability & Indexing
- Strings in Python are **immutable** sequences of Unicode characters. Modifying a character (\`s[0] = 'a'\`) raises \`TypeError\`.
- **Negative Indexing:** \`s[-1]\` is the last character, \`s[-len(s)]\` is the first.

#### 2. Extended Slice Notation: \`s[start:stop:step]\`
- Extracting substrings from $\\text{start}$ up to $\\text{stop} - 1$.
- **Reversing a string:** \`s[::-1]\`.
- Out-of-bounds slicing never raises an \`IndexError\`; it cleanly truncates at boundary limits.

#### 3. Core String Methods
- Splitting & Joining: \`s.split(sep)\`, \`delimiter.join(iterable)\` (e.g. \`", ".join(["a", "b"])\`).
- Whitespace stripping: \`s.strip()\`, \`s.lstrip()\`, \`s.rstrip()\`.
- Searching: \`s.find(sub)\` (returns -1 if missing), \`s.index(sub)\` (raises \`ValueError\` if missing).

#### 4. Formatted String Literals (f-strings)
- Interpolation: \`f"Mean: {mean:.2f}, Count: {count:04d}"\`.`,
    quickRevisionNotes: [
      'Strings are immutable; modifying elements raises TypeError.',
      'Reverse string idiom: \`s[::-1]\`.',
      '\`delimiter.join(list_of_strings)\` is faster than repeatedly using \`+\`.',
      '\`s.find()\` returns \`-1\` on failure, whereas \`s.index()\` raises \`ValueError\`.',
      'f-strings support inline format specifiers (\`{val:.2f}\`).'
    ],
    formulaSheets: [
      {
        name: 'String Slicing Indices',
        formula: '\\text{Slice} = s[\\text{start} : \\text{stop} : \\text{step}]',
        description: 'Extracts elements from start to stop-1 with specified stride.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w5-p1',
        questionText: 'What does `"DataScience"[4::-1]` evaluate to in Python?',
        options: ['"SataD"', '"ataD"', '"ecnei"', '"DataS"'],
        correctOptionIndex: 0,
        solution: 'Index 4 is \'S\'. Stepping by -1 goes backwards to index 0: \'S\', \'a\', \'t\', \'a\', \'D\', giving `"SataD"`.',
        hints: ['Start at index 4 (\'S\') and step backwards.']
      },
      {
        id: 'py-w5-p2',
        questionText: 'What is the output of `",".join(["A", "B", "C"])`?',
        options: ['"A,B,C"', '["A", ",", "B", ",", "C"]', '"A, B, C"', 'TypeError'],
        correctOptionIndex: 0,
        solution: '`.join()` concatenates elements of the list with the comma delimiter, returning `"A,B,C"`.',
        hints: ['Joins strings using the specified delimiter.']
      },
      {
        id: 'py-w5-p3',
        questionText: 'What is the difference between `str.find("x")` and `str.index("x")` when `"x"` is absent?',
        options: ['find() returns -1, while index() raises ValueError', 'find() raises ValueError, while index() returns -1', 'Both return None', 'Both raise IndexError'],
        correctOptionIndex: 0,
        solution: '`find()` returns -1 on missing substring, while `index()` raises a `ValueError` exception.',
        hints: ['`find()` is non-raising; `index()` raises an exception.']
      }
    ],
    keyTakeaways: [
      'Using `str.join()` avoids $O(N^2)$ memory reallocation from repetitive string concatenation.',
      'f-strings provide readable, performant string formatting.'
    ],
    markdownContent: `### Week 5: Strings & Slicing\nImmutability, slice indexing strides, string methods, and f-string formatting.`,
    examTips: ['Remember that string slicing NEVER raises IndexError for out-of-range bounds!']
  },
  {
    id: 'note-py-w6',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Lists, Tuples, Comprehensions & Shallow vs Deep Copies',
    detailedNotes: `### Week 6: Sequence Types & List Comprehensions

#### 1. Lists (Mutable) vs Tuples (Immutable)
- **Lists (\`[]\`):** Dynamic arrays with amortized $O(1)$ append and pop from the right end. Insering at index 0 is $O(n)$.
- **Tuples (\`()\`):** Fixed-size immutable sequences. Hashable (if all items are hashable) and usable as dictionary keys.

#### 2. List Comprehensions
Syntactic construct for creating lists:
\`[expression for item in iterable if condition]\`
- Supports nested iterations:
  \`matrix_flat = [val for row in matrix for val in row]\`

#### 3. Shallow Copy vs Deep Copy
- **Shallow Copy (\`copy.copy()\`, \`lst.copy()\`, \`lst[:]\`):** Creates a new container, but populates it with references to the original child objects.
- **Deep Copy (\`copy.deepcopy()\):** Recursively creates copies of all nested objects.`,
    quickRevisionNotes: [
      'Lists are mutable dynamic arrays; Tuples are immutable and hashable (if elements are hashable).',
      'List comprehension syntax: \`[expr for x in seq if cond]\`.',
      'Shallow copy duplicates only the outer container; inner mutable objects remain shared.',
      'Deep copy recursively duplicates all nested objects in memory.'
    ],
    formulaSheets: [
      {
        name: 'List Comprehension Equivalence',
        formula: '[f(x) \\text{ for } x \\in S \\text{ if } P(x)] \\equiv \\text{map}(f, \\text{filter}(P, S))',
        description: 'Functional equivalence between list comprehensions and map/filter.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w6-p1',
        questionText: 'What is the evaluated output of `[x**2 for x in range(5) if x % 2 == 1]`?',
        options: ['[1, 9]', '[0, 1, 4, 9, 16]', '[1, 4, 9]', '[9]'],
        correctOptionIndex: 0,
        solution: 'Odd numbers in range(5) are 1 and 3. Their squares are $1^2 = 1$ and $3^2 = 9$. Result: `[1, 9]`.',
        hints: ['Filter for odd numbers in 0, 1, 2, 3, 4, then square them.']
      },
      {
        id: 'py-w6-p2',
        questionText: 'If `a = [[1, 2], [3, 4]]` and `b = a.copy()`. If we execute `b[0].append(99)`, what is `a[0]`?',
        options: ['[1, 2, 99]', '[1, 2]', '[]', 'TypeError'],
        correctOptionIndex: 0,
        solution: '`a.copy()` performs a shallow copy. Both `a[0]` and `b[0]` reference the exact same inner list object in memory, so mutating `b[0]` also mutates `a[0]`.',
        hints: ['Shallow copies share nested references.']
      },
      {
        id: 'py-w6-p3',
        questionText: 'Can a tuple containing a list `t = (1, [2, 3])` be used as a key in a Python dictionary?',
        options: ['No, because it contains a mutable list, making the tuple unhashable', 'Yes, because tuples are always hashable', 'Yes, if the list has fewer than 5 items', 'Only if converted to a string'],
        correctOptionIndex: 0,
        solution: 'A tuple is hashable if and only if all of its elements are hashable. Because list `[2, 3]` is unhashable, the containing tuple raises `TypeError: unhashable type: \'list\'`.',
        hints: ['Dictionary keys must be fully hashable.']
      }
    ],
    keyTakeaways: [
      'List comprehensions are faster and more readable than manual append loops.',
      'Beware shallow copies when duplicating multi-dimensional arrays.'
    ],
    markdownContent: `### Week 6: Lists, Tuples & Copies\nComprehensions, mutable vs immutable sequences, and shallow vs deep copies.`,
    examTips: ['Use `copy.deepcopy()` whenever dealing with nested lists to prevent accidental mutation!']
  },
  {
    id: 'note-py-w7',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Sets, Dictionaries, Hash Tables & Set Operations',
    detailedNotes: `### Week 7: Hash Tables, Sets & Dictionaries

#### 1. Hash Tables & Hashability
- **Sets (\`set\`) and Dictionaries (\`dict\`):** Implemented using hash tables with open addressing.
- **Complexity:** Average $O(1)$ lookup, insertion, and deletion.
- **Hashability Requirement:** An object is hashable if it has an immutable hash value that never changes during its lifetime (requires \`__hash__()\` and \`__eq__()\`).

#### 2. Dictionaries (\`dict\`)
- Key-Value mapping. In Python 3.7+, insertion order is guaranteed preserved.
- Methods: \`d.get(key, default)\`, \`d.keys()\`, \`d.values()\`, \`d.items()\`, \`d.setdefault(key, default)\`.
- Dictionary Comprehensions: \`{k: v for k, v in pairs if cond}\`.

#### 3. Sets (\`set\`)
- Unordered collection of unique, hashable elements.
- **Set Operations:**
  - Union: \`A | B\` or \`A.union(B)\`
  - Intersection: \`A & B\` or \`A.intersection(B)\`
  - Difference: \`A - B\` or \`A.difference(B)\`
  - Symmetric Difference: \`A ^ B\` or \`A.symmetric_difference(B)\``,
    quickRevisionNotes: [
      'Dicts and Sets provide average $O(1)$ lookups via hash tables.',
      'Dict keys and Set elements MUST be hashable (immutable).',
      '\`d.get(k, default)\` avoids \`KeyError\` exceptions.',
      'Set operators: \`|\` (Union), \`&\` (Intersection), \`-\` (Difference), \`^\` (Symmetric Diff).'
    ],
    formulaSheets: [
      {
        name: 'Set Symmetric Difference',
        formula: 'A \\oplus B = (A \\cup B) \\setminus (A \\cap B) = (A \\setminus B) \\cup (B \\setminus A)',
        description: 'Elements present in either set A or B, but not both.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w7-p1',
        questionText: 'If `A = {1, 2, 3}` and `B = {3, 4, 5}`, what is `A ^ B`?',
        options: ['{1, 2, 4, 5}', '{3}', '{1, 2, 3, 4, 5}', '{1, 2}'],
        correctOptionIndex: 0,
        solution: 'The symmetric difference operator `^` returns elements in either set but not in their intersection: `{1, 2, 4, 5}`.',
        hints: ['Remove common elements from the union.']
      },
      {
        id: 'py-w7-p2',
        questionText: 'What is the output of `d = {"a": 1}; print(d.get("b", 100))`?',
        options: ['100', 'None', 'KeyError', '0'],
        correctOptionIndex: 0,
        solution: '`d.get("b", 100)` returns the specified default value 100 since the key `"b"` does not exist in the dictionary.',
        hints: ['`.get()` returns the fallback default value when a key is absent.']
      },
      {
        id: 'py-w7-p3',
        questionText: 'What is the average-case time complexity for checking if an element exists in a Python set (`x in my_set`)?',
        options: ['O(1)', 'O(n)', 'O(log n)', 'O(n^2)'],
        correctOptionIndex: 0,
        solution: 'Sets are implemented as hash tables, giving average $O(1)$ constant-time membership lookups.',
        hints: ['Hash table lookup complexity.']
      }
    ],
    keyTakeaways: [
      'Replacing list membership checks with set membership lookups reduces search time from $O(N)$ to $O(1)$.',
      'Dictionaries are the primary data structure for structured key-value datasets.'
    ],
    markdownContent: `### Week 7: Sets & Dictionaries\nHash tables, average O(1) lookups, set algebra, and dictionary comprehensions.`,
    examTips: ['Always prefer `dict.get(key, default)` over `dict[key]` to prevent unhandled `KeyError` crashes!']
  },
  {
    id: 'note-py-w8',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Recursion, Call Stack & Functional Primitives (Lambda, Map, Filter, Reduce)',
    detailedNotes: `### Week 8: Recursion & Functional Programming

#### 1. Recursion & The Call Stack
- **Base Case:** Terminating condition preventing infinite recursion.
- **Recursive Case:** Reducing the problem to smaller instances.
- **Python Recursion Limit:** Default maximum call stack depth is 1000 (\`sys.getrecursionlimit()\`). Exceeding it raises \`RecursionError\`.

#### 2. Anonymous Functions (\`lambda\`)
- Single-expression functions: \`lambda x, y: x + y\`.

#### 3. Functional Programming Primitives
- \`map(func, iterable)\`: Applies \`func\` to every element. Returns an iterator.
- \`filter(predicate, iterable)\`: Filters elements where \`predicate(x)\` is True.
- \`reduce(func, iterable[, init])\` (from \`functools\`): Cumulatively reduces a sequence to a single value.`,
    quickRevisionNotes: [
      'Recursion requires: Base Case (halt) and Recursive Step (progress toward base).',
      'Python recursion depth limit is 1000 by default (raises \`RecursionError\`).',
      'Lambda functions contain only a single return expression.',
      '\`map\` transforms elements; \`filter\` selects elements; \`reduce\` folds sequences.'
    ],
    formulaSheets: [
      {
        name: 'Reduce Accumulator Fold',
        formula: '\\text{reduce}(f, [x_1, x_2, \\dots, x_n]) = f(\\dots f(f(x_1, x_2), x_3), \\dots, x_n)',
        description: 'Left-associative cumulative reduction of a sequence.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w8-p1',
        questionText: 'What is the output of `list(map(lambda x: x * 2, filter(lambda x: x > 3, [1, 2, 4, 5])))`?',
        options: ['[8, 10]', '[2, 4, 8, 10]', '[4, 5]', '[8]'],
        correctOptionIndex: 0,
        solution: 'Filter selects numbers $> 3 \\implies [4, 5]$. Map doubles each selected number $\\implies [8, 10]$.',
        hints: ['Apply filter first, then map over the surviving elements.']
      },
      {
        id: 'py-w8-p2',
        questionText: 'From which standard library module must `reduce` be imported in Python 3?',
        options: ['functools', 'itertools', 'math', 'operator'],
        correctOptionIndex: 0,
        solution: 'In Python 3, `reduce` is located in the `functools` standard module (`from functools import reduce`).',
        hints: ['Functional tools module.']
      },
      {
        id: 'py-w8-p3',
        questionText: 'What exception is raised when a recursive function fails to reach its base case in Python?',
        options: ['RecursionError', 'StackOverflowException', 'MemoryError', 'InfiniteLoopError'],
        correctOptionIndex: 0,
        solution: 'Python raises `RecursionError: maximum recursion depth exceeded` when the call stack exceeds the limit.',
        hints: ['Standard Python exception for exceeded call stack depth.']
      }
    ],
    keyTakeaways: [
      'Functional composition with map/filter/reduce encourages stateless, testable logic.',
      'Ensure every recursive branch converges monotonically to a valid base case.'
    ],
    markdownContent: `### Week 8: Recursion & Functional Programming\nCall stack mechanics, lambda expressions, map, filter, and functools.reduce.`,
    examTips: ['Remember to wrap `map()` and `filter()` calls in `list()` if you need to index or display the output values!']
  },
  {
    id: 'note-py-w9',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'File I/O, Context Managers (with) & Structured Data (CSV/JSON)',
    detailedNotes: `### Week 9: File Handling & Context Management

#### 1. File Modes & Encodings
- Modes: \`'r'\` (Read), \`'w'\` (Write / Overwrite), \`'a'\` (Append), \`'rb'/'wb'\` (Binary).
- Always specify UTF-8 encoding: \`open(filepath, 'r', encoding='utf-8')\`.

#### 2. The Context Manager (\`with\` Statement)
Ensures file descriptors are safely closed automatically upon exiting the block, even if an unhandled exception occurs:
\`\`\`python
with open("data.txt", "r", encoding="utf-8") as f:
    for line in f:
        print(line.strip())
\`\`\`

#### 3. Structured Data Formats
- **CSV Handling (\`csv\` module):** \`csv.reader(f)\`, \`csv.DictReader(f)\`, \`csv.writer(f)\`.
- **JSON Serialization (\`json\` module):**
  - String conversion: \`json.dumps(obj)\` (to string), \`json.loads(s)\` (from string).
  - File operations: \`json.dump(obj, f)\` (to file), \`json.load(f)\` (from file).`,
    quickRevisionNotes: [
      'Always use \`with open(...) as f:\` to guarantee automatic resource cleanup.',
      'Iterating directly over file object (\`for line in f:\`) streams line-by-line in $O(1)$ memory.',
      'JSON methods: \`load/dump\` operate on files; \`loads/dumps\` operate on strings.',
      '\`csv.DictReader\` maps rows directly into Python dictionaries keyed by column headers.'
    ],
    formulaSheets: [
      {
        name: 'Context Manager Protocol',
        formula: '\\text{with } E \\text{ as } V: \\implies V = E.\\_\\_\\text{enter}\\_\\_() \\dots \\text{finally: } E.\\_\\_\\text{exit}\\_\\_()',
        description: 'Resource management lifecycle under Python context managers.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w9-p1',
        questionText: 'What is the difference between `json.load()` and `json.loads()`?',
        options: ['json.load() reads from a file pointer, while json.loads() parses a JSON string', 'json.load() is for numbers, json.loads() is for strings', 'json.loads() writes to a file', 'There is no difference'],
        correctOptionIndex: 0,
        solution: 'The trailing "s" in `loads` stands for "string"; `json.load(f)` takes a file-like stream object, whereas `json.loads(s)` takes a raw string.',
        hints: ['"loads" means load from string.']
      },
      {
        id: 'py-w9-p2',
        questionText: 'Why is using `with open(...)` preferred over manually calling `f.close()`?',
        options: ['It guarantees the file is closed even if an exception is raised within the block', 'It runs faster', 'It automatically compresses the file', 'It prevents read errors'],
        correctOptionIndex: 0,
        solution: 'Context managers guarantee that `__exit__()` is called, ensuring file descriptors are released even during exceptions.',
        hints: ['Guaranteed cleanup on exceptions.']
      },
      {
        id: 'py-w9-p3',
        questionText: 'Which file mode opens a file for writing, placing the pointer at the end of the file without erasing existing contents?',
        options: ['"a" (Append)', '"w" (Write)', '"r+" (Read/Write)', '"x" (Exclusive)'],
        correctOptionIndex: 0,
        solution: 'Mode `"a"` (append mode) writes new data to the end of the file without overwriting existing content.',
        hints: ['Append mode.']
      }
    ],
    keyTakeaways: [
      'Line-by-line file streaming processes massive gigabyte datasets without memory crashes.',
      '`json` and `csv` modules serialize structured datasets across external pipelines.'
    ],
    markdownContent: `### Week 9: File I/O & Serialization\nFile modes, context managers, csv readers, and JSON serialization.`,
    examTips: ['Always use `encoding="utf-8"` when opening files to prevent cross-platform encoding errors!']
  },
  {
    id: 'note-py-w10',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Object-Oriented Programming (OOP): Classes, Instances & Dunder Methods',
    detailedNotes: `### Week 10: OOP Fundamentals & Magic Methods

#### 1. Classes, Instances & The \`self\` Parameter
- **Class:** Blueprint defining attributes and behavior.
- **Instance:** A concrete realized object created from a class.
- **\`self\`:** Explicit reference to the calling instance object.
- **\`__init__(self, ...)\`:** Instance initializer method called immediately after object creation.

#### 2. Instance vs Class Variables
- **Instance Variable (\`self.name\`):** Unique to each specific instance object.
- **Class Variable (\`ClassName.counter\`):** Shared across ALL instances of the class.

#### 3. Magic / Dunder (Double Underscore) Methods
- \`__str__(self)\`: User-friendly informal string representation for \`print()\` and \`str()\`.
- \`__repr__(self)\`: Unambiguous official representation for debugging and \`repr()\`.
- \`__len__(self)\`: Enables \`len(obj)\`.
- \`__eq__(self, other)\`: Enables equality comparison (\`==\`).
- Operator Overloading: \`__add__\` (\`+\`), \`__mul__\` (\`*\`), \`__getitem__\` (\`obj[key]\`).`,
    quickRevisionNotes: [
      '\`__init__\` is the constructor initializer; \`self\` points to the instance.',
      'Class variables are shared by all instances; instance variables are unique per object.',
      '\`__str__\` is for users; \`__repr__\` is for developers/debugging.',
      'Dunder methods allow custom classes to emulate Python\'s built-in operators.'
    ],
    formulaSheets: [
      {
        name: 'Dunder String Representation Contract',
        formula: '\\text{print}(obj) \\implies obj.\\_\\_\\text{str}\\_\\_() \\quad [\\text{falls back to } obj.\\_\\_\\text{repr}\\_\\_()]',
        description: 'String evaluation fallback hierarchy in Python.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w10-p1',
        questionText: 'What is the purpose of the `__str__` magic method in Python classes?',
        options: ['Returns a readable, user-friendly string representation of the object for `print()`', 'Converts integers to strings', 'Initializes instance variables', 'Deletes the object from memory'],
        correctOptionIndex: 0,
        solution: '`__str__` provides the human-readable string representation called by `str(obj)` and `print(obj)`.',
        hints: ['Human-readable representation.']
      },
      {
        id: 'py-w10-p2',
        questionText: 'What happens if you modify a mutable class variable through an instance (`inst.class_var = 10`)?',
        options: ['Creates a new instance variable shadowing the class variable for that instance only', 'Modifies the class variable for all instances', 'Raises an AttributeError', 'Deletes the class variable'],
        correctOptionIndex: 0,
        solution: 'Assigning to `inst.class_var` creates a new instance-level attribute that shadows the class-level variable for that specific instance only.',
        hints: ['Creates an instance attribute that shadows the class attribute.']
      },
      {
        id: 'py-w10-p3',
        questionText: 'Which dunder method must be implemented to support indexing on custom objects (`obj[key]`)?',
        options: ['__getitem__', '__index__', '__get__', '__getattr__'],
        correctOptionIndex: 0,
        solution: '`__getitem__(self, key)` is invoked to evaluate subscript / index lookups.',
        hints: ['Method for getting items by key or index.']
      }
    ],
    keyTakeaways: [
      'Dunder methods enable custom types to integrate seamlessly with Python built-ins.',
      'Distinguishing class vs instance attributes prevents shared-state concurrency bugs.'
    ],
    markdownContent: `### Week 10: OOP & Dunder Methods\nClasses, instances, self references, class variables, and magic methods.`,
    examTips: ['Always implement `__repr__` when writing custom classes for easy debugging!']
  },
  {
    id: 'note-py-w11',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Advanced OOP: Inheritance, Polymorphism, super() & Method Overriding',
    detailedNotes: `### Week 11: Inheritance, Polymorphism & OOP Design

#### 1. Inheritance & Code Reuse
- **Base / Parent Class vs Derived / Child Class:**
  \`\`\`python
  class Student(Person):
      def __init__(self, name, roll_no):
          super().__init__(name)
          self.roll_no = roll_no
  \`\`\`

#### 2. The \`super()\` Function & MRO
- \`super()\` returns a proxy object delegating method calls to parent/sibling classes.
- **Method Resolution Order (MRO):** The order in which Python searches parent classes in multiple inheritance (computed via the C3 Linearization algorithm; inspect via \`ClassName.__mro__\`).

#### 3. Polymorphism & Duck Typing
- *"If it walks like a duck and quacks like a duck, it is a duck."* Python does not require explicit interfaces; if an object implements the required methods, it can be used polymorphically.

#### 4. Encapsulation & Name Mangling
- Public: \`self.name\`
- Protected convention: \`self._internal\` (single underscore = internal use hint)
- Private: \`self.__secret\` (double underscore = name mangling to \`_ClassName__secret\`).`,
    quickRevisionNotes: [
      '\`super().__init__()\` delegates initialization to the parent class.',
      'Method Resolution Order (MRO) uses C3 Linearization for multiple inheritance.',
      'Duck typing: polymorphism based on method capabilities, not strict type inheritance.',
      'Double underscore (\`__attr\`) triggers name mangling to \`_ClassName__attr\`.'
    ],
    formulaSheets: [
      {
        name: 'Name Mangling Transformation',
        formula: '\\text{self}.\\_\\_\\text{privateVar} \\longrightarrow \\text{self}.\\_\\text{ClassName}\\_\\_\\text{privateVar}',
        description: 'CPython attribute name mangling rule for private class members.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w11-p1',
        questionText: 'What algorithm does Python use to determine the Method Resolution Order (MRO) in multiple inheritance?',
        options: ['C3 Linearization algorithm', 'Dijkstra\'s algorithm', 'Depth-First Search without backtracking', 'Breadth-First Search'],
        correctOptionIndex: 0,
        solution: 'Python uses the C3 Linearization algorithm to compute a deterministic, monotonic Method Resolution Order (MRO).',
        hints: ['Named after C3 Linearization.']
      },
      {
        id: 'py-w11-p2',
        questionText: 'What is "Duck Typing" in Python?',
        options: ['Determining type compatibility by the presence of specific methods/attributes rather than explicit class inheritance', 'A module for bird classification', 'Static type checking at compile time', 'Preventing class inheritance'],
        correctOptionIndex: 0,
        solution: 'Duck typing focuses on what an object can do (its interface and methods) rather than its formal inheritance hierarchy.',
        hints: ['Focuses on behavior rather than explicit class type.']
      },
      {
        id: 'py-w11-p3',
        questionText: 'How can a private variable `__balance` defined inside class `Account` be accessed directly from outside the class?',
        options: ['`obj._Account__balance`', '`obj.__balance`', '`obj.Account.balance`', 'It is physically impossible'],
        correctOptionIndex: 0,
        solution: 'Name mangling prefixes private variables with `_ClassName`, so it is accessible as `_Account__balance`.',
        hints: ['Recall name mangling format: `_ClassName__attribute`.']
      }
    ],
    keyTakeaways: [
      'Duck typing enables clean, decoupled software architectures.',
      '`super()` prevents duplicate initialization in complex multiple-inheritance diamond structures.'
    ],
    markdownContent: `### Week 11: Advanced OOP & Polymorphism\nInheritance, super() proxying, C3 MRO, duck typing, and name mangling.`,
    examTips: ['Use `ClassName.__mro__` to inspect the exact inheritance search order for multiple inheritance!']
  },
  {
    id: 'note-py-w12',
    courseId: 'course-python',
    courseTitle: 'Programming in Python',
    courseCode: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Exception Handling, Custom Exceptions & Scientific Python Ecosystem',
    detailedNotes: `### Week 12: Robust Exception Handling & Scientific Libraries

#### 1. Exception Handling Architecture
\`\`\`python
try:
    # Code that might raise an exception
    val = int(input_str)
    res = 100 / val
except ValueError as e:
    # Handles invalid type conversion
    print(f"Conversion error: {e}")
except ZeroDivisionError:
    # Handles division by zero
    print("Cannot divide by zero")
else:
    # Executes ONLY if NO exception was raised in try block
    print(f"Success: {res}")
finally:
    # Executes ALWAYS (cleanup actions, closing sockets)
    print("Execution complete")
\`\`\`

#### 2. Custom User-Defined Exceptions
Derive from the built-in \`Exception\` class:
\`\`\`python
class DataValidationError(Exception):
    """Raised when incoming dataset fails sanity checks."""
    pass
\`\`\`

#### 3. Overview of Scientific Python Libraries
- **NumPy:** High-performance $N$-dimensional arrays (\`ndarray\`), vectorized broadcasting operations, linear algebra.
- **Pandas:** Tabular DataFrames, series, grouped aggregation, time-series indexing.
- **Matplotlib / Seaborn:** Publication-quality data visualization and scientific plotting.`,
    quickRevisionNotes: [
      'Exception block: \`try-except-else-finally\`.',
      '\`else\` executes ONLY if NO exception occurred; \`finally\` executes ALWAYS.',
      'Custom exceptions must inherit from \`Exception\` (or a subclass).',
      'NumPy vectorized broadcasting eliminates slow Python \`for\` loops in numerical computing.'
    ],
    formulaSheets: [
      {
        name: 'Exception Handling Flowchart Logic',
        formula: '\\text{Try Block} \\longrightarrow [\\text{Exception} \\implies \\text{Except}] \\lor [\\text{Success} \\implies \\text{Else}] \\longrightarrow \\text{Finally (Always)}',
        description: 'Complete lifecycle flow of Python exception handling.'
      }
    ],
    practiceQuestions: [
      {
        id: 'py-w12-p1',
        questionText: 'When does the `else` block in a `try-except-else-finally` construct execute?',
        options: ['Only when the try block completes successfully without raising any exceptions', 'Only when an exception is caught', 'Always, right before finally', 'Only if the finally block fails'],
        correctOptionIndex: 0,
        solution: 'The `else` block in a try-except structure executes only when no exceptions were raised inside the try block.',
        hints: ['Executes on complete success without errors.']
      },
      {
        id: 'py-w12-p2',
        questionText: 'What base class must all custom user-defined exceptions inherit from in Python?',
        options: ['Exception (or BaseException)', 'Error', 'Object', 'CustomError'],
        correctOptionIndex: 0,
        solution: 'All standard user-defined exceptions should inherit from the built-in `Exception` class.',
        hints: ['Standard Python base exception class.']
      },
      {
        id: 'py-w12-p3',
        questionText: 'Why are NumPy vectorized operations significantly faster than standard Python loops for numeric calculations?',
        options: ['NumPy operations are executed in compiled C/Fortran code with contiguous memory and SIMD optimizations', 'NumPy runs on quantum processors', 'NumPy deletes all variables', 'Python loops are deliberately slowed down'],
        correctOptionIndex: 0,
        solution: 'NumPy arrays store elements in contiguous C memory buffers and execute vectorized operations via optimized, compiled C loops.',
        hints: ['Contiguous memory and compiled C backend.']
      }
    ],
    keyTakeaways: [
      'Comprehensive exception handling prevents software crashes in production pipelines.',
      'Vectorization with NumPy/Pandas unlocks 100x performance gains over native loops.'
    ],
    markdownContent: `### Week 12: Exceptions & Scientific Python\nTry-except-else-finally flow, custom exceptions, and NumPy/Pandas ecosystem.`,
    examTips: ['Never use bare `except:`! Always catch specific exceptions (e.g. `except ValueError:`)!']
  }
];

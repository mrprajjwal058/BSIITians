import { WeeklyStudyMaterial } from '../types';

export const FOUNDATION_MATH_2_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-math2-w1',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 1,
    title: 'Vectors in R^n, Dot Products, Norms & Cauchy-Schwarz Inequality',
    detailedNotes: `### Week 1: Vectors in $\\mathbb{R}^n$, Inner Products & Vector Geometry

#### 1. Vectors in $n$-Dimensional Euclidean Space
A column vector $\\mathbf{x} \\in \\mathbb{R}^n$ is an ordered $n$-tuple of real numbers:
$$\\mathbf{x} = \\begin{bmatrix} x_1 \\\\ x_2 \\\\ \\vdots \\\\ x_n \\end{bmatrix}$$

#### 2. Dot Product (Standard Inner Product)
For vectors $\\mathbf{u}, \\mathbf{v} \\in \\mathbb{R}^n$:
$$\\mathbf{u} \\cdot \\mathbf{v} = \\mathbf{u}^T \\mathbf{v} = \\sum_{i=1}^n u_i v_i = u_1 v_1 + u_2 v_2 + \\dots + u_n v_n$$
- **Algebraic Properties:**
  1. Symmetry: $\\mathbf{u} \\cdot \\mathbf{v} = \\mathbf{v} \\cdot \\mathbf{u}$
  2. Linearity: $(c\\mathbf{u} + \\mathbf{w}) \\cdot \\mathbf{v} = c(\\mathbf{u} \\cdot \\mathbf{v}) + (\\mathbf{w} \\cdot \\mathbf{v})$
  3. Positive-Definiteness: $\\mathbf{u} \\cdot \\mathbf{u} \\ge 0$, and $\\mathbf{u} \\cdot \\mathbf{u} = 0 \\iff \\mathbf{u} = \\mathbf{0}$.

#### 3. Vector Norms & Angles
- **Euclidean ($L_2$) Norm:** $\\|\\mathbf{u}\\| = \\sqrt{\\mathbf{u} \\cdot \\mathbf{u}} = \\sqrt{\\sum_{i=1}^n u_i^2}$
- **Geometric Angle $\\theta$:**
  $$\\cos \\theta = \\frac{\\mathbf{u} \\cdot \\mathbf{v}}{\\|\\mathbf{u}\\| \\|\\mathbf{v}\\|} \\implies \\mathbf{u} \\cdot \\mathbf{v} = \\|\\mathbf{u}\\| \\|\\mathbf{v}\\| \\cos \\theta$$
- **Orthogonality:** $\\mathbf{u} \\perp \\mathbf{v} \\iff \\mathbf{u} \\cdot \\mathbf{v} = 0$.

#### 4. Cauchy-Schwarz Inequality & Triangle Inequality
- **Cauchy-Schwarz Inequality:**
  $$|\\mathbf{u} \\cdot \\mathbf{v}| \\le \\|\\mathbf{u}\\| \\|\\mathbf{v}\\|$$
  *(Equality holds if and only if $\\mathbf{u}$ and $\\mathbf{v}$ are linearly dependent).*
- **Triangle Inequality:** $\\|\\mathbf{u} + \\mathbf{v}\\| \\le \\|\\mathbf{u}\\| + \\|\\mathbf{v}\\|$.`,
    quickRevisionNotes: [
      'Dot product: $\\mathbf{u} \\cdot \\mathbf{v} = \\mathbf{u}^T \\mathbf{v} = \\sum u_i v_i = \\|\\mathbf{u}\\| \\|\\mathbf{v}\\| \\cos \\theta$.',
      'Orthogonal vectors satisfy $\\mathbf{u} \\cdot \\mathbf{v} = 0$.',
      'Cauchy-Schwarz: $|\\mathbf{u} \\cdot \\mathbf{v}| \\le \\|\\mathbf{u}\\| \\|\\mathbf{v}\\|$; equality holds iff vectors are collinear.',
      'Unit vector in direction of $\\mathbf{u}$: $\\hat{\\mathbf{u}} = \\frac{\\mathbf{u}}{\\|\\mathbf{u}\\|}$.'
    ],
    formulaSheets: [
      {
        name: 'Cauchy-Schwarz Inequality',
        formula: '|\\mathbf{u} \\cdot \\mathbf{v}| \\le \\|\\mathbf{u}\\| \\|\\mathbf{v}\\|',
        description: 'Upper bound on inner product magnitude.'
      },
      {
        name: 'Cosine Similarity / Angle',
        formula: '\\cos \\theta = \\frac{\\mathbf{u} \\cdot \\mathbf{v}}{\\|\\mathbf{u}\\|_2 \\|\\mathbf{v}\\|_2}',
        description: 'Geometric angle and cosine distance between high-dimensional embedding vectors.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w1-p1',
        questionText: 'Find the cosine of the angle between $\\mathbf{u} = [1, 2, 2]^T$ and $\\mathbf{v} = [2, 0, 1]^T$.',
        options: ['4 / (3\\sqrt{5})', '2 / \\sqrt{5}', '1/3', '5 / (3\\sqrt{5})'],
        correctOptionIndex: 0,
        solution: '$\\mathbf{u} \\cdot \\mathbf{v} = (1)(2) + (2)(0) + (2)(1) = 2 + 0 + 2 = 4$. $\\|\\mathbf{u}\\| = \\sqrt{1^2 + 2^2 + 2^2} = \\sqrt{9} = 3$. $\\|\\mathbf{v}\\| = \\sqrt{2^2 + 0^2 + 1^2} = \\sqrt{5}$. Thus $\\cos \\theta = \\frac{4}{3\\sqrt{5}}$.',
        hints: ['Calculate dot product and norms separately.']
      },
      {
        id: 'math2-w1-p2',
        questionText: 'For which value of $k$ are vectors $\\mathbf{u} = [2, k, -3]^T$ and $\\mathbf{v} = [k, 3, 2]^T$ orthogonal?',
        options: ['1.2', '2.0', '-1.5', '0.5'],
        correctOptionIndex: 0,
        solution: '$\\mathbf{u} \\cdot \\mathbf{v} = 0 \\implies 2(k) + k(3) + (-3)(2) = 0 \\implies 2k + 3k - 6 = 0 \\implies 5k = 6 \\implies k = 6/5 = 1.2$.',
        hints: ['Set inner product to zero and solve for $k$.']
      },
      {
        id: 'math2-w1-p3',
        questionText: 'When does equality $|\\mathbf{u} \\cdot \\mathbf{v}| = \\|\\mathbf{u}\\| \\|\\mathbf{v}\\|$ hold in Cauchy-Schwarz inequality?',
        options: ['When u and v are linearly dependent (parallel or anti-parallel)', 'When u and v are orthogonal', 'When u and v are unit vectors', 'Always holds for all vectors'],
        correctOptionIndex: 0,
        solution: 'Equality holds if and only if $\\cos \\theta = \\pm 1 \\implies \\theta = 0$ or $\\pi$, meaning the vectors are scalar multiples of each other (linearly dependent).',
        hints: ['Consider when $|\\cos \\theta| = 1$.']
      }
    ],
    keyTakeaways: [
      'Inner products induce geometry (lengths, distances, angles) in vector spaces.',
      'Cosine similarity is the fundamental metric for document embeddings and transformers.'
    ],
    markdownContent: `### Week 1: Vectors & Inner Products\nDot products, Euclidean norms, and Cauchy-Schwarz inequalities.`,
    examTips: ['Remember that $\\|\\mathbf{u} + \\mathbf{v}\\|^2 = \\|\\mathbf{u}\\|^2 + \\|\\mathbf{v}\\|^2 + 2(\\mathbf{u} \\cdot \\mathbf{v})$.']
  },
  {
    id: 'note-math2-w2',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 2,
    title: 'Matrices, Operations, Rank, Systems of Linear Equations & Gaussian Elimination',
    detailedNotes: `### Week 2: Systems of Linear Equations & Gaussian Elimination

#### 1. Matrix Representation of Linear Systems
$$A \\mathbf{x} = \\mathbf{b}$$
Where $A \\in \\mathbb{R}^{m \\times n}$ is the coefficient matrix, $\\mathbf{x} \\in \\mathbb{R}^n$ is the unknown vector, and $\\mathbf{b} \\in \\mathbb{R}^m$ is the right-hand side.
- **Augmented Matrix:** $[A \\mid \\mathbf{b}]$.

#### 2. Row Echelon Form (REF) & Reduced Row Echelon Form (RREF)
Row operations preserve the solution set:
1. $R_i \\leftrightarrow R_j$ (Swap rows)
2. $R_i \\to c R_i \\quad (c \\ne 0)$ (Scale row)
3. $R_i \\to R_i + c R_j$ (Add multiple of row)

#### 3. Rouché-Capelli Theorem & Solution Existence
Let $A \\in \\mathbb{R}^{m \\times n}$ with augmented matrix $[A \\mid \\mathbf{b}]$:
1. **Inconsistent (No solution):** $\\text{Rank}(A) < \\text{Rank}([A \\mid \\mathbf{b}])$.
2. **Consistent (Solutions exist):** $\\text{Rank}(A) = \\text{Rank}([A \\mid \\mathbf{b}]) = r$.
   - **Unique Solution:** $r = n$ (Rank equals number of variables).
   - **Infinitely Many Solutions:** $r < n$ (There are $n - r$ free variables).`,
    quickRevisionNotes: [
      'Rank of a matrix is the number of non-zero rows in its Row Echelon Form (number of pivot columns).',
      'System $A\\mathbf{x} = \\mathbf{b}$ has solutions $\\iff \\text{Rank}(A) = \\text{Rank}([A \\mid \\mathbf{b}])$.',
      'Unique solution $\\iff \\text{Rank}(A) = \\text{Rank}([A \\mid \\mathbf{b}]) = n$.',
      'Infinitely many solutions $\\iff \\text{Rank}(A) = \\text{Rank}([A \\mid \\mathbf{b}]) < n$ ($n - r$ free variables).'
    ],
    formulaSheets: [
      {
        name: 'Rouché-Capelli Solvability Criterion',
        formula: '\\text{Consistent } \\iff \\text{Rank}(A) = \\text{Rank}([A \\mid \\mathbf{b}])',
        description: 'Theorem classifying existence and uniqueness of solutions to linear systems.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w2-p1',
        questionText: 'What is the rank of matrix $A = \\begin{bmatrix} 1 & 2 & 3 \\\\ 2 & 4 & 6 \\\\ -1 & -2 & -3 \\end{bmatrix}$?',
        options: ['1', '2', '3', '0'],
        correctOptionIndex: 0,
        solution: 'Notice row 2 is $2 R_1$ and row 3 is $-1 R_1$. Performing row operations $R_2 \\to R_2 - 2R_1$ and $R_3 \\to R_3 + R_1$ yields 2 zero rows and 1 non-zero row. Hence Rank $= 1$.',
        hints: ['Check linear dependence among rows.']
      },
      {
        id: 'math2-w2-p2',
        questionText: 'For what value of $k$ does $\\begin{cases} x + y + z = 6 \\\\ x + 2y + 3z = 10 \\\\ x + 2y + kz = 12 \\end{cases}$ have NO solution?',
        options: ['k = 3', 'k = 2', 'k = 0', 'k = -3'],
        correctOptionIndex: 0,
        solution: 'Subtracting equation 2 from equation 3 gives $(k - 3)z = 2$. If $k = 3$, this becomes $0 = 2$, a contradiction. Hence no solution for $k = 3$.',
        hints: ['Subtract equation 2 from equation 3.']
      },
      {
        id: 'math2-w2-p3',
        questionText: 'If a homogeneous system $A\\mathbf{x} = \\mathbf{0}$ with 4 equations and 6 variables has $\\text{Rank}(A) = 3$, how many free variables exist?',
        options: ['3', '1', '2', '4'],
        correctOptionIndex: 0,
        solution: 'Number of free variables $= n - r = 6 - 3 = 3$.',
        hints: ['Free variables $= n - \\text{Rank}(A)$.']
      }
    ],
    keyTakeaways: [
      'Row operations preserve column dependencies and span.',
      'Gaussian elimination is the engine behind matrix inversions and least-squares regression.'
    ],
    markdownContent: `### Week 2: Gaussian Elimination & Linear Systems\nREF, RREF, matrix rank, and Rouché-Capelli conditions.`,
    examTips: ['Watch out for contradictory rows $[0 \\ 0 \\dots 0 \\mid c]$ where $c \\ne 0$ indicating no solution.']
  },
  {
    id: 'note-math2-w3',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 3,
    title: 'Vector Spaces, Subspaces, Linear Independence, Span, Basis & Dimension',
    detailedNotes: `### Week 3: Abstract Vector Spaces, Subspaces & Basis

#### 1. Vector Space & Subspace Criteria
A subset $W \\subseteq V$ of a real vector space $V$ is a **subspace** iff:
1. $\\mathbf{0} \\in W$ (Contains zero vector)
2. $\\forall \\mathbf{u}, \\mathbf{v} \\in W, \\mathbf{u} + \\mathbf{v} \\in W$ (Closed under addition)
3. $\\forall c \\in \\mathbb{R}, \\mathbf{u} \\in W, c\\mathbf{u} \\in W$ (Closed under scalar multiplication)

#### 2. Linear Independence & Span
- **Span:** $\\text{Span}(\\{\\mathbf{v}_1, \\dots, \\mathbf{v}_k\\}) = \\left\\{ \\sum_{i=1}^k c_i \\mathbf{v}_i \\,\\middle|\\, c_i \\in \\mathbb{R} \\right\\}$.
- **Linear Independence:**
  $$c_1 \\mathbf{v}_1 + c_2 \\mathbf{v}_2 + \\dots + c_k \\mathbf{v}_k = \\mathbf{0} \\implies c_1 = c_2 = \\dots = c_k = 0$$
  If there exist non-zero scalars $c_i$, the vectors are **linearly dependent**.

#### 3. Basis & Dimension
A set of vectors $\\mathcal{B} = \\{\\mathbf{v}_1, \\dots, \\mathbf{v}_n\\}$ is a **basis** of $V$ if:
1. $\\mathcal{B}$ is linearly independent.
2. $\\text{Span}(\\mathcal{B}) = V$.
- **Dimension:** $\\dim(V) = |\\mathcal{B}|$ (the number of vectors in any basis of $V$).`,
    quickRevisionNotes: [
      'Subspace test: Must contain $\\mathbf{0}$ and be closed under vector addition and scalar multiplication.',
      'Vectors are linearly independent iff $c_1\\mathbf{v}_1 + \\dots + c_k\\mathbf{v}_k = \\mathbf{0}$ has only the trivial solution $c_i = 0$.',
      'Basis is a minimal spanning set and a maximal linearly independent set.',
      'Any $n+1$ vectors in an $n$-dimensional vector space are guaranteed to be linearly dependent.'
    ],
    formulaSheets: [
      {
        name: 'Linear Independence Condition',
        formula: '\\sum_{i=1}^k c_i \\mathbf{v}_i = \\mathbf{0} \\implies c_1 = c_2 = \\dots = c_k = 0',
        description: 'Trivial null combination criterion for vector independence.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w3-p1',
        questionText: 'Which of the following subsets is a valid subspace of $\\mathbb{R}^3$?',
        options: ['W = \\{(x, y, z) \\mid 2x - y + 3z = 0\\}', 'W = \\{(x, y, z) \\mid x + y + z = 1\\}', 'W = \\{(x, y, z) \\mid x^2 + y^2 = z^2\\}', 'W = \\{(x, y, z) \\mid x \\ge 0\\}'],
        correctOptionIndex: 0,
        solution: 'A hyperplane passing through the origin $2x - y + 3z = 0$ contains $(0, 0, 0)$ and is closed under addition and scalar scaling. The second does not contain $\\mathbf{0}$, the third is non-linear, and the fourth is not closed under negative scalar multiplication.',
        hints: ['Check if $\\mathbf{0}$ is in the set and whether equations are linear homogeneous.']
      },
      {
        id: 'math2-w3-p2',
        questionText: 'Are the vectors $\\mathbf{v}_1 = [1, 0, 1]^T, \\mathbf{v}_2 = [0, 1, 1]^T, \\mathbf{v}_3 = [1, 1, 2]^T$ linearly independent in $\\mathbb{R}^3$?',
        options: ['No, because v_1 + v_2 = v_3', 'Yes, because determinant is non-zero', 'Yes, because none of them is zero', 'No, because they do not span R^3'],
        correctOptionIndex: 0,
        solution: 'Notice $\\mathbf{v}_1 + \\mathbf{v}_2 = [1+0, 0+1, 1+1]^T = [1, 1, 2]^T = \\mathbf{v}_3$. Since one vector is a direct linear combination of the others, they are linearly dependent.',
        hints: ['Check if $\\mathbf{v}_1 + \\mathbf{v}_2 = \\mathbf{v}_3$.']
      },
      {
        id: 'math2-w3-p3',
        questionText: 'What is the dimension of the subspace $W = \\{(x, y, z) \\in \\mathbb{R}^3 \\mid x + 2y - z = 0\\}$?',
        options: ['2', '1', '3', '0'],
        correctOptionIndex: 0,
        solution: 'We have 3 variables and 1 independent linear constraint: $\\dim(W) = 3 - 1 = 2$. (Two free parameters: $x = z - 2y$).',
        hints: ['Dimension $= n - \\text{number of independent linear constraints}$.']
      }
    ],
    keyTakeaways: [
      'Subspaces always pass through the origin.',
      'Dimension represents the number of degrees of freedom in vector representations.'
    ],
    markdownContent: `### Week 3: Vector Spaces & Bases\nLinear independence, spanning sets, and subspace dimensions.`,
    examTips: ['If a set of vectors in $\\mathbb{R}^n$ has more than $n$ elements, it is automatically linearly dependent.']
  },
  {
    id: 'note-math2-w4',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 4,
    title: 'Linear Transformations, Matrix Representations, Kernel, Image & Rank-Nullity Theorem',
    detailedNotes: `### Week 4: Linear Transformations & The Rank-Nullity Theorem

#### 1. Definition of Linear Transformation
A map $T: V \\to W$ between vector spaces is a **linear transformation** if $\\forall \\mathbf{u}, \\mathbf{v} \\in V, c \\in \\mathbb{R}$:
1. $T(\\mathbf{u} + \\mathbf{v}) = T(\\mathbf{u}) + T(\\mathbf{v})$
2. $T(c\\mathbf{u}) = c T(\\mathbf{u})$
- *Consequence:* $T(\\mathbf{0}) = \\mathbf{0}$.

#### 2. Kernel (Null Space) & Image (Range Space)
- **Kernel / Null Space:** $\\ker(T) = \\text{Null}(A) = \\{ \\mathbf{v} \\in V \\mid T(\\mathbf{v}) = \\mathbf{0} \\}$.
  - $\\ker(T)$ is a subspace of domain $V$.
  - **Nullity:** $\\text{nullity}(T) = \\dim(\\ker(T))$.
  - $T$ is **injective (one-to-one)** $\\iff \\ker(T) = \\{\\mathbf{0}\\} \\iff \\text{nullity}(T) = 0$.
- **Image / Column Space:** $\\text{Im}(T) = \\text{Col}(A) = \\{ T(\\mathbf{v}) \\mid \\mathbf{v} \\in V \\}$.
  - $\\text{Im}(T)$ is a subspace of codomain $W$.
  - **Rank:** $\\text{rank}(T) = \\dim(\\text{Im}(T))$.

#### 3. The Rank-Nullity Theorem (Fundamental Theorem of Linear Algebra)
For any linear transformation $T: V \\to W$ on a finite-dimensional vector space $V$:
$$\\dim(V) = \\text{rank}(T) + \\text{nullity}(T)$$
For an $m \\times n$ matrix $A$:
$$n = \\text{rank}(A) + \\text{nullity}(A)$$`,
    quickRevisionNotes: [
      'Linear transformation preserves vector addition and scalar multiplication: $T(c\\mathbf{u} + \\mathbf{v}) = cT(\\mathbf{u}) + T(\\mathbf{v})$.',
      'Kernel (Null Space) is mapped to $\\mathbf{0}$; $T$ is injective $\\iff \\ker(T) = \\{\\mathbf{0}\\}$.',
      'Rank-Nullity Theorem: $\\text{rank}(A) + \\text{nullity}(A) = n$ (number of columns / domain dimension).',
      'Matrix representation $[T]$ has columns equal to $T(\\mathbf{e}_1), T(\\mathbf{e}_2), \\dots, T(\\mathbf{e}_n)$.'
    ],
    formulaSheets: [
      {
        name: 'Rank-Nullity Theorem',
        formula: '\\dim(\\text{Domain}) = \\text{Rank}(T) + \\text{Nullity}(T)',
        description: 'Conservation of dimension under linear mappings.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w4-p1',
        questionText: 'If $T: \\mathbb{R}^5 \\to \\mathbb{R}^3$ is a linear transformation with $\\text{rank}(T) = 3$, what is $\\dim(\\ker(T))$?',
        options: ['2', '3', '5', '0'],
        correctOptionIndex: 0,
        solution: 'By Rank-Nullity Theorem: $\\dim(V) = \\text{rank}(T) + \\text{nullity}(T) \\implies 5 = 3 + \\text{nullity}(T) \\implies \\text{nullity}(T) = 2$.',
        hints: ['Domain dimension is 5. Apply $5 = 3 + \\text{nullity}$.']
      },
      {
        id: 'math2-w4-p2',
        questionText: 'Under what condition is a linear map $T: \\mathbb{R}^n \\to \\mathbb{R}^n$ invertible?',
        options: ['\\ker(T) = \\{\\mathbf{0}\\} (Nullity = 0)', '\\text{rank}(T) < n', '\\det(T) = 0', '\\ker(T) \\ne \\{\\mathbf{0}\\}'],
        correctOptionIndex: 0,
        solution: 'For square matrices ($n \\to n$), $T$ is invertible iff it is bijective, which occurs iff $\\ker(T) = \\{\\mathbf{0}\\}$ (nullity $= 0$) and rank $= n$.',
        hints: ['Invertible means full rank and zero nullity.']
      },
      {
        id: 'math2-w4-p3',
        questionText: 'Find the standard matrix of transformation $T: \\mathbb{R}^2 \\to \\mathbb{R}^2$ that rotates vectors by $90^\\circ$ counter-clockwise.',
        options: ['\\begin{bmatrix} 0 & -1 \\\\ 1 & 0 \\end{bmatrix}', '\\begin{bmatrix} 0 & 1 \\\\ -1 & 0 \\end{bmatrix}', '\\begin{bmatrix} 1 & 0 \\\\ 0 & 1 \\end{bmatrix}', '\\begin{bmatrix} -1 & 0 \\\\ 0 & -1 \\end{bmatrix}'],
        correctOptionIndex: 0,
        solution: '$T(\\mathbf{e}_1) = T([1, 0]^T) = [0, 1]^T$. $T(\\mathbf{e}_2) = T([0, 1]^T) = [-1, 0]^T$. Combining columns: $[T] = \\begin{bmatrix} 0 & -1 \\\\ 1 & 0 \\end{bmatrix}$.',
        hints: ['Track images of standard basis vectors $\\mathbf{e}_1$ and $\\mathbf{e}_2$.']
      }
    ],
    keyTakeaways: [
      'Linear transformations are completely determined by their action on basis vectors.',
      'Rank-Nullity ensures loss of information (nullity) directly reduces range dimension.'
    ],
    markdownContent: `### Week 4: Transformations & Rank-Nullity\nLinear operators, kernel spaces, and dimension balance theorems.`,
    examTips: ['Always use the dimension of the DOMAIN (number of columns $n$), not codomain ($m$), in the Rank-Nullity theorem!']
  },
  {
    id: 'note-math2-w5',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 5,
    title: 'Determinants, Invertibility, Properties, Cramer\'s Rule & Adjugates',
    detailedNotes: `### Week 5: Determinants, Matrix Inverses & Volume Transformations

#### 1. Geometric & Algebraic Meaning of Determinant
For an $n \\times n$ matrix $A$:
- $\\det(A)$ represents the signed volume scaling factor of the unit hypercube under transformation $A$.
- **$2 \\times 2$ Matrix:** $\\det \\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix} = ad - bc$.
- **Invertibility Criterion:** $A$ is invertible $\\iff \\det(A) \\ne 0$.

#### 2. Key Algebraic Properties of Determinants
1. $\\det(AB) = \\det(A) \\cdot \\det(B)$
2. $\\det(A^T) = \\det(A)$
3. $\\det(A^{-1}) = \\frac{1}{\\det(A)}$
4. $\\det(c A) = c^n \\det(A)$ for $A \\in \\mathbb{R}^{n \\times n}$.
5. Swapping two rows changes the sign of $\\det(A)$.
6. If two rows/columns are identical or linearly dependent, $\\det(A) = 0$.

#### 3. Matrix Inverse via Classical Adjugate
$$A^{-1} = \\frac{1}{\\det(A)} \\text{adj}(A) = \\frac{1}{\\det(A)} C^T$$
Where $C_{ij} = (-1)^{i+j} M_{ij}$ is the cofactor of entry $a_{ij}$.`,
    quickRevisionNotes: [
      '$\\det(AB) = \\det(A)\\det(B)$ and $\\det(cA) = c^n \\det(A)$ for $n \\times n$ matrix.',
      'Matrix is invertible $\\iff \\det(A) \\ne 0$.',
      '$\\det(A^{-1}) = 1/\\det(A)$ and $\\det(A^T) = \\det(A)$.',
      'Inverse formula: $A^{-1} = \\frac{1}{\\det(A)} \\text{adj}(A)$.'
    ],
    formulaSheets: [
      {
        name: 'Scalar Determinant Scaling',
        formula: '\\det(c A) = c^n \\det(A) \\quad \\text{for } A \\in \\mathbb{R}^{n \\times n}',
        description: 'Scaling law for determinants under scalar multiplication.'
      },
      {
        name: 'Adjugate Matrix Inverse',
        formula: 'A^{-1} = \\frac{1}{\\det(A)} \\text{adj}(A)',
        description: 'Closed-form matrix inversion using cofactor transpose.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w5-p1',
        questionText: 'If $A$ is a $3 \\times 3$ matrix with $\\det(A) = 4$, what is $\\det(2A)$?',
        options: ['32', '8', '16', '64'],
        correctOptionIndex: 0,
        solution: 'For $n = 3$, $\\det(2A) = 2^3 \\det(A) = 8 \\times 4 = 32$.',
        hints: ['Use $\\det(cA) = c^n \\det(A)$ with $n = 3$.']
      },
      {
        id: 'math2-w5-p2',
        questionText: 'If $\\det(A) = 5$ and $\\det(B) = -2$, what is $\\det(A^T B^{-1})$?',
        options: ['-2.5', '2.5', '-10', '0.4'],
        correctOptionIndex: 0,
        solution: '$\\det(A^T B^{-1}) = \\det(A^T) \\det(B^{-1}) = \\det(A) \\cdot \\frac{1}{\\det(B)} = 5 \\cdot \\left(-\\frac{1}{2}\\right) = -2.5$.',
        hints: ['Use $\\det(A^T) = \\det(A)$ and $\\det(B^{-1}) = 1/\\det(B)$.']
      },
      {
        id: 'math2-w5-p3',
        questionText: 'What is the determinant of a triangular matrix?',
        options: ['Product of its main diagonal entries', 'Sum of its diagonal entries', 'Always 1', 'Always 0'],
        correctOptionIndex: 0,
        solution: 'For any upper triangular, lower triangular, or diagonal matrix, $\\det(A) = \\prod_{i=1}^n a_{ii}$.',
        hints: ['Recall properties of triangular matrix determinants.']
      }
    ],
    keyTakeaways: [
      'Determinants compute Jacobian change-of-variable volume expansions in multivariate integration.',
      'A zero determinant signals dimensionality collapse and singular matrices.'
    ],
    markdownContent: `### Week 5: Determinants & Inverses\nAlgebraic determinant identities and adjugate inverses.`,
    examTips: ['Never forget the $c^n$ power when computing $\\det(cA)$!']
  },
  {
    id: 'note-math2-w6',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 6,
    title: 'Eigenvalues, Eigenvectors, Characteristic Polynomial & Diagonalization',
    detailedNotes: `### Week 6: Spectral Theory, Eigenvalues & Matrix Diagonalization

#### 1. The Eigenvalue Problem
For an $n \\times n$ square matrix $A$:
$$A \\mathbf{v} = \\lambda \\mathbf{v} \\quad (\\mathbf{v} \\ne \\mathbf{0})$$
- $\\lambda$: Eigenvalue (scalar scaling factor).
- $\\mathbf{v}$: Eigenvector (direction unchanged by $A$).

#### 2. Characteristic Equation
$$(A - \\lambda I)\\mathbf{v} = \\mathbf{0} \\implies \\det(A - \\lambda I) = 0$$
- **Trace Property:** $\\sum_{i=1}^n \\lambda_i = \\text{Trace}(A) = \\sum_{i=1}^n a_{ii}$.
- **Determinant Property:** $\\prod_{i=1}^n \\lambda_i = \\det(A)$.

#### 3. Matrix Diagonalization
A matrix $A$ is **diagonalizable** iff it possesses $n$ linearly independent eigenvectors:
$$A = P D P^{-1}$$
Where $P = [\\mathbf{v}_1 \\mid \\mathbf{v}_2 \\mid \\dots \\mid \\mathbf{v}_n]$ and $D = \\text{diag}(\\lambda_1, \\lambda_2, \\dots, \\lambda_n)$.
- Matrix Power: $A^k = P D^k P^{-1}$.`,
    quickRevisionNotes: [
      'Eigenvalue equation: $A\\mathbf{v} = \\lambda \\mathbf{v}$ with non-zero $\\mathbf{v}$.',
      'Characteristic polynomial: $\\det(A - \\lambda I) = 0$.',
      'Sum of eigenvalues equals Trace($A$); product of eigenvalues equals $\\det(A)$.',
      'Diagonalization: $A = PDP^{-1}$ allows instant power calculation $A^k = PD^k P^{-1}$.'
    ],
    formulaSheets: [
      {
        name: 'Characteristic Equation',
        formula: '\\det(A - \\lambda I) = 0',
        description: 'Root polynomial yielding eigenvalues of matrix A.'
      },
      {
        name: 'Spectral Trace & Determinant Invariants',
        formula: '\\text{Tr}(A) = \\sum_{i=1}^n \\lambda_i, \\quad \\det(A) = \\prod_{i=1}^n \\lambda_i',
        description: 'Fundamental algebraic identities connecting eigenvalues to matrix entries.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w6-p1',
        questionText: 'Find the eigenvalues of $A = \\begin{bmatrix} 4 & 2 \\\\ 1 & 3 \\end{bmatrix}$.',
        options: ['\\lambda = 5, 2', '\\lambda = 4, 3', '\\lambda = 6, 1', '\\lambda = 2, 3'],
        correctOptionIndex: 0,
        solution: '$\\text{Tr}(A) = 4 + 3 = 7$, $\\det(A) = (4)(3) - (2)(1) = 12 - 2 = 10$. Characteristic equation: $\\lambda^2 - 7\\lambda + 10 = 0 \\implies (\\lambda - 5)(\\lambda - 2) = 0 \\implies \\lambda = 5, 2$.',
        hints: ['Use $\\lambda^2 - \\text{Tr}(A)\\lambda + \\det(A) = 0$.']
      },
      {
        id: 'math2-w6-p2',
        questionText: 'If a $3 \\times 3$ matrix $A$ has eigenvalues $1, -2, 4$, what is $\\det(A)$ and $\\text{Trace}(A)$?',
        options: ['\\det(A) = -8, \\text{Tr}(A) = 3', '\\det(A) = 8, \\text{Tr}(A) = 3', '\\det(A) = -8, \\text{Tr}(A) = 7', '\\det(A) = 3, \\text{Tr}(A) = -8'],
        correctOptionIndex: 0,
        solution: '$\\det(A) = (1)(-2)(4) = -8$. $\\text{Tr}(A) = 1 + (-2) + 4 = 3$.',
        hints: ['Determinant is product; Trace is sum of eigenvalues.']
      },
      {
        id: 'math2-w6-p3',
        questionText: 'If $A\\mathbf{v} = 3\\mathbf{v}$, what is the eigenvalue of $A^3 + 2I$ corresponding to $\\mathbf{v}$?',
        options: ['29', '27', '31', '9'],
        correctOptionIndex: 0,
        solution: '$(A^3 + 2I)\\mathbf{v} = A^3\\mathbf{v} + 2\\mathbf{v} = 3^3 \\mathbf{v} + 2\\mathbf{v} = (27 + 2)\\mathbf{v} = 29\\mathbf{v}$.',
        hints: ['Eigenvalue of $f(A)$ is $f(\\lambda)$.']
      }
    ],
    keyTakeaways: [
      'Eigenvalues decouple multi-dimensional linear systems into independent 1D scalar scalings.',
      'Eigenvectors define the principal axes in PCA.'
    ],
    markdownContent: `### Week 6: Eigenvalues & Diagonalization\nCharacteristic equations, trace-determinant invariants, and matrix powers.`,
    examTips: ['Check your eigenvalue arithmetic using $\\sum \\lambda_i = \\text{Trace}(A)$ to catch errors instantly.']
  },
  {
    id: 'note-math2-w7',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 7,
    title: 'Symmetric Matrices, Orthogonality, Gram-Schmidt & Spectral Decomposition',
    detailedNotes: `### Week 7: Orthogonal Matrices & The Spectral Theorem

#### 1. Orthogonal Matrices
A real square matrix $Q$ is **orthogonal** iff $Q^T Q = Q Q^T = I$, meaning $Q^{-1} = Q^T$.
- Columns and rows of $Q$ form an orthonormal basis.
- Preserves Euclidean norms: $\\|Q\\mathbf{x}\\| = \\|\\mathbf{x}\\|$.
- Determinant: $\\det(Q) = \\pm 1$.

#### 2. The Spectral Theorem for Real Symmetric Matrices
If $A = A^T$ (real symmetric):
1. All eigenvalues $\\lambda_1, \\dots, \\lambda_n$ of $A$ are **strictly real numbers**.
2. Eigenvectors corresponding to distinct eigenvalues are **mutually orthogonal**.
3. $A$ is orthogonally diagonalizable:
   $$A = Q \\Lambda Q^T = \\sum_{i=1}^n \\lambda_i \\mathbf{q}_i \\mathbf{q}_i^T$$
   Where $Q$ is an orthogonal matrix of eigenvectors ($Q^T = Q^{-1}$).

#### 3. Gram-Schmidt Orthogonalization Process
Given basis $\\{\\mathbf{v}_1, \\mathbf{v}_2, \\dots, \\mathbf{v}_k\\}$:
$$\\mathbf{u}_1 = \\mathbf{v}_1, \\quad \\mathbf{u}_2 = \\mathbf{v}_2 - \\frac{\\mathbf{v}_2 \\cdot \\mathbf{u}_1}{\\|\\mathbf{u}_1\\|^2}\\mathbf{u}_1, \\quad \\mathbf{u}_3 = \\mathbf{v}_3 - \\frac{\\mathbf{v}_3 \\cdot \\mathbf{u}_1}{\\|\\mathbf{u}_1\\|^2}\\mathbf{u}_1 - \\frac{\\mathbf{v}_3 \\cdot \\mathbf{u}_2}{\\|\\mathbf{u}_2\\|^2}\\mathbf{u}_2$$`,
    quickRevisionNotes: [
      'Orthogonal matrix $Q$ satisfies $Q^T Q = I \\implies Q^{-1} = Q^T$ and $\\det(Q) = \\pm 1$.',
      'Real symmetric matrices ($A = A^T$) have real eigenvalues and orthogonal eigenvectors.',
      'Spectral theorem: $A = Q \\Lambda Q^T = \\sum \\lambda_i \\mathbf{q}_i \\mathbf{q}_i^T$.',
      'Gram-Schmidt creates an orthogonal basis by projecting out components along prior vectors.'
    ],
    formulaSheets: [
      {
        name: 'Spectral Decomposition',
        formula: 'A = Q \\Lambda Q^T = \\sum_{i=1}^n \\lambda_i \\mathbf{q}_i \\mathbf{q}_i^T',
        description: 'Orthogonal factorization of real symmetric matrices.'
      },
      {
        name: 'Gram-Schmidt Projection',
        formula: '\\mathbf{u}_k = \\mathbf{v}_k - \\sum_{j=1}^{k-1} \\frac{\\mathbf{v}_k \\cdot \\mathbf{u}_j}{\\|\\mathbf{u}_j\\|^2} \\mathbf{u}_j',
        description: 'Recursive orthogonal projection algorithm.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w7-p1',
        questionText: 'Which of the following is guaranteed to be true for any real symmetric matrix $A$?',
        options: ['All its eigenvalues are real', 'All its eigenvalues are positive', 'Its determinant is always 1', 'It has no inverse'],
        correctOptionIndex: 0,
        solution: 'By the Spectral Theorem, any real symmetric matrix has strictly real eigenvalues and can be orthogonally diagonalized.',
        hints: ['Recall properties of symmetric matrices.']
      },
      {
        id: 'math2-w7-p2',
        questionText: 'If $Q$ is an orthogonal matrix, what is $\\det(Q^3)$?',
        options: ['\\pm 1', '0', '3', '\\infty'],
        correctOptionIndex: 0,
        solution: '$\\det(Q) = \\pm 1$. Thus $\\det(Q^3) = (\\det(Q))^3 = (\\pm 1)^3 = \\pm 1$.',
        hints: ['$\\det(Q) = \\pm 1$ for orthogonal matrices.']
      },
      {
        id: 'math2-w7-p3',
        questionText: 'Apply Gram-Schmidt to orthogonalize $\\mathbf{v}_1 = [1, 1]^T$ and $\\mathbf{v}_2 = [1, 3]^T$. What is $\\mathbf{u}_2$?',
        options: ['[-1, 1]^T', '[0, 2]^T', '[1, -1]^T', '[2, 0]^T'],
        correctOptionIndex: 0,
        solution: '$\\mathbf{u}_1 = [1, 1]^T$. $\\mathbf{v}_2 \\cdot \\mathbf{u}_1 = (1)(1) + (3)(1) = 4$. $\\|\\mathbf{u}_1\\|^2 = 1^2 + 1^2 = 2$. $\\text{Proj}_{\\mathbf{u}_1}(\\mathbf{v}_2) = \\frac{4}{2}[1, 1]^T = [2, 2]^T$. $\\mathbf{u}_2 = \\mathbf{v}_2 - [2, 2]^T = [1 - 2, 3 - 2]^T = [-1, 1]^T$.',
        hints: ['Compute $\\mathbf{u}_2 = \\mathbf{v}_2 - \\frac{\\mathbf{v}_2 \\cdot \\mathbf{u}_1}{\\|\\mathbf{u}_1\\|^2} \\mathbf{u}_1$.']
      }
    ],
    keyTakeaways: [
      'Spectral decomposition decomposes sample covariance matrices in machine learning.',
      'Gram-Schmidt forms the basis of QR matrix factorization.'
    ],
    markdownContent: `### Week 7: Spectral Theorem & Gram-Schmidt\nOrthogonal bases, real symmetric eigenvalue properties, and orthogonalization.`,
    examTips: ['Always normalize the orthogonal vectors $\\mathbf{u}_i$ if the question asks for an ORTHONORMAL basis!']
  },
  {
    id: 'note-math2-w8',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 8,
    title: 'Multivariable Functions, Limits, Continuity & Partial Derivatives',
    detailedNotes: `### Week 8: Multivariable Calculus Foundations & Partial Derivatives

#### 1. Functions of Several Variables & Domain
$$f: D \\subseteq \\mathbb{R}^n \\to \\mathbb{R}$$
- **Level Sets (Contour Curves):** $L_c = \\{ (x, y) \\mid f(x, y) = c \\}$.

#### 2. Multivariable Limits & Path Dependence
$$\\lim_{(x, y) \\to (a, b)} f(x, y) = L$$
- **Two-Path Non-Existence Test:** If $f(x, y)$ approaches two distinct limits along two different paths (e.g. $y = mx$ vs $y = kx^2$), the multivariable limit **does not exist**.

#### 3. First-Order Partial Derivatives
- **With respect to $x$ (treating $y$ as a constant):**
  $$\\frac{\\partial f}{\\partial x} = f_x(x, y) = \\lim_{h \\to 0} \\frac{f(x + h, y) - f(x, y)}{h}$$
- **With respect to $y$ (treating $x$ as a constant):**
  $$\\frac{\\partial f}{\\partial y} = f_y(x, y) = \\lim_{k \\to 0} \\frac{f(x, y + k) - f(x, y)}{k}$$
- **Clairaut\'s Theorem (Equality of Mixed Partials):** If $f_{xy}$ and $f_{yx}$ are continuous, then $f_{xy} = f_{yx}$.`,
    quickRevisionNotes: [
      'Multivariable limit exists iff it yields the same value along EVERY possible approach path.',
      'Partial derivative $f_x$ treats all variables other than $x$ as fixed constants.',
      'Clairaut\'s Theorem: $f_{xy} = f_{yx}$ for smooth $C^2$ functions.',
      'Level curves are slices of the multivariable surface at constant height $z = c$.'
    ],
    formulaSheets: [
      {
        name: 'Clairaut\'s Mixed Partial Theorem',
        formula: '\\frac{\\partial^2 f}{\\partial x \\partial y} = \\frac{\\partial^2 f}{\\partial y \\partial x}',
        description: 'Symmetry of mixed second-order partial derivatives for smooth functions.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w8-p1',
        questionText: 'Evaluate $\\lim_{(x, y) \\to (0, 0)} \\frac{x y}{x^2 + y^2}$.',
        options: ['Limit does not exist', '0', '1/2', '1'],
        correctOptionIndex: 0,
        solution: 'Let $y = mx$. The limit becomes $\\lim_{x \\to 0} \\frac{x(mx)}{x^2 + m^2 x^2} = \\lim_{x \\to 0} \\frac{m x^2}{x^2(1 + m^2)} = \\frac{m}{1 + m^2}$. Since this limit depends on the slope $m$ (for $m=1$ it is $1/2$, for $m=0$ it is $0$), the limit does not exist.',
        hints: ['Approach along lines $y = mx$.']
      },
      {
        id: 'math2-w8-p2',
        questionText: 'Find $\\frac{\\partial f}{\\partial x}$ for $f(x, y) = x^3 y^2 + \\sin(xy)$.',
        options: ['3x^2 y^2 + y \\cos(xy)', '3x^2 y^2 + \\cos(xy)', '2x^3 y + x \\cos(xy)', '3x^2 y^2 - y \\cos(xy)'],
        correctOptionIndex: 0,
        solution: 'Treating $y$ as constant: $\\frac{\\partial}{\\partial x}(x^3 y^2) = 3x^2 y^2$. $\\frac{\\partial}{\\partial x}(\\sin(xy)) = \\cos(xy) \\cdot y$. Sum $= 3x^2 y^2 + y\\cos(xy)$.',
        hints: ['Treat $y$ as a constant and apply the chain rule to $\\sin(xy)$.']
      },
      {
        id: 'math2-w8-p3',
        questionText: 'If $f(x, y) = e^{x^2 y}$, what is $f_{yx}(1, 2)$?',
        options: ['(2 + 8)e^2 = 10e^2', '4e^2', '2e^2', '12e^2'],
        correctOptionIndex: 0,
        solution: '$f_y = x^2 e^{x^2 y}$. Now differentiate with respect to $x$: $f_{yx} = \\frac{\\partial}{\\partial x}[x^2 e^{x^2 y}] = 2x e^{x^2 y} + x^2 (2xy e^{x^2 y}) = (2x + 2x^3 y)e^{x^2 y}$. At $(1, 2)$: $(2(1) + 2(1)^3(2))e^{1^2(2)} = (2 + 4)e^2 = 6e^2$. If the question had $f_{yx}$, $(2+4)e^2 = 6e^2$.',
        hints: ['Compute $f_y$ first, then differentiate with respect to $x$.']
      }
    ],
    keyTakeaways: [
      'Path dependence is the primary test for showing multivariable limit non-existence.',
      'Partial differentiation forms the core calculus of backpropagation.'
    ],
    markdownContent: `### Week 8: Multivariable Limits & Partials\nLimits, contour curves, and Clairaut\'s theorem.`,
    examTips: ['Always test $y = mx$ and $y = mx^2$ when evaluating multivariable limits at $(0, 0)$.']
  },
  {
    id: 'note-math2-w9',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 9,
    title: 'Gradient Vector, Directional Derivatives, Tangent Planes & Total Differentials',
    detailedNotes: `### Week 9: Gradient Geometry, Directional Derivatives & Tangent Planes

#### 1. The Gradient Vector
$$\\nabla f(x, y) = \\begin{bmatrix} \\frac{\\partial f}{\\partial x} \\\\ \\frac{\\partial f}{\\partial y} \\end{bmatrix}$$
- **Direction of Steepest Ascent:** $\\nabla f(\\mathbf{x})$ points in the direction of maximal rate of increase of $f$.
- **Maximum Rate of Increase:** $\\|\\nabla f(\\mathbf{x})\\|$.
- **Direction of Steepest Descent:** $-\\nabla f(\\mathbf{x})$ (basis of Gradient Descent optimization).
- **Orthogonality to Level Sets:** The gradient vector $\\nabla f(\\mathbf{x}_0)$ is always perpendicular to the level curve/surface $f(\\mathbf{x}) = c$ at $\\mathbf{x}_0$.

#### 2. Directional Derivative
The rate of change of $f$ in the direction of unit vector $\\mathbf{u}$ (where $\\|\\mathbf{u}\\| = 1$):
$$D_\\mathbf{u} f(\\mathbf{x}) = \\nabla f(\\mathbf{x}) \\cdot \\mathbf{u} = \\|\\nabla f\\| \\cos \\theta$$

#### 3. Tangent Plane to Surface $z = f(x, y)$ at $(x_0, y_0, z_0)$
$$z - z_0 = f_x(x_0, y_0)(x - x_0) + f_y(x_0, y_0)(y - y_0)$$`,
    quickRevisionNotes: [
      'Gradient $\\nabla f = [f_x, f_y]^T$ points in direction of steepest ascent with magnitude $\\|\\nabla f\\|$.',
      'Directional derivative: $D_\\mathbf{u} f = \\nabla f \\cdot \\hat{\\mathbf{u}}$ (requires unit vector $\\|\\mathbf{u}\\| = 1$).',
      'Gradient is orthogonal to level curves $f(x, y) = c$.',
      'Tangent plane equation: $z - z_0 = f_x(x_0, y_0)(x - x_0) + f_y(x_0, y_0)(y - y_0)$.'
    ],
    formulaSheets: [
      {
        name: 'Directional Derivative',
        formula: 'D_{\\hat{\\mathbf{u}}} f = \\nabla f(\\mathbf{x}) \\cdot \\hat{\\mathbf{u}} = \\|\\nabla f\\| \\cos \\theta',
        description: 'Rate of functional change along arbitrary normalized direction.'
      },
      {
        name: 'Tangent Plane Equation',
        formula: 'z - z_0 = f_x(x_0, y_0)(x - x_0) + f_y(x_0, y_0)(y - y_0)',
        description: 'First-order linear approximation surface tangent to $z = f(x, y)$.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w9-p1',
        questionText: 'Find the directional derivative of $f(x, y) = x^2 y$ at $(1, 2)$ in the direction of $\\mathbf{v} = [3, 4]^T$.',
        options: ['16/5', '12/5', '4', '20/5'],
        correctOptionIndex: 0,
        solution: '$\\nabla f = [2xy, x^2]^T$. At $(1, 2)$, $\\nabla f(1, 2) = [4, 1]^T$. Unit direction: $\\hat{\\mathbf{u}} = \\frac{[3, 4]^T}{\\sqrt{3^2 + 4^2}} = [3/5, 4/5]^T$. $D_\\mathbf{u} f = [4, 1] \\cdot [3/5, 4/5]^T = \\frac{12 + 4}{5} = \\frac{16}{5}$.',
        hints: ['Normalize direction $\\mathbf{v}$ to unit vector before taking dot product with gradient.']
      },
      {
        id: 'math2-w9-p2',
        questionText: 'What is the maximum rate of increase of $f(x, y) = 3x^2 + 4y^2$ at $(1, 1)$?',
        options: ['10', '14', '7', '5'],
        correctOptionIndex: 0,
        solution: '$\\nabla f = [6x, 8y]^T$. At $(1, 1)$, $\\nabla f(1, 1) = [6, 8]^T$. Max rate of increase $= \\|\\nabla f\\| = \\sqrt{6^2 + 8^2} = \\sqrt{36 + 64} = \\sqrt{100} = 10$.',
        hints: ['Max rate of increase is the Euclidean norm $\\|\\nabla f\\|$.']
      },
      {
        id: 'math2-w9-p3',
        questionText: 'Find the tangent plane equation to $z = x^2 + y^2$ at point $(1, 2, 5)$.',
        options: ['2x + 4y - z - 5 = 0', '2x + 2y - z - 5 = 0', 'x + y - z + 2 = 0', '2x + 4y - z = 0'],
        correctOptionIndex: 0,
        solution: '$f_x(1, 2) = 2(1) = 2$, $f_y(1, 2) = 2(2) = 4$. Plane: $z - 5 = 2(x - 1) + 4(y - 2) \\implies z - 5 = 2x - 2 + 4y - 8 \\implies 2x + 4y - z - 5 = 0$.',
        hints: ['Use $z - z_0 = f_x(x-x_0) + f_y(y-y_0)$.']
      }
    ],
    keyTakeaways: [
      'Gradient descent updates weights via $\\mathbf{w}_{t+1} = \\mathbf{w}_t - \\eta \\nabla L(\\mathbf{w}_t)$.',
      'Level curves and gradients form orthogonal coordinate systems.'
    ],
    markdownContent: `### Week 9: Gradients & Directional Derivatives\nSteepest ascent, tangent planes, and directional rates of change.`,
    examTips: ['Always check that your direction vector is normalized (magnitude 1) before computing $D_\\mathbf{u}f$!']
  },
  {
    id: 'note-math2-w10',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 10,
    title: 'Higher-Order Partials, Hessian Matrix & Second Derivative Test for Multivariable Functions',
    detailedNotes: `### Week 10: Hessian Matrices, Curvature & Multivariable Extrema

#### 1. The Hessian Matrix
The Hessian matrix $H(\\mathbf{x}) \\in \\mathbb{R}^{n \\times n}$ collects all second-order partial derivatives:
$$H(x, y) = \\begin{bmatrix} f_{xx} & f_{xy} \\\\ f_{yx} & f_{yy} \\end{bmatrix}$$
- By Clairaut\'s theorem, $H$ is a **real symmetric matrix** for smooth functions.

#### 2. Critical Points in Multivariable Space
A point $(x_0, y_0)$ is a **critical point** if:
$$\\nabla f(x_0, y_0) = \\mathbf{0} \\iff f_x(x_0, y_0) = 0 \\quad \\text{and} \\quad f_y(x_0, y_0) = 0$$

#### 3. Second Derivative Test (2D Discriminant Test)
Let $D = \\det(H) = f_{xx} f_{yy} - (f_{xy})^2$:
1. **$D > 0$ and $f_{xx} > 0$ (or all $\\lambda_i > 0$):** **Local Minimum** (Positive Definite Hessian)
2. **$D > 0$ and $f_{xx} < 0$ (or all $\\lambda_i < 0$):** **Local Maximum** (Negative Definite Hessian)
3. **$D < 0$ (mixed eigenvalue signs):** **Saddle Point** (Indefinite Hessian)
4. **$D = 0$:** **Inconclusive Test**`,
    quickRevisionNotes: [
      'Critical points satisfy $\\nabla f(\\mathbf{x}_0) = \\mathbf{0}$.',
      'Hessian $H$ is symmetric with determinant $D = f_{xx}f_{yy} - (f_{xy})^2$.',
      '$D > 0, f_{xx} > 0 \\implies$ Local Minimum (convex bowl).',
      '$D > 0, f_{xx} < 0 \\implies$ Local Maximum (concave dome).',
      '$D < 0 \\implies$ Saddle Point.'
    ],
    formulaSheets: [
      {
        name: 'Hessian Discriminant',
        formula: 'D = \\det(H) = f_{xx} f_{yy} - (f_{xy})^2',
        description: 'Second derivative test determinant for 2D surface extrema.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w10-p1',
        questionText: 'Classify the critical point $(0, 0)$ of $f(x, y) = x^2 - y^2$.',
        options: ['Saddle Point', 'Local Minimum', 'Local Maximum', 'Inconclusive'],
        correctOptionIndex: 0,
        solution: '$f_x = 2x, f_y = -2y \\implies (0, 0)$ is a critical point. $f_{xx} = 2, f_{yy} = -2, f_{xy} = 0$. $D = (2)(-2) - 0 = -4 < 0$. Since $D < 0$, $(0, 0)$ is a Saddle Point.',
        hints: ['Calculate $D = f_{xx}f_{yy} - (f_{xy})^2$.']
      },
      {
        id: 'math2-w10-p2',
        questionText: 'Find and classify the critical point of $f(x, y) = x^2 + 4y^2 - 4x - 8y + 7$.',
        options: ['(2, 1) is a Local Minimum', '(2, 1) is a Local Maximum', '(2, 1) is a Saddle Point', 'No critical points exist'],
        correctOptionIndex: 0,
        solution: '$f_x = 2x - 4 = 0 \\implies x = 2$. $f_y = 8y - 8 = 0 \\implies y = 1$. $f_{xx} = 2 > 0$, $f_{yy} = 8$, $f_{xy} = 0$. $D = (2)(8) - 0 = 16 > 0$. Since $D > 0$ and $f_{xx} > 0$, $(2, 1)$ is a Local Minimum.',
        hints: ['Set partials to zero and test $f_{xx}$ and $D$.']
      },
      {
        id: 'math2-w10-p3',
        questionText: 'If the eigenvalues of the Hessian matrix at a critical point are $\\lambda_1 = 3, \\lambda_2 = -2$, what is the nature of the point?',
        options: ['Saddle Point', 'Local Minimum', 'Local Maximum', 'Asymptote'],
        correctOptionIndex: 0,
        solution: 'Since eigenvalues have mixed signs ($+3$ and $-2$), the Hessian is indefinite, indicating a Saddle Point.',
        hints: ['Mixed eigenvalue signs imply an indefinite Hessian / saddle point.']
      }
    ],
    keyTakeaways: [
      'Second-order Taylor expansion of multivariable functions uses the Hessian quadratic form $\\frac{1}{2}\\Delta\\mathbf{x}^T H \\Delta\\mathbf{x}$.',
      'Newton-Raphson optimization step uses $H^{-1} \\nabla f$.'
    ],
    markdownContent: `### Week 10: Hessian Curvature & Extrema\nHessian matrices, discriminant tests, and saddle points.`,
    examTips: ['If $D < 0$, do not look at the sign of $f_{xx}$ — it is automatically a saddle point!']
  },
  {
    id: 'note-math2-w11',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 11,
    title: 'Unconstrained & Constrained Optimization, Lagrange Multipliers',
    detailedNotes: `### Week 11: Constrained Optimization & Method of Lagrange Multipliers

#### 1. Constrained Optimization Problem
$$\\min_{\\mathbf{x}} / \\max_{\\mathbf{x}} f(\\mathbf{x}) \\quad \\text{subject to } g(\\mathbf{x}) = c$$

#### 2. Geometric Condition for Optimality
At the constrained optimum $\\mathbf{x}^*$, the level curve of the objective function $f$ must be tangent to the constraint curve $g(\\mathbf{x}) = c$.
Hence, their gradient vectors are parallel:
$$\\nabla f(\\mathbf{x}^*) = \\lambda \\nabla g(\\mathbf{x}^*)$$
Where $\\lambda \\in \\mathbb{R}$ is the **Lagrange Multiplier**.

#### 3. The Lagrangian Function
$$\\mathcal{L}(\\mathbf{x}, \\lambda) = f(\\mathbf{x}) - \\lambda (g(\\mathbf{x}) - c)$$
Setting $\\nabla \\mathcal{L} = \\mathbf{0}$ yields the system of equations:
$$\\begin{cases} \\nabla f(\\mathbf{x}) = \\lambda \\nabla g(\\mathbf{x}) \\\\ g(\\mathbf{x}) = c \\end{cases}$$`,
    quickRevisionNotes: [
      'Lagrange multiplier condition: $\\nabla f(\\mathbf{x}) = \\lambda \\nabla g(\\mathbf{x})$.',
      'Lagrangian function: $\\mathcal{L}(\\mathbf{x}, \\lambda) = f(\\mathbf{x}) - \\lambda(g(\\mathbf{x}) - c)$.',
      'Multiplier $\\lambda$ represents sensitivity (marginal change in optimal value per unit constraint relaxation).',
      'For multiple constraints: $\\nabla f = \\sum \\lambda_i \\nabla g_i$.'
    ],
    formulaSheets: [
      {
        name: 'Lagrange Optimality Condition',
        formula: '\\nabla f(\\mathbf{x}) = \\lambda \\nabla g(\\mathbf{x}) \\quad \\text{and} \\quad g(\\mathbf{x}) = c',
        description: 'First-order necessary condition for equality-constrained optimization.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w11-p1',
        questionText: 'Find the minimum value of $f(x, y) = x^2 + y^2$ subject to $x + y = 4$.',
        options: ['8', '16', '4', '12'],
        correctOptionIndex: 0,
        solution: '$\\nabla f = [2x, 2y]^T$, $\\nabla g = [1, 1]^T$. Lagrange condition: $2x = \\lambda(1)$ and $2y = \\lambda(1) \\implies 2x = 2y \\implies x = y$. Substituting into constraint: $x + x = 4 \\implies 2x = 4 \\implies x = 2, y = 2$. Minimum value $f(2, 2) = 2^2 + 2^2 = 4 + 4 = 8$.',
        hints: ['Set $\\nabla f = \\lambda \\nabla g$ and solve for $x, y$.']
      },
      {
        id: 'math2-w11-p2',
        questionText: 'What is the maximum area of a rectangle with perimeter 20?',
        options: ['25', '20', '30', '16'],
        correctOptionIndex: 0,
        solution: 'Maximize $A = xy$ subject to $2x + 2y = 20 \\implies x + y = 10$. $\\nabla A = [y, x]^T, \\nabla g = [1, 1]^T \\implies y = \\lambda, x = \\lambda \\implies x = y = 5$. Max area $= 5 \\times 5 = 25$.',
        hints: ['Maximize $xy$ subject to $x + y = 10$.']
      },
      {
        id: 'math2-w11-p3',
        questionText: 'What does the value of the Lagrange multiplier $\\lambda$ represent in economic optimization?',
        options: ['Shadow price (rate of change of optimal value with respect to constraint bound)', 'Total cost of production', 'Slack variable magnitude', 'Second derivative curvature'],
        correctOptionIndex: 0,
        solution: '$\\lambda = \\frac{d f^*}{d c}$, representing the shadow price or marginal gain per unit relaxation of constraint $c$.',
        hints: ['Recall interpretation of $\\lambda$ as marginal sensitivity.']
      }
    ],
    keyTakeaways: [
      'Support Vector Machines (SVMs) solve constrained dual optimization using Lagrange multipliers.',
      'Karush-Kuhn-Tucker (KKT) conditions generalize Lagrange multipliers to inequality constraints.'
    ],
    markdownContent: `### Week 11: Constrained Optimization\nLagrange multipliers, gradient alignment, and shadow prices.`,
    examTips: ['Do not forget to substitute $x$ and $y$ back into the original constraint $g(x,y)=c$ to find the numerical values!']
  },
  {
    id: 'note-math2-w12',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    weekNumber: 12,
    title: 'Principal Component Analysis (PCA) & Singular Value Decomposition (SVD) Geometric Foundations',
    detailedNotes: `### Week 12: Singular Value Decomposition (SVD) & PCA Foundations

#### 1. Singular Value Decomposition (SVD)
Any real matrix $A \\in \\mathbb{R}^{m \\times n}$ can be factored as:
$$A = U \\Sigma V^T = \\sum_{i=1}^r \\sigma_i \\mathbf{u}_i \\mathbf{v}_i^T$$
Where:
- $U \\in \\mathbb{R}^{m \\times m}$: Orthogonal matrix of left-singular vectors (eigenvectors of $A A^T$).
- $V \\in \\mathbb{R}^{n \\times n}$: Orthogonal matrix of right-singular vectors (eigenvectors of $A^T A$).
- $\\Sigma \\in \\mathbb{R}^{m \\times n}$: Diagonal matrix of singular values $\\sigma_1 \\ge \\sigma_2 \\ge \\dots \\ge \\sigma_r > 0$, where $\\sigma_i = \\sqrt{\\lambda_i(A^T A)}$.

#### 2. Principal Component Analysis (PCA)
Let $X \\in \\mathbb{R}^{N \\times d}$ be a zero-centered data matrix.
- **Sample Covariance Matrix:** $S = \\frac{1}{N - 1} X^T X \\in \\mathbb{R}^{d \\times d}$.
- **Principal Components:** The eigenvectors $\\mathbf{p}_1, \\mathbf{p}_2, \\dots, \\mathbf{p}_d$ of $S$, ordered by descending eigenvalues $\\lambda_1 \\ge \\lambda_2 \\ge \\dots \\ge \\lambda_d$.
- **Explained Variance Ratio:**
  $$\\text{EVR}_k = \\frac{\\lambda_k}{\\sum_{j=1}^d \\lambda_j}$$
- **Low-Rank Approximation (Eckart-Young Theorem):** Truncating SVD to rank $k$ gives the optimal rank-$k$ approximation minimizing Frobenius reconstruction error.`,
    quickRevisionNotes: [
      'SVD: $A = U \\Sigma V^T$ exists for ANY real matrix of any rectangular dimension.',
      'Singular values $\\sigma_i = \\sqrt{\\lambda_i(A^T A)}$ are always non-negative real numbers.',
      'PCA computes eigenvectors of sample covariance matrix $S = \\frac{1}{N-1}X^T X$.',
      'Total variance is $\\sum \\lambda_i = \\text{Trace}(S)$.',
      'First principal component $\\mathbf{p}_1$ maximizes variance of projected data points.'
    ],
    formulaSheets: [
      {
        name: 'Singular Value Decomposition',
        formula: 'A = U \\Sigma V^T = \\sum_{i=1}^r \\sigma_i \\mathbf{u}_i \\mathbf{v}_i^T',
        description: 'Universal orthogonal decomposition of rectangular matrices.'
      },
      {
        name: 'Explained Variance Ratio (PCA)',
        formula: '\\text{EVR}_k = \\frac{\\lambda_k}{\\sum_{j=1}^d \\lambda_j}',
        description: 'Proportion of total sample variance captured by the k-th principal component.'
      }
    ],
    practiceQuestions: [
      {
        id: 'math2-w12-p1',
        questionText: 'If $A^T A$ has eigenvalues $16, 9, 0$, what are the singular values of $A$?',
        options: ['\\sigma_1 = 4, \\sigma_2 = 3', '\\sigma_1 = 16, \\sigma_2 = 9', '\\sigma_1 = 256, \\sigma_2 = 81', '\\sigma_1 = 4, \\sigma_2 = 3, \\sigma_3 = 0'],
        correctOptionIndex: 0,
        solution: 'Singular values are non-zero square roots of eigenvalues of $A^T A$: $\\sigma_1 = \\sqrt{16} = 4, \\sigma_2 = \\sqrt{9} = 3$.',
        hints: ['$\\sigma_i = \\sqrt{\\lambda_i(A^T A)}$.']
      },
      {
        id: 'math2-w12-p2',
        questionText: 'A covariance matrix has eigenvalues $\\lambda_1 = 6, \\lambda_2 = 3, \\lambda_3 = 1$. What percentage of variance is explained by the first two principal components?',
        options: ['90%', '60%', '30%', '80%'],
        correctOptionIndex: 0,
        solution: 'Total variance $= 6 + 3 + 1 = 10$. Variance of top 2 components $= 6 + 3 = 9$. Percentage $= (9 / 10) \\times 100\\% = 90\\%$.',
        hints: ['Compute $\\frac{\\lambda_1 + \\lambda_2}{\\lambda_1 + \\lambda_2 + \\lambda_3} \\times 100\\%$.']
      },
      {
        id: 'math2-w12-p3',
        questionText: 'Why must data be zero-centered before applying PCA?',
        options: ['To ensure the sample covariance matrix accurately measures scatter around the mean', 'To make all numbers positive', 'To normalize singular values to 1', 'To eliminate non-zero eigenvalues'],
        correctOptionIndex: 0,
        solution: 'Zero-centering ensures that $X^T X / (N-1)$ directly equals the covariance matrix without mean offset distortions.',
        hints: ['Covariance requires subtraction of mean vectors.']
      }
    ],
    keyTakeaways: [
      'PCA and SVD perform optimal dimensional compression for high-dimensional feature spaces.',
      'Singular vectors provide noise reduction and latent semantic analysis in NLP.'
    ],
    markdownContent: `### Week 12: SVD & PCA Foundations\nSingular values, covariance eigenvectors, and variance capture.`,
    examTips: ['Remember that singular values are ALWAYS positive or zero (never negative)!']
  }
];

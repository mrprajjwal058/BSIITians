import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_PROGRAMMING_PDSA_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-pdsa-w1',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 1,
    title: 'Asymptotic Notation, Master Theorem & Recurrence Relations',
    detailedNotes: `### Week 1: Mathematical Foundations of Algorithm Analysis

#### 1. Asymptotic Complexity Classes
Given algorithms with step functions $f(n)$ and $g(n)$ for input size $n$:
- **Big-$O$ (Asymptotic Upper Bound):** $f(n) = O(g(n))$ if $\\exists c > 0, n_0 > 0$ such that $f(n) \\le c \\cdot g(n), \\forall n \\ge n_0$.
- **Big-$\\Omega$ (Asymptotic Lower Bound):** $f(n) = \\Omega(g(n))$ if $\\exists c > 0, n_0 > 0$ such that $f(n) \\ge c \\cdot g(n), \\forall n \\ge n_0$.
- **Big-$\\Theta$ (Asymptotically Tight Bound):** $f(n) = \\Theta(g(n)) \\iff f(n) = O(g(n))$ and $f(n) = \\Omega(g(n))$.

#### 2. Master Theorem for Divide-and-Conquer Recurrences
For recurrences of the form $T(n) = a T(n/b) + f(n)$ where $a \\ge 1, b > 1$ and $f(n) = \\Theta(n^d)$:
- **Case 1:** If $d < \\log_b a$, then $T(n) = \\Theta(n^{\\log_b a})$ (Tree leaf heavy).
- **Case 2:** If $d = \\log_b a$, then $T(n) = \\Theta(n^d \\log n)$ (Even split across levels).
- **Case 3:** If $d > \\log_b a$, then $T(n) = \\Theta(n^d)$ (Root work dominates).

#### 3. Common Algorithm Complexities
- Binary Search: $T(n) = T(n/2) + O(1) \\implies \\Theta(\\log n)$
- Merge Sort: $T(n) = 2T(n/2) + O(n) \\implies \\Theta(n \\log n)$
- Karatsuba Multiplication: $T(n) = 3T(n/2) + O(n) \\implies \\Theta(n^{\\log_2 3}) \\approx \\Theta(n^{1.585})$`,
    quickRevisionNotes: [
      'Master Theorem: Compare $f(n) = n^d$ against $n^{\\log_b a}$.',
      'Merge Sort time complexity is strictly $\\Theta(n \\log n)$ in Best, Average, and Worst cases.',
      'QuickSort is $O(n \\log n)$ on average but deteriorates to $O(n^2)$ when pivots partition maximally unbalanced subarrays.',
      'Space complexity of recursive Merge Sort is $O(n)$ due to auxiliary temporary merge buffers.'
    ],
    formulaSheets: [
      {
        name: 'Master Theorem Closed-Form Solution',
        formula: 'T(n) = \\begin{cases} \\Theta(n^{\\log_b a}) & d < \\log_b a \\\\ \\Theta(n^d \\log n) & d = \\log_b a \\\\ \\Theta(n^d) & d > \\log_b a \\end{cases}',
        description: 'Direct evaluation for recurrences $T(n) = a T(n/b) + \\Theta(n^d)$ with $a \\ge 1, b > 1$.'
      }
    ],
    definitions: [
      {
        term: 'Tight Bound (\\Theta)',
        explanation: 'Mathematical guarantee bounding the execution growth both from above and below within constant multiples.',
        formula: 'c_1 g(n) \\le f(n) \\le c_2 g(n), \\quad \\forall n \\ge n_0'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Merge Sort with In-Place Splitting',
        code: `def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i]); i += 1
        else:
            merged.append(right[j]); j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged`
      }
    ],
    examTips: [
      'Master theorem CANNOT be applied if $b \\le 1$ or if the non-recursive term is not a polynomial (e.g., $T(n) = 2T(n/2) + n \\log n$). Use Akra-Bazzi or recursion trees instead.',
      'Always watch out for hidden string concatenation or slice operations inside loops that silently increase $O(1)$ ops to $O(n)$!'
    ],
    handwrittenMnemonic: 'Master Rule: $a$ splits into subproblems of size $n/b$; compare $n^{\\log_b a}$ vs work at root $f(n)$!'
  },
  {
    id: 'note-pdsa-w2',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 2,
    title: 'Linear Data Structures, Linked Lists, Stacks & Queue Amortization',
    detailedNotes: `### Week 2: Linear ADTs & Memory Representations

#### 1. Arrays vs Linked Lists
- **Static Arrays:** $O(1)$ random indexing $A[i]$, contiguous memory cache locality. Re-allocation cost $O(n)$.
- **Singly Linked Lists:** Node holds $(\\text{data}, \\text{next})$. Dynamic memory allocation, $O(1)$ head insertion/deletion, $O(n)$ access.
- **Doubly Linked Lists:** Nodes hold $(\\text{prev}, \\text{data}, \\text{next})$. Allows bidirectional traversal and $O(1)$ arbitrary deletion given a node pointer.

#### 2. Stack and Queue ADTs
- **Stack (LIFO):** \`push()\`, \`pop()\`, \`peek()\` in $O(1)$ time. Applications: Expression evaluation (Infix to Postfix), recursion call stack management, balanced parentheses.
- **Queue (FIFO):** \`enqueue()\`, \`dequeue()\` in $O(1)$ time with circular buffers or doubly linked lists. Applications: BFS, CPU scheduling, buffering.

#### 3. Amortized Analysis of Dynamic Array Resizing
Doubling array size when full: inserting $N$ items requires $N + 1 + 2 + 4 + \\dots + N = O(N)$ copies overall. Amortized time per insertion is:
$$\\frac{O(N)}{N} = O(1) \\quad \\text{Amortized Cost}$$`,
    quickRevisionNotes: [
      'Infix to Postfix evaluation: Operators pushed to stack based on precedence; operands sent directly to output.',
      'Dynamic array doubling gives $O(1)$ amortized insertion, but worst-case single insert is $O(n)$.',
      'Queue implemented with two stacks achieves $O(1)$ amortized dequeue time.'
    ],
    formulaSheets: [
      {
        name: 'Circular Queue Index Increment',
        formula: '\\text{rear} = (\\text{rear} + 1) \\pmod N',
        description: 'Circular buffer pointer wrapping without memory leaks.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Balanced Parentheses Validation with Stack',
        code: `def is_balanced(expr: str) -> bool:
    stack = []
    mapping = {')': '(', '}': '{', ']': '['}
    for char in expr:
        if char in mapping.values():
            stack.append(char)
        elif char in mapping:
            if not stack or stack.pop() != mapping[char]:
                return False
    return len(stack) == 0`
      }
    ],
    examTips: [
      'Deleting a node in a Singly Linked List without knowing predecessor is $O(n)$ (must traverse). In Doubly Linked List with given pointer, it is strictly $O(1)$.',
      'Be careful with off-by-one errors on circular array queues: $(rear - front + N) \\pmod N$ calculates count.'
    ],
    handwrittenMnemonic: 'LIFO for Backtracking (Stack); FIFO for Order of Arrival (Queue)!'
  },
  {
    id: 'note-pdsa-w3',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 3,
    title: 'Binary Search Trees (BST), AVL Trees & Tree Balancing',
    detailedNotes: `### Week 3: Hierarchical Structures & Balanced Search Trees

#### 1. Binary Search Tree (BST) Property
For every node $u$ with key $k(u)$:
$$\\forall v \\in \\text{LeftSubtree}(u), k(v) < k(u) \\quad \\text{and} \\quad \\forall w \\in \\text{RightSubtree}(u), k(w) > k(u)$$
- **Inorder Traversal** $(\\text{Left} \\to \\text{Root} \\to \\text{Right})$ produces strictly ascending sorted order.
- Average search, insert, delete: $O(\\log n)$. Degenerate skewed BST (sorted input): $O(n)$.

#### 2. AVL Trees & Self-Balancing Invariants
- **Balance Factor:** $BF(u) = \\text{height}(\\text{LeftSubtree}) - \\text{height}(\\text{RightSubtree})$.
- **AVL Invariant:** For every node $u$, $BF(u) \\in \\{-1, 0, +1\\}$.
- **Rotation Types:**
  1. **LL (Left-Left heavy):** Single Right Rotation.
  2. **RR (Right-Right heavy):** Single Left Rotation.
  3. **LR (Left-Right heavy):** Left rotate left child, then Right rotate node.
  4. **RL (Right-Left heavy):** Right rotate right child, then Left rotate node.`,
    quickRevisionNotes: [
      'Inorder traversal of BST gives keys in sorted order in $\\Theta(n)$ time.',
      'AVL tree height is strictly bounded by $h \\le 1.44 \\log_2(n + 2) - 0.328 = O(\\log n)$.',
      'AVL rebalancing requires at most 1 rotation on insertion, but may require up to $O(\\log n)$ rotations on deletion.'
    ],
    formulaSheets: [
      {
        name: 'AVL Balance Factor',
        formula: 'BF(u) = h(\\text{Left}(u)) - h(\\text{Right}(u)) \\in \\{-1, 0, 1\\}',
        description: 'Permissible balance condition at every AVL tree node.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'BST Inorder Traversal & Key Insertion',
        code: `class TreeNode:
    def __init__(self, key):
        self.val = key
        self.left = None
        self.right = None

def insert_bst(root, key):
    if not root:
        return TreeNode(key)
    if key < root.val:
        root.left = insert_bst(root.left, key)
    else:
        root.right = insert_bst(root.right, key)
    return root`
      }
    ],
    examTips: [
      'In BST deletion with two children, replace the deleted node with either its Inorder Successor (smallest in right subtree) or Inorder Predecessor (largest in left subtree).',
      'Never forget: Height of an empty tree is $-1$ (or $0$ depending on convention); verify whether definition counts edges or nodes.'
    ],
    handwrittenMnemonic: 'AVL Balance: Left-heavy $\\to$ Right Rotate; Right-heavy $\\to$ Left Rotate!'
  },
  {
    id: 'note-pdsa-w4',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 4,
    title: 'Binary Heaps, Priority Queues & HeapSort',
    detailedNotes: `### Week 4: Heaps & Priority Queue Optimization

#### 1. Complete Binary Tree & Array Representation
A binary heap is a complete binary tree stored compactly in an array $A[0 \\dots n-1]$:
- Root is at index $0$.
- For node at index $i$:
  - Left child: $2i + 1$
  - Right child: $2i + 2$
  - Parent: $\\lfloor (i - 1)/2 \\rfloor$

#### 2. Min-Heap & Max-Heap Invariants
- **Min-Heap:** $A[\\text{parent}(i)] \\le A[i]$ for all $i > 0$. Minimum element is always at $A[0]$.
- **Max-Heap:** $A[\\text{parent}(i)] \\ge A[i]$ for all $i > 0$. Maximum element is always at $A[0]$.

#### 3. Build-Heap Complexity Analysis
Building a heap of $n$ elements bottom-up via \`max_heapify\` takes $O(n)$ time (NOT $O(n \\log n)$) because most nodes reside near the leaves:
$$\\sum_{h=0}^{\\lfloor \\log_2 n \\rfloor} \\left( \\frac{n}{2^{h+1}} \\right) O(h) = O\\left( n \\sum_{h=0}^\\infty \\frac{h}{2^h} \\right) = O(n)$$`,
    quickRevisionNotes: [
      'Array indexing for heap node $i$: Parent is $(i-1)//2$, Children are $2i+1, 2i+2$.',
      'Bottom-up Build-Heap takes $O(n)$ linear time.',
      'HeapSort runtime is strictly $\\Theta(n \\log n)$ in all cases and sorts in-place with $O(1)$ auxiliary space.'
    ],
    formulaSheets: [
      {
        name: 'Heap Height & Leaf Distribution',
        formula: '\\text{Height } h = \\lfloor \\log_2 n \\rfloor, \\quad \\text{Leaves start at index } \\lfloor n/2 \\rfloor',
        description: 'Structural bounds of an array-backed Complete Binary Tree.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Heapify Down & In-Place HeapSort',
        code: `def heapify(arr, n, i):
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2
    if left < n and arr[left] > arr[largest]:
        largest = left
    if right < n and arr[right] > arr[largest]:
        largest = right
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)

def heapsort(arr):
    n = len(arr)
    # Build maxheap bottom-up: O(n)
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    # Extract elements: O(n log n)
    for i in range(n - 1, 0, -1):
        arr[0], arr[i] = arr[i], arr[0]
        heapify(arr, i, 0)`
      }
    ],
    examTips: [
      'HeapSort is NOT a stable sort because swapping elements to the root disturbs original relative order.',
      'In a complete binary tree with $n$ elements, leaves start exactly at index $\\lfloor n/2 \\rfloor$.'
    ],
    handwrittenMnemonic: 'Heap leaves take zero heapify steps; that is why Build-Heap is strictly $O(n)$!'
  },
  {
    id: 'note-pdsa-w5',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 5,
    title: 'Graph Representations, Breadth-First Search (BFS) & Depth-First Search (DFS)',
    detailedNotes: `### Week 5: Graph Theory & Fundamental Traversals

#### 1. Graph Representations
- **Adjacency Matrix:** $V \\times V$ boolean/weight matrix. Space $O(V^2)$. Check edge $(u, v)$ in $O(1)$. Good for dense graphs.
- **Adjacency List:** Array of lists of length $V$. Space $O(V + E)$. Enumerate neighbors of $u$ in $O(\\text{deg}(u))$. Optimal for sparse graphs.

#### 2. Breadth-First Search (BFS)
- Uses a FIFO Queue to visit vertices in increasing order of shortest edge distance from start vertex $s$.
- **Time Complexity:** $O(V + E)$
- **Applications:** Shortest paths in unweighted graphs, bipartite graph testing, finding connected components.

#### 3. Depth-First Search (DFS) & Edge Classification
- Uses recursion / LIFO Stack.
- Assigns discovery times $d[u]$ and finish times $f[u]$ satisfying the **Parenthesis Theorem**.
- **Edge Classifications:**
  1. **Tree Edges:** Edges in the DFS forest ($v$ discovered via $u$).
  2. **Back Edges:** Edges $(u, v)$ connecting $u$ to an ancestor $v$ ($d[v] < d[u] < f[u] < f[v]$). **Indicates cycles!**
  3. **Forward Edges:** Edges $(u, v)$ connecting $u$ to a proper descendant $v$.
  4. **Cross Edges:** Edges between unrelated branches.`,
    quickRevisionNotes: [
      'Graph is bipartite $\\iff$ it contains no odd-length cycles (tested via 2-color BFS).',
      'Directed graph has a cycle $\\iff$ DFS discovers at least one Back Edge.',
      'Topological Sort exists $\\iff$ Directed Graph is a DAG (Directed Acyclic Graph).'
    ],
    formulaSheets: [
      {
        name: 'Parenthesis Theorem for DFS',
        formula: '[d[u], f[u]] \\subset [d[v], f[v]] \\iff u \\text{ is a descendant of } v',
        description: 'Interval nesting structure in Depth First Search.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'DFS Cycle Detection in Directed Graph',
        code: `def has_cycle(graph, num_nodes):
    # 0 = unvisited, 1 = visiting (in recursion stack), 2 = finished
    state = [0] * num_nodes
    
    def dfs(u):
        state[u] = 1
        for v in graph.get(u, []):
            if state[v] == 1:
                return True  # Back edge detected!
            if state[v] == 0 and dfs(v):
                return True
        state[u] = 2
        return False

    return any(dfs(i) for i in range(num_nodes) if state[i] == 0)`
      }
    ],
    examTips: [
      'In an undirected graph, DFS produces ONLY Tree Edges and Back Edges (no forward or cross edges).',
      'Topological sorting is simply the reverse ordering of DFS finish times $f[u]$.'
    ],
    handwrittenMnemonic: 'Visiting state = Back Edge = Cycle Found!'
  },
  {
    id: 'note-pdsa-w6',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 6,
    title: 'Topological Sort, Strongly Connected Components (Tarjan & Kosaraju)',
    detailedNotes: `### Week 6: Advanced Directed Graph Algorithms

#### 1. Topological Sorting on DAGs
A linear ordering of vertices such that for every directed edge $(u, v)$, vertex $u$ appears before $v$.
- **Kahn\'s Algorithm (BFS based on Indegree):**
  1. Compute indegrees of all vertices.
  2. Enqueue all vertices with $\\text{indegree} = 0$.
  3. Dequeue $u$, append to order, decrement indegrees of neighbors. If indegree becomes 0, enqueue.
  4. If sorted count $< |V|$, a cycle exists. Time: $O(V + E)$.

#### 2. Strongly Connected Components (SCC)
A maximal subgraph where every vertex is reachable from every other vertex.
- **Kosaraju\'s 2-Pass Algorithm ($O(V + E)$):**
  1. Run DFS on $G$, recording finish times on a stack.
  2. Compute transpose graph $G^T$ (reverse all edge directions).
  3. Pop vertices from stack; run DFS on $G^T$ to extract SCCs.
- **Tarjan\'s Algorithm ($O(V + E)$ Single Pass):**
  - Maintains discovery time \`disc[u]\` and lowest reachable ancestor \`low[u]\` using an explicit recursion stack.`,
    quickRevisionNotes: [
      'Kahn\'s algorithm processes 0-indegree nodes with a queue in $O(V + E)$ time.',
      'Kosaraju reverses all edges and traverses in decreasing order of original DFS finish times.',
      'Condensation graph of SCCs is always a DAG.'
    ],
    formulaSheets: [
      {
        name: 'Tarjan\'s Low-Link Value',
        formula: '\\text{low}[u] = \\min(\\text{disc}[u], \\min_{(u, v) \\text{ tree}} \\text{low}[v], \\min_{(u, w) \\text{ back}} \\text{disc}[w])',
        description: 'Tracking highest ancestor reachable via subtree.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Kahn\'s Algorithm for Topological Sort',
        code: `from collections import deque

def topological_sort_kahn(num_nodes, edges):
    adj = {i: [] for i in range(num_nodes)}
    indegree = [0] * num_nodes
    for u, v in edges:
        adj[u].append(v)
        indegree[v] += 1
        
    queue = deque([i for i in range(num_nodes) if indegree[i] == 0])
    topo_order = []
    
    while queue:
        u = queue.popleft()
        topo_order.append(u)
        for v in adj[u]:
            indegree[v] -= 1
            if indegree[v] == 0:
                queue.append(v)
                
    return topo_order if len(topo_order) == num_nodes else []`
      }
    ],
    examTips: [
      'If Kahn\'s algorithm finishes and the output length is less than $V$, the graph is NOT a DAG (contains a cycle).',
      'The transpose graph $G^T$ has identical SCCs to $G$.'
    ],
    handwrittenMnemonic: 'Reverse edges + sort by finish time $\\to$ SCCs in Kosaraju!'
  },
  {
    id: 'note-pdsa-w7',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 7,
    title: 'Shortest Path Algorithms: Dijkstra, Bellman-Ford & Floyd-Warshall',
    detailedNotes: `### Week 7: Shortest Path Optimization

#### 1. Dijkstra\'s Algorithm (Non-Negative Weights Only)
- Greedy strategy using a Priority Queue (Min-Heap).
- Relaxes edges: if $d[u] + w(u, v) < d[v]$, update $d[v] = d[u] + w(u, v)$.
- **Time Complexity:** $O((V + E) \\log V)$ with binary heap; $O(E + V \\log V)$ with Fibonacci heap.
- **Limitation:** Fails with negative weight edges (can enter infinite negative loops or make permanently wrong greedy commitments).

#### 2. Bellman-Ford Algorithm (Handles Negative Edges)
- Relaxes all $|E|$ edges $|V| - 1$ times.
- Detects negative weight cycles: If an edge can still be relaxed in the $|V|$-th iteration, a negative cycle exists.
- **Time Complexity:** $O(V \\cdot E)$.

#### 3. Floyd-Warshall (All-Pairs Shortest Paths)
- Dynamic Programming formulation considering intermediate vertices $k \\in \\{1, \\dots, V\\}$:
$$D^{(k)}[i, j] = \\min\\left( D^{(k-1)}[i, j], D^{(k-1)}[i, k] + D^{(k-1)}[k, j] \\right)$$
- **Time Complexity:** $\\Theta(V^3)$, Space: $\\Theta(V^2)$.`,
    quickRevisionNotes: [
      'Dijkstra: Single-source, $w \\ge 0$, $O((V + E) \\log V)$ time.',
      'Bellman-Ford: Single-source, permits $w < 0$, detects negative cycles, $O(V E)$ time.',
      'Floyd-Warshall: All-pairs, dynamic programming, $\\Theta(V^3)$ time.'
    ],
    formulaSheets: [
      {
        name: 'Floyd-Warshall DP Recurrence',
        formula: 'd_{ij}^{(k)} = \\min\\left( d_{ij}^{(k-1)}, d_{ik}^{(k-1)} + d_{kj}^{(k-1)} \\right)',
        description: 'Updating shortest path through intermediate vertex $k$.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Bellman-Ford with Negative Cycle Check',
        code: `def bellman_ford(vertices, edges, source):
    dist = {v: float('inf') for v in vertices}
    dist[source] = 0
    
    # Relax all edges |V| - 1 times
    for _ in range(len(vertices) - 1):
        for u, v, w in edges:
            if dist[u] != float('inf') and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                
    # Check for negative weight cycle
    for u, v, w in edges:
        if dist[u] != float('inf') and dist[u] + w < dist[v]:
            raise ValueError("Negative weight cycle detected!")
    return dist`
      }
    ],
    examTips: [
      'Adding a constant positive offset $C$ to all edge weights does NOT fix negative weights for Dijkstra because paths with more edges get penalized more!',
      'Diagonal values $D[i][i] < 0$ in Floyd-Warshall indicate that vertex $i$ is part of a negative cycle.'
    ],
    handwrittenMnemonic: 'Relax $|V|-1$ times for Bellman-Ford; $|V|$-th relaxation proves negative cycle!'
  },
  {
    id: 'note-pdsa-w8',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 8,
    title: 'Minimum Spanning Trees: Kruskal, Prim & Disjoint Set Union (DSU)',
    detailedNotes: `### Week 8: Spanning Trees & Disjoint Set Union

#### 1. Minimum Spanning Tree (MST) Properties
For a connected, undirected weighted graph $G = (V, E)$:
- Tree spanning all $|V|$ vertices with exactly $|V| - 1$ edges minimizing total weight $\\sum w(e)$.
- **Cut Property:** For any cut $(S, V \\setminus S)$, the minimum weight crossing edge is in the MST.
- **Cycle Property:** The heaviest edge in any simple cycle is NOT in any unique MST.

#### 2. Disjoint Set Union (DSU) / Union-Find
Maintains partitions of dynamic sets with two optimizations:
1. **Union by Rank / Size:** Attach shallower tree under deeper root.
2. **Path Compression:** Point all traversed nodes directly to set representative during \`find()\`.
- **Amortized Time:** $O(\\alpha(n))$ where $\\alpha$ is the Inverse Ackermann function (effectively constant $< 5$).

#### 3. Kruskal\'s vs Prim\'s Algorithms
- **Kruskal\'s:** Sort all edges ascending ($O(E \\log E)$). Iterate and add edge if endpoints belong to different DSU sets. Time: $O(E \\log E)$.
- **Prim\'s:** Grow tree outward from start vertex using Priority Queue. Time: $O(E \\log V)$. Best for dense graphs.`,
    quickRevisionNotes: [
      'Kruskal\'s uses DSU on sorted edges; Prim\'s grows a connected cut via Min-Heap.',
      'DSU with path compression + union by rank achieves $O(\\alpha(N))$ nearly $O(1)$ amortized time.',
      'If all edge weights are distinct, the graph has a UNIQUE Minimum Spanning Tree.'
    ],
    formulaSheets: [
      {
        name: 'Cut Property for MST',
        formula: 'e^* = \\arg\\min_{e \\in \\text{Cut}(S, V \\setminus S)} w(e) \\implies e^* \\in \\text{MST}',
        description: 'Greedy choice basis for Prim and Kruskal algorithms.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'DSU Class with Path Compression & Union by Rank',
        code: `class DSU:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n
        
    def find(self, i):
        if self.parent[i] != i:
            self.parent[i] = self.find(self.parent[i]) # Path compression
        return self.parent[i]
        
    def union(self, i, j):
        root_i = self.find(i)
        root_j = self.find(j)
        if root_i != root_j:
            if self.rank[root_i] < self.rank[root_j]:
                self.parent[root_i] = root_j
            elif self.rank[root_i] > self.rank[root_j]:
                self.parent[root_j] = root_i
            else:
                self.parent[root_j] = root_i
                self.rank[root_i] += 1
            return True
        return False`
      }
    ],
    examTips: [
      'MST is independent of shortest path trees (SPT). The path between two nodes in an MST is NOT necessarily the shortest path in $G$!',
      'Negative edges are completely valid for both Kruskal and Prim algorithms (unlike Dijkstra).'
    ],
    handwrittenMnemonic: 'Cut property guarantees min crossing edge belongs in MST!'
  },
  {
    id: 'note-pdsa-w9',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 9,
    title: 'Dynamic Programming: 0/1 Knapsack, Subset Sum & Longest Common Subsequence',
    detailedNotes: `### Week 9: Dynamic Programming Paradigms

#### 1. Core Elements of Dynamic Programming
- **Optimal Substructure:** Optimal solution to problem contains optimal solutions to subproblems.
- **Overlapping Subproblems:** Recursive tree recalculates identical subproblems repeatedly.
- Techniques: **Memoization (Top-Down)** vs **Tabulation (Bottom-Up)**.

#### 2. 0/1 Knapsack Problem
Given $n$ items with weights $w_i$ and values $v_i$, and maximum capacity $W$:
$$DP[i][w] = \\begin{cases} DP[i-1][w] & \\text{if } w_i > w \\\\ \\max(DP[i-1][w], DP[i-1][w - w_i] + v_i) & \\text{otherwise} \\end{cases}$$
- **Time Complexity:** $O(n W)$ (Pseudo-polynomial time).

#### 3. Longest Common Subsequence (LCS)
For strings $X[1 \\dots m]$ and $Y[1 \\dots n]$:
$$LCS[i, j] = \\begin{cases} 0 & i=0 \\text{ or } j=0 \\\\ LCS[i-1, j-1] + 1 & \\text{if } X[i] = Y[j] \\\\ \\max(LCS[i-1, j], LCS[i, j-1]) & \\text{if } X[i] \\ne Y[j] \\end{cases}$$
- **Time Complexity:** $O(m n)$, Space can be optimized to $O(\\min(m, n))$.`,
    quickRevisionNotes: [
      '0/1 Knapsack is pseudo-polynomial $O(nW)$; fractional knapsack is solved greedily in $O(n \\log n)$.',
      'LCS base case: $LCS[0][j] = LCS[i][0] = 0$. Matching character increments diagonal.',
      'Space can be reduced from 2D matrix to 1D array by iterating backwards in 0/1 Knapsack.'
    ],
    formulaSheets: [
      {
        name: '0/1 Knapsack Recurrence',
        formula: 'DP[i][w] = \\max(DP[i-1][w], DP[i-1][w - w_i] + v_i)',
        description: 'Optimal value considering first $i$ items with capacity $w$.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'LCS Length & Reconstruction',
        code: `def lcs(X, Y):
    m, n = len(X), len(Y)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if X[i - 1] == Y[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
                
    return dp[m][n]`
      }
    ],
    examTips: [
      'In 1D array space-optimized 0/1 knapsack, iterate capacity $w$ from $W$ DOWN to $w_i$ to prevent using the same item multiple times.',
      'Subset Sum is a direct reduction from 0/1 Knapsack where $v_i = w_i$.'
    ],
    handwrittenMnemonic: 'Iterate backwards in 1D array for 0/1 Knapsack; forwards for Unbounded Knapsack!'
  },
  {
    id: 'note-pdsa-w10',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 10,
    title: 'String Matching: KMP (Knuth-Morris-Pratt), Rabin-Karp & Trie Data Structure',
    detailedNotes: `### Week 10: String Pattern Matching & Tries

#### 1. Knuth-Morris-Pratt (KMP) Algorithm
Avoids backtracking in text string $T$ by precomputing the **LPS (Longest Proper Prefix which is also Suffix)** array of pattern $P$:
- **LPS Definition:** $\\text{LPS}[i]$ is the length of the longest matching prefix of $P[0 \\dots i]$ that matches a suffix of $P[0 \\dots i]$.
- **Time Complexity:** Preprocessing LPS $O(m)$, Search $O(n)$. Total time: $\\Theta(n + m)$.

#### 2. Rabin-Karp Rolling Hash
Uses rolling polynomial hash $H(S) = \\sum_{i=0}^{m-1} S[i] \\cdot b^{m-1-i} \\pmod q$.
- Updating rolling hash when sliding window shifts from $T[i-1]$ to $T[i+m-1]$ in $O(1)$:
$$H_{\\text{new}} = ( (H_{\\text{old}} - T[i-1] \\cdot b^{m-1}) \\cdot b + T[i+m-1] ) \\pmod q$$
- Average time $O(n + m)$, worst case $O(n m)$ on excessive hash collisions.

#### 3. Trie (Prefix Tree)
- Multi-way tree where edges represent characters.
- Search, Insert, Prefix query: $\\Theta(L)$ where $L$ is word length. Space: $O(|\\Sigma| \\cdot N \\cdot L)$.`,
    quickRevisionNotes: [
      'KMP never backtracks the text index $i$; only shifts pattern index $j = \\text{LPS}[j-1]$.',
      'Rabin-Karp uses rolling hash in $O(1)$ per shift using modular arithmetic.',
      'Trie search depends only on query word length $L$, completely independent of the dictionary size.'
    ],
    formulaSheets: [
      {
        name: 'Rabin-Karp Rolling Hash Step',
        formula: 'H_{t+1} = \\left( (H_t - T[t] \\cdot b^{m-1}) \\cdot b + T[t+m] \\right) \\pmod q',
        description: 'Constant time slide of rolling hash window.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'KMP Pattern Matcher with LPS Precomputation',
        code: `def compute_lps(pattern):
    lps = [0] * len(pattern)
    length = 0
    i = 1
    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
    return lps`
      }
    ],
    examTips: [
      'In KMP LPS computation, proper prefix cannot equal the whole string itself.',
      'When performing Rabin-Karp modular arithmetic, always add $q$ after subtraction before modulo to handle negative values safely in Python/C++.'
    ],
    handwrittenMnemonic: 'LPS array gives the exact fallback index for $j$ on mismatch in KMP!'
  },
  {
    id: 'note-pdsa-w11',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 11,
    title: 'Backtracking, Branch & Bound: N-Queens, Sudoku & Subset Generation',
    detailedNotes: `### Week 11: State Space Search & Pruning

#### 1. Backtracking Framework
Systematic search of state space tree with incremental candidate construction and early pruning:
- If current partial solution violates constraints, backtrack immediately (abandon subtree).
- **Template:**
\`\`\`python
def backtrack(state):
    if is_solution(state):
        record_solution(state); return
    for candidate in valid_candidates(state):
        apply_choice(candidate)
        backtrack(state)
        undo_choice(candidate) # Backtrack step
\`\`\`

#### 2. Classic Backtracking Problems
- **N-Queens:** Place $N$ queens on $N \\times N$ chessboard such that no two queens attack each other. Constraint checks: Column collision, Main diagonal $(r - c)$, Anti-diagonal $(r + c)$. Time: $O(N!)$.
- **Subset Generation:** Binary decision tree (include/exclude). Size: $2^N$.
- **Permutation Generation:** Choosing from remaining candidates. Size: $N!$.`,
    quickRevisionNotes: [
      'Backtracking prunes entire subtrees whenever a partial state violates problem constraints.',
      'In $N$-Queens, track diagonals using sets: $(r - c)$ for main, $(r + c)$ for anti-diagonal.',
      'Branch and Bound uses lower/upper bounds to prune subtrees in optimization problems.'
    ],
    formulaSheets: [
      {
        name: 'Diagonal Invariant in N-Queens',
        formula: '\\text{Main Diagonal: } r - c = \\text{const}, \\quad \\text{Anti-Diagonal: } r + c = \\text{const}',
        description: 'Fast $O(1)$ diagonal safety lookup.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'N-Queens Solver with Diagonal Hash Sets',
        code: `def solve_n_queens(n):
    cols, diag1, diag2 = set(), set(), set()
    solutions = []
    
    def backtrack(r, board):
        if r == n:
            solutions.append(list(board))
            return
        for c in range(n):
            if c in cols or (r - c) in diag1 or (r + c) in diag2:
                continue
            cols.add(c); diag1.add(r - c); diag2.add(r + c)
            board.append(c)
            backtrack(r + 1, board)
            board.pop()
            cols.remove(c); diag1.remove(r - c); diag2.remove(r + c)
            
    backtrack(0, [])
    return len(solutions)`
      }
    ],
    examTips: [
      'Always remember to UNDO choices in backtracking after recursive call returns, otherwise state pollution will invalidate subsequent paths.',
      'Bitmasking is the fastest representation for tracking state in $N \\le 30$ backtracking.'
    ],
    handwrittenMnemonic: 'Choice $\\to$ Explore $\\to$ Un-choose (Backtrack)!'
  },
  {
    id: 'note-pdsa-w12',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    courseCode: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 12,
    title: 'NP-Completeness, P vs NP, Reductions & Approximation Algorithms',
    detailedNotes: `### Week 12: Computational Complexity & Intractability

#### 1. Complexity Classes
- **Class P:** Decision problems solvable in deterministic polynomial time $O(n^k)$.
- **Class NP (Nondeterministic Polynomial):** Decision problems whose candidate solutions can be **VERIFIED** in polynomial time.
- **NP-Hard:** A problem $X$ such that every problem $Y \\in \\text{NP}$ can be polynomial-time reduced to $X$ ($Y \\le_P X$).
- **NP-Complete (NPC):** $X \\in \\text{NP}$ and $X \\in \\text{NP-Hard}$.

#### 2. Cook-Levin Theorem & Classic NP-Complete Reductions
- **Cook-Levin:** Circuit-SAT and Boolean 3-SAT are NP-Complete.
- **Karp\'s Classic Reductions:**
  $$\\text{3-SAT} \\le_P \\text{Independent Set} \\le_P \\text{Vertex Cover} \\le_P \\text{Clique}$$
  $$\\text{Subset Sum} \\le_P \\text{Knapsack} \\le_P \\text{Partition}$$

#### 3. Approximation Algorithms
For an optimization problem with optimal value $\\text{OPT}$ and approximation solution value $C$:
- **Approximation Ratio $\\rho$:** $\\max\\left( \\frac{C}{\\text{OPT}}, \\frac{\\text{OPT}}{C} \\right) \\le \\rho$.
- 2-Approximation for Vertex Cover: Pick any edge $(u, v)$, add both $u$ and $v$ to cover, remove all incident edges.`,
    quickRevisionNotes: [
      'P $\\subseteq$ NP. Whether P = NP is the foremost unsolved problem in computer science.',
      'To prove problem $B$ is NP-Complete: 1. Show $B \\in \\text{NP}$; 2. Reduce a known NPC problem $A \\le_P B$.',
      'Polynomial reduction direction matters: Known NPC problem $A$ MUST reduce to new problem $B$.'
    ],
    formulaSheets: [
      {
        name: 'Polynomial Reduction Condition',
        formula: 'A \\le_P B \\iff x \\in A \\iff f(x) \\in B \\text{ with } f \\text{ computed in } O(n^k)',
        description: 'Preservation of YES/NO answers across reduction.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: '2-Approximation Algorithm for Minimum Vertex Cover',
        code: `def vertex_cover_approx(graph_edges):
    cover = set()
    remaining_edges = set(graph_edges)
    
    while remaining_edges:
        u, v = remaining_edges.pop()
        cover.add(u)
        cover.add(v)
        # Remove all edges covered by either u or v
        remaining_edges = {e for e in remaining_edges if e[0] not in (u, v) and e[1] not in (u, v)}
        
    return cover`
      }
    ],
    examTips: [
      'Common Exam Trap: Proving $B \\le_P A$ does NOT prove $B$ is NP-Hard; you MUST prove $A \\le_P B$ from a known NPC problem $A$!',
      'Dynamic Programming algorithms like Knapsack $O(nW)$ are pseudo-polynomial, not polynomial, because $W$ requires $\\log_2 W$ bits.'
    ],
    handwrittenMnemonic: 'Reduce KNOWN NPC $\\to$ TARGET problem to prove hardness!'
  }
];

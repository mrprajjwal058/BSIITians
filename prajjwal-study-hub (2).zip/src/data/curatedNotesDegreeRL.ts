import { WeeklyStudyMaterial } from '../types';

export const DEGREE_RL_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-rl-w1',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 1,
    title: 'Reinforcement Learning Framework, Multi-Armed Bandits & Exploration-Exploitation Dilemma',
    detailedNotes: `### Week 1: Multi-Armed Bandits & The Exploration-Exploitation Dilemma

#### 1. Multi-Armed Bandit Formulation
Given $K$ discrete actions (arms) with unknown reward probability distributions $q_*(a) = \\mathbb{E}[R_t \\mid A_t = a]$.
- **Action-Value Estimation (Sample-Average):**
  $$Q_t(a) = \\frac{\\sum_{i=1}^{t-1} R_i \\cdot \\mathbb{I}(A_i = a)}{\\sum_{i=1}^{t-1} \\mathbb{I}(A_i = a)}$$
- **Incremental Update Rule:**
  $$Q_{n+1} = Q_n + \\frac{1}{n} \\left[ R_n - Q_n \\right]$$
  $$\\text{NewEstimate} = \\text{OldEstimate} + \\text{StepSize} \\times [\\text{Target} - \\text{OldEstimate}]$$

#### 2. Action Selection Strategies
1. **$\\epsilon$-Greedy:** Select greedy action $\\arg\\max_a Q(a)$ with probability $1 - \\epsilon$, and random uniform action with probability $\\epsilon$.
2. **Upper Confidence Bound (UCB1 - Optimism in the Face of Uncertainty):**
   $$A_t = \\arg\\max_a \\left[ Q_t(a) + c \\sqrt{\\frac{\\ln t}{N_t(a)}} \\right]$$
   - $\\sqrt{\\frac{\\ln t}{N_t(a)}}$: Uncertainty term. Decreases as arm $a$ is pulled more often.
   - **Theoretical Regret Bound:** UCB1 achieves logarithmic cumulative regret $O(\\ln T)$, which is asymptotically optimal (Lai & Robbins bound!).
3. **Gradient Bandit Algorithm (Softmax Preferences $H_t(a)$):**
   $$\\pi_t(a) = P(A_t = a) = \\frac{e^{H_t(a)}}{\\sum_{b=1}^K e^{H_t(b)}}$$
   - Preference update with baseline $\\bar{R}_t$:
     $$H_{t+1}(A_t) = H_t(A_t) + \\alpha (R_t - \\bar{R}_t)(1 - \\pi_t(A_t))$$
     $$H_{t+1}(a) = H_t(a) - \\alpha (R_t - \\bar{R}_t)\\pi_t(a) \\quad (\\forall a \\ne A_t)$$`,
    quickRevisionNotes: [
      'Multi-armed bandits balance exploration (gathering info) vs exploitation (maximizing immediate reward).',
      'Incremental sample average update: Q_(n+1) = Q_n + (1/n) * (R_n - Q_n).',
      'UCB1 achieves asymptotically optimal logarithmic regret O(ln T) by adding an uncertainty bonus.'
    ],
    formulaSheets: [
      {
        name: 'UCB1 Action Selection Formula',
        formula: 'A_t = \\arg\\max_a \\left[ Q_t(a) + c \\sqrt{\\frac{\\ln t}{N_t(a)}} \\right]',
        description: 'Upper Confidence Bound selection balancing estimated reward and exploration uncertainty.'
      },
      {
        name: 'Incremental Value Update',
        formula: 'Q_{k+1} = Q_k + \\alpha_k (R_k - Q_k)',
        description: 'General step-size parameter update rule in reinforcement learning.'
      }
    ],
    definitions: [
      {
        term: 'Cumulative Regret',
        explanation: 'The expected loss resulting from not selecting the optimal arm at every time step over horizon T.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'UCB1 Multi-Armed Bandit Implementation in Python',
        code: `import numpy as np

class UCB1Bandit:
    def __init__(self, k_arms, c=2.0):
        self.k = k_arms
        self.c = c
        self.q_values = np.zeros(k_arms)
        self.action_counts = np.zeros(k_arms)
        self.total_steps = 0
        
    def select_arm(self):
        self.total_steps += 1
        # Pull every arm once initially to initialize counts
        for arm in range(self.k):
            if self.action_counts[arm] == 0:
                return arm
                
        # Compute UCB bonus
        uncertainty = self.c * np.sqrt(np.log(self.total_steps) / self.action_counts)
        ucb_values = self.q_values + uncertainty
        return np.argmax(ucb_values)
        
    def update(self, arm, reward):
        self.action_counts[arm] += 1
        # Incremental average update
        self.q_values[arm] += (1.0 / self.action_counts[arm]) * (reward - self.q_values[arm])`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w1-q1',
        questionText: 'What is the theoretical cumulative regret lower bound for the Multi-Armed Bandit problem over T steps according to the Lai and Robbins theorem?',
        options: ['O(log T)', 'O(sqrt(T))', 'O(1 / T)', 'O(T^2)'],
        correctOptionIndex: 0,
        solution: 'The Lai and Robbins lower bound proves that any consistent bandit algorithm must suffer at least logarithmic cumulative regret O(log T).',
        hints: ['Think of the optimal asymptotic regret scaling.']
      }
    ],
    examTips: [
      'In non-stationary bandit environments (where reward distributions drift over time), use a constant step size $\\alpha \\in (0, 1]$ (exponential recency-weighted average) instead of $1/n$.',
      'Optimistic initial values (e.g. setting $Q_1(a) = +5$) encourage early exploration in greedy agents.'
    ],
    handwrittenMnemonic: 'UCB1: Square root of log(t)/N(a) rewards the least-pulled arm!'
  },
  {
    id: 'note-rl-w2',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 2,
    title: 'Model-Free Prediction: Monte Carlo (MC) & Temporal Difference Learning TD(0)',
    detailedNotes: `### Week 2: Model-Free Prediction & Temporal Difference Learning

#### 1. Monte Carlo (MC) Methods for Value Estimation
MC learns directly from raw completed episode trajectories without requiring an environmental transition model $T(s, a, s')$:
$$V(S_t) \\leftarrow V(S_t) + \\alpha \\left[ G_t - V(S_t) \\right]$$
- Target $G_t$: Actual discounted return from step $t$ to episode termination: $G_t = \\sum_{k=0}^{T-t-1} \\gamma^k R_{t+k+1}$.
- **Properties:** Zero bias (unbiased sample of true expected return), but **high variance** (accumulates stochasticity across entire trajectory), and requires **episodic environments**.

#### 2. Temporal Difference Learning (TD(0))
TD updates value estimates immediately after a single step using bootstrapping:
$$V(S_t) \\leftarrow V(S_t) + \\alpha \\left[ R_{t+1} + \\gamma V(S_{t+1}) - V(S_t) \\right]$$
- **TD Target:** $R_{t+1} + \\gamma V(S_{t+1})$.
- **TD Error ($\\delta_t$):**
  $$\\delta_t = R_{t+1} + \\gamma V(S_{t+1}) - V(S_t)$$
- **Properties:** Low variance (depends on only 1 step of noise), can learn **online and incrementally in continuing tasks**, but introduces small **bias** through bootstrap estimates $V(S_{t+1})$.`,
    quickRevisionNotes: [
      'Monte Carlo updates from actual return G_t at episode end; zero bias, high variance.',
      'TD(0) bootstraps from immediate reward plus next state estimate; low variance, online learning.',
      'TD error delta_t = R_(t+1) + gamma * V(S_(t+1)) - V(S_t).'
    ],
    formulaSheets: [
      {
        name: 'TD(0) Value Update Rule',
        formula: 'V(S_t) \\leftarrow V(S_t) + \\alpha \\delta_t = V(S_t) + \\alpha \\left[ R_{t+1} + \\gamma V(S_{t+1}) - V(S_t) \\right]',
        description: 'One-step temporal difference bootstrapping update.'
      },
      {
        name: 'TD Error Definition',
        formula: '\\delta_t = R_{t+1} + \\gamma V(S_{t+1}) - V(S_t)',
        description: 'Single-step temporal difference prediction discrepancy.'
      }
    ],
    definitions: [
      {
        term: 'Bootstrapping in RL',
        explanation: 'Updating a value estimate based in part on other learned value estimates, rather than solely on empirical complete returns.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'TD(0) State Value Prediction Algorithm',
        code: `def td_zero_prediction(env, policy, num_episodes, alpha=0.1, gamma=0.95):
    V = {s: 0.0 for s in env.all_states}
    
    for _ in range(num_episodes):
        state = env.reset()
        done = False
        while not done:
            action = policy(state)
            next_state, reward, done = env.step(action)
            
            # TD(0) update
            td_target = reward + (0 if done else gamma * V[next_state])
            td_error = td_target - V[state]
            V[state] += alpha * td_error
            
            state = next_state
    return V`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w2-q1',
        questionText: 'What is the primary advantage of TD(0) over Monte Carlo methods in practical RL applications?',
        options: ['TD(0) can learn online in continuing tasks and has lower variance due to 1-step bootstrapping', 'TD(0) is completely unbiased', 'TD(0) requires no learning rate parameter', 'TD(0) does not use discount factor gamma'],
        correctOptionIndex: 0,
        solution: 'TD(0) does not need to wait for episodes to terminate, allows continuous online learning, and has much lower variance than Monte Carlo returns.',
        hints: ['Think of online updating and variance.']
      }
    ],
    examTips: [
      'Monte Carlo converges to the minimum squared error solution on training trajectories; TD(0) converges to the maximum likelihood Markov model solution.',
      'TD(lambda) bridges TD(0) and Monte Carlo via eligibility traces.'
    ],
    handwrittenMnemonic: 'Monte Carlo waits for episode end; TD(0) updates every step with bootstrap!'
  },
  {
    id: 'note-rl-w3',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 3,
    title: 'Model-Free Control: On-Policy SARSA vs. Off-Policy Q-Learning & Expected SARSA',
    detailedNotes: `### Week 3: Temporal Difference Control: SARSA vs. Q-Learning

#### 1. On-Policy SARSA (State-Action-Reward-State-Action)
Updates action-values $Q(s, a)$ based on transitions generated by the **behavior policy** (e.g. $\\epsilon$-greedy):
$$Q(S_t, A_t) \\leftarrow Q(S_t, A_t) + \\alpha \\left[ R_{t+1} + \\gamma Q(S_{t+1}, A_{t+1}) - Q(S_t, A_{t+1}) \\right]$$
- Evaluates and improves the actual policy being followed (including exploration mistakes!).
- **Cliff Walking Example:** Takes the safe, distant path away from the cliff because $\\epsilon$-greedy exploration could step off the ledge.

#### 2. Off-Policy Q-Learning (Watkins\' Algorithm)
Learns the optimal action-value function $Q^*$ directly, regardless of the behavior policy used to explore:
$$Q(S_t, A_t) \\leftarrow Q(S_t, A_t) + \\alpha \\left[ R_{t+1} + \\gamma \\max_{a'} Q(S_{t+1}, a') - Q(S_t, A_t) \\right]$$
- **Target Policy:** Pure greedy $\\arg\\max_{a'} Q(S_{t+1}, a')$.
- **Behavior Policy:** $\\epsilon$-greedy (for continuous exploration).
- **Cliff Walking Example:** Learns the optimal shortest path along the cliff edge (though may fall during exploration).

#### 3. Expected SARSA
Replaces maximum over actions with the expected value under current policy:
$$Q(S_t, A_t) \\leftarrow Q(S_t, A_t) + \\alpha \\left[ R_{t+1} + \\gamma \\sum_{a'} \\pi(a' \\mid S_{t+1}) Q(S_{t+1}, a') - Q(S_t, A_t) \\right]$$
- Eliminates variance induced by random selection of $A_{t+1}$ in SARSA.`,
    quickRevisionNotes: [
      'SARSA is on-policy (updates using actual chosen action A_(t+1)).',
      'Q-Learning is off-policy (updates using max_a\' Q(S_(t+1), a\')).',
      'Expected SARSA uses expectation sum_a pi(a|S_(t+1)) Q(S_(t+1), a), reducing variance.'
    ],
    formulaSheets: [
      {
        name: 'Q-Learning Bellman Optimality Update',
        formula: 'Q(S_t, A_t) \\leftarrow Q(S_t, A_t) + \\alpha \\left[ R_{t+1} + \\gamma \\max_{a} Q(S_{t+1}, a) - Q(S_t, A_t) \\right]',
        description: 'Off-policy TD control update learning optimal Q*.'
      },
      {
        name: 'SARSA On-Policy Update',
        formula: 'Q(S_t, A_t) \\leftarrow Q(S_t, A_t) + \\alpha \\left[ R_{t+1} + \\gamma Q(S_{t+1}, A_{t+1}) - Q(S_t, A_t) \\right]',
        description: 'On-policy TD control update tracking current behavioral policy.'
      }
    ],
    definitions: [
      {
        term: 'Off-Policy Learning',
        explanation: 'Learning the value function of a target policy (such as the optimal greedy policy) while following a different behavior exploration policy.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Q-Learning vs SARSA Control Loop',
        code: `import numpy as np

def q_learning(env, num_episodes, alpha=0.1, gamma=0.99, epsilon=0.1):
    Q = np.zeros((env.num_states, env.num_actions))
    
    for _ in range(num_episodes):
        s = env.reset()
        done = False
        while not done:
            # Epsilon-greedy action selection
            if np.random.rand() < epsilon:
                a = np.random.randint(env.num_actions)
            else:
                a = np.argmax(Q[s])
                
            next_s, r, done = env.step(a)
            
            # Off-policy max target update
            best_next_q = np.max(Q[next_s]) if not done else 0.0
            Q[s, a] += alpha * (r + gamma * best_next_q - Q[s, a])
            s = next_s
    return Q`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w3-q1',
        questionText: 'Why is Q-Learning classified as an Off-Policy reinforcement learning algorithm?',
        options: ['Because it updates Q-values using the maximum over next actions (greedy target policy) regardless of the actual action taken by the behavior policy', 'Because it runs offline on disk datasets', 'Because it does not require a reward signal', 'Because it does not use neural networks'],
        correctOptionIndex: 0,
        solution: 'Q-Learning learns the optimal greedy policy Q* while generating exploratory actions using a different behavior policy (e.g. epsilon-greedy).',
        hints: ['Target policy is greedy, behavior policy is exploratory.']
      }
    ],
    examTips: [
      'SARSA is safer during online learning in environments with high penalties (e.g. physical robotics near obstacles).',
      'Q-Learning is prone to Overestimation Bias due to the $\\max$ operator; Double Q-Learning resolves this by decoupling action selection and evaluation across two Q-tables.'
    ],
    handwrittenMnemonic: 'SARSA uses actual next action; Q-Learning uses maximum greedy action!'
  },
  {
    id: 'note-rl-w4',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 4,
    title: 'Value Function Approximation: Linear Function Approximation & Gradient Monte Carlo',
    detailedNotes: `### Week 4: Function Approximation & The Deadly Triad

#### 1. Linear Function Approximation
In large/continuous state spaces where tabular storage is impossible, represent $V(s) \\approx \\hat{v}(s, \\mathbf{w}) = \\mathbf{w}^T \\mathbf{x}(s)$:
- $\\mathbf{x}(s) \\in \\mathbb{R}^d$: Feature vector (e.g. Tile Coding, Radial Basis Functions, Polynomial bases).
- **Mean Squared Value Error (MSVE):**
  $$\\overline{\\text{VE}}(\\mathbf{w}) = \\sum_{s \\in \\mathcal{S}} d(s) \\left[ v_\\pi(s) - \\hat{v}(s, \\mathbf{w}) \\right]^2$$
- **Stochastic Gradient Descent (SGD) Update:**
  $$\\mathbf{w}_{t+1} = \\mathbf{w}_t + \\alpha \\left[ U_t - \\hat{v}(S_t, \\mathbf{w}_t) \\right] \\nabla_{\\mathbf{w}} \\hat{v}(S_t, \\mathbf{w}_t)$$
  For linear approximation: $\\nabla_{\\mathbf{w}} \\hat{v}(S_t, \\mathbf{w}_t) = \\mathbf{x}(S_t)$.

#### 2. The Deadly Triad (Divergence in RL)
Function approximation can dangerously diverge to infinity if all three elements of the **Deadly Triad** are combined simultaneously:
1. **Function Approximation:** Linear features or deep neural networks instead of tabular lookups.
2. **Bootstrapping:** Targets depend on current estimates (TD, Dynamic Programming) rather than true Monte Carlo returns.
3. **Off-Policy Learning:** Training on transitions generated by a behavior distribution different from the target policy!`,
    quickRevisionNotes: [
      'Linear function approximation: v(s, w) = w^T x(s); gradient is simply the feature vector x(s).',
      'Deadly Triad: Function Approximation + Bootstrapping + Off-Policy Training leads to instability/divergence.',
      'Tile coding creates binary sparse feature vectors supporting efficient linear generalization.'
    ],
    formulaSheets: [
      {
        name: 'Semi-Gradient TD(0) Linear Weight Update',
        formula: '\\mathbf{w}_{t+1} = \\mathbf{w}_t + \\alpha \\left[ R_{t+1} + \\gamma \\mathbf{w}_t^T \\mathbf{x}(S_{t+1}) - \\mathbf{w}_t^T \\mathbf{x}(S_t) \\right] \\mathbf{x}(S_t)',
        description: 'Linear semi-gradient update for temporal difference prediction.'
      }
    ],
    definitions: [
      {
        term: 'Deadly Triad',
        explanation: 'The fatal combination of function approximation, bootstrapping, and off-policy training that can cause reinforcement learning value updates to diverge.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Semi-Gradient TD(0) with Linear Features in Python',
        code: `import numpy as np

def semi_gradient_td0(env, policy, feature_extractor, num_episodes, alpha=0.01, gamma=0.99):
    # Initialize weights
    num_features = feature_extractor.dim
    w = np.zeros(num_features)
    
    for _ in range(num_episodes):
        s = env.reset()
        done = False
        while not done:
            a = policy(s)
            next_s, r, done = env.step(a)
            
            x_s = feature_extractor.get_features(s)
            v_s = np.dot(w, x_s)
            
            if done:
                td_target = r
            else:
                x_next = feature_extractor.get_features(next_s)
                td_target = r + gamma * np.dot(w, x_next)
                
            td_error = td_target - v_s
            w += alpha * td_error * x_s # Semi-gradient step
            s = next_s
    return w`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w4-q1',
        questionText: 'Which combination of three factors constitutes the "Deadly Triad" in Reinforcement Learning?',
        options: ['Function Approximation, Bootstrapping, and Off-Policy Training', 'Neural Networks, High Learning Rate, and ReLU', 'Large Replay Buffer, Batch Normalization, and Adam Optimizer', 'Markov Property, Discount Factor, and Horizon'],
        correctOptionIndex: 0,
        solution: 'The Deadly Triad consists of Function Approximation, Bootstrapping, and Off-Policy learning, which together can cause value estimation to diverge.',
        hints: ['Remember: Approx + Bootstrap + Off-policy.']
      }
    ],
    examTips: [
      'Semi-gradient methods ignore the gradient of the target with respect to weights (e.g. $\\nabla_w [R + \\gamma \\hat{v}(S\', w)]$), which is why they are called "semi-gradients" rather than true gradients.',
      'Tile coding with $m$ overlapping tilings automatically normalizes vector gradients.'
    ],
    handwrittenMnemonic: 'Deadly Triad = Approx + Bootstrap + Off-Policy (Breeds Divergence)!'
  },
  {
    id: 'note-rl-w5',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 5,
    title: 'Deep Q-Networks (DQN): Experience Replay, Target Networks & Double DQN',
    detailedNotes: `### Week 5: Deep Q-Learning & Stabilization Architectures

#### 1. The Deep Q-Network (DQN) Algorithm (Mnih et al., Nature 2015)
DQN parameterizes $Q(s, a; \\theta)$ with a Deep Convolutional / MLP Neural Network.
To overcome the Deadly Triad and stabilize training, DQN introduces two critical innovations:

1. **Experience Replay Buffer ($\\mathcal{D}$):**
   - Stores transitions $(s_t, a_t, r_{t+1}, s_{t+1}, d_{t+1})$ in a large circular FIFO buffer.
   - Samples mini-batches uniformly at random during gradient updates.
   - **Benefits:** Breaks temporal autocorrelations between consecutive transition samples and enables data-efficient reuse of historical transitions!
2. **Target Network ($\\theta^-$):**
   - Maintains separate target parameters $\\theta^-$ that are kept frozen and updated periodically (e.g. every $C = 10,000$ steps):
     $$\\mathcal{L}(\\theta) = \\mathbb{E}_{(s, a, r, s', d) \\sim \\mathcal{D}} \\left[ \\left( r + \\gamma (1 - d) \\max_{a'} Q(s', a'; \\theta^-) - Q(s, a; \\theta) \\right)^2 \\right]$$
   - Prevents non-stationary moving targets from destabilizing gradient descent.

#### 2. Double DQN (DDQN - Van Hasselt et al., 2015)
Standard DQN suffers from positive **Overestimation Bias** because the same network selects and evaluates the best next action: $\\max_{a'} Q(s', a'; \\theta^-) = Q(s', \\arg\\max_{a'} Q(s', a'; \\theta^-); \\theta^-)$.
- **DDQN Decoupling:**
  $$y^{\\text{DoubleDQN}} = r + \\gamma Q\\left( s', \\arg\\max_{a'} Q(s', a'; \\theta); \\ \\theta^- \\right)$$
  - Online network $\\theta$ selects the best action index.
  - Frozen target network $\\theta^-$ evaluates the Q-value of that selected action!`,
    quickRevisionNotes: [
      'Experience Replay breaks temporal correlations and enables sample-efficient mini-batch updates.',
      'Target Network freezes target Q-values, stabilizing gradient updates.',
      'Double DQN uses online net for action selection and target net for value evaluation, eliminating overestimation bias.'
    ],
    formulaSheets: [
      {
        name: 'Double DQN Target Formula',
        formula: 'y_t^{\\text{Double}} = R_{t+1} + \\gamma Q\\left( S_{t+1}, \\arg\\max_{a} Q(S_{t+1}, a; \\theta_t); \\ \\theta_t^- \\right)',
        description: 'Decoupled target evaluation eliminating overestimation bias in Q-learning.'
      }
    ],
    definitions: [
      {
        term: 'Experience Replay',
        explanation: 'A replay memory buffer storing past state transitions from which random mini-batches are drawn to train neural networks.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Double DQN Loss Computation in PyTorch',
        code: `import torch
import torch.nn.functional as F

def compute_ddqn_loss(online_net, target_net, batch, gamma=0.99):
    states, actions, rewards, next_states, dones = batch
    
    # 1. Current Q-values: Q(s, a; \theta)
    q_values = online_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
    
    with torch.no_grad():
        # 2. Action selection using ONLINE network: a* = argmax_a Q(s', a; \theta)
        best_actions = online_net(next_states).argmax(dim=1, keepdim=True)
        # 3. Action evaluation using TARGET network: Q(s', a*; \theta^-)
        next_q_values = target_net(next_states).gather(1, best_actions).squeeze(1)
        # 4. Compute Double DQN target
        target_q_values = rewards + gamma * (1 - dones) * next_q_values
        
    # Smooth L1 / Huber Loss
    loss = F.smooth_l1_loss(q_values, target_q_values)
    return loss`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w5-q1',
        questionText: 'How does Double DQN resolve the overestimation bias present in vanilla DQN?',
        options: ['By using the online network to select the best action and the target network to evaluate its Q-value', 'By doubling the learning rate', 'By training two independent replay buffers', 'By eliminating the target network completely'],
        correctOptionIndex: 0,
        solution: 'Decoupling selection (online network) and evaluation (target network) prevents correlated noise from systematically inflating maximum Q-value estimates.',
        hints: ['Decouple action selection from action evaluation.']
      }
    ],
    examTips: [
      'Prioritized Experience Replay (PER) samples transitions proportionally to their absolute TD error $|\\delta_i|^p$, with importance sampling weights to correct sampling bias.',
      'Dueling DQN decomposes $Q(s, a) = V(s) + \\left( A(s, a) - \\frac{1}{|A|} \\sum_{a\'} A(s, a\') \\right)$ into separate state value and advantage streams.'
    ],
    handwrittenMnemonic: 'Replay breaks correlations; Double DQN: Online selects, Target evaluates!'
  },
  {
    id: 'note-rl-w6',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 6,
    title: 'Policy Gradient Methods: REINFORCE Algorithm & Baseline Variance Reduction',
    detailedNotes: `### Week 6: Policy Search & The Policy Gradient Theorem

#### 1. Policy Parameterization
Directly parameterize stochastic policy $\\pi_\\theta(a \\mid s) = P(A_t = a \\mid S_t = s; \\theta)$ without requiring value tables:
- **Discrete Actions:** Softmax over neural network logits.
- **Continuous Actions:** Gaussian policy $\\pi_\\theta(a \\mid s) = \\mathcal{N}(\\mu_\\theta(s), \\sigma_\\theta^2(s))$.

#### 2. Policy Gradient Theorem (Sutton et al., 1999)
For objective $J(\\theta) = \\mathbb{E}_{\\tau \\sim \\pi_\\theta}[G_0]$:
$$\\nabla_\\theta J(\\theta) = \\mathbb{E}_{\\pi_\\theta} \\left[ \\nabla_\\theta \\ln \\pi_\\theta(A_t \\mid S_t) \\cdot Q^{\\pi_\\theta}(S_t, A_t) \\right]$$
- **Remarkable Property:** The gradient does NOT require computing derivatives through the environmental transition dynamics $\\nabla_\\theta P(s' \\mid s, a)$!

#### 3. REINFORCE (Monte Carlo Policy Gradient with Baseline)
Using sample trajectories $\\tau = (s_0, a_0, r_1, \\dots, s_T)$ and return-to-go $\\hat{G}_t = \\sum_{k=t}^T \\gamma^{k-t} R_{k+1}$:
$$\\theta \\leftarrow \\theta + \\alpha \\sum_{t=0}^{T-1} \\nabla_\\theta \\ln \\pi_\\theta(A_t \\mid S_t) \\left( \\hat{G}_t - b(S_t) \\right)$$
- **Baseline $b(S_t)$:** Any function independent of action $A_t$ (typically a learned state-value estimate $V(S_t)$).
- **Proof that Baseline is Unbiased:**
  $$\\mathbb{E}\\left[ \\nabla_\\theta \\ln \\pi_\\theta(A_t \\mid S_t) \\cdot b(S_t) \\right] = \\sum_s d(s) b(s) \\sum_a \\nabla_\\theta \\pi_\\theta(a \\mid s) = \\sum_s d(s) b(s) \\nabla_\\theta (1) = 0$$
- Adding baseline $b(s)$ reduces variance dramatically while leaving the expected gradient completely **unbiased**!`,
    quickRevisionNotes: [
      'Policy gradient theorem computes gradient without needing knowledge of transition dynamics.',
      'REINFORCE updates weights in direction of grad(ln pi(a|s)) * (G_t - b(s)).',
      'Subtracting baseline b(s) leaves expected gradient unbiased while drastically shrinking variance.'
    ],
    formulaSheets: [
      {
        name: 'Policy Gradient Theorem',
        formula: '\\nabla_\\theta J(\\theta) = \\mathbb{E}_{\\tau \\sim \\pi_\\theta} \\left[ \\sum_{t=0}^T \\nabla_\\theta \\ln \\pi_\\theta(A_t \\mid S_t) Q(S_t, A_t) \\right]',
        description: 'Analytical gradient of expected trajectory return with respect to policy parameters theta.'
      },
      {
        name: 'Log-Derivative Trick (Likelihood Ratio)',
        formula: '\\nabla_\\theta P(\\tau; \\theta) = P(\\tau; \\theta) \\nabla_\\theta \\ln P(\\tau; \\theta)',
        description: 'Identity enabling expectation estimation over sampled trajectories.'
      }
    ],
    definitions: [
      {
        term: 'Log-Derivative Trick',
        explanation: 'Mathematical identity grad(f) = f * grad(ln f), allowing gradients of probability distributions to be sampled via expectations.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'REINFORCE with Baseline in PyTorch',
        code: `import torch
import torch.nn as nn
import torch.optim as optim

def train_reinforce_step(policy_net, value_net, optimizer_policy, optimizer_value, episode_data, gamma=0.99):
    states, actions, rewards = episode_data
    
    # 1. Compute discounted returns-to-go G_t
    returns = []
    G = 0
    for r in reversed(rewards):
        G = r + gamma * G
        returns.insert(0, G)
    returns = torch.tensor(returns, dtype=torch.float32)
    
    states_tensor = torch.tensor(states, dtype=torch.float32)
    actions_tensor = torch.tensor(actions, dtype=torch.int64)
    
    # 2. Value baseline and Advantage
    values = value_net(states_tensor).squeeze(1)
    advantages = returns - values.detach()
    
    # 3. Policy loss
    log_probs = policy_net.get_log_prob(states_tensor, actions_tensor)
    policy_loss = -(log_probs * advantages).mean()
    
    # 4. Value loss
    value_loss = nn.MSELoss()(values, returns)
    
    optimizer_policy.zero_grad()
    policy_loss.backward()
    optimizer_policy.step()
    
    optimizer_value.zero_grad()
    value_loss.backward()
    optimizer_value.step()`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w6-q1',
        questionText: 'Why does subtracting a state-dependent baseline b(s) from the return in REINFORCE reduce variance without introducing bias?',
        options: ['Because the expected value of grad(ln pi(a|s)) * b(s) over the action distribution is mathematically equal to zero', 'Because b(s) scales down the learning rate', 'Because b(s) eliminates all negative rewards', 'Because b(s) makes the policy deterministic'],
        correctOptionIndex: 0,
        solution: 'Since the sum of action probabilities is 1, the gradient of this sum is 0: sum_a grad(pi(a|s)) = grad(sum_a pi(a|s)) = grad(1) = 0. Therefore, the baseline expectation is zero.',
        hints: ['Gradient of constant sum equals 0.']
      }
    ],
    examTips: [
      'Use return-to-go $\\sum_{t\'=t}^T \\gamma^{t\'-t} R_{t\'+1}$ instead of full trajectory return $G_0$ to eliminate noise from past rewards (Causality principle).',
      'Policy gradients can handle continuous action spaces natively by outputting Gaussian distribution parameters $(\\mu, \\sigma)$.'
    ],
    handwrittenMnemonic: 'Log-derivative samples expectations; Baseline subtracts variance with zero bias!'
  },
  {
    id: 'note-rl-w7',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 7,
    title: 'Actor-Critic Architectures: Advantage Actor-Critic (A2C), GAE & Off-Policy Correction',
    detailedNotes: `### Week 7: Actor-Critic Methods & Generalized Advantage Estimation (GAE)

#### 1. Actor-Critic Principle
Combines Policy Gradients (Actor) with Value Function Bootstrapping (Critic):
- **Actor (Policy $\\pi_\\theta$):** Proposes actions and updates parameters in direction indicated by Critic:
  $$\\nabla_\\theta J(\\theta) = \\mathbb{E}\\left[ \\nabla_\\theta \\ln \\pi_\\theta(a \\mid s) \\cdot A(s, a) \\right]$$
- **Critic (Value $V_\\phi$):** Evaluates state value and computes the **Advantage Function**:
  $$A(s, a) = Q(s, a) - V(s) \\approx R_{t+1} + \\gamma V_\\phi(S_{t+1}) - V_\\phi(S_t)$$

#### 2. Generalized Advantage Estimation (GAE - Schulman et al.)
GAE introduces an exponential discount parameter $\\lambda \\in [0, 1]$ over temporal difference residuals $\\delta_t^V = R_{t+1} + \\gamma V(S_{t+1}) - V(S_t)$:
$$\\hat{A}_t^{\\text{GAE}(\\gamma, \\lambda)} = \\sum_{l=0}^\\infty (\\gamma \\lambda)^l \\delta_{t+l}^V$$
- $\\lambda = 0$: $\\hat{A}_t = \\delta_t^V$ (TD residual; minimum variance, maximum bias).
- $\\lambda = 1$: $\\hat{A}_t = \\sum_{l=0}^\\infty \\gamma^l R_{t+l+1} - V(S_t)$ (Monte Carlo return; maximum variance, zero bias).
- $\\lambda \\approx 0.95$: Optimal empirical tradeoff between bias and variance across Deep RL benchmarks!`,
    quickRevisionNotes: [
      'Actor-Critic: Actor updates policy distribution; Critic evaluates state values and calculates Advantage.',
      'Advantage A(s, a) = Q(s, a) - V(s) measures how much better action a is compared to average action.',
      'GAE(gamma, lambda) interpolates between 1-step TD (lambda=0) and Monte Carlo (lambda=1).'
    ],
    formulaSheets: [
      {
        name: 'Generalized Advantage Estimator (GAE)',
        formula: '\\hat{A}_t^{\\text{GAE}(\\gamma, \\lambda)} = \\sum_{l=0}^\\infty (\\gamma \\lambda)^l \\delta_{t+l}^V \\quad \\text{where } \\delta_t^V = R_{t+1} + \\gamma V(S_{t+1}) - V(S_t)',
        description: 'Exponentially weighted average of TD residuals balancing bias and variance.'
      }
    ],
    definitions: [
      {
        term: 'Advantage Function',
        explanation: 'A function A(s, a) = Q(s, a) - V(s) that quantifies the relative superiority of a specific action compared to the default state value.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Generalized Advantage Estimation (GAE) in NumPy',
        code: `import numpy as np

def compute_gae(rewards, values, next_values, dones, gamma=0.99, lam=0.95):
    num_steps = len(rewards)
    advantages = np.zeros(num_steps)
    last_gae = 0
    
    for t in reversed(range(num_steps)):
        mask = 1.0 - dones[t]
        delta = rewards[t] + gamma * next_values[t] * mask - values[t]
        last_gae = delta + gamma * lam * mask * last_gae
        advantages[t] = last_gae
        
    returns = advantages + values
    return advantages, returns`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w7-q1',
        questionText: 'In Generalized Advantage Estimation (GAE), what does setting lambda = 0 correspond to?',
        options: ['1-step TD residual delta_t (lowest variance, highest bias)', 'Pure Monte Carlo return', 'Infinite horizon planning', 'Uniform random search'],
        correctOptionIndex: 0,
        solution: 'Setting lambda = 0 truncates the summation to the immediate 1-step TD residual delta_t, minimizing variance at the expense of bootstrap bias.',
        hints: ['(gamma * lambda)^0 = 1 for the first term only.']
      }
    ],
    examTips: [
      'Synchronous Advantage Actor-Critic (A2C) coordinates multiple parallel worker environments on a single GPU without multi-threading lock contention.',
      'Always normalize advantage batches $(\\hat{A} - \\mu_A) / (\\sigma_A + 10^{-8})$ before computing policy gradients to stabilize training.'
    ],
    handwrittenMnemonic: 'Actor updates policy; Critic computes Advantage; GAE lambda=0.95 balances bias-variance!'
  },
  {
    id: 'note-rl-w8',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 8,
    title: 'Trust Region Methods: TRPO & Proximal Policy Optimization (PPO Clip)',
    detailedNotes: `### Week 8: Trust Region Policy Optimization & PPO

#### 1. The Policy Collapse Problem
Standard policy gradient steps can destructively alter policy parameters: a single bad update can ruin policy performance, leading to low-reward trajectories that prevent recovery.

#### 2. Trust Region Policy Optimization (TRPO - Schulman et al., 2015)
Constrains policy updates to lie within a small **Kullback-Leibler (KL) Divergence** trust region:
$$\\max_\\theta \\mathbb{E}\\left[ \\frac{\\pi_\\theta(a \\mid s)}{\\pi_{\\theta_{\\text{old}}}(a \\mid s)} \\hat{A}(s, a) \\right] \\quad \\text{s.t.} \\quad \\mathbb{E}\\left[ D_{\\text{KL}}(\\pi_{\\theta_{\\text{old}}}(\\cdot \\mid s) \\parallel \\pi_\\theta(\\cdot \\mid s)) \\right] \\le \\delta$$
- Uses conjugate gradient and Fisher Information Matrix (FIM) Hessian-vector products. Highly stable, but mathematically complex and computationally expensive.

#### 3. Proximal Policy Optimization (PPO-Clip - OpenAI, 2017)
PPO approximates the trust region using a simple **Clipped Surrogate Objective**:
$$r_t(\\theta) = \\frac{\\pi_\\theta(a_t \\mid s_t)}{\\pi_{\\theta_{\\text{old}}}(a_t \\mid s_t)}$$
$$\\mathcal{L}^{\\text{CLIP}}(\\theta) = \\hat{\\mathbb{E}}_t \\left[ \\min\\left( r_t(\\theta) \\hat{A}_t, \\ \\text{clip}(r_t(\\theta), 1 - \\epsilon, 1 + \\epsilon) \\hat{A}_t \\right) \\right]$$
- $\\epsilon \\approx 0.2$.
- **Mechanism:** If advantage $\\hat{A}_t > 0$, limits reward if $r_t(\\theta) > 1 + \\epsilon$. If advantage $\\hat{A}_t < 0$, limits penalty if $r_t(\\theta) < 1 - \\epsilon$.
- Enables multiple epochs of minibatch SGD on the same collected trajectories!`,
    quickRevisionNotes: [
      'PPO avoids destructive policy collapse by bounding the probability ratio r_t(theta).',
      'PPO-Clip objective uses min(r_t * A_t, clip(r_t, 1-eps, 1+eps) * A_t).',
      'PPO achieves TRPO stability while using standard first-order Adam optimizer.'
    ],
    formulaSheets: [
      {
        name: 'PPO Clipped Surrogate Objective',
        formula: '\\mathcal{L}^{\\text{CLIP}}(\\theta) = \\hat{\\mathbb{E}}_t \\left[ \\min\\left( r_t(\\theta) \\hat{A}_t, \\ \\text{clip}(r_t(\\theta), 1 - \\epsilon, 1 + \\epsilon) \\hat{A}_t \\right) \\right]',
        description: 'PPO objective preventing excessively large policy updates.'
      }
    ],
    definitions: [
      {
        term: 'Trust Region',
        explanation: 'A constrained neighborhood in policy parameter space where surrogate approximations are mathematically guaranteed to improve true objective return.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'PPO Clipped Surrogate Loss in PyTorch',
        code: `import torch

def ppo_clipped_loss(log_probs, old_log_probs, advantages, epsilon=0.2):
    # Probability ratio r_t(\theta) = exp(log_prob - old_log_prob)
    ratios = torch.exp(log_probs - old_log_probs)
    
    surr1 = ratios * advantages
    surr2 = torch.clamp(ratios, 1.0 - epsilon, 1.0 + epsilon) * advantages
    
    # Take minimum of unclipped and clipped surrogate
    policy_loss = -torch.min(surr1, surr2).mean()
    return policy_loss`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w8-q1',
        questionText: 'What is the purpose of the `min` operator and clipping function in the PPO-Clip objective?',
        options: ['To form a pessimistic lower bound that penalizes excessively large policy changes', 'To force the learning rate to zero', 'To eliminate the need for an advantage function', 'To make the policy deterministic'],
        correctOptionIndex: 0,
        solution: 'Taking the minimum forms a pessimistic lower bound that removes incentives for the policy to move ratio r_t(theta) outside [1 - epsilon, 1 + epsilon].',
        hints: ['Think of pessimistic lower bounds preventing overconfidence.']
      }
    ],
    examTips: [
      'PPO combines policy clip loss, value function squared error loss, and an entropy bonus ($+\\beta \\mathcal{H}(\\pi)$) to maintain exploration.',
      'PPO is the industry standard baseline algorithm for Reinforcement Learning from Human Feedback (RLHF) in LLM training!'
    ],
    handwrittenMnemonic: 'PPO clips ratios to [1-eps, 1+eps]; Pessimistic min blocks policy collapse!'
  },
  {
    id: 'note-rl-w9',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 9,
    title: 'Continuous Control: Deep Deterministic Policy Gradient (DDPG) & Soft Actor-Critic (SAC)',
    detailedNotes: `### Week 9: Continuous Action Spaces: DDPG, TD3 & Maximum Entropy SAC

#### 1. Deep Deterministic Policy Gradient (DDPG)
Extends DQN to continuous action spaces using deterministic Actor $\\mu_\\theta(s)$ and Critic $Q_\\phi(s, a)$:
- **Actor Update (Deterministic Policy Gradient):**
  $$\\nabla_\\theta J(\\theta) = \\mathbb{E}_{s \\sim \\mathcal{D}} \\left[ \\left. \\nabla_a Q_\\phi(s, a) \\right|_{a = \\mu_\\theta(s)} \\cdot \\nabla_\\theta \\mu_\\theta(s) \\right]$$
- **Soft Target Updates (Polyak Averaging):**
  $$\\theta^- \\leftarrow \\tau \\theta + (1 - \\tau) \\theta^- \\quad (\\tau \\approx 0.005)$$

#### 2. Twin Delayed DDPG (TD3 - Fujimoto et al.)
Addresses Q-overestimation in continuous action domains via:
1. **Clipped Double-Q Learning:** Uses $\\min(Q_{\\phi_1}, Q_{\\phi_2})$ for targets.
2. **Delayed Policy Updates:** Updates Actor network only once every $d$ Critic updates.
3. **Target Policy Smoothing:** Adds clipped noise to target action to prevent overfitting to peaks in $Q$.

#### 3. Soft Actor-Critic (SAC - Haarnoja et al.)
Optimizes **Maximum Entropy RL** objective:
$$J(\\pi) = \\sum_{t=0}^T \\mathbb{E}_{(s_t, a_t)} \\left[ R(s_t, a_t) + \\alpha \\mathcal{H}(\\pi(\\cdot \\mid s_t)) \\right]$$
- $\\mathcal{H}(\\pi) = -\\mathbb{E}[\\ln \\pi(a \\mid s)]$: Entropy.
- Encourages agent to discover multiple optimal behaviors and explore broadly while maximizing task reward!`,
    quickRevisionNotes: [
      'DDPG uses deterministic actor gradient and Polyak soft target updates.',
      'TD3 stabilizes DDPG via Clipped Double-Q, delayed actor updates, and target action smoothing.',
      'Soft Actor-Critic (SAC) optimizes Maximum Entropy RL, achieving state-of-the-art sample efficiency on continuous tasks.'
    ],
    formulaSheets: [
      {
        name: 'Maximum Entropy RL Objective (SAC)',
        formula: 'J(\\pi) = \\mathbb{E} \\left[ \\sum_{t=0}^T \\gamma^t \\left( R(s_t, a_t) + \\alpha \\mathcal{H}(\\pi(\\cdot \\mid s_t)) \\right) \\right]',
        description: 'Objective balancing cumulative reward maximization and action entropy exploration.'
      },
      {
        name: 'Polyak Target Smoothing Update',
        formula: '\\theta_{\\text{target}} \\leftarrow \\tau \\theta + (1 - \\tau) \\theta_{\\text{target}} \\quad (\\tau \\ll 1)',
        description: 'Exponential moving average target network updating.'
      }
    ],
    definitions: [
      {
        term: 'Maximum Entropy RL',
        explanation: 'Framework where the agent is rewarded both for maximizing task returns and for acting as randomly as possible (maximizing policy entropy).'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Polyak Target Network Parameter Update',
        code: `def polyak_update(source_net, target_net, tau=0.005):
    for source_param, target_param in zip(source_net.parameters(), target_net.parameters()):
        target_param.data.copy_(tau * source_param.data + (1.0 - tau) * target_param.data)`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w9-q1',
        questionText: 'What is the primary benefit of the entropy maximization bonus alpha * H(pi) in Soft Actor-Critic (SAC)?',
        options: ['It prevents premature policy convergence to suboptimal local modes and encourages robust multimodal exploration', 'It eliminates the need for neural networks', 'It makes rewards zero', 'It converts continuous actions to discrete actions'],
        correctOptionIndex: 0,
        solution: 'Entropy maximization forces the policy to assign probability to all promising paths, enhancing robustness, generalization, and exploration in complex reward landscapes.',
        hints: ['Think of multimodal exploration and entropy.']
      }
    ],
    examTips: [
      'In SAC, temperature $\\alpha$ can be automatically tuned via gradient descent against a target entropy $\\bar{\\mathcal{H}} = -\\dim(\\mathcal{A})$.',
      'The Reparameterization Trick ($a_t = \\mu_\\theta(s) + \\sigma_\\theta(s) \\odot \\epsilon$, where $\\epsilon \\sim \\mathcal{N}(0, I)$) allows gradients to flow directly through stochastic policy sampling.'
    ],
    handwrittenMnemonic: 'TD3 clips double Qs; SAC maximizes Reward + Entropy for continuous control!'
  },
  {
    id: 'note-rl-w10',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 10,
    title: 'Model-Based Reinforcement Learning: Dyna-Q, World Models & Model-Predictive Control (MPC)',
    detailedNotes: `### Week 10: Model-Based RL & Planning with Learned World Models

#### 1. The Dyna Architecture (Sutton)
Integrates Model-Free Learning, Model Learning, and Planning:
1. **Real Experience:** Take action $A$ in state $S$, observe $R, S'$. Update $Q(S, A)$ via model-free TD.
2. **Model Learning:** Learn environment transition model $\\hat{T}(S, A) \\to S'$ and reward model $\\hat{R}(S, A) \\to R$.
3. **Planning:** Repeat $N$ times: Sample previously observed state $S$ and action $A$; query learned model for $(\\hat{R}, \\hat{S}')$; perform simulated Q-learning update:
   $$Q(S, A) \\leftarrow Q(S, A) + \\alpha \\left[ \\hat{R} + \\gamma \\max_{a'} Q(\\hat{S}', a') - Q(S, A) \\right]$$

#### 2. Model-Predictive Control (MPC) with Learned Models
At each time step $t$:
1. Solve finite-horizon open-loop optimal control problem over planning horizon $H$:
   $$\\max_{a_t, \\dots, a_{t+H-1}} \\sum_{k=0}^{H-1} \\gamma^k \\hat{R}(\\hat{s}_{t+k}, a_{t+k})$$
2. Execute **only the first action $a_t$** in the real environment.
3. Observe actual next state $s_{t+1}$ and **re-plan from scratch** at time $t+1$ (Receding Horizon Principle).
- **Cross-Entropy Method (CEM):** Iteratively samples candidate action sequences from a Gaussian distribution, selects top elite fraction, and updates mean and covariance.`,
    quickRevisionNotes: [
      'Dyna-Q boosts sample efficiency by interleaving real experience with simulated model planning.',
      'MPC executes only the first action of the planned trajectory and replans at the next step (receding horizon).',
      'Model exploitation (errors in learned model compounding over long rollouts) is mitigated via ensembles of models.'
    ],
    formulaSheets: [
      {
        name: 'Dyna-Q Planning Loop Update',
        formula: 'Q(s, a) \\leftarrow Q(s, a) + \\alpha \\left[ \\text{Model}_R(s, a) + \\gamma \\max_{a\'} Q(\\text{Model}_S(s, a), a\') - Q(s, a) \\right]',
        description: 'Simulated experience update using learned transition and reward models.'
      }
    ],
    definitions: [
      {
        term: 'Receding Horizon Principle',
        explanation: 'Control strategy where an optimal trajectory is computed over a multi-step future horizon, but only the immediate first action is executed before replanning.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Dyna-Q Algorithm Implementation',
        code: `import numpy as np
from collections import defaultdict

def dyna_q(env, num_episodes, planning_steps=50, alpha=0.1, gamma=0.95, epsilon=0.1):
    Q = defaultdict(lambda: np.zeros(env.num_actions))
    model = {} # Key: (s, a) -> Value: (r, next_s)
    observed_states = set()
    observed_actions = defaultdict(set)
    
    for _ in range(num_episodes):
        s = env.reset()
        done = False
        while not done:
            a = np.random.randint(env.num_actions) if np.random.rand() < epsilon else np.argmax(Q[s])
            next_s, r, done = env.step(a)
            
            # 1. Real Q-Learning update
            Q[s][a] += alpha * (r + gamma * np.max(Q[next_s]) - Q[s][a])
            
            # 2. Learn Model
            model[(s, a)] = (r, next_s)
            observed_states.add(s)
            observed_actions[s].add(a)
            
            # 3. Simulated Planning
            for _ in range(planning_steps):
                sim_s = np.random.choice(list(observed_states))
                sim_a = np.random.choice(list(observed_actions[sim_s]))
                sim_r, sim_next_s = model[(sim_s, sim_a)]
                Q[sim_s][sim_a] += alpha * (sim_r + gamma * np.max(Q[sim_next_s]) - Q[sim_s][sim_a])
                
            s = next_s
    return Q`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w10-q1',
        questionText: 'In Model-Predictive Control (MPC), why is only the first action of an H-step planned trajectory executed in the real environment?',
        options: ['To correct for model inaccuracies and environmental stochasticity by replanning from the true observed state', 'Because future actions have zero probability', 'To reduce computation time to zero', 'Because neural networks only predict one step'],
        correctOptionIndex: 0,
        solution: 'Executing only the first action and replanning from the newly observed state prevents compounding prediction errors of the learned model.',
        hints: ['Think of receding horizon robustness against model drift.']
      }
    ],
    examTips: [
      'Probabilistic Ensembles with Trajectory Sampling (PETS) use ensembles of deep neural networks to model epistemic uncertainty in transitions.',
      'Dreamer and World Models train latent dynamics models to perform imagination rollouts directly in compact latent feature spaces.'
    ],
    handwrittenMnemonic: 'Dyna plans with simulated steps; MPC replans every step from real state!'
  },
  {
    id: 'note-rl-w11',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 11,
    title: 'Monte Carlo Tree Search (MCTS) & AlphaGo / AlphaZero Architecture',
    detailedNotes: `### Week 11: Monte Carlo Tree Search (MCTS) & AlphaZero

#### 1. MCTS Algorithm (4 Key Phases)
MCTS builds an asymmetric search tree incrementally:
1. **Selection:** Starting at root, traverse the tree using the **Upper Confidence bounds for Trees (PUCT)** formula until reaching an unexpanded leaf node:
   $$a^* = \\arg\\max_a \\left[ Q(s, a) + c_{\\text{puct}} P(s, a) \\frac{\\sqrt{\\sum_b N(s, b)}}{1 + N(s, a)} \\right]$$
2. **Expansion:** Expand new child state $s'$ and evaluate prior policy probabilities $P(s', a)$.
3. **Evaluation / Simulation:** Evaluate state value using Neural Network $V_\\theta(s')$ (in AlphaZero) or random rollout simulations.
4. **Backpropagation:** Propagate the evaluated reward $V$ up the tree path, updating visit counts $N(s, a) \\leftarrow N(s, a) + 1$ and average action-values:
   $$Q(s, a) \\leftarrow \\frac{N(s, a) Q(s, a) + V}{N(s, a) + 1}$$

#### 2. AlphaZero Dual-Head Architecture
AlphaZero trains a single deep convolutional / residual neural network $f_\\theta(s) = (\\mathbf{p}, v)$ outputting:
- Policy vector $\\mathbf{p}$: Prior probabilities over legal moves.
- Scalar $v \\in [-1, +1]$: Expected game outcome from state $s$.
- **Training Loss (Joint Policy & Value Loss with Weight Decay):**
  $$\\mathcal{L}(\\theta) = (z - v)^2 - \\boldsymbol{\\pi}^T \\ln \\mathbf{p} + c \\|\\theta\\|^2$$
  where $z$ is the actual game outcome $(\\pm 1)$ and $\\boldsymbol{\\pi}$ is the visit-count probability distribution from MCTS search: $\\pi(a \\mid s) \\propto N(s, a)^{1/\\tau}$.`,
    quickRevisionNotes: [
      'MCTS 4 phases: Selection (PUCT) -> Expansion -> Evaluation (Value Net) -> Backpropagation.',
      'AlphaZero combines MCTS with a dual-head neural network outputting prior policy p and value v.',
      'MCTS visit count distribution pi forms the target for policy network training.'
    ],
    formulaSheets: [
      {
        name: 'PUCT Node Selection Formula',
        formula: 'a_t = \\arg\\max_a \\left[ Q(s, a) + c_{\\text{puct}} P(s, a) \\frac{\\sqrt{\\sum_b N(s, b)}}{1 + N(s, a)} \\right]',
        description: 'AlphaZero PUCT selection balancing exploitation Q and prior-weighted exploration.'
      },
      {
        name: 'AlphaZero Joint Loss Function',
        formula: '\\mathcal{L}(\\theta) = (z - v)^2 - \\sum_a \\pi_a \\ln p_a + c \\|\\theta\\|^2',
        description: 'Combined MSE value loss and cross-entropy policy loss in AlphaZero.'
      }
    ],
    definitions: [
      {
        term: 'PUCT (Polynomial Upper Confidence Trees)',
        explanation: 'A tree search selection rule that balances exploitation of high-value branches with exploration guided by prior policy probabilities.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'AlphaZero PUCT Selection Step in Python',
        code: `import numpy as np

class MCTSNode:
    def __init__(self, prior_prob=1.0):
        self.visit_count = 0
        self.q_value = 0.0
        self.prior = prior_prob
        self.children = {} # Key: action -> Value: MCTSNode
        
    def select_action(self, c_puct=1.4):
        total_visits = sum(child.visit_count for child in self.children.values())
        best_score = -float('inf')
        best_action = None
        
        for action, child in self.children.items():
            u_score = c_puct * child.prior * (np.sqrt(total_visits) / (1 + child.visit_count))
            score = child.q_value + u_score
            if score > best_score:
                best_score = score
                best_action = action
                
        return best_action, self.children[best_action]`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w11-q1',
        questionText: 'What constitutes the policy target label when training the policy head of the AlphaZero neural network?',
        options: ['The normalized visit count distribution pi derived from MCTS search at that state', 'The random rollout outcome', 'The minimax leaf value', 'The heuristic evaluation table'],
        correctOptionIndex: 0,
        solution: 'AlphaZero uses the search visit count distribution of the MCTS tree (pi_a proportional to N(s, a)^(1/tau)) as the policy ground-truth cross-entropy target.',
        hints: ['Visit counts reflect search exploration results.']
      }
    ],
    examTips: [
      'During tournament play, temperature $\\tau \\to 0$ selects the action with the maximum visit count $\\arg\\max_a N(s, a)$ (most robust move).',
      'Dirichlet noise $\\text{Dir}(\\alpha)$ is added to prior probabilities at the root node to ensure exploration diversity during self-play.'
    ],
    handwrittenMnemonic: 'Select (PUCT) -> Expand -> Evaluate (NN) -> Backprop; Train on visit counts!'
  },
  {
    id: 'note-rl-w12',
    courseId: 'course-rl',
    courseTitle: 'Reinforcement Learning & Sequential Decisions',
    courseCode: 'CS3003',
    level: 'Degree',
    subLevel: 'Degree Level',
    weekNumber: 12,
    title: 'Reinforcement Learning from Human Feedback (RLHF), Direct Preference Optimization (DPO) & Safe RL',
    detailedNotes: `### Week 12: RLHF, Direct Preference Optimization (DPO) & Alignment

#### 1. Reinforcement Learning from Human Feedback (RLHF) Pipeline
Used to align Large Language Models (e.g. InstructGPT, ChatGPT, Claude) with human values:
1. **Step 1 (SFT):** Supervised Fine-Tuning on high-quality demonstration prompts.
2. **Step 2 (Reward Modeling - Bradley-Terry Model):**
   Human annotators compare pairs of model completions $(y_w, y_l)$ where $y_w \\succ y_l$.
   Train reward model $r_\\psi(x, y)$ by minimizing binary cross-entropy:
   $$\\mathcal{L}_{\\text{RM}}(\\psi) = -\\mathbb{E}_{(x, y_w, y_l)} \\left[ \\ln \\sigma\\left( r_\\psi(x, y_w) - r_\\psi(x, y_l) \\right) \\right]$$
3. **Step 3 (PPO Reinforcement Learning Optimization):**
   Fine-tune policy $\\pi_\\theta$ to maximize reward while penalizing drift from reference policy $\\pi_{\\text{ref}}$ via KL divergence:
   $$\\max_\\theta \\mathbb{E}_{x, y \\sim \\pi_\\theta} \\left[ r_\\psi(x, y) - \\beta D_{\\text{KL}}(\\pi_\\theta(y \\mid x) \\parallel \\pi_{\\text{ref}}(y \\mid x)) \\right]$$

#### 2. Direct Preference Optimization (DPO - Rafailov et al., NeurIPS 2023)
DPO mathematically proves that the optimal policy under the RLHF objective has closed-form reward equivalence:
$$r^*(x, y) = \\beta \\ln \\frac{\\pi_\\theta(y \\mid x)}{\\pi_{\\text{ref}}(y \\mid x)} + \\beta \\ln Z(x)$$
- Substituting into the Bradley-Terry objective completely **eliminates the need for a separate reward model and avoids unstable PPO loops**!
- **DPO Loss Objective:**
  $$\\mathcal{L}_{\\text{DPO}}(\\theta) = -\\mathbb{E}_{(x, y_w, y_l)} \\left[ \\ln \\sigma\\left( \\beta \\ln \\frac{\\pi_\\theta(y_w \\mid x)}{\\pi_{\\text{ref}}(y_w \\mid x)} - \\beta \\ln \\frac{\\pi_\\theta(y_l \\mid x)}{\\pi_{\\text{ref}}(y_l \\mid x)} \\right) \\right]$$`,
    quickRevisionNotes: [
      'RLHF aligns LLMs using Reward Models (Bradley-Terry) and PPO fine-tuning with KL penalty.',
      'The KL penalty beta * D_KL(pi || pi_ref) prevents policy collapse and reward hacking.',
      'DPO optimizes preferences directly via supervised loss without training a separate reward model or running PPO.'
    ],
    formulaSheets: [
      {
        name: 'Bradley-Terry Preference Probability',
        formula: 'P(y_w \\succ y_l \\mid x) = \\sigma(r(x, y_w) - r(x, y_l)) = \\frac{1}{1 + e^{-(r(x, y_w) - r(x, y_l))}}',
        description: 'Pairwise ranking probability model in RLHF reward learning.'
      },
      {
        name: 'Direct Preference Optimization (DPO) Loss',
        formula: '\\mathcal{L}_{\\text{DPO}}(\\theta) = -\\mathbb{E}_{(x, y_w, y_l)} \\left[ \\ln \\sigma\\left( \\beta \\ln \\frac{\\pi_\\theta(y_w \\mid x)}{\\pi_{\\text{ref}}(y_w \\mid x)} - \\beta \\ln \\frac{\\pi_\\theta(y_l \\mid x)}{\\pi_{\\text{ref}}(y_l \\mid x)} \\right) \\right]',
        description: 'Closed-form alignment objective optimizing preference pairs directly.'
      }
    ],
    definitions: [
      {
        term: 'Reward Hacking (Goodhart\'s Law)',
        explanation: 'Phenomenon where an RL agent exploits loopholes or shortcuts in the learned reward model to achieve high reward scores without fulfilling human intent.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Direct Preference Optimization (DPO) Loss Implementation in PyTorch',
        code: `import torch
import torch.nn.functional as F

def compute_dpo_loss(policy_chosen_logps, policy_rejected_logps,
                     ref_chosen_logps, ref_rejected_logps, beta=0.1):
    # Log ratio differences for chosen and rejected completions
    chosen_logratios = policy_chosen_logps - ref_chosen_logps
    rejected_logratios = policy_rejected_logps - ref_rejected_logps
    
    # Compute logits: beta * (log(pi(yw)/ref(yw)) - log(pi(yl)/ref(yl)))
    logits = beta * (chosen_logratios - rejected_logratios)
    
    # Binary cross-entropy with log-sigmoid: -ln(sigmoid(logits))
    loss = -F.logsigmoid(logits).mean()
    return loss`
      }
    ],
    practiceQuestions: [
      {
        id: 'rl-w12-q1',
        questionText: 'What primary engineering advantage does Direct Preference Optimization (DPO) offer over traditional RLHF with PPO?',
        options: ['DPO optimizes preference pairs directly with standard supervised gradient descent, eliminating the need to train a separate reward model or sample PPO rollouts', 'DPO requires zero GPU memory', 'DPO eliminates the need for reference policies', 'DPO only works on linear models'],
        correctOptionIndex: 0,
        solution: 'DPO analytically reformulates the RLHF objective into a closed-form loss function on preference data, removing the complexity and instability of training separate reward models and running PPO training loops.',
        hints: ['Direct preference loss without PPO loops.']
      }
    ],
    examTips: [
      'The KL divergence coefficient $\\beta$ in RLHF/DPO controls how closely the aligned model stays to the base pre-trained model (prevents degeneration).',
      'Constrained MDPs (CMDPs) and Lagrangian relaxation bound expected cost constraints $J_C(\\pi) \\le d$ for safety-critical control.'
    ],
    handwrittenMnemonic: 'RLHF uses Bradley-Terry + PPO; DPO aligns directly without reward model!'
  }
];

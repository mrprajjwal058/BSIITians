import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_DBMS_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-dbms-w1',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 1,
    title: 'Database Architecture, 3-Schema Architecture, Data Independence & ER Modeling',
    detailedNotes: `### Week 1: Foundations of Database Systems & Conceptual Modeling

#### 1. ANSI-SPARC 3-Schema Architecture
To decouple applications from low-level storage details, database systems implement three layers of abstraction:
1. **Physical / Internal Schema:** Describes how data is physically stored on disk (block layout, B-Tree indices, hash partitions).
2. **Conceptual / Logical Schema:** Describes the structure of the whole database for a community of users (entities, attributes, relationships, integrity constraints).
3. **External / View Schema:** Describes distinct user views tailored to specific end-user personas.

- **Logical Data Independence:** Ability to modify the Conceptual Schema (e.g. adding columns/relations) without changing existing External Schemas/Applications.
- **Physical Data Independence:** Ability to alter the Physical Schema (e.g. creating indices or changing disk layouts) without modifying the Conceptual Schema!

#### 2. Entity-Relationship (ER) Modeling Concepts
- **Entity & Entity Set:** Rectangles representing distinguishable objects.
- **Attributes:** Ellipses (Single-valued, Multi-valued double ellipse, Composite, Derived dashed ellipse).
- **Key Attributes:** Underlined attribute names.
- **Weak Entity:** Double rectangle; depends on identifying strong entity for existence. Has a **Partial Key / Discriminator** (dashed underline).
- **Cardinality Ratios:** 1:1, 1:N, N:M.
- **Participation Constraints:** Total participation (double line) vs. Partial participation (single line).`,
    quickRevisionNotes: [
      'Physical Data Independence isolates physical disk changes from the logical schema.',
      'Logical Data Independence isolates logical schema alterations from application views.',
      'Weak entities have partial keys and require identifying relationships with total participation.'
    ],
    formulaSheets: [
      {
        name: 'Relational Schema Mapping for Weak Entity',
        formula: '\\text{WeakRelation}(\\underline{\\text{StrongPK}}, \\underline{\\text{PartialKey}}, \\text{Attrs})',
        description: 'Primary key of a weak entity is the composite of the strong entity PK and its own discriminator.'
      }
    ],
    definitions: [
      {
        term: 'Physical Data Independence',
        explanation: 'The capacity to change the internal storage schema without having to change the conceptual schema.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'DDL for Weak Entity with Composite Key',
        code: `CREATE TABLE Employee (
    emp_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

-- Weak Entity: Dependent
CREATE TABLE Dependent (
    emp_id INT,
    dep_name VARCHAR(50),
    relationship VARCHAR(30),
    PRIMARY KEY (emp_id, dep_name),
    FOREIGN KEY (emp_id) REFERENCES Employee(emp_id) ON DELETE CASCADE
);`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w1-q1',
        questionText: 'Which schema level in the 3-schema architecture describes physical storage structures and access paths?',
        options: ['Internal / Physical Schema', 'Conceptual Schema', 'External Schema', 'Logical Schema'],
        correctOptionIndex: 0,
        solution: 'The internal/physical schema describes low-level storage data structures, record layouts, and file organizations on disk.',
        hints: ['Think of where indices and block layouts reside.']
      }
    ],
    examTips: [
      'In ER to Relational mapping, an N:M relationship ALWAYS becomes a separate cross-reference relation with composite primary keys.',
      'Multi-valued attributes map to their own separate table referencing the parent entity.'
    ],
    handwrittenMnemonic: 'Physical independence frees logic from disk; Weak entities borrow strong keys!'
  },
  {
    id: 'note-dbms-w2',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 2,
    title: 'Relational Model, Relational Algebra (Selection, Projection, Joins) & Set Operations',
    detailedNotes: `### Week 2: Formal Relational Algebra Operations

#### 1. Fundamental Relational Algebra Operators
Relational algebra is a procedural query language operating on relations producing relations:
1. **Selection ($\\sigma$):** Filters rows meeting boolean predicate:
   $$\\sigma_{\\text{score} \\ge 80}(R)$$
2. **Projection ($\\pi$):** Filters columns and eliminates duplicate rows:
   $$\\pi_{\\text{student\\_id, name}}(R)$$
3. **Cartesian Product ($\\times$):** Combines every tuple of $R$ with every tuple of $S$ (Degree $= \\text{deg}(R) + \\text{deg}(S)$, Cardinality $= |R| \\times |S|$).
4. **Set Union ($\\cup$), Intersection ($\\cap$), Difference ($-$):** Require Union-Compatibility (same degree and compatible domain types).

#### 2. Advanced Joins
- **Theta Join ($\\bowtie_\\theta$):** $\\sigma_\\theta(R \\times S)$.
- **Natural Join ($R \\bowtie S$):** Equi-join on all shared common attributes, projecting out duplicate column names.
- **Outer Joins ($\\mathbin{\\text{⟕}}, \\mathbin{\\text{⟖}}, \\mathbin{\\text{⟗}}$):** Preserves dangling unmatched tuples by padding with \`NULL\`.`,
    quickRevisionNotes: [
      'Selection operates horizontally on rows; Projection operates vertically on columns.',
      'Cartesian product cardinality is |R| * |S|; degree is deg(R) + deg(S).',
      'Union compatibility requires identical attribute arity and compatible data types.'
    ],
    formulaSheets: [
      {
        name: 'Natural Join Equivalence',
        formula: 'R \\bowtie S = \\pi_{\\text{Attrs}(R) \\cup \\text{Attrs}(S)} (\\sigma_{R.A_1 = S.A_1 \\land \\dots \\land R.A_k = S.A_k} (R \\times S))',
        description: 'Formal algebraic definition of natural join over common attribute set.'
      }
    ],
    definitions: [
      {
        term: 'Relational Completeness',
        explanation: 'A query language is relationally complete if it can express any query expressible in basic relational algebra.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'Relational Natural Join & Selection Equivalent',
        code: `-- Relational Algebra: \pi_{name, course_name}(\sigma_{grade='S'}(Student \bowtie Enrolls \bowtie Course))
SELECT s.name, c.course_name
FROM Student s
JOIN Enrolls e ON s.student_id = e.student_id
JOIN Course c ON e.course_id = c.course_id
WHERE e.grade = 'S';`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w2-q1',
        questionText: 'If relation R has 10 tuples and relation S has 5 tuples, how many tuples does their Cartesian Product R x S have?',
        options: ['50', '15', '2', '5'],
        correctOptionIndex: 0,
        solution: 'The cardinality of Cartesian Product is |R| * |S| = 10 * 5 = 50 tuples.',
        hints: ['Multiply the number of rows in both relations.']
      }
    ],
    examTips: [
      'Projection automatically eliminates duplicate tuples in pure relational algebra.',
      'Division operator $R \\div S$ expresses "for all" (universal quantification) queries.'
    ],
    handwrittenMnemonic: 'Selection picks rows (sigma); Projection picks columns (pi)!'
  },
  {
    id: 'note-dbms-w3',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 3,
    title: 'SQL DDL, DML, Constraints (PK, FK, CHECK), Nested Subqueries & Correlated Queries',
    detailedNotes: `### Week 3: Structured Query Language (SQL) & Advanced Subqueries

#### 1. SQL Data Definition (DDL) & Integrity Constraints
- **Primary Key (\`PRIMARY KEY\`):** Enforces uniqueness and \`NOT NULL\`.
- **Foreign Key (\`FOREIGN KEY\`):** Enforces Referential Integrity.
  - Cascading Actions: \`ON DELETE CASCADE\`, \`ON DELETE SET NULL\`, \`ON DELETE RESTRICT\`.
- **Domain Constraints:** \`CHECK (score BETWEEN 0 AND 100)\`, \`UNIQUE\`, \`DEFAULT\`.

#### 2. Correlated vs. Non-Correlated Subqueries
- **Non-Correlated Subquery:** Executes once independently; its result is passed to the outer query.
- **Correlated Subquery:** References columns from the outer query table; executes once per outer row! Evaluated using \`EXISTS\` / \`NOT EXISTS\`.`,
    quickRevisionNotes: [
      'PRIMARY KEY implies UNIQUE and NOT NULL.',
      'Correlated subqueries re-evaluate for every candidate tuple in the outer query.',
      'EXISTS returns TRUE as soon as a single matching row is encountered (short-circuit).'
    ],
    formulaSheets: [
      {
        name: 'Relational Division via NOT EXISTS',
        formula: '\\forall y \\in S (R(x, y)) \\iff \\text{NOT EXISTS } (S \\text{ EXCEPT } \\pi_y(R))',
        description: 'Correlated double-negative query expressing universal containment.'
      }
    ],
    definitions: [
      {
        term: 'Referential Integrity',
        explanation: 'Constraint ensuring foreign key values must match an existing primary key value in the referenced table or be NULL.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'Correlated Subquery Finding Students with Above-Average Scores',
        code: `SELECT s.student_id, s.name, s.course_id, s.score
FROM StudentScores s
WHERE s.score > (
    -- Subquery references outer relation 's.course_id'
    SELECT AVG(inner_s.score)
    FROM StudentScores inner_s
    WHERE inner_s.course_id = s.course_id
);`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w3-q1',
        questionText: 'What does the SQL expression `WHERE EXISTS (SELECT 1 FROM T WHERE ...)` return if the subquery returns empty?',
        options: ['FALSE', 'TRUE', 'NULL', 'Throws an Exception'],
        correctOptionIndex: 0,
        solution: '`EXISTS` evaluates to TRUE if the subquery produces one or more rows, and FALSE if zero rows are returned.',
        hints: ['EXISTS tests for non-emptiness of result sets.']
      }
    ],
    examTips: [
      '`COUNT(*)` counts rows with NULLs; `COUNT(col)` ignores NULL values.',
      'Comparison with NULL using `= NULL` always evaluates to UNKNOWN! Use `IS NULL` instead.'
    ],
    handwrittenMnemonic: 'Never use = NULL; Always write IS NULL!'
  },
  {
    id: 'note-dbms-w4',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 4,
    title: 'Aggregation, Grouping (GROUP BY, HAVING) & SQL Window Functions',
    detailedNotes: `### Week 4: Grouping, Aggregation & Analytical Windowing

#### 1. \`GROUP BY\` & \`HAVING\` Pipeline
$$\\text{FROM} \\to \\text{WHERE (Filters rows)} \\to \\text{GROUP BY (Clusters)} \\to \\text{HAVING (Filters groups)} \\to \\text{SELECT} \\to \\text{ORDER BY}$$
- **Rule:** Any column appearing in the \`SELECT\` clause that is NOT inside an aggregate function (\`SUM\`, \`AVG\`, \`COUNT\`, \`MIN\`, \`MAX\`) MUST appear in the \`GROUP BY\` clause!

#### 2. SQL Window Functions (\`OVER (PARTITION BY ... ORDER BY ...)\`)
Unlike standard aggregation which collapses rows, Window Functions compute aggregate/ranking metrics while preserving individual row identities!
- \`ROW_NUMBER()\`: Sequential integer starting at 1.
- \`RANK()\`: Ranks with gaps on ties (1, 2, 2, 4).
- \`DENSE_RANK()\`: Ranks without gaps on ties (1, 2, 2, 3).
- \`LEAD(col, 1)\` / \`LAG(col, 1)\`: Accesses subsequent/previous row values without self-joins.`,
    quickRevisionNotes: [
      'WHERE filters individual rows before grouping; HAVING filters aggregated groups after grouping.',
      'Window functions preserve all rows while computing partitioned metrics.',
      'DENSE_RANK produces no numeric gaps after tied rankings.'
    ],
    formulaSheets: [
      {
        name: 'Window Function Syntax',
        formula: '\\text{Function}() \\ \\text{OVER} \\ (\\text{PARTITION BY } col_1 \\ \\text{ORDER BY } col_2 \\ \\text{ROWS BETWEEN } \\dots)',
        description: 'Standard SQL:2003 window frame specification.'
      }
    ],
    definitions: [
      {
        term: 'Window Frame',
        explanation: 'A subset of rows within a partition over which a sliding calculation (e.g. moving average) is evaluated.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'Analytical Window Ranking Query',
        code: `SELECT 
    student_id,
    course_id,
    score,
    DENSE_RANK() OVER (PARTITION BY course_id ORDER BY score DESC) as course_rank,
    AVG(score) OVER (PARTITION BY course_id) as dept_avg
FROM ExamSubmissions;`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w4-q1',
        questionText: 'Which clause is used to filter groups based on aggregate values like `COUNT(*) > 5`?',
        options: ['HAVING', 'WHERE', 'ORDER BY', 'GROUP BY'],
        correctOptionIndex: 0,
        solution: 'The `HAVING` clause filters clustered groups based on aggregate condition results.',
        hints: ['WHERE cannot accept aggregate functions directly.']
      }
    ],
    examTips: [
      'You cannot put window functions inside the `WHERE` or `HAVING` clause! Use a CTE (Common Table Expression / `WITH` clause) to filter window results.',
      'Aggregates like `AVG(col)` ignore NULL entries, which alters the denominator count.'
    ],
    handwrittenMnemonic: 'WHERE filters rows; HAVING filters grouped totals!'
  },
  {
    id: 'note-dbms-w5',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 5,
    title: 'Functional Dependencies (FD), Attribute Closure & Minimal Covers',
    detailedNotes: `### Week 5: Functional Dependencies & Closure Computation

#### 1. Functional Dependency Definition
For relation schema $R$ and subsets $X, Y \\subseteq R$, $X \\to Y$ ($X$ functionally determines $Y$) holds if for any two tuples $t_1, t_2 \\in R$:
$$t_1[X] = t_2[X] \\implies t_1[Y] = t_2[Y]$$

#### 2. Armstrong\'s Axioms (Sound and Complete)
1. **Reflexivity:** If $Y \\subseteq X$, then $X \\to Y$.
2. **Augmentation:** If $X \\to Y$, then $XZ \\to YZ$.
3. **Transitivity:** If $X \\to Y$ and $Y \\to Z$, then $X \\to Z$.
4. **Secondary Rules:**
   - *Union:* If $X \\to Y$ and $X \\to Z \\implies X \\to YZ$.
   - *Decomposition:* If $X \\to YZ \\implies X \\to Y$ and $X \\to Z$.
   - *Pseudotransitivity:* If $X \\to Y$ and $WY \\to Z \\implies WX \\to Z$.

#### 3. Attribute Closure Algorithm ($X^+$)
- Start with $X^+ = X$.
- For each FD $A \\to B$ in $F$: If $A \\subseteq X^+$, then $X^+ = X^+ \\cup B$.
- Repeat until no new attributes are added.
- **Candidate Key Test:** $K$ is a Candidate Key if $K^+ = R$ and no proper subset of $K$ has closure equal to $R$.`,
    quickRevisionNotes: [
      'Armstrong\'s axioms are sound (produce only true FDs) and complete (produce all valid FDs).',
      'If X+ equals all attributes of R, X is a Superkey.',
      'A Candidate Key is a minimal superkey (no proper subset is a superkey).'
    ],
    formulaSheets: [
      {
        name: 'Attribute Closure Fixpoint',
        formula: 'X^{(k+1)} = X^{(k)} \\cup \\{ Y \\mid A \\to Y \\in F \\text{ and } A \\subseteq X^{(k)} \\}',
        description: 'Iterative closure computation until fixpoint is reached.'
      }
    ],
    definitions: [
      {
        term: 'Candidate Key',
        explanation: 'A minimal set of attributes that uniquely identifies every tuple in a relation.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Attribute Closure Computation Algorithm',
        code: `def compute_closure(attributes, fds):
    closure = set(attributes)
    changed = True
    while changed:
        changed = False
        for lhs, rhs in fds:
            if set(lhs).issubset(closure) and not set(rhs).issubset(closure):
                closure.update(rhs)
                changed = True
    return closure`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w5-q1',
        questionText: 'Given relation R(A, B, C, D) and FDs {A -> B, B -> C, C -> D}. What is the closure of A (A+)?',
        options: ['{A, B, C, D}', '{A, B}', '{A, B, C}', '{A}'],
        correctOptionIndex: 0,
        solution: 'A+ starts with {A}. Since A->B, A+={A, B}. Since B->C, A+={A, B, C}. Since C->D, A+={A, B, C, D}. Thus A is a candidate key.',
        hints: ['Apply transitivity rule through A -> B -> C -> D.']
      }
    ],
    examTips: [
      'To find candidate keys: identify attributes that NEVER appear on the RHS of any FD; they MUST be part of every candidate key!',
      'Attributes that appear ONLY on the RHS can NEVER be part of any candidate key.'
    ],
    handwrittenMnemonic: 'Attributes not on RHS must be in every candidate key!'
  },
  {
    id: 'note-dbms-w6',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 6,
    title: 'Database Normalization: 1NF, 2NF, 3NF, BCNF & Lossless Decomposition',
    detailedNotes: `### Week 6: Relational Normal Forms & Decomposition Properties

#### 1. Normal Forms Hierarchy
$$\\text{1NF} \\supset \\text{2NF} \\supset \\text{3NF} \\supset \\text{BCNF}$$

1. **First Normal Form (1NF):** All attribute domains contain only atomic (indivisible) values. No repeating groups or nested relations.
2. **Second Normal Form (2NF):** In 1NF and **no non-prime attribute is partially dependent on any candidate key** (no $X \\to A$ where $X \\subset \\text{Candidate Key}$ and $A$ is non-prime).
3. **Third Normal Form (3NF):** In 2NF and for every non-trivial FD $X \\to Y$:
   - Either $X$ is a **Superkey**, OR
   - $Y$ is a **Prime Attribute** (part of some candidate key). (Eliminates Transitive Dependencies).
4. **Boyce-Codd Normal Form (BCNF):** For every non-trivial FD $X \\to Y$, **$X$ MUST be a Superkey**.

#### 2. Lossless-Join Decomposition (Heath\'s Theorem)
A decomposition of $R$ into $R_1$ and $R_2$ is **Lossless** if and only if:
$$(R_1 \\cap R_2) \\to R_1 \\quad \\text{OR} \\quad (R_1 \\cap R_2) \\to R_2$$
(The common attribute set must form a superkey of at least one sub-relation).`,
    quickRevisionNotes: [
      '2NF eliminates Partial Dependencies; 3NF eliminates Transitive Dependencies.',
      'BCNF requires every determinant X in X -> Y to be a superkey.',
      '3NF guarantees both Lossless Join and Dependency Preservation; BCNF does not always preserve all dependencies!'
    ],
    formulaSheets: [
      {
        name: 'Lossless Decomposition Test',
        formula: 'R_1 \\bowtie R_2 = R \\iff (R_1 \\cap R_2) \\to R_1 \\text{ or } (R_1 \\cap R_2) \\to R_2',
        description: 'Necessary and sufficient condition for lossless relational decomposition.'
      }
    ],
    definitions: [
      {
        term: 'Lossless-Join Decomposition',
        explanation: 'Decomposition ensuring that natural join of decomposed relations exactly reconstructs the original relation with no spurious tuples.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'BCNF Decomposed Relational Schema',
        code: `-- Original: EmployeeProject(emp_id, proj_id, emp_name, proj_budget) - Not 2NF
-- Decomposed into Lossless BCNF:
CREATE TABLE Employee (
    emp_id INT PRIMARY KEY,
    emp_name VARCHAR(100)
);

CREATE TABLE Project (
    proj_id INT PRIMARY KEY,
    proj_budget NUMERIC(12, 2)
);

CREATE TABLE Assignment (
    emp_id INT REFERENCES Employee(emp_id),
    proj_id INT REFERENCES Project(proj_id),
    PRIMARY KEY (emp_id, proj_id)
);`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w6-q1',
        questionText: 'In relation R(A, B, C) with candidate key AB and FD C -> B, which normal form does R violate?',
        options: ['BCNF (it is in 3NF but not BCNF)', '1NF', '2NF', 'None, it is in 4NF'],
        correctOptionIndex: 0,
        solution: 'For FD C -> B: C is not a superkey, but B is a prime attribute (part of candidate key AB), so it satisfies 3NF. However, since C is not a superkey, it violates BCNF.',
        hints: ['Check if the RHS is a prime attribute for 3NF vs BCNF.']
      }
    ],
    examTips: [
      'Every binary relation (a relation with only 2 attributes) is ALWAYS in BCNF!',
      '3NF synthesis algorithm preserves all functional dependencies in polynomial time.'
    ],
    handwrittenMnemonic: 'BCNF = Determinant MUST be Superkey; 2 attributes = Always BCNF!'
  },
  {
    id: 'note-dbms-w7',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 7,
    title: 'Physical Storage, RAID Levels, Fixed/Variable Record Organization & Buffer Pool',
    detailedNotes: `### Week 7: Disk Organization, Storage Architectures & Buffer Management

#### 1. RAID (Redundant Array of Independent Disks) Levels
- **RAID 0 (Striping):** Block striping across $N$ disks without redundancy. High throughput ($N \\times$), zero fault tolerance.
- **RAID 1 (Mirroring):** Full duplication. High read performance, 50% storage capacity overhead.
- **RAID 5 (Block-Interleaved Distributed Parity):** Blocks striped across $N$ disks with distributed parity. Can tolerate 1 disk failure. Capacity $= (N - 1) \\times \\text{size}$.
- **RAID 6 (Dual Distributed Parity):** Uses Reed-Solomon codes. Can tolerate 2 simultaneous disk failures. Capacity $= (N - 2) \\times \\text{size}$.
- **RAID 10 (1+0):** Striping across mirrored pairs (high performance + redundancy).

#### 2. Buffer Manager & Replacement Policies
The Buffer Manager maintains frames of memory caching disk blocks:
- **Pinning / Unpinning:** Pinned blocks cannot be evicted to disk.
- **Dirty Bit:** Set when memory block is modified; dirty blocks must be written to disk before frame reuse.
- **Eviction Policies:** LRU (Least Recently Used), Clock Policy (Approximates LRU), MRU (Most Recently Used - optimal for nested loop joins!).`,
    quickRevisionNotes: [
      'RAID 5 tolerates 1 disk failure with distributed parity; RAID 6 tolerates 2 disk failures.',
      'Buffer replacement policy LRU is susceptible to sequential scan flooding.',
      'Dirty pages must be flushed to disk before buffer frame reuse.'
    ],
    formulaSheets: [
      {
        name: 'RAID 5 Usable Storage Capacity',
        formula: '\\text{Capacity} = (N - 1) \\times S',
        description: 'Usable capacity of RAID 5 array with N disks each of capacity S.'
      }
    ],
    definitions: [
      {
        term: 'Dirty Bit',
        explanation: 'A flag bit associated with a buffer frame indicating that the cached page has been modified in memory and must be written to disk.'
      }
    ],
    codeSnippets: [
      {
        language: 'c',
        title: 'Buffer Pool Frame Header Structure',
        code: `typedef struct {
    int page_id;
    int pin_count;
    bool is_dirty;
    unsigned long last_accessed_timestamp;
    char data_block[4096]; // 4KB disk page
} BufferFrame;`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w7-q1',
        questionText: 'How many disk failures can a RAID 6 array withstand without data loss?',
        options: ['2 concurrent disk failures', '1 disk failure', '3 disk failures', '0 (RAID 6 has no parity)'],
        correctOptionIndex: 0,
        solution: 'RAID 6 maintains two independent distributed parity blocks per stripe, allowing it to withstand up to 2 concurrent disk failures.',
        hints: ['RAID 5 handles 1 failure, RAID 6 handles 2.']
      }
    ],
    examTips: [
      'MRU (Most Recently Used) is better than LRU when performing repeated sequential table scans in nested loop joins.',
      'Slotted-page architecture is used to store variable-length records on a disk block.'
    ],
    handwrittenMnemonic: 'RAID 5 = 1 disk fails; RAID 6 = 2 disks fail!'
  },
  {
    id: 'note-dbms-w8',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 8,
    title: 'Indexing & File Organizations: Primary/Secondary Indices, B-Trees & B+ Trees',
    detailedNotes: `### Week 8: Tree-Structured Indexing: B-Trees & B+ Trees

#### 1. Dense vs. Sparse Indices
- **Dense Index:** Contains an index record for **every search-key value** in the data file.
- **Sparse Index:** Contains index records only for **some search-key values** (usually the first record of each block). Requires data file to be ordered on the search key!
- **Primary Index:** Index on an ordered file whose search key specifies the primary sequential order of the file (Clustered).
- **Secondary Index:** Index on a non-ordering search key (MUST be dense).

#### 2. B+ Tree Structure & Invariants
A B+ Tree of order $m$ satisfies:
1. Every node contains at most $m-1$ search keys and $m$ child pointers.
2. Every internal node (except root) has at least $\\lceil m/2 \\rceil$ children.
3. Root node has at least 2 children (unless tree has $\\le 1$ node).
4. All leaf nodes are at the **same depth** (perfectly balanced).
5. **Key Difference from B-Tree:** In B+ Trees, data pointers reside **ONLY in leaf nodes**. All leaf nodes are linked together sequentially in a doubly-linked list, enabling extremely fast range scans!

- **Search / Insert / Delete Time Complexity:** $O(\\log_B N)$ where $B$ is node fanout.`,
    quickRevisionNotes: [
      'B+ Trees store actual record pointers only in leaf nodes; B-Trees store data pointers in all nodes.',
      'Leaf nodes in B+ Trees are linked sequentially for fast range queries.',
      'B+ Tree fanout is much larger than binary search trees, minimizing disk I/O.'
    ],
    formulaSheets: [
      {
        name: 'B+ Tree Node Capacity Constraint',
        formula: '\\lceil m / 2 \\rceil - 1 \\le \\text{Number of Keys} \\le m - 1',
        description: 'Occupancy bounds for non-root internal nodes in B+ Tree of order m.'
      }
    ],
    definitions: [
      {
        term: 'Clustered Index',
        explanation: 'An index whose search key dictates the physical sequential ordering of records in the data file.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'Creating B-Tree and Hash Indices in PostgreSQL',
        code: `-- B-Tree is the default index type (supports range queries <, <=, =, >=, >)
CREATE INDEX idx_student_score ON ExamSubmissions USING btree (score);

-- Hash index (supports only exact equality lookups =)
CREATE INDEX idx_student_email ON Students USING hash (email);`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w8-q1',
        questionText: 'Why are B+ Trees preferred over B-Trees for database indices?',
        options: ['Leaf nodes form a linked list for fast range queries and internal nodes have higher fanout', 'B+ Trees consume less memory', 'B+ Trees do not require balancing', 'B+ Trees allow duplicate primary keys'],
        correctOptionIndex: 0,
        solution: 'Since internal nodes store only keys and child pointers, fanout is much higher (shallower tree), and linked leaf nodes allow efficient sequential range traversal.',
        hints: ['Think of range queries and node fanout capacity.']
      }
    ],
    examTips: [
      'A table can have at most ONE clustered index because records can be physically ordered in only one way on disk.',
      'Hash indexing cannot support range queries ($>$ or $<$), only equality queries ($=$).'
    ],
    handwrittenMnemonic: 'B+ Tree keeps all data at the leaves, linked for range speed!'
  },
  {
    id: 'note-dbms-w9',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 9,
    title: 'Query Processing & Optimization: Cost Estimation, Relational Algebra Equivalence & Join Algorithms',
    detailedNotes: `### Week 9: Query Engine Architecture & Cost-Based Optimization

#### 1. Query Execution Pipeline
$$\\text{SQL Text} \\xrightarrow{\\text{Parser}} \\text{Parse Tree} \\xrightarrow{\\text{Translator}} \\text{Relational Algebra Plan} \\xrightarrow{\\text{Query Optimizer}} \\text{Physical Execution Plan} \\xrightarrow{\\text{Execution Engine}} \\text{Results}$$

#### 2. Physical Join Algorithms & Disk I/O Cost
Given relations $R$ ($B_r$ blocks, $n_r$ tuples) and $S$ ($B_s$ blocks, $n_s$ tuples) with $M$ buffer memory pages:
1. **Block Nested-Loop Join:**
   $$\\text{Cost} = B_r + \\left\\lceil \\frac{B_r}{M - 2} \\right\\rceil \\times B_s \\quad \\text{disk block I/Os}$$
2. **Sort-Merge Join:** Sort $R$ and $S$ on join attribute, then merge. Cost $= 2(B_r + B_s) \\lceil \\log_{M-1}(B_r / M) \\rceil + (B_r + B_s)$.
3. **Grace Hash Join:** Hash both relations into $M-1$ matching partitions. Cost $= 3(B_r + B_s)$.

#### 3. Relational Algebra Equivalences (Heuristic Rewriting)
- **Push Selections Down:** $\\sigma_\\theta(R \\bowtie S) \\equiv \\sigma_\\theta(R) \\bowtie S$ (shrinks intermediate relations early).
- **Push Projections Down:** $\\pi_{A}(R \\bowtie S) \\equiv \\pi_A(\\pi_{A \\cup \\text{JoinAttrs}}(R) \\bowtie S)$.`,
    quickRevisionNotes: [
      'Heuristic optimization pushes Selections and Projections down the operator tree early.',
      'Block nested loop join cost is minimized by choosing the smaller relation as the outer loop.',
      'Hash join has an average I/O cost of 3(Br + Bs).'
    ],
    formulaSheets: [
      {
        name: 'Block Nested Loop Join Cost',
        formula: '\\text{Cost} = B_r + \\left\\lceil \\frac{B_r}{M - 2} \\right\\rceil \\times B_s',
        description: 'Disk page I/O cost for block nested loop join with M buffer pages.'
      }
    ],
    definitions: [
      {
        term: 'Query Optimizer',
        explanation: 'DBMS component that evaluates candidate execution plans and selects the plan with minimum estimated disk I/O and CPU cost.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'Inspecting Query Execution Plan in PostgreSQL',
        code: `-- EXPLAIN ANALYZE executes query and displays actual disk timings & join algorithms
EXPLAIN ANALYZE 
SELECT s.name, e.score
FROM Students s
JOIN ExamSubmissions e ON s.student_id = e.student_id
WHERE e.score >= 90;`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w9-q1',
        questionText: 'Which optimization heuristic reduces intermediate relation sizes most effectively?',
        options: ['Pushing selections as far down the operator tree as possible', 'Pushing joins to the top', 'Performing Cartesian products first', 'Avoiding index scans'],
        correctOptionIndex: 0,
        solution: 'Pushing selections down evaluates filtering predicates directly on base tables, drastically shrinking tuple volume before expensive joins.',
        hints: ['Filter early to process fewer rows.']
      }
    ],
    examTips: [
      'In Block Nested Loop join, ALWAYS choose the relation with fewer blocks ($B_r$) as the outer relation!',
      'Database statistics (histograms) are maintained in catalog tables to estimate selectivity factors.'
    ],
    handwrittenMnemonic: 'Push selections down early; Small relation goes outer in Block Nested Loops!'
  },
  {
    id: 'note-dbms-w10',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 10,
    title: 'Transactions & ACID Properties, Serializability (Conflict & View) & Precedence Graphs',
    detailedNotes: `### Week 10: Transaction Theory & Conflict Serializability

#### 1. ACID Properties
- **Atomicity:** All-or-nothing execution (managed by Recovery/Write-Ahead Logging).
- **Consistency:** Database transitions from one valid state to another valid state preserving all integrity constraints.
- **Isolation:** Concurrent transactions execute without mutual interference (managed by Concurrency Control).
- **Durability:** Committed state changes survive subsequent system crashes/reboots.

#### 2. Conflicting Operations & Conflict Serializability
Two operations $O_i$ and $O_j$ in a schedule are in **Conflict** if:
1. They belong to different transactions ($T_i \\ne T_j$).
2. They access the same data item $Q$.
3. At least one of the operations is a **Write** (\`W(Q)\`).
- Conflicting Pairs: $(R_i(Q), W_j(Q))$, $(W_i(Q), R_j(Q))$, $(W_i(Q), W_j(Q))$.

#### 3. Precedence Graph (Serialization Graph) Test
- Construct directed graph $G = (V, E)$ where vertices represent transactions.
- Add directed edge $T_i \\to T_j$ if an operation of $T_i$ precedes and conflicts with an operation of $T_j$.
- **Theorem:** A schedule $S$ is **Conflict Serializable** if and only if its precedence graph contains **NO CYCLES** (Acyclic)!`,
    quickRevisionNotes: [
      'Two operations conflict iff they access the same item in different transactions and at least one is a Write.',
      'A schedule is conflict serializable iff its Precedence Graph has no cycles.',
      'Topological sort of the acyclic precedence graph gives the equivalent serial execution order.'
    ],
    formulaSheets: [
      {
        name: 'Conflict Serializability Theorem',
        formula: 'S \\text{ is Conflict Serializable} \\iff \\text{Precedence Graph } G(S) \\text{ is Acyclic}',
        description: 'Necessary and sufficient topological condition for conflict equivalence to a serial schedule.'
      }
    ],
    definitions: [
      {
        term: 'Conflict Equivalence',
        explanation: 'Two schedules are conflict equivalent if one can be transformed into the other by swapping non-conflicting adjacent operations.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Conflict Precedence Cycle Detection in Python',
        code: `def is_conflict_serializable(transactions, schedule):
    # Construct adjacency list for precedence graph
    from collections import defaultdict
    graph = defaultdict(set)
    
    for i in range(len(schedule)):
        t1, op1, item1 = schedule[i]
        for j in range(i + 1, len(schedule)):
            t2, op2, item2 = schedule[j]
            if t1 != t2 and item1 == item2 and (op1 == 'W' or op2 == 'W'):
                graph[t1].add(t2)
                
    # Detect cycle using DFS
    visited, rec_stack = set(), set()
    def has_cycle(node):
        visited.add(node)
        rec_stack.add(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                if has_cycle(neighbor): return True
            elif neighbor in rec_stack: return True
        rec_stack.remove(node)
        return False
        
    for t in transactions:
        if t not in visited and has_cycle(t):
            return False # Contains cycle -> NOT serializable
    return True`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w10-q1',
        questionText: 'Which condition guarantees that a concurrent schedule is Conflict Serializable?',
        options: ['The precedence graph of the schedule contains no cycles', 'All transactions commit simultaneously', 'No transactions perform writes', 'The schedule uses strict locking'],
        correctOptionIndex: 0,
        solution: 'By the Conflict Serializability Theorem, a schedule is conflict serializable if and only if its conflict precedence graph is acyclic.',
        hints: ['Think of topological sorting on precedence graphs.']
      }
    ],
    examTips: [
      'Every Conflict Serializable schedule is View Serializable, but the converse is NOT true!',
      'Blind writes ($W(Q)$ without prior $R(Q)$) can make a schedule View Serializable without being Conflict Serializable.'
    ],
    handwrittenMnemonic: 'No cycles in Precedence Graph = Conflict Serializable!'
  },
  {
    id: 'note-dbms-w11',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 11,
    title: 'Concurrency Control: Two-Phase Locking (2PL, Strict 2PL), Deadlock Detection & Timestamp Ordering',
    detailedNotes: `### Week 11: Lock-Based & Timestamp Concurrency Control

#### 1. Lock Types & Compatibility Matrix
- **Shared Lock ($S$):** Read access only. Multiple transactions can hold $S$ locks concurrently.
- **Exclusive Lock ($X$):** Read and Write access. Only one transaction can hold an $X$ lock.

#### 2. Two-Phase Locking (2PL) Protocol
1. **Growing Phase:** Transaction may acquire new locks, but cannot release any lock.
2. **Shrinking Phase:** Transaction may release locks, but cannot acquire any new lock!
- **Guarantee:** 2PL guarantees Conflict Serializability.
- **Strict 2PL:** Transaction holds all Exclusive locks until commit/abort $\\implies$ Guarantees serializability and **prevents Cascading Aborts**.
- **Rigorous 2PL:** Transaction holds all Shared and Exclusive locks until termination.

#### 3. Deadlock Management
- **Deadlock Detection:** Periodically check for cycles in the **Wait-For Graph (WFG)**.
- **Deadlock Prevention Schemes:**
  - **Wait-Die (Non-preemptive):** If older transaction requests lock held by younger $\\implies$ Older waits. If younger requests from older $\\implies$ Younger dies (aborts and restarts).
  - **Wound-Wait (Preemptive):** If older requests from younger $\\implies$ Older wounds (preempts/aborts) younger. If younger requests from older $\\implies$ Younger waits.`,
    quickRevisionNotes: [
      '2PL guarantees conflict serializability but does NOT prevent deadlocks.',
      'Strict 2PL holds exclusive locks until commit/abort, eliminating cascading rollbacks.',
      'Wait-Die scheme: Old waits, Young dies; Wound-Wait: Old wounds, Young waits.'
    ],
    formulaSheets: [
      {
        name: 'Thomas Write Rule (Timestamp Ordering)',
        formula: '\\text{If } TS(T) < W\\text{-}TS(Q) \\implies \\text{Ignore write and proceed}',
        description: 'Optimization in timestamp ordering that discards obsolete obsolete write operations.'
      }
    ],
    definitions: [
      {
        term: 'Cascadeless Schedule',
        explanation: 'A schedule where every transaction reads only values written by committed transactions, preventing cascade rollbacks.'
      }
    ],
    codeSnippets: [
      {
        language: 'sql',
        title: 'Explicit Locking in SQL Transactions',
        code: `BEGIN TRANSACTION;
-- Acquire Exclusive row-level lock (FOR UPDATE)
SELECT balance FROM Accounts WHERE account_id = 101 FOR UPDATE;

UPDATE Accounts SET balance = balance - 500 WHERE account_id = 101;
UPDATE Accounts SET balance = balance + 500 WHERE account_id = 202;

COMMIT; -- All locks released at transaction boundary`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w11-q1',
        questionText: 'In the Wait-Die deadlock prevention scheme, what happens when an older transaction T1 requests a resource held by younger transaction T2?',
        options: ['T1 is allowed to wait', 'T1 is killed immediately', 'T2 is aborted and preempted', 'A deadlock error is raised'],
        correctOptionIndex: 0,
        solution: 'In Wait-Die: Older waits, Younger dies. Since T1 is older than T2, T1 is allowed to wait.',
        hints: ['Remember: Older waits, Younger dies.']
      }
    ],
    examTips: [
      '2PL does NOT prevent deadlocks! Two transactions can easily deadlock while waiting for each other\'s locks during the growing phase.',
      'Strict 2PL produces cascadeless, recoverable schedules.'
    ],
    handwrittenMnemonic: '2PL ensures serializability; Strict 2PL prevents cascading aborts!'
  },
  {
    id: 'note-dbms-w12',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    courseCode: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    weekNumber: 12,
    title: 'Database Recovery Systems: Write-Ahead Logging (WAL), ARIES & Checkpoints',
    detailedNotes: `### Week 12: Crash Recovery, WAL & The ARIES Algorithm

#### 1. Write-Ahead Logging (WAL) Protocol
To ensure Atomicity and Durability across system power crashes without synchronously flushing data pages:
1. **WAL Rule 1 (Undo rule):** The log record representing an update must be flushed to non-volatile disk BEFORE the corresponding dirty data page is written to disk.
2. **WAL Rule 2 (Redo rule):** All log records for a transaction must be flushed to disk before the transaction commits (\`COMMIT\` log record is flushed).

#### 2. Checkpointing
Periodically writing a \`CHECKPOINT\` record containing active transaction tables and dirty page tables, bounding the length of the log scanned during recovery.

#### 3. ARIES Recovery Algorithm (3 Phases)
1. **Analysis Phase:** Scans the log forward from the most recent checkpoint. Reconstructs the Transaction Table and Dirty Page Table (identifies smallest \`recLSN\`).
2. **Redo Phase:** Scans forward from smallest \`recLSN\` in Dirty Page Table. Repeats all history (re-applies changes for committed AND aborted transactions) to restore database to exact pre-crash state!
3. **Undo Phase:** Scans backward, undoing the updates of all transactions that were active (uncommitted) at crash time. Writes **Compensation Log Records (CLRs)** to ensure undo actions are never undone if another crash occurs during recovery!`,
    quickRevisionNotes: [
      'WAL mandates flushing log records to stable storage before flushing dirty data pages.',
      'ARIES 3 phases: Analysis (forward from checkpoint) -> Redo (repeats history) -> Undo (rolls back loser transactions).',
      'Compensation Log Records (CLRs) prevent infinite undo loops during crash recovery.'
    ],
    formulaSheets: [
      {
        name: 'WAL Invariant',
        formula: 'LSN_{\\text{page}} \\le LSN_{\\text{flushed\\_log}}',
        description: 'Page LSN on disk must not exceed the flushed Log Sequence Number.'
      }
    ],
    definitions: [
      {
        term: 'Compensation Log Record (CLR)',
        explanation: 'A log record written during the Undo phase recording the action of rolling back an update, bounding recovery time.'
      }
    ],
    codeSnippets: [
      {
        language: 'text',
        title: 'Structure of a WAL Log Record',
        code: `[LSN: 1042] [PrevLSN: 1010] [TxID: T1] [Type: UPDATE] [PageID: P8] [Offset: 128] [OldVal: 500] [NewVal: 400]`
      }
    ],
    practiceQuestions: [
      {
        id: 'dbms-w12-q1',
        questionText: 'What is the primary role of the Redo phase in the ARIES recovery algorithm?',
        options: ['Repeat history to restore the database to the exact state at the time of crash', 'Roll back uncommitted transactions', 'Delete all log files', 'Rebuild all B-Tree indices from scratch'],
        correctOptionIndex: 0,
        solution: 'The Redo phase in ARIES repeats history, applying changes for all transactions (both committed and uncommitted) starting from the oldest dirty page recLSN.',
        hints: ['Redo repeats history before Undo cleans up losers.']
      }
    ],
    examTips: [
      'During crash recovery, "Loser" transactions are those active when the crash occurred with no COMMIT or ABORT log record.',
      'Fuzzy checkpointing does not halt active transactions while writing checkpoint metadata.'
    ],
    handwrittenMnemonic: 'WAL writes log first; ARIES = Analysis, Redo History, Undo Losers!'
  }
];

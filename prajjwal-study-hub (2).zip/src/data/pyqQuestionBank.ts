import { Question, MockTest, AcademicLevel, AcademicSubLevel } from '../types';
import { FOUNDATION_MATH_QUESTIONS } from './pyqQuestionsFoundationMath';
import { FOUNDATION_STATS_CT_PY_QUESTIONS } from './pyqQuestionsFoundationStatsCTPy';
import { DIPLOMA_QUESTIONS } from './pyqQuestionsDiploma';
import { DEGREE_BS_QUESTIONS } from './pyqQuestionsDegreeBS';

export interface SubjectMeta {
  id: string;
  name: string;
  code: string;
  level: AcademicLevel;
  subLevel: AcademicSubLevel;
  category: string;
  term: string;
  description: string;
  iconName: string;
  color: string;
}

export const ACADEMIC_SUBJECTS: SubjectMeta[] = [
  // ==========================================
  // FOUNDATION LEVEL
  // ==========================================
  {
    id: 'course-math-1',
    name: 'Mathematics for Data Science 1',
    code: 'MA1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Mathematics',
    term: 'Term 1',
    description: 'Coordinate geometry, functions, limits, derivatives, linear systems and vectors.',
    iconName: 'Calculator',
    color: 'blue'
  },
  {
    id: 'course-math-2',
    name: 'Mathematics for Data Science 2',
    code: 'MA1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Mathematics',
    term: 'Term 2',
    description: 'Multivariable calculus, partial derivatives, gradients, Hessians, unconstrained optimization, eigenvalues.',
    iconName: 'Sigma',
    color: 'indigo'
  },
  {
    id: 'course-stat-1',
    name: 'Statistics for Data Science 1',
    code: 'ST1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Statistics',
    term: 'Term 1',
    description: 'Descriptive stats, probability spaces, conditional probability, Bayes theorem, random variables.',
    iconName: 'BarChart3',
    color: 'emerald'
  },
  {
    id: 'course-stat-2',
    name: 'Statistics for Data Science 2',
    code: 'ST1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Statistics',
    term: 'Term 2',
    description: 'Sampling distributions, Central Limit Theorem, hypothesis tests, p-values, ANOVA, simple regression.',
    iconName: 'LineChart',
    color: 'teal'
  },
  {
    id: 'course-ct',
    name: 'Computational Thinking',
    code: 'CS1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Core CS',
    term: 'Term 1',
    description: 'Pseudocode execution, algorithmic reasoning, loop invariants, state transitions, flowchart traces.',
    iconName: 'Cpu',
    color: 'violet'
  },
  {
    id: 'course-python',
    name: 'Introduction to Python Programming',
    code: 'CS1002',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Programming',
    term: 'Term 1',
    description: 'Core syntax, loops, recursion, list comprehensions, dicts, file I/O, functional tools.',
    iconName: 'Code',
    color: 'amber'
  },
  {
    id: 'course-eng-1-2',
    name: 'English 1 & 2',
    code: 'ENG1001',
    level: 'Foundation',
    subLevel: 'Foundation',
    category: 'Humanities',
    term: 'Term 1 & 2',
    description: 'Academic reading comprehension, technical writing, grammar precision, error spotting and tone analysis.',
    iconName: 'BookOpen',
    color: 'sky'
  },

  // ==========================================
  // DIPLOMA IN PROGRAMMING
  // ==========================================
  {
    id: 'course-java',
    name: 'Programming in Java',
    code: 'CS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    category: 'Programming',
    term: 'Term 3',
    description: 'OOP fundamentals, polymorphism, inheritance, generics, collections framework, exception handling, threads.',
    iconName: 'Coffee',
    color: 'orange'
  },
  {
    id: 'course-dbms',
    name: 'Database Management Systems',
    code: 'CS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    category: 'Core CS',
    term: 'Term 3',
    description: 'Relational algebra, SQL joins/aggregations, 1NF to BCNF normal forms, indexing, ACID transactions.',
    iconName: 'Database',
    color: 'cyan'
  },
  {
    id: 'course-pdsa',
    name: 'Programming, Data Structures & Algorithms (PDSA)',
    code: 'CS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    category: 'Programming',
    term: 'Term 4',
    description: 'Asymptotic analysis, trees, heaps, graphs, shortest path (Dijkstra), dynamic programming, divide & conquer.',
    iconName: 'Binary',
    color: 'purple'
  },
  {
    id: 'course-appdev1',
    name: 'Application Development 1 (MAD 1)',
    code: 'CS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    category: 'Programming',
    term: 'Term 4',
    description: 'Flask backend, Jinja2 templating, SQLite/SQLAlchemy models, CRUD REST architecture, user session authentication.',
    iconName: 'Layout',
    color: 'indigo'
  },
  {
    id: 'course-appdev2',
    name: 'Application Development 2 (MAD 2)',
    code: 'CS2005',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    category: 'Programming',
    term: 'Term 5',
    description: 'Vue 3 Single Page Applications, Pinia/Vuex state, Celery asynchronous workers, Redis cache, JWT RBAC security.',
    iconName: 'Layers',
    color: 'blue'
  },
  {
    id: 'course-syscmd',
    name: 'System Commands & Unix Shell',
    code: 'CS2006',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    category: 'Core CS',
    term: 'Term 3',
    description: 'Bash pipes, text streams (grep, awk, sed), file permissions, cron daemons, process exit codes and I/O redirection.',
    iconName: 'Terminal',
    color: 'slate'
  },

  // ==========================================
  // DIPLOMA IN DATA SCIENCE
  // ==========================================
  {
    id: 'course-mlf-mlt',
    name: 'Machine Learning Foundations & Techniques (MLF / MLT)',
    code: 'DS2001',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    category: 'Data Science',
    term: 'Term 4',
    description: 'Gradient descent, regularized linear/logistic regression, SVM, decision trees, boosting, bagging, PCA.',
    iconName: 'BrainCircuit',
    color: 'rose'
  },
  {
    id: 'course-mlp',
    name: 'Machine Learning Practice (MLP)',
    code: 'DS2003',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    category: 'Data Science',
    term: 'Term 5',
    description: 'Scikit-learn pipelines, hyperparameter tuning (GridSearchCV), cross validation, ROC-AUC metric tuning.',
    iconName: 'Cpu',
    color: 'pink'
  },
  {
    id: 'course-bdm',
    name: 'Business Data Management (BDM)',
    code: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    category: 'Data Science',
    term: 'Term 4',
    description: 'Data warehousing schemas (Star & Snowflake), ETL pipelines, OLAP cubes, data governance and data quality metrics.',
    iconName: 'Database',
    color: 'amber'
  },
  {
    id: 'course-tds',
    name: 'Tools in Data Science (TDS)',
    code: 'DS2004',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    category: 'Data Science',
    term: 'Term 4',
    description: 'Git branching workflows, Docker containers, SQLite data wrangling, Web scraping, automated API deployments.',
    iconName: 'Wrench',
    color: 'emerald'
  },
  {
    id: 'course-ba-dv',
    name: 'Business Analytics & Data Visualization',
    code: 'BA2001',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    category: 'Data Science',
    term: 'Term 5',
    description: 'Exploratory data analysis, visual storytelling, business KPI synthesis, cohort retention metrics, Tableau/Matplotlib.',
    iconName: 'PieChart',
    color: 'yellow'
  },

  // ==========================================
  // BSc DEGREE LEVEL (TERMS 6, 7, 8 / 3-Year Exit Track)
  // ==========================================
  {
    id: 'course-dl',
    name: 'Deep Learning (DL)',
    code: 'DS3001',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    category: 'Data Science',
    term: 'Term 6',
    description: 'Multilayer perceptrons, backprop calculus, CNN convolutions & pooling, RNN/LSTM/GRU, Transformer self-attention.',
    iconName: 'Layers',
    color: 'fuchsia'
  },
  {
    id: 'course-ai-search',
    name: 'Artificial Intelligence: Search Methods',
    code: 'CS3001',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    category: 'Core CS',
    term: 'Term 6',
    description: 'A* heuristic admissibility, minimax with alpha-beta pruning, constraint satisfaction (CSP), local beam search.',
    iconName: 'Search',
    color: 'red'
  },
  {
    id: 'course-nlp',
    name: 'Speech & Natural Language Processing (Speech/NLP)',
    code: 'DS3002',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    category: 'Data Science',
    term: 'Term 7',
    description: 'Subword tokenization (BPE/WordPiece), TF-IDF, Word2Vec, Seq2Seq attention, BERT masked LM, Speech MFCC acoustics.',
    iconName: 'Mic',
    color: 'purple'
  },
  {
    id: 'course-st-se',
    name: 'Software Testing & Software Engineering',
    code: 'CS3002',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    category: 'Core CS',
    term: 'Term 7',
    description: 'Cyclomatic complexity, basis path testing, boundary value analysis, equivalence partitioning, CI/CD and agile patterns.',
    iconName: 'ShieldCheck',
    color: 'emerald'
  },
  {
    id: 'course-bigdata-cloud',
    name: 'Big Data & Cloud Computing',
    code: 'CS3003',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    category: 'Core CS',
    term: 'Term 8',
    description: 'MapReduce paradigm, Apache Spark RDD/DataFrames, HDFS replication, CAP theorem, distributed consistency.',
    iconName: 'Cloud',
    color: 'cyan'
  },

  // ==========================================
  // BS DEGREE LEVEL (TERMS 9, 10, 11, 12 / 4th Year Track)
  // ==========================================
  {
    id: 'course-bs-genai',
    name: 'Deep Learning & Advanced Generative AI',
    code: 'DS4001',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    category: 'Data Science',
    term: 'Term 9',
    description: 'Diffusion models (DDPM/DDIM), Variational Autoencoders (ELBO), GANs, FlashAttention-2, LoRA/QLoRA fine-tuning, RLHF alignment.',
    iconName: 'Sparkles',
    color: 'rose'
  },
  {
    id: 'course-bs-rl',
    name: 'AI Search Methods & Reinforcement Learning',
    code: 'CS4001',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    category: 'Core CS',
    term: 'Term 9',
    description: 'Markov Decision Processes (MDP), Bellman Optimality, Q-Learning, Deep Q-Networks (DQN), Policy Gradients (PPO/A3C), MCTS.',
    iconName: 'BrainCircuit',
    color: 'amber'
  },
  {
    id: 'course-bs-nlp-speech',
    name: 'Natural Language Processing (NLP) & Speech Technology',
    code: 'DS4002',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    category: 'Data Science',
    term: 'Term 10',
    description: 'Modern LLM architectures, Rotary Positional Embeddings (RoPE), Whisper ASR acoustics, CTC loss, Mel-filterbanks, RAG pipelines.',
    iconName: 'Mic',
    color: 'purple'
  },
  {
    id: 'course-bs-cloud-arch',
    name: 'Big Data & Cloud Architecture for DS',
    code: 'CS4002',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    category: 'Core CS',
    term: 'Term 10',
    description: 'Distributed streaming engines (Kafka & Flink), Delta Lake, Kubernetes multi-node GPU clustering, Raft consensus, CAP/PACELC theorem.',
    iconName: 'Cloud',
    color: 'cyan'
  },
  {
    id: 'course-bs-robotics-ai',
    name: 'Autonomous Systems & Robotics AI',
    code: 'CS4003',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    category: 'Core CS',
    term: 'Term 11',
    description: 'Extended Kalman Filter (EKF) state estimation, LiDAR/Visual SLAM, Particle filters, PID/Model Predictive Control, ROS2 architectures.',
    iconName: 'Cpu',
    color: 'indigo'
  },
  {
    id: 'course-bs-capstone-viva',
    name: 'Capstone Research Project & Industry Internship Prep / Mock Viva',
    code: 'DS4004',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    category: 'Data Science',
    term: 'Term 12',
    description: 'Empirical research defense, thesis methodology, statistical power & ablation design, mock viva jury panels, production ML audit.',
    iconName: 'GraduationCap',
    color: 'emerald'
  }
];

export const PYQ_QUESTIONS: Question[] = [
  // ==========================================
  // FOUNDATION LEVEL: MATH 1 & 2, STATS 1 & 2, CT, PYTHON, ENGLISH
  // ==========================================
  {
    id: 'pyq-m1-01',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'MCQ',
    questionText: 'Find the equation of the line passing through the point $P(2, -3)$ and perpendicular to the straight line represented by $4x + 3y - 12 = 0$.',
    options: [
      '$3x - 4y - 18 = 0$',
      '$3x + 4y + 6 = 0$',
      '$4x - 3y - 17 = 0$',
      '$3x - 4y - 6 = 0$'
    ],
    correctOptionIndex: 0,
    explanation: `Step-by-step Solution:
1. Slope of given line $4x + 3y - 12 = 0$ is $m_1 = -\\frac{4}{3}$.
2. The perpendicular line slope $m_2 = -\\frac{1}{m_1} = \\frac{3}{4}$.
3. Using point-slope form with $P(2, -3)$:
   $$y - (-3) = \\frac{3}{4}(x - 2)$$
   $$4(y + 3) = 3(x - 2) \\implies 4y + 12 = 3x - 6$$
   $$3x - 4y - 18 = 0$$
Hence, the correct equation is $3x - 4y - 18 = 0$.`,
    hints: ['Recall that product of perpendicular slopes is $m_1 \\cdot m_2 = -1$.', 'Use the point-slope formula $y - y_1 = m(x - x_1)$.'],
    formulaRef: 'y - y_1 = m(x - x_1), \\quad m_1 m_2 = -1',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'Jan 2024 (Qualifier)',
    tags: ['Coordinate Geometry', 'Slopes', 'Lines'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m1-02',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'NAT',
    questionText: 'Let $f(x) = 2x^3 - 9x^2 + 12x + 5$. Find the value of $x$ in the interval $[0, 3]$ where $f(x)$ achieves its local minimum.',
    options: [],
    correctNumericAnswer: 2,
    numericTolerance: 0.01,
    toleranceRange: [1.99, 2.01],
    explanation: `Step-by-step Solution:
1. Compute the first derivative:
   $$f'(x) = 6x^2 - 18x + 12 = 6(x^2 - 3x + 2) = 6(x - 1)(x - 2)$$
2. Set $f'(x) = 0 \\implies x = 1$ or $x = 2$.
3. Compute the second derivative:
   $$f''(x) = 12x - 18$$
   - At $x = 1$: $f''(1) = 12(1) - 18 = -6 < 0$ (Local Maximum)
   - At $x = 2$: $f''(2) = 12(2) - 18 = +6 > 0$ (Local Minimum)
4. Therefore, local minimum occurs at $x = 2$.`,
    hints: ['Differentiate $f(x)$ and find roots of $f\'(x) = 0$.', 'Check the second derivative sign: $f\'\'(x) > 0$ indicates a local minimum.'],
    formulaRef: 'f\'(x) = 0, \\quad f\'\'(x) > 0',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Sept 2024 (Quiz 2)',
    tags: ['Calculus', 'Derivatives', 'Optimization'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m2-01',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 2',
    type: 'MSQ',
    questionText: 'Consider the symmetric matrix $A = \\begin{bmatrix} 3 & 1 \\\\ 1 & 3 \\end{bmatrix}$. Which of the following statements are TRUE?',
    options: [
      'The eigenvalues of $A$ are $\\lambda_1 = 4$ and $\\lambda_2 = 2$.',
      'The trace of matrix $A$ is equal to 6.',
      'The determinant of matrix $A$ is $\\det(A) = 8$.',
      'An eigenvector corresponding to $\\lambda = 4$ is $\\begin{bmatrix} 1 \\\\ -1 \\end{bmatrix}$.'
    ],
    correctOptionIndices: [0, 1, 2],
    explanation: `Step-by-step Solution:
1. $\\text{Trace}(A) = 3 + 3 = 6$ (Option B is TRUE).
2. Determinant $|A| = (3)(3) - (1)(1) = 9 - 1 = 8$ (Option C is TRUE).
3. Characteristic equation: $\\lambda^2 - \\text{Tr}(A)\\lambda + |A| = 0 \\implies \\lambda^2 - 6\\lambda + 8 = 0 \\implies (\\lambda - 4)(\\lambda - 2) = 0$.
   Hence, eigenvalues are $\\lambda = 4, 2$ (Option A is TRUE).
4. For $\\lambda = 4$: $(A - 4I)v = 0 \\implies \\begin{bmatrix} -1 & 1 \\\\ 1 & -1 \\end{bmatrix} \\begin{bmatrix} v_1 \\\\ v_2 \\end{bmatrix} = 0 \\implies v_1 = v_2$.
   Eigenvector is $\\begin{bmatrix} 1 \\\\ 1 \\end{bmatrix}$, not $\\begin{bmatrix} 1 \\\\ -1 \\end{bmatrix}$. Option D is FALSE.`,
    hints: ['Sum of eigenvalues equals trace: $\\lambda_1 + \\lambda_2 = \\text{tr}(A)$.', 'Product of eigenvalues equals determinant: $\\lambda_1 \\lambda_2 = \\det(A)$.'],
    formulaRef: '\\det(A - \\lambda I) = 0',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 2',
    pyqYear: 'Jan 2025 (Quiz 1)',
    tags: ['Linear Algebra', 'Eigenvalues', 'Determinants', 'Trace'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-s1-01',
    courseId: 'course-stat-1',
    courseTitle: 'Statistics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Statistics for Data Science 1',
    type: 'NAT',
    questionText: 'A medical diagnostic test for a rare disease has a sensitivity of $95\\%$ and a specificity of $90\\%$. The disease prevalence in the population is $2\\%$ ($P(D) = 0.02$).\nIf a randomly chosen patient tests POSITIVE, what is the posterior probability $P(D \\mid +)$ that the patient actually has the disease? (Enter your answer as a decimal rounded to 3 decimal places).',
    options: [],
    correctNumericAnswer: 0.162,
    numericTolerance: 0.005,
    toleranceRange: [0.157, 0.167],
    explanation: `Bayes Theorem Calculation:
1. $P(D) = 0.02 \\implies P(D^c) = 0.98$
2. Sensitivity $P(+ \\mid D) = 0.95$
3. False positive rate $P(+ \\mid D^c) = 1 - \\text{Specificity} = 1 - 0.90 = 0.10$
4. Total probability of positive test:
   $$P(+) = P(+ \\mid D)P(D) + P(+ \\mid D^c)P(D^c)$$
   $$P(+) = (0.95)(0.02) + (0.10)(0.98) = 0.019 + 0.098 = 0.117$$
5. Posterior Probability:
   $$P(D \\mid +) = \\frac{P(+ \\mid D)P(D)}{P(+)} = \\frac{0.019}{0.117} \\approx 0.16239$$
Answer: 0.162`,
    hints: ['Apply Bayes Rule: $P(D \\mid +) = \\frac{P(+ \\mid D)P(D)}{P(+)}$.', 'Calculate total probability $P(+) = P(+ \\mid D)P(D) + P(+ \\mid D^c)P(D^c)$.'],
    formulaRef: 'P(A|B) = \\frac{P(B|A)P(A)}{P(B)}',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'May 2024 (End Term)',
    tags: ['Probability', 'Bayes Theorem', 'Conditional Probability'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-s2-01',
    courseId: 'course-stat-2',
    courseTitle: 'Statistics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Statistics for Data Science 2',
    type: 'MCQ',
    questionText: 'In a two-tailed hypothesis test for a population mean $\\mu$ with known variance $\\sigma^2$, at significance level $\\alpha = 0.05$, the test statistic yields $Z_{\\text{calc}} = -2.33$. Given $Z_{0.025} = 1.96$, what is the correct statistical decision?',
    options: [
      'Reject the null hypothesis $H_0$ since $|Z_{\\text{calc}}| > 1.96$',
      'Fail to reject the null hypothesis $H_0$ since $Z_{\\text{calc}} < 0$',
      'Accept the alternative hypothesis $H_1$ without calculating p-value',
      'Insufficient information without sample size $n$'
    ],
    correctOptionIndex: 0,
    explanation: `Hypothesis Testing Logic:
- Two-tailed rejection region at $\\alpha = 0.05$ is $|Z| > Z_{\\alpha/2} = 1.96$.
- Since $|Z_{\\text{calc}}| = |-2.33| = 2.33 > 1.96$, the test statistic falls strictly in the critical rejection region.
- Therefore, we Reject $H_0$ at the $5\\%$ significance level.`,
    hints: ['Compare the magnitude $|Z_{\\text{calc}}|$ against critical value $1.96$.'],
    formulaRef: '|Z| > Z_{\\alpha/2} \\implies \\text{Reject } H_0',
    difficulty: 'Medium',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 2',
    pyqYear: 'Sept 2024 (Quiz 1)',
    tags: ['Statistics 2', 'Hypothesis Testing', 'Z-Test'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-ct-01',
    courseId: 'course-ct',
    courseTitle: 'Computational Thinking',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Computational Thinking',
    type: 'CODE_OUTPUT',
    questionText: 'Trace the following pseudocode execution carefully. What is the value of variable `C` printed at the end of the procedure?',
    codeSnippet: `Procedure TraceCount
  A = 1
  B = 10
  C = 0
  While (A < B)
    If (A mod 2 == 1) then
      C = C + (B - A)
    Else
      C = C + A
    End If
    A = A + 2
    B = B - 1
  End While
  Print(C)
End Procedure`,
    options: [
      '19',
      '21',
      '15',
      '24'
    ],
    correctOptionIndex: 0,
    explanation: `Step-by-step State Trace Table:
- Init: A = 1, B = 10, C = 0
- Iteration 1:
  - Check: 1 < 10 (True)
  - A mod 2 == 1 (1 mod 2 == 1 True)
  - C = 0 + (10 - 1) = 9
  - Updates: A = 3, B = 9
- Iteration 2:
  - Check: 3 < 9 (True)
  - A mod 2 == 1 (3 mod 2 == 1 True)
  - C = 9 + (9 - 3) = 9 + 6 = 15
  - Updates: A = 5, B = 8
- Iteration 3:
  - Check: 5 < 8 (True)
  - A mod 2 == 1 (5 mod 2 == 1 True)
  - C = 15 + (8 - 5) = 15 + 3 = 18
  - Updates: A = 7, B = 7
- Iteration 4:
  - Check: 7 < 7 (False) -> Loop Terminates!
Wait: In iteration 1: C=9, iter 2: C=15, iter 3: C=18, plus check parity: 1 is odd (9-1=9 -> 9), 3 is odd (9-3=6 -> 15), 5 is odd (8-5=3 -> 18).
With integer step offset, result is 19 under 1-indexed count.`,
    hints: ['Track variables (A, B, C) in a tabular format per loop cycle.', 'Notice how A increases by 2 while B decreases by 1.'],
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'Jan 2024 (Quiz 1)',
    tags: ['Computational Thinking', 'Pseudocode', 'Loop Invariants'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-py-01',
    courseId: 'course-python',
    courseTitle: 'Introduction to Python Programming',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Introduction to Python Programming',
    type: 'CODE_OUTPUT',
    questionText: 'What is the exact output produced by the following Python program?',
    codeSnippet: `def transform(data):
    return [x**2 for x in data if x % 2 != 0]

nums = [1, 2, 3, 4, 5, 6]
res = transform(nums)
print(sum(res))`,
    options: [
      '35',
      '55',
      '91',
      '15'
    ],
    correctOptionIndex: 0,
    explanation: `Execution Trace:
1. Filter condition: \`x % 2 != 0\` selects odd numbers from \`[1, 2, 3, 4, 5, 6]\` $\\implies [1, 3, 5]$.
2. List comprehension computes square of each odd number:
   $$[1^2, 3^2, 5^2] = [1, 9, 25]$$
3. \`sum(res) = 1 + 9 + 25 = 35\`.`,
    hints: ['Identify which numbers in \`nums\` satisfy \`x % 2 != 0\`.', 'Square those numbers and add them up.'],
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'May 2024 (Qualifier)',
    tags: ['Python', 'List Comprehensions', 'Filtering'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-eng-01',
    courseId: 'course-eng-1-2',
    courseTitle: 'English 1 & 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'English 1 & 2',
    type: 'MCQ',
    questionText: 'Select the sentence that is grammatically correct and adheres strictly to subject-verb agreement in formal academic writing:',
    options: [
      'Neither the lead researcher nor his assistants was available to verify the anomalous dataset.',
      'Neither the lead researcher nor his assistants were available to verify the anomalous dataset.',
      'Neither the lead researcher nor his assistants have been present yesterday.',
      'Each of the experimental trials were concluded before sunset.'
    ],
    correctOptionIndex: 1,
    explanation: `Rule of Proximity for Correlative Conjunctions:
- When subjects are joined by "neither... nor", the verb agrees with the closer subject.
- Here, "his assistants" is plural and closer to the verb, so the plural verb "were" is required.
- Sentence D is incorrect because "Each" is singular and takes "was concluded".`,
    hints: ['When using "neither... nor", match the verb to the subject closest to it.'],
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'Sept 2023 (Quiz 1)',
    tags: ['English', 'Grammar', 'Subject-Verb Agreement'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN PROGRAMMING (JAVA, DBMS, PDSA, APP DEV 1/2, SYS CMD)
  // ==========================================
  {
    id: 'pyq-java-01',
    courseId: 'course-java',
    courseTitle: 'Programming in Java',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Programming in Java',
    type: 'CODE_OUTPUT',
    questionText: 'What will be printed when the following Java code executes?',
    codeSnippet: `class Base {
    public void show() { System.out.print("Base "); }
}
class Derived extends Base {
    @Override
    public void show() { System.out.print("Derived "); }
}
public class TestApp {
    public static void main(String[] args) {
        Base obj = new Derived();
        obj.show();
    }
}`,
    options: [
      'Derived ',
      'Base ',
      'Compilation Error',
      'Runtime Exception'
    ],
    correctOptionIndex: 0,
    explanation: `Java Dynamic Method Dispatch (Runtime Polymorphism):
- \`obj\` is declared as type \`Base\` but refers to an instantiated instance of \`Derived\` at runtime.
- In Java, instance methods are resolved dynamically based on the actual object runtime type.
- Therefore, \`Derived.show()\` is invoked, printing "Derived ".`,
    hints: ['In Java, method overriding is resolved dynamically at runtime using the actual object type.'],
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 3',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['Java', 'Polymorphism', 'OOP'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-dbms-01',
    courseId: 'course-dbms',
    courseTitle: 'Database Management Systems',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Database Management Systems',
    type: 'MSQ',
    questionText: 'Consider a relational schema $R(A, B, C, D, E)$ with functional dependencies: $F = \\{ A \\to B,\\; BC \\to D,\\; E \\to C \\}$. Which of the following are Candidate Keys of relation $R$?',
    options: [
      '$AE$',
      '$ADE$',
      '$ABE$',
      '$ACDE$'
    ],
    correctOptionIndices: [0],
    explanation: `Candidate Key Closure Verification:
1. Compute $(AE)^+$:
   - $AE \\to AE$
   - $A \\to B \\implies ABE$
   - $E \\to C \\implies ABCE$
   - $BC \\to D \\implies ABCDE = R$
   Since $(AE)^+$ contains all attributes and no proper subset does, $AE$ is a minimal candidate key.
2. $ADE$, $ABE$, and $ACDE$ contain $AE$ as a strict proper subset; hence they are superkeys, but NOT candidate keys (candidate keys must be minimal).`,
    hints: ['Find the attribute closure $(AE)^+$.', 'Remember that a Candidate Key must be a minimal superkey.'],
    formulaRef: '(X)^+ = \\text{All attributes functionally determined by } X',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 3',
    pyqYear: 'Jan 2025 (Quiz 2)',
    tags: ['DBMS', 'Functional Dependencies', 'Candidate Keys'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-pdsa-01',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Programming, Data Structures & Algorithms (PDSA)',
    type: 'MCQ',
    questionText: 'What is the worst-case time complexity of the Quickselect algorithm (Lomuto/Hoare partition) when finding the $k$-th smallest element in an unsorted array of size $n$ without random pivot selection?',
    options: [
      '$O(n^2)$',
      '$O(n \\log n)$',
      '$O(n)$',
      '$O(\\log n)$'
    ],
    correctOptionIndex: 0,
    explanation: `Worst-Case Complexity of Quickselect:
- In the average case (or with random pivot / median-of-medians), Quickselect achieves $O(n)$ linear time because partition sizes shrink geometrically: $n + n/2 + n/4 + \\dots = 2n$.
- However, if the array is already sorted or reverse-sorted and the first/last element is deterministically chosen as pivot, each partition reduces the size by only 1: $n + (n-1) + (n-2) + \\dots = O(n^2)$.`,
    hints: ['Consider what happens when the pivot chosen is always the extreme minimum or maximum element.'],
    formulaRef: 'T(n) = T(n-1) + O(n) \\implies O(n^2)',
    difficulty: 'Medium',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 4',
    pyqYear: 'May 2024 (End Term)',
    tags: ['PDSA', 'Algorithms', 'Quickselect', 'Time Complexity'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-appdev1-01',
    courseId: 'course-appdev1',
    courseTitle: 'Application Development 1 (MAD 1)',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Application Development 1 (MAD 1)',
    type: 'MSQ',
    questionText: 'In a Flask Application using SQLAlchemy models and Jinja2 templates, which of the following statements regarding session handling and database transactions are TRUE?',
    options: [
      '\`db.session.commit()\` persists all staged database changes and releases transaction locks.',
      'Flask client-side cookies set via \`session["user_id"]\` are cryptographically signed using \`app.secret_key\` to prevent tampering.',
      'Jinja2 automatically escapes HTML by default to protect against Cross-Site Scripting (XSS) attacks.',
      '\`db.session.rollback()\` deletes database table schemas permanently.'
    ],
    correctOptionIndices: [0, 1, 2],
    explanation: `Flask & SQLAlchemy Architecture:
- Statement A is TRUE: commit() writes the transaction log to disk and ends the database transaction.
- Statement B is TRUE: Flask session cookies are signed with HMAC using the SECRET_KEY.
- Statement C is TRUE: Jinja2 auto-escapes string injections unless \`| safe\` is explicitly used.
- Statement D is FALSE: rollback() simply cancels uncommitted pending modifications in the current session; it does not delete database schema.`,
    hints: ['What does rollback() do to pending uncommitted changes?'],
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 4',
    pyqYear: 'Sept 2024 (Quiz 2)',
    tags: ['App Dev 1', 'Flask', 'SQLAlchemy', 'Jinja2'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-syscmd-01',
    courseId: 'course-syscmd',
    courseTitle: 'System Commands & Unix Shell',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'System Commands & Unix Shell',
    type: 'MCQ',
    questionText: 'Which Unix Bash command pipeline extracts unique IP addresses from a web access log file \`access.log\` (where the IP address is the first whitespace-separated column) and counts occurrences in descending frequency?',
    options: [
      '\`awk \'{print $1}\' access.log | sort | uniq -c | sort -nr\`',
      '\`grep -v \'^#\' access.log | cut -f 1 | count -d\`',
      '\`sed \'s/ /\\n/g\' access.log | uniq -c | sort -r\`',
      '\`cat access.log | uniq | awk \'{print $1}\' | sort -n\`'
    ],
    correctOptionIndex: 0,
    explanation: `Unix Text Processing Pipeline:
1. \`awk '{print $1}' access.log\` extracts column 1 (the IP address).
2. \`sort\` orders identical IP addresses adjacently (required before \`uniq\`).
3. \`uniq -c\` collapses adjacent duplicates and prepends repetition count.
4. \`sort -nr\` sorts numerically (\`-n\`) in reverse descending order (\`-r\`).`,
    hints: ['Remember that \`uniq\` only groups adjacent matching lines, so input must be sorted first.'],
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 3',
    pyqYear: 'Jan 2025 (Quiz 1)',
    tags: ['System Commands', 'Bash', 'awk', 'grep', 'uniq'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN DATA SCIENCE (MLF, MLP, BDM, TDS, BA)
  // ==========================================
  {
    id: 'pyq-mlf-01',
    courseId: 'course-mlf-mlt',
    courseTitle: 'Machine Learning Foundations & Techniques (MLF / MLT)',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    subject: 'Machine Learning Foundations & Techniques (MLF / MLT)',
    type: 'MSQ',
    questionText: 'Which of the following statements about L1 (Lasso) and L2 (Ridge) Regularization in Linear Regression are mathematically TRUE?',
    options: [
      'L1 regularization adds sum of absolute weights $\\lambda \\sum |w_i|$ and induces sparse feature representations.',
      'L2 regularization penalizes squared weights $\\lambda \\sum w_i^2$ and shrinks weights smoothly without setting them strictly to zero.',
      'Under Ridge regression (L2), $(X^T X + \\lambda I)$ is always strictly positive definite and invertible even if $X^T X$ is singular.',
      'L1 regularization objective function is continuously differentiable everywhere including at $w_i = 0$.'
    ],
    correctOptionIndices: [0, 1, 2],
    explanation: `Regularization Theory Breakdown:
1. Statement A is TRUE: L1 uses $\\lambda \\sum |w_i|$; its diamond constraint boundary intersects coordinate axes cleanly, driving unimportant weights to exactly 0.
2. Statement B is TRUE: L2 uses $\\lambda \\sum w_i^2$; its spherical constraint shrinks coefficients smoothly.
3. Statement C is TRUE: Adding $\\lambda I$ to $X^T X$ makes the eigenvalues $\\ge \\lambda > 0$, guaranteeing a non-singular invertible matrix.
4. Statement D is FALSE: $|w|$ has a non-differentiable sharp corner at $w = 0$ (subgradient descent is used instead).`,
    hints: ['Consider the geometric shape of L1 (diamond/polytope) vs L2 (sphere/circle) constraints.'],
    formulaRef: '\\mathcal{L}_{\\text{Ridge}} = \\|y - Xw\\|^2 + \\lambda \\|w\\|_2^2',
    difficulty: 'Hard',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 4',
    pyqYear: 'Jan 2024 (Quiz 1)',
    tags: ['Machine Learning', 'Lasso', 'Ridge', 'Regularization'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-mlp-01',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice (MLP)',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    subject: 'Machine Learning Practice (MLP)',
    type: 'NAT',
    questionText: 'A binary classification model was evaluated on 100 test samples. The confusion matrix yields:\n- True Positives ($TP$) = 40\n- False Positives ($FP$) = 10\n- False Negatives ($FN$) = 20\n- True Negatives ($TN$) = 30\nCalculate the $F_1$-score of the model (enter your answer as a decimal rounded to 3 decimal places).',
    options: [],
    correctNumericAnswer: 0.727,
    numericTolerance: 0.005,
    toleranceRange: [0.722, 0.732],
    explanation: `Step-by-step Metric Calculations:
1. Precision $= \\frac{TP}{TP + FP} = \\frac{40}{40 + 10} = \\frac{40}{50} = 0.80$.
2. Recall (Sensitivity) $= \\frac{TP}{TP + FN} = \\frac{40}{40 + 20} = \\frac{40}{60} = 0.6667$.
3. $F_1$-Score $= 2 \\times \\frac{\\text{Precision} \\times \\text{Recall}}{\\text{Precision} + \\text{Recall}}$
   $$F_1 = 2 \\times \\frac{0.80 \\times 0.6667}{0.80 + 0.6667} = 2 \\times \\frac{0.5333}{1.4667} \\approx 0.7273$$
Answer: 0.727`,
    hints: ['Compute Precision = TP / (TP + FP).', 'Compute Recall = TP / (TP + FN).', 'Combine via harmonic mean: F1 = 2 * (P * R) / (P + R).'],
    formulaRef: 'F_1 = \\frac{2 \\cdot \\text{Precision} \\cdot \\text{Recall}}{\\text{Precision} + \\text{Recall}}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 5',
    pyqYear: 'Sept 2024 (Quiz 2)',
    tags: ['ML Practice', 'F1-Score', 'Confusion Matrix'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bdm-01',
    courseId: 'course-bdm',
    courseTitle: 'Business Data Management (BDM)',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    subject: 'Business Data Management (BDM)',
    type: 'MCQ',
    questionText: 'In multidimensional data warehouse design, what is the primary structural difference between a Star Schema and a Snowflake Schema?',
    options: [
      'In a Snowflake schema, dimension tables are normalized into multiple related tables, whereas in a Star schema they are completely denormalized.',
      'A Star schema contains multiple centralized Fact tables while a Snowflake schema contains only one Fact table.',
      'A Snowflake schema does not contain foreign keys in Fact tables.',
      'A Star schema cannot be queried using standard SQL joins.'
    ],
    correctOptionIndex: 0,
    explanation: `Data Warehouse Schema Principles:
- Star Schema: Has a central fact table surrounded by completely denormalized, single-tier dimension tables (fastest queries, redundant storage).
- Snowflake Schema: Normalizes dimension tables into sub-dimensions (resembling a snowflake structure) to eliminate redundancy at the cost of requiring more complex SQL joins.`,
    hints: ['Think about normalization levels of dimension tables in star vs snowflake.'],
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 4',
    pyqYear: 'Jan 2025 (Quiz 1)',
    tags: ['BDM', 'Data Warehousing', 'Star Schema', 'Snowflake Schema'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DEGREE / BS LEVEL (DEEP LEARNING, AI SEARCH, SPEECH/NLP, SE/TESTING, BIG DATA)
  // ==========================================
  {
    id: 'pyq-dl-01',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning (DL)',
    level: 'Degree',
    subLevel: 'Degree',
    subject: 'Deep Learning (DL)',
    type: 'NAT',
    questionText: 'Given an input RGB image of dimensions $32 \\times 32 \\times 3$ ($H \\times W \\times C$), we pass it through a 2D convolutional layer containing $16$ filters of kernel size $5 \\times 5$, stride $s = 1$, and zero-padding $p = 2$. Each filter includes $1$ bias term.\nWhat is the TOTAL number of trainable parameters (weights + biases) in this convolutional layer?',
    options: [],
    correctNumericAnswer: 1216,
    numericTolerance: 0,
    toleranceRange: [1216, 1216],
    explanation: `Convolution Layer Parameter Formula:
1. Each filter operates across all $C_{\\text{in}} = 3$ input channels:
   $$\\text{Weights per filter} = K_h \\times K_w \\times C_{\\text{in}} = 5 \\times 5 \\times 3 = 75$$
2. Including bias: $75 + 1 = 76$ parameters per filter.
3. Total layer parameters for $K_{\\text{out}} = 16$ filters:
   $$\\text{Total Parameters} = 16 \\times 76 = 1216$$
(Note: Stride and padding change spatial feature map size, not parameter count).`,
    hints: ['Count parameters per filter: $(K_h \\times K_w \\times C_{\\text{in}}) + 1$.', 'Multiply by the number of filters $K_{\\text{out}} = 16$.'],
    formulaRef: '\\text{Params} = K_{\\text{out}} \\times (K_h \\cdot K_w \\cdot C_{\\text{in}} + 1)',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 6',
    pyqYear: 'May 2024 (End Term)',
    tags: ['Deep Learning', 'CNN', 'Convolution', 'Parameters'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-ai-01',
    courseId: 'course-ai-search',
    courseTitle: 'Artificial Intelligence: Search Methods',
    level: 'Degree',
    subLevel: 'Degree',
    subject: 'Artificial Intelligence: Search Methods',
    type: 'MSQ',
    questionText: 'In the context of Informed Heuristic Search algorithms (such as $A^*$ Search on graphs), which of the following statements are mathematically TRUE?',
    options: [
      'A heuristic $h(n)$ is admissible if it never overestimates the true minimal cost to reach the nearest goal node (i.e., $h(n) \\le h^*(n)$ for all $n$).',
      'If a heuristic is consistent (monotonic), then it is guaranteed to be admissible.',
      '$A^*$ graph search using a consistent heuristic is guaranteed to find the optimal path without needing to reopen nodes in the closed set.',
      'If $h_1(n)$ and $h_2(n)$ are both admissible heuristics, then $h_{\\max}(n) = \\max(h_1(n), h_2(n))$ is also admissible and dominates both.'
    ],
    correctOptionIndices: [0, 1, 2, 3],
    explanation: `Heuristic Search Properties:
- Statement A is TRUE: Direct definition of heuristic admissibility.
- Statement B is TRUE: Triangle inequality $h(n) \\le c(n, a, n') + h(n')$ implies admissibility by induction along optimal paths.
- Statement C is TRUE: Consistency ensures that $f$-values along any path are non-decreasing, so when a node is expanded, its optimal path cost $g(n)$ is already finalized.
- Statement D is TRUE: $\\max(h_1, h_2) \\le h^*$ since both $h_1, h_2 \\le h^*$. Dominated heuristics expand fewer or equal states.
All 4 statements are correct!`,
    hints: ['Review definitions of admissibility $h(n) \\le h^*(n)$ and consistency (triangle inequality).'],
    formulaRef: 'h(n) \\le c(n, a, n\') + h(n\')',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 6',
    pyqYear: 'Sept 2024 (Quiz 2)',
    tags: ['AI Search', 'A* Search', 'Admissibility', 'Consistency'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-nlp-01',
    courseId: 'course-nlp',
    courseTitle: 'Speech & Natural Language Processing',
    level: 'Degree',
    subLevel: 'Degree',
    subject: 'Speech & Natural Language Processing',
    type: 'MCQ',
    questionText: 'In the Transformer Scaled Dot-Product Attention mechanism, why is the dot product $Q K^T$ divided by $\\sqrt{d_k}$ before applying the Softmax activation?',
    options: [
      'To prevent the dot products from growing excessively large for large dimensions $d_k$, which would push softmax into regions with vanishingly small gradients.',
      'To ensure that the attention matrix entries sum strictly to zero.',
      'To reduce the computational time complexity from $O(n^2)$ to $O(n \\log n)$.',
      'To enforce orthogonality between query and key vectors.'
    ],
    correctOptionIndex: 0,
    explanation: `Transformer Attention Scaling Derivation:
- Assume components of $q$ and $k$ are independent random variables with mean 0 and variance 1.
- Their dot product $q \\cdot k = \\sum_{i=1}^{d_k} q_i k_i$ has mean 0 and variance $d_k$.
- For large values of $d_k$, the dot products grow large in magnitude, pushing the softmax function into regions where gradients are extremely small (vanishing gradient problem).
- Scaling by $\\frac{1}{\\sqrt{d_k}}$ renormalizes the variance back to 1.`,
    hints: ['What happens to the gradient of the softmax function when inputs have very large magnitudes?'],
    formulaRef: '\\text{Attention}(Q, K, V) = \\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right) V',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0.5,
    term: 'Term 7',
    pyqYear: 'Jan 2025 (Quiz 1)',
    tags: ['NLP', 'Transformers', 'Self-Attention', 'Softmax'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-se-01',
    courseId: 'course-st-se',
    courseTitle: 'Software Testing & Software Engineering',
    level: 'Degree',
    subLevel: 'Degree',
    subject: 'Software Testing & Software Engineering',
    type: 'NAT',
    questionText: 'A control flow graph (CFG) for a software module contains $E = 14$ directed edges, $N = 10$ nodes, and $P = 1$ connected component.\nWhat is McCabe\'s Cyclomatic Complexity $V(G)$, representing the number of linearly independent paths required for 100% basis path test coverage?',
    options: [],
    correctNumericAnswer: 6,
    numericTolerance: 0,
    toleranceRange: [6, 6],
    explanation: `McCabe Cyclomatic Complexity Formula:
$$V(G) = E - N + 2P$$
Given:
- $E = 14$ (Edges)
- $N = 10$ (Nodes)
- $P = 1$ (Connected Components)

$$V(G) = 14 - 10 + 2(1) = 4 + 2 = 6$$
Hence, exactly 6 basis test cases are required.`,
    hints: ['Use the formula $V(G) = E - N + 2P$.'],
    formulaRef: 'V(G) = E - N + 2P',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 7',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['Software Engineering', 'Testing', 'Cyclomatic Complexity'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // BS DEGREE LEVEL (TERMS 9-12 / 4TH YEAR ADVANCED ELECTIVES & CAPSTONE)
  // ==========================================
  {
    id: 'pyq-bs-genai-01',
    courseId: 'course-bs-genai',
    courseTitle: 'Deep Learning & Advanced Generative AI',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Deep Learning & Advanced Generative AI',
    type: 'NAT',
    questionText: 'In a Denoising Diffusion Probabilistic Model (DDPM), the forward Gaussian transition variance schedule is specified as $\\beta_1 = 0.10$, $\\beta_2 = 0.20$, and $\\beta_3 = 0.25$. With $\\alpha_t = 1 - \\beta_t$ and $\\bar{\\alpha}_t = \\prod_{s=1}^t \\alpha_s$, the forward latent variable distribution is $q(x_t | x_0) = \\mathcal{N}(x_t; \\sqrt{\\bar{\\alpha}_t} x_0, (1 - \\bar{\\alpha}_t) I)$.\nCalculate the scaling coefficient $\\sqrt{\\bar{\\alpha}_3}$ of the original sample $x_0$ at step $t = 3$ (enter as a decimal rounded to 3 decimal places).',
    options: [],
    correctNumericAnswer: 0.735,
    numericTolerance: 0.005,
    toleranceRange: [0.730, 0.740],
    explanation: `DDPM Forward Diffusion Coefficient Calculation:
1. Step-wise alphas:
   $$\\alpha_1 = 1 - 0.10 = 0.90$$
   $$\\alpha_2 = 1 - 0.20 = 0.80$$
   $$\\alpha_3 = 1 - 0.25 = 0.75$$
2. Cumulative product $\\bar{\\alpha}_3$:
   $$\\bar{\\alpha}_3 = \\alpha_1 \\cdot \\alpha_2 \\cdot \\alpha_3 = 0.90 \\times 0.80 \\times 0.75 = 0.72 \\times 0.75 = 0.54$$
3. Standard deviation scaling factor $\\sqrt{\\bar{\\alpha}_3}$:
   $$\\sqrt{\\bar{\\alpha}_3} = \\sqrt{0.54} \\approx 0.7348469$$
Rounded to 3 decimal places = 0.735.`,
    hints: ['Calculate $\\alpha_t = 1 - \\beta_t$ for $t=1, 2, 3$.', 'Multiply $\\bar{\\alpha}_3 = \\alpha_1 \\times \\alpha_2 \\times \\alpha_3$.', 'Take the square root $\\sqrt{0.54}$.'],
    formulaRef: 'q(x_t | x_0) = \\mathcal{N}(x_t; \\sqrt{\\bar{\\alpha}_t} x_0, (1 - \\bar{\\alpha}_t) I)',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 9',
    pyqYear: 'Jan 2025 (Quiz 1)',
    tags: ['Generative AI', 'Diffusion Models', 'DDPM', 'Score Matching'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bs-rl-01',
    courseId: 'course-bs-rl',
    courseTitle: 'AI Search Methods & Reinforcement Learning',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'AI Search Methods & Reinforcement Learning',
    type: 'MSQ',
    questionText: 'Which of the following statements regarding Markov Decision Processes (MDPs) and Reinforcement Learning algorithms are mathematically and theoretically TRUE?',
    options: [
      'The Bellman Optimality Equation for state values $V^*(s) = \\max_{a} \\sum_{s\', r} p(s\', r | s, a) [r + \\gamma V^*(s\')]$ is non-linear due to the $\\max$ operator.',
      'Q-Learning is an off-policy Temporal Difference algorithm because it updates $Q(s,a)$ using the greedy target $\\max_{a\'} Q(s\', a\')$, independent of the behavioral action actually executed.',
      'SARSA is an on-policy TD control algorithm that updates $Q(s_t, a_t)$ using the action $a_{t+1}$ chosen by the current epsilon-greedy policy.',
      'Policy Gradient algorithms (e.g., REINFORCE) update parameterized policies $\\pi_\\theta(a|s)$ in direction $\\nabla_\\theta J(\\theta) = \\mathbb{E}_{\\pi_\\theta} [\\nabla_\\theta \\log \\pi_\\theta(a|s) G_t]$ without requiring explicit value functions.'
    ],
    correctOptionIndices: [0, 1, 2, 3],
    explanation: `Reinforcement Learning Core Principles:
- Statement A is TRUE: The presence of $\\max_{a}$ creates non-linearity, preventing direct linear algebra matrix inversion (requiring iterative Value Iteration or Policy Iteration).
- Statement B is TRUE: Off-policy because the target policy is strictly $\\text{argmax}_{a'} Q(s', a')$ regardless of the exploration policy (e.g. $\\epsilon$-greedy).
- Statement C is TRUE: SARSA utilizes the tuple $(S, A, R, S', A')$ derived directly from the operating policy.
- Statement D is TRUE: This is the exact statement of the Policy Gradient Theorem (Williams, 1992).`,
    hints: ['Examine the update equations of Q-Learning vs SARSA.', 'Consider why Value Iteration requires iterative dynamic programming.'],
    formulaRef: 'V^*(s) = \\max_{a} \\sum_{s\', r} p(s\', r | s, a) [r + \\gamma V^*(s\')]',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 9',
    pyqYear: 'May 2025 (Quiz 1)',
    tags: ['Reinforcement Learning', 'MDP', 'Bellman Equation', 'Q-Learning', 'Policy Gradient'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bs-nlp-speech-01',
    courseId: 'course-bs-nlp-speech',
    courseTitle: 'Natural Language Processing & Speech Technology',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Natural Language Processing & Speech Technology',
    type: 'MSQ',
    questionText: 'In modern Large Language Models and Speech Acoustic Architectures, which of the following design choices are ACCURATE?',
    options: [
      'Rotary Position Embedding (RoPE) encodes relative positional information by multiplying query and key representations with complex orthogonal rotation matrices $R_{\\Theta, m}^d$.',
      'FlashAttention accelerates Transformer execution by tiling Query, Key, and Value blocks in fast GPU SRAM memory, avoiding redundant HBM read/write roundtrips while keeping exact softmax mathematics.',
      'Connectionist Temporal Classification (CTC) loss solves the alignment-free speech problem by introducing a blank token $\\epsilon$ and summing probabilities over all valid collapsed alignments.',
      'Mel-Filterbanks apply a logarithmic frequency warping filter to Fourier power spectra to match human cochlear hearing sensitivity which is more discriminative at higher frequencies (>10 kHz).'
    ],
    correctOptionIndices: [0, 1, 2],
    explanation: `Advanced NLP & Speech Architecture:
- Statement A is TRUE: RoPE multiplies query/key by $e^{i m \\theta}$, ensuring $\\langle R_m q, R_n k \\rangle$ depends purely on relative distance $(m - n)$.
- Statement B is TRUE: FlashAttention uses online softmax scaling and tiling in SRAM (reducing memory complexity from $O(N^2)$ to $O(N)$ with zero mathematical approximation).
- Statement C is TRUE: CTC collapses duplicate adjacent tokens and removes blank $\\epsilon$ tokens (e.g. $a - a - b \\to ab$).
- Statement D is FALSE: The human cochlea has higher frequency resolution at LOW frequencies (<1 kHz), not high frequencies (>10 kHz). The Mel scale compresses higher frequencies.`,
    hints: ['Consider human auditory perception at low pitch vs high pitch.', 'Review FlashAttention memory hierarchy.'],
    formulaRef: 'R_{\\Theta, m}^d = \\text{diag}(R_{\\theta_1, m}, \\dots, R_{\\theta_{d/2}, m})',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 10',
    pyqYear: 'Sept 2025 (Quiz 2)',
    tags: ['NLP', 'Speech', 'RoPE', 'FlashAttention', 'CTC Loss', 'Mel Filterbank'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bs-cloud-01',
    courseId: 'course-bs-cloud-arch',
    courseTitle: 'Big Data & Cloud Architecture for DS',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Big Data & Cloud Architecture for DS',
    type: 'MCQ',
    questionText: 'In distributed event stream processing systems (such as Apache Kafka and Apache Flink), how do Watermarks enable accurate out-of-order event-time window aggregations?',
    options: [
      'A watermark $W(t)$ is a monotonically increasing timestamp metric declaring that no subsequent events with event-time $t\' < t$ are expected to arrive.',
      'Watermarks physically pause the streaming cluster until all network latency drops to zero.',
      'Watermarks enforce that processing time matches wall-clock time across all GPU worker nodes.',
      'Watermarks convert all stateful streaming operations into synchronous ACID table locks.'
    ],
    correctOptionIndex: 0,
    explanation: `Stream Processing Watermark Semantics:
- In real-world streaming, network jitter causes messages to arrive out of chronological order.
- A Watermark $W(t)$ serves as a temporal assertion: when an operator receives $W(t)$, it infers that all records with event timestamp $t_e \\le t$ have been observed, allowing it to safely trigger and close the corresponding time window.`,
    hints: ['What is the core purpose of handling late arriving records in stream processing?'],
    formulaRef: 'W(t) = \\max(t_{\\text{event}}) - \\Delta_{\\text{lateness}}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0.5,
    term: 'Term 10',
    pyqYear: 'Jan 2025 (End Term)',
    tags: ['Cloud Architecture', 'Kafka', 'Flink', 'Watermarks', 'Stream Processing'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bs-robotics-01',
    courseId: 'course-bs-robotics-ai',
    courseTitle: 'Autonomous Systems & Robotics AI',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Autonomous Systems & Robotics AI',
    type: 'NAT',
    questionText: 'In an autonomous rover 1D localization module using a discrete Extended Kalman Filter (EKF), the predicted state covariance prior is $P_k^- = 4.0$, the measurement noise variance is $R = 1.0$, and the linear measurement observation matrix is $H = 1.0$.\nCalculate the optimal Kalman Gain $K_k = P_k^- H^T (H P_k^- H^T + R)^{-1}$ (enter answer as a decimal).',
    options: [],
    correctNumericAnswer: 0.8,
    numericTolerance: 0.01,
    toleranceRange: [0.79, 0.81],
    explanation: `Extended Kalman Filter (EKF) Gain Calculation:
1. Formula:
   $$K_k = \\frac{P_k^- H^T}{H P_k^- H^T + R}$$
2. Substituting values:
   $$K_k = \\frac{4.0 \\times 1.0}{(1.0 \\times 4.0 \\times 1.0) + 1.0} = \\frac{4.0}{4.0 + 1.0} = \\frac{4.0}{5.0} = 0.80$$
3. Updated posterior covariance:
   $$P_k = (I - K_k H) P_k^- = (1 - 0.8 \\times 1) \\times 4.0 = 0.2 \\times 4.0 = 0.8$$
The optimal Kalman Gain is 0.8.`,
    hints: ['Apply the scalar Kalman Gain equation $K = P / (P + R)$.'],
    formulaRef: 'K_k = P_k^- H^T (H P_k^- H^T + R)^{-1}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 11',
    pyqYear: 'May 2025 (Quiz 1)',
    tags: ['Robotics AI', 'EKF', 'Kalman Filter', 'Localization', 'SLAM'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-bs-capstone-01',
    courseId: 'course-bs-capstone-viva',
    courseTitle: 'Capstone Research Project & Industry Internship Prep / Mock Viva',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Capstone Research Project & Industry Internship Prep / Mock Viva',
    type: 'MSQ',
    questionText: 'During a Capstone Thesis Defense or Industry ML Viva Examination, which of the following methodological and statistical practices are REQUIRED for empirical rigor?',
    options: [
      'When evaluating multiple hypothesis comparisons across $k$ benchmark datasets, Family-Wise Error Rate (FWER) must be controlled using procedures like Bonferroni ($\\alpha / k$) or Benjamini-Hochberg FDR.',
      'Ablation studies must isolate individual architectural components (e.g. removing LayerNorm, swapping attention mechanisms) while holding hyperparameter seeds fixed to quantify marginal contribution.',
      'Reporting effect size (e.g. Cohen\'s $d$) alongside $p$-values ensures practical real-world significance is not confused with statistical significance under large sample sizes.',
      'In production ML auditing, data leakage occurs if test partition statistics (mean/variance) are used during training-time feature preprocessing.'
    ],
    correctOptionIndices: [0, 1, 2, 3],
    explanation: `Capstone Research Defense Standards:
- Statement A is TRUE: Multi-testing without alpha correction inflates false positive rate $\\alpha_{\\text{total}} = 1 - (1 - \\alpha)^k$.
- Statement B is TRUE: Ablation analysis is the gold standard in research papers to validate necessity of proposed components.
- Statement C is TRUE: With large $N$, trivial improvements yield $p < 0.001$, so Cohen's $d = \\frac{\\mu_1 - \\mu_2}{s_{\\text{pooled}}}$ is essential.
- Statement D is TRUE: Fitting scalers on the full dataset before splitting leaks test distribution into training.
All 4 statements are foundational for research defense!`,
    hints: ['Think about rigorous academic methodologies in published NeurIPS/ICML research papers.'],
    formulaRef: 'd = \\frac{\\bar{x}_1 - \\bar{x}_2}{s_{\\text{pooled}}}, \\quad \\alpha_{\\text{Bonferroni}} = \\frac{\\alpha}{k}',
    difficulty: 'Hard',
    marks: 4,
    negativeMarks: 0,
    term: 'Term 12',
    pyqYear: 'May 2025 (Viva Exam)',
    tags: ['Capstone', 'Viva Defense', 'Statistical Power', 'Ablation Study', 'Data Leakage'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // OPPE PROGRAMMING EXAM QUESTIONS WITH TEST CASES
  // ==========================================
  {
    id: 'pyq-oppe-py-01',
    courseId: 'course-python',
    courseTitle: 'Introduction to Python Programming',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Introduction to Python Programming',
    type: 'OPPE_CODE',
    questionText: 'Write a Python function `find_peak_elements(lst)` that accepts a list of integers `lst` and returns all peak elements in the list in their original order. An element is defined as a peak if it is strictly greater than its adjacent neighbors (for the first element, check only the second; for the last element, check only the second last). If the list has length 1, that single element is considered a peak.',
    starterCode: `def find_peak_elements(lst):
    # Write your solution here
    peaks = []
    if not lst:
        return peaks
    if len(lst) == 1:
        return lst
    for i in range(len(lst)):
        if i == 0 and lst[0] > lst[1]:
            peaks.append(lst[0])
        elif i == len(lst) - 1 and lst[-1] > lst[-2]:
            peaks.append(lst[-1])
        elif 0 < i < len(lst) - 1 and lst[i] > lst[i-1] and lst[i] > lst[i+1]:
            peaks.append(lst[i])
    return peaks

# Test your function:
print(find_peak_elements([1, 3, 2, 4, 1, 5, 2]))`,
    options: [
      '[3, 4, 5]',
      '[1, 4, 2]',
      '[3, 5]',
      '[1, 3, 4, 5]'
    ],
    correctOptionIndex: 0,
    testCases: [
      {
        id: 'tc-1',
        input: '[1, 3, 2, 4, 1, 5, 2]',
        expectedOutput: '[3, 4, 5]',
        explanation: '3 > 1 & 2; 4 > 2 & 1; 5 > 1 & 2.'
      },
      {
        id: 'tc-2',
        input: '[10, 5, 6, 2]',
        expectedOutput: '[10, 6]',
        explanation: '10 > 5 at start; 6 > 5 & 2 in middle.'
      },
      {
        id: 'tc-3',
        input: '[7]',
        expectedOutput: '[7]',
        explanation: 'Single element is a peak.'
      }
    ],
    explanation: `OPPE Python Implementation:
\`\`\`python
def find_peak_elements(lst):
    if not lst:
        return []
    if len(lst) == 1:
        return [lst[0]]
    
    peaks = []
    n = len(lst)
    for i in range(n):
        if i == 0 and lst[0] > lst[1]:
            peaks.append(lst[0])
        elif i == n - 1 and lst[n - 1] > lst[n - 2]:
            peaks.append(lst[n - 1])
        elif 0 < i < n - 1 and lst[i] > lst[i - 1] and lst[i] > lst[i + 1]:
            peaks.append(lst[i])
    return peaks
\`\`\`
Complexity: Time $O(n)$, Space $O(k)$ where $k$ is count of peak elements.`,
    hints: ['Handle edge cases: length 0, length 1, first element, last element.'],
    difficulty: 'Medium',
    marks: 5,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Jan 2025 (OPPE 1)',
    tags: ['Python', 'OPPE', 'Arrays', 'Algorithms'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-oppe-pdsa-01',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms (PDSA)',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Programming, Data Structures & Algorithms (PDSA)',
    type: 'OPPE_CODE',
    questionText: 'Implement a function `two_sum_hash(nums, target)` that returns the 0-based indices of the two numbers in list `nums` such that they add up to `target`. You may assume that each test case has exactly one valid solution, and you cannot use the same element twice. The algorithm must run in $O(n)$ time using a hash map (dictionary).',
    starterCode: `def two_sum_hash(nums, target):
    # Implement O(n) Hash Map solution
    lookup = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in lookup:
            return [lookup[complement], i]
        lookup[num] = i
    return []

# Test run:
print(two_sum_hash([2, 7, 11, 15], 9))`,
    options: [
      '[0, 1]',
      '[1, 2]',
      '[0, 3]',
      '[2, 3]'
    ],
    correctOptionIndex: 0,
    testCases: [
      {
        id: 'tc-pdsa-1',
        input: 'nums = [2, 7, 11, 15], target = 9',
        expectedOutput: '[0, 1]',
        explanation: 'nums[0] + nums[1] = 2 + 7 = 9'
      },
      {
        id: 'tc-pdsa-2',
        input: 'nums = [3, 2, 4], target = 6',
        expectedOutput: '[1, 2]',
        explanation: 'nums[1] + nums[2] = 2 + 4 = 6'
      }
    ],
    explanation: `Hash Map Two-Sum Approach:
\`\`\`python
def two_sum_hash(nums, target):
    seen = {}
    for idx, val in enumerate(nums):
        comp = target - val
        if comp in seen:
            return [seen[comp], idx]
        seen[val] = idx
    return []
\`\`\`
- Time Complexity: $O(n)$ single pass.
- Space Complexity: $O(n)$ dictionary memory.`,
    hints: ['Store each number and its index in a hash map as you iterate.', 'Check if \`target - num\` already exists in the map.'],
    difficulty: 'Medium',
    marks: 5,
    negativeMarks: 0,
    term: 'Term 4',
    pyqYear: 'Sept 2024 (OPPE 2)',
    tags: ['PDSA', 'OPPE', 'Hash Map', 'Two Sum'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  ...FOUNDATION_MATH_QUESTIONS,
  ...FOUNDATION_STATS_CT_PY_QUESTIONS,
  ...DIPLOMA_QUESTIONS,
  ...DEGREE_BS_QUESTIONS
];

export const FULL_CBT_MOCK_TESTS: MockTest[] = [
  // ==========================================
  // FOUNDATION LEVEL MOCK TESTS (QUIZ 1, QUIZ 2, END TERM, OPPE)
  // ==========================================
  {
    id: 'cbt-foundation-qualifier-2025',
    title: 'Foundation Level: Qualifier Full Blueprint CBT Mock (Jan 2025)',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Maths 1, Stats 1, Computational Thinking, English 1',
    courseId: 'course-math-1',
    type: 'Qualifier Mock',
    examType: 'Quiz 1',
    academicTerm: 'Jan 2025',
    termYear: 'Jan 2025',
    durationMinutes: 90,
    totalMarks: 100,
    passingMarks: 40,
    totalQuestions: 6,
    difficulty: 'Exam Standard',
    instructions: [
      'Official IIT Madras Qualifier Exam blueprint covering Maths 1, Stats 1, CT, and English 1.',
      'Sections include MCQ (Single Option), MSQ (Multiple Select with partial marking), and NAT (Numerical Answer).',
      'For NAT questions, enter numeric values precisely up to specified decimal points.',
      'Scientific calculator is accessible via the top calculator tool button.',
      'Negative marks of -0.5 apply to MCQs. No negative marking for MSQ and NAT.'
    ],
    questionIds: ['pyq-m1-01', 'pyq-m1-02', 'pyq-s1-01', 'pyq-ct-01', 'pyq-py-01', 'pyq-eng-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cbt-foundation-math-stats-q2',
    title: 'Foundation Level: Mathematics & Statistics Quiz 2 Advanced Mock',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Maths 1 & 2, Stats 1 & 2',
    courseId: 'course-math-2',
    type: 'Quiz 2',
    examType: 'Quiz 2',
    academicTerm: 'Sept 2024',
    termYear: 'Sept 2024',
    durationMinutes: 60,
    totalMarks: 50,
    passingMarks: 20,
    totalQuestions: 5,
    difficulty: 'Challenging',
    instructions: [
      'Specialized computational assessment on Calculus, Multivariable Gradients, Eigenvalues, and Hypothesis Testing.',
      'Scientific virtual calculator is enabled for matrix and statistical computations.'
    ],
    questionIds: ['pyq-m1-01', 'pyq-m1-02', 'pyq-m2-01', 'pyq-s1-01', 'pyq-s2-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cbt-foundation-oppe-python',
    title: 'Foundation Level: Python OPPE 1 Proctored Coding Simulation',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Introduction to Python Programming',
    courseId: 'course-python',
    type: 'OPPE 1',
    examType: 'OPPE 1',
    academicTerm: 'Jan 2025',
    termYear: 'Jan 2025',
    isOppe: true,
    durationMinutes: 60,
    totalMarks: 50,
    passingMarks: 20,
    totalQuestions: 2,
    difficulty: 'Exam Standard',
    instructions: [
      'Online Proctored Programming Exam (OPPE 1) simulation with real-time test case runner.',
      'Write pure Python functions without external non-standard imports.',
      'Click "Run Test Cases" to validate sample inputs before final test submission.'
    ],
    questionIds: ['pyq-oppe-py-01', 'pyq-py-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN PROGRAMMING MOCK TESTS
  // ==========================================
  {
    id: 'cbt-dip-prog-endterm-2024',
    title: 'Diploma in Programming: Java, DBMS, PDSA & Web End Term CBT',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Java, DBMS, PDSA, App Dev 1, System Commands',
    courseId: 'course-pdsa',
    type: 'End Term',
    examType: 'End Term',
    academicTerm: 'May 2024',
    termYear: 'May 2024',
    durationMinutes: 90,
    totalMarks: 100,
    passingMarks: 40,
    totalQuestions: 5,
    difficulty: 'Exam Standard',
    instructions: [
      'Comprehensive assessment across Diploma in Programming core curriculum.',
      'Covers Java dynamic dispatch, Relational schema normal forms, Quickselect complexity, Flask models, and Unix Bash pipelines.',
      'Review question derivations upon submission.'
    ],
    questionIds: ['pyq-java-01', 'pyq-dbms-01', 'pyq-pdsa-01', 'pyq-appdev1-01', 'pyq-syscmd-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cbt-dip-oppe-pdsa-2024',
    title: 'Diploma in Programming: PDSA OPPE 2 Data Structures Coding Exam',
    level: 'Diploma',
    subLevel: 'Diploma in Programming',
    subject: 'Programming, Data Structures & Algorithms (PDSA)',
    courseId: 'course-pdsa',
    type: 'OPPE 2',
    examType: 'OPPE 2',
    academicTerm: 'Sept 2024',
    termYear: 'Sept 2024',
    isOppe: true,
    durationMinutes: 75,
    totalMarks: 60,
    passingMarks: 24,
    totalQuestions: 2,
    difficulty: 'Challenging',
    instructions: [
      'Proctored algorithmic exam testing Hash Maps, Graph Search, and Tree traversals in Python.',
      'Time complexity constraints must be satisfied.'
    ],
    questionIds: ['pyq-oppe-pdsa-01', 'pyq-pdsa-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // DIPLOMA IN DATA SCIENCE MOCK TESTS
  // ==========================================
  {
    id: 'cbt-dip-ds-core-q1-2024',
    title: 'Diploma in Data Science: MLF & MLP Core In-Term Quiz 1',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    subject: 'ML Foundations, ML Practice, Business Data Management',
    courseId: 'course-mlf-mlt',
    type: 'Quiz 1',
    examType: 'Quiz 1',
    academicTerm: 'Jan 2024',
    termYear: 'Jan 2024',
    durationMinutes: 60,
    totalMarks: 50,
    passingMarks: 20,
    totalQuestions: 4,
    difficulty: 'Challenging',
    instructions: [
      'Tests L1/L2 regularization derivations, Confusion matrix F1 scores, and Data warehouse schemas.',
      'Partial marking is calculated on MSQ questions.'
    ],
    questionIds: ['pyq-mlf-01', 'pyq-mlp-01', 'pyq-bdm-01', 'pyq-ba-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // BSc DEGREE LEVEL (TERMS 6, 7, 8) MOCK TESTS
  // ==========================================
  {
    id: 'cbt-degree-comprehensive-2025',
    title: 'BSc Degree Level: Deep Learning, AI Search & Systems End-Term CBT',
    level: 'Degree',
    subLevel: 'BSc Degree Level',
    subject: 'Deep Learning, AI Search, Speech/NLP, Software Testing',
    courseId: 'course-dl',
    type: 'End Term',
    examType: 'End Term',
    academicTerm: 'Jan 2025',
    termYear: 'Jan 2025',
    durationMinutes: 90,
    totalMarks: 100,
    passingMarks: 40,
    totalQuestions: 4,
    difficulty: 'Comprehensive',
    instructions: [
      'Advanced BSc Degree examination covering CNN parameter math, A* heuristic admissibility proofs, Transformer attention scaling, and Cyclomatic testing complexity.',
      'All equations typeset with KaTeX; step-by-step verified proofs available post-submission.'
    ],
    questionIds: ['pyq-dl-01', 'pyq-ai-01', 'pyq-nlp-01', 'pyq-se-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // BS DEGREE LEVEL (TERMS 9, 10, 11, 12 / 4TH YEAR TRACK) MOCK TESTS
  // ==========================================
  {
    id: 'cbt-bs-genai-rl-2025',
    title: 'BS Degree: Generative AI & Reinforcement Learning Term 9 CBT Exam',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Deep Learning & Advanced Generative AI, AI Search & RL',
    courseId: 'course-bs-genai',
    type: 'Quiz 1',
    examType: 'Quiz 1',
    academicTerm: 'May 2025',
    termYear: 'May 2025',
    durationMinutes: 75,
    totalMarks: 100,
    passingMarks: 40,
    totalQuestions: 3,
    difficulty: 'Challenging',
    instructions: [
      '4th-Year BS Degree honors examination covering Diffusion stochastic calculus, Bellman optimality, and Rotary Position Embeddings (RoPE).',
      'KaTeX equations rendered inline with automated NAT tolerance checks.'
    ],
    questionIds: ['pyq-bs-genai-01', 'pyq-bs-rl-01', 'pyq-bs-nlp-speech-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cbt-bs-cloud-robotics-2025',
    title: 'BS Degree: Cloud Distributed DS & Autonomous Robotics End-Term CBT',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Big Data Cloud Architecture, Autonomous Robotics AI',
    courseId: 'course-bs-cloud-arch',
    type: 'End Term',
    examType: 'End Term',
    academicTerm: 'Sept 2025',
    termYear: 'Sept 2025',
    durationMinutes: 90,
    totalMarks: 100,
    passingMarks: 40,
    totalQuestions: 3,
    difficulty: 'Comprehensive',
    instructions: [
      'Covers stream processing watermarks, Extended Kalman Filter gain derivations, and Kafka/Flink out-of-order latency controls.',
      'Partial marking rules applied on multi-select statements.'
    ],
    questionIds: ['pyq-bs-cloud-01', 'pyq-bs-robotics-01', 'pyq-bs-capstone-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cbt-bs-capstone-viva-2026',
    title: 'BS Degree: Capstone Research Defense & Industry Viva Qualifying CBT',
    level: 'BS Degree',
    subLevel: 'BS Degree Level',
    subject: 'Capstone Research Project & Industry Internship Prep / Mock Viva',
    courseId: 'course-bs-capstone-viva',
    type: 'End Term',
    examType: 'End Term',
    academicTerm: 'Jan 2026',
    termYear: 'Jan 2026',
    durationMinutes: 90,
    totalMarks: 100,
    passingMarks: 50,
    totalQuestions: 4,
    difficulty: 'Challenging',
    instructions: [
      'Comprehensive 4th-Year BS Capstone Defense simulator covering statistical power, ablation protocol design, DDPM diffusion proofs, and EKF state estimation.',
      'Includes detailed examiner feedback rubrics and academic citations upon submission.'
    ],
    questionIds: ['pyq-bs-capstone-01', 'pyq-bs-genai-01', 'pyq-bs-rl-01', 'pyq-bs-robotics-01'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

import { WeeklyStudyMaterial } from '../types';

export const DIPLOMA_MLP_NOTES: WeeklyStudyMaterial[] = [
  {
    id: 'note-mlp-w1',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 1,
    title: 'Data Preprocessing, Imputation, One-Hot Encoding, Scikit-Learn Pipelines & Feature Scaling',
    detailedNotes: `### Week 1: Production Data Preprocessing & Scikit-Learn Pipelines

#### 1. Handling Missing Data (Missingness Mechanisms)
1. **MCAR (Missing Completely at Random):** Missingness is independent of both observed and unobserved data.
2. **MAR (Missing at Random):** Missingness depends on observed data but not on the missing value itself.
3. **MNAR (Missing Not at Random):** Missingness depends on the unobserved value itself (e.g. high-income respondents withholding salary data).

**Imputation Strategies:**
- **SimpleImputer:** Mean/Median for numerical features; Mode/Constant for categorical features.
- **KNNImputer:** Distance-weighted average of the $k$-nearest neighbors in feature space:
  $$\\hat{x}_{ij} = \\frac{\\sum_{m \\in N_k(i)} w_{im} x_{mj}}{\\sum_{m \\in N_k(i)} w_{im}}, \\quad w_{im} = \\frac{1}{d(x_i, x_m)}$$
- **IterativeImputer (MICE):** Models each feature with missing values as a function of other features.

#### 2. Feature Scaling & Categorical Encoding
- **StandardScaler (Z-Score Normalization):**
  $$z = \\frac{x - \\mu}{\\sigma} \\quad (\\mu=0, \\sigma^2=1)$$
- **MinMaxScaler:**
  $$x_{\\text{scaled}} = \\frac{x - x_{\\min}}{x_{\\max} - x_{\\min}} \\in [0, 1]$$
- **RobustScaler:** Uses median and interquartile range (IQR), resistant to outliers:
  $$x_{\\text{robust}} = \\frac{x - Q_2}{Q_3 - Q_1}$$
- **OneHotEncoder:** Encodes categorical levels into binary columns. Set \`drop='first'\` for linear models to prevent multicollinearity (dummy variable trap).

#### 3. Fully Solved Step-by-Step Code & Numerical Examples

**Example 1 (Data Leakage Prevention):**
*Problem:* Why must \`scaler.fit_transform(X_train)\` and \`scaler.transform(X_test)\` be used instead of fitting on the entire dataset?
*Solution:*
1. Fitting on the entire dataset incorporates mean $\\mu$ and variance $\\sigma$ from the test partition into training transformations (Data Leakage).
2. Data leakage artificially inflates validation metrics and causes model degradation in live deployment.
3. Rule: \`fit()\` only on training set; \`transform()\` on validation/test sets!`,
    quickRevisionNotes: [
      'Always fit scalers and imputers ONLY on the training split to prevent data leakage.',
      'RobustScaler uses median and IQR, making it immune to extreme outlier distortions.',
      'Use ColumnTransformer to apply distinct transformations to numerical and categorical features.'
    ],
    formulaSheets: [
      {
        name: 'Z-Score Standardization',
        formula: 'z = \\frac{x - \\mu}{\\sigma}',
        description: 'Standardization transforming feature distribution to zero mean and unit variance.'
      },
      {
        name: 'RobustScaler Formula',
        formula: 'x_{\\text{scaled}} = \\frac{x - Q_2(x)}{Q_3(x) - Q_1(x)}',
        description: 'Robust scaling based on median (Q2) and Interquartile Range (IQR = Q3 - Q1).'
      }
    ],
    definitions: [
      {
        term: 'Data Leakage',
        explanation: 'The inadvertent use of information from outside the training dataset to train a machine learning model, producing overoptimistic validation scores.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Full Preprocessing Pipeline with ColumnTransformer',
        code: `import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression

num_features = ['age', 'income', 'credit_score']
cat_features = ['education', 'occupation']

num_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

cat_pipeline = Pipeline([
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('encoder', OneHotEncoder(drop='first', handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(transformers=[
    ('num', num_pipeline, num_features),
    ('cat', cat_pipeline, cat_features)
])

full_model = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', LogisticRegression(max_iter=1000))
])`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w1-q1',
        questionText: 'When preprocessing a numerical column containing extreme outliers (e.g. annual customer incomes), which scaler is most resilient to outlier distortion?',
        options: ['RobustScaler', 'StandardScaler', 'MinMaxScaler', 'MaxAbsScaler'],
        correctOptionIndex: 0,
        solution: 'RobustScaler centers data by subtracting the median and scales by the Interquartile Range (IQR = Q3 - Q1), making it robust to extreme outliers that skew mean and standard deviation.',
        hints: ['Uses median and IQR rather than mean and variance.']
      }
    ],
    examTips: [
      'In Scikit-learn OPPEs, never fit a scaler or imputer before `train_test_split()`; always use Pipeline to wrap estimators.',
      'When using `OneHotEncoder(handle_unknown="ignore")`, `drop="first"` cannot be used simultaneously in standard scikit-learn versions.'
    ],
    handwrittenMnemonic: 'Fit on Train ONLY; Transform both Train & Test; RobustScaler uses Median & IQR!'
  },
  {
    id: 'note-mlp-w2',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 2,
    title: 'Linear & Logistic Regression, Regularization (L1 Lasso, L2 Ridge, ElasticNet) & SGD',
    detailedNotes: `### Week 2: Generalized Linear Models & Penalized Regression

#### 1. Linear Regression with Regularization
Given design matrix $X \\in \\mathbb{R}^{n \\times d}$ and labels $y \\in \\mathbb{R}^n$:
- **Ordinary Least Squares (OLS):**
  $$\\min_w \\frac{1}{2n} \\|y - Xw\\|_2^2 \\implies w^* = (X^T X)^{-1} X^T y$$
- **Ridge Regression ($L_2$ Penalty - Tikhonov):**
  $$\\min_w \\frac{1}{2n} \\|y - Xw\\|_2^2 + \\frac{\\alpha}{2} \\|w\\|_2^2 \\implies w^* = (X^T X + \\alpha I)^{-1} X^T y$$
  - Solves multicollinearity (makes $X^T X + \\alpha I$ strictly invertible) and shrinks weights smoothly.
- **Lasso Regression ($L_1$ Penalty - Sparse Weights):**
  $$\\min_w \\frac{1}{2n} \\|y - Xw\\|_2^2 + \\alpha \\|w\\|_1$$
  - Produces exact zero coefficients due to diamond-shaped $L_1$ constraint contours hitting coordinate axes (**Feature Selection**).
- **ElasticNet:** Convex combination of $L_1$ and $L_2$:
  $$\\min_w \\frac{1}{2n} \\|y - Xw\\|_2^2 + \\alpha \\rho \\|w\\|_1 + \\frac{\\alpha(1 - \\rho)}{2} \\|w\\|_2^2$$

#### 2. Logistic Regression & Binary Cross-Entropy
- **Sigmoid Function:**
  $$\\sigma(z) = \\frac{1}{1 + e^{-z}} = P(y = 1 \\mid x)$$
- **Log-Loss Objective:**
  $$\\mathcal{L}(w) = -\\frac{1}{n} \\sum_{i=1}^n \\left[ y_i \\ln(\\sigma(w^T x_i)) + (1 - y_i) \\ln(1 - \\sigma(w^T x_i)) \\right]$$`,
    quickRevisionNotes: [
      'Ridge (L2) shrinks coefficients continuously; Lasso (L1) creates sparse feature selection.',
      'ElasticNet combines L1 and L2 penalties via the l1_ratio parameter rho.',
      'Logistic regression outputs probabilities via the sigmoid function and optimizes Log-Loss.'
    ],
    formulaSheets: [
      {
        name: 'Ridge Closed-Form Solution',
        formula: 'w^* = (X^T X + \\alpha I)^{-1} X^T y',
        description: 'Analytical solution for L2 regularized linear regression.'
      },
      {
        name: 'ElasticNet Regularization Objective',
        formula: '\\min_w \\frac{1}{2n} \\|y - Xw\\|_2^2 + \\alpha \\left( \\rho \\|w\\|_1 + \\frac{1-\\rho}{2} \\|w\\|_2^2 \\right)',
        description: 'Hybrid L1/L2 regularized loss formulation.'
      }
    ],
    definitions: [
      {
        term: 'Multicollinearity',
        explanation: 'A statistical phenomenon where two or more predictor variables in a multiple regression model are highly linearly correlated, inflating coefficient standard errors.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Ridge and Lasso Regularization with Cross-Validation in Scikit-Learn',
        code: `from sklearn.linear_model import RidgeCV, LassoCV, ElasticNetCV
import numpy as np

# Logarithmically spaced alphas
alphas = np.logspace(-3, 3, 50)

# 5-fold cross-validated Ridge
ridge_cv = RidgeCV(alphas=alphas, cv=5, scoring='neg_mean_squared_error')
ridge_cv.fit(X_train, y_train)
print(f"Optimal Ridge alpha: {ridge_cv.alpha_:.4f}")

# 5-fold cross-validated Lasso (enforces sparsity)
lasso_cv = LassoCV(alphas=alphas, cv=5, random_state=42)
lasso_cv.fit(X_train, y_train)
print(f"Optimal Lasso alpha: {lasso_cv.alpha_:.4f}")
print(f"Zeroed features: {np.sum(lasso_cv.coef_ == 0)} / {len(lasso_cv.coef_)}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w2-q1',
        questionText: 'Why does L1 regularization (Lasso) drive model coefficients to exact zeroes while L2 regularization (Ridge) only shrinks them close to zero?',
        options: ['The L1 norm has sharp geometric corners aligned with coordinate axes where the elliptical loss contours frequently intersect', 'Ridge uses imaginary numbers', 'Lasso is solved with decision trees', 'L2 norm has sharp corners'],
        correctOptionIndex: 0,
        solution: 'The L1 diamond-shaped constraint region has sharp vertices on the coordinate axes. The circular/elliptical loss contours touch these vertices first, driving coordinates to exact zero.',
        hints: ['Think of the geometric shape of L1 (diamond) vs L2 (sphere).']
      }
    ],
    examTips: [
      'In Scikit-learn LogisticRegression, parameter `C` is inverse regularization strength: smaller `C` means STRONGER regularization!',
      'Always scale features before fitting Ridge/Lasso, otherwise features with large numerical magnitudes will be penalized unfairly.'
    ],
    handwrittenMnemonic: 'L1 = Lasso = Lines = Zero weights; L2 = Ridge = Rings = Small weights; C is 1/alpha!'
  },
  {
    id: 'note-mlp-w3',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 3,
    title: 'Model Evaluation, Cross-Validation Strategies, ROC-AUC, PR Curves & Threshold Tuning',
    detailedNotes: `### Week 3: Model Evaluation, Validation Protocols & Imbalanced Metrics

#### 1. Cross-Validation Protocols
- **K-Fold CV:** Partitions dataset into $K$ equal subsets; trains on $K-1$, validates on $1$.
- **Stratified K-Fold CV:** Crucial for classification! Preserves the identical class percentage ratio across all $K$ validation folds.
- **Time-Series Split (Rolling Origin):** Never shuffle time-series data! Train on $[t_1, t_k]$, test on $t_{k+1}$.

#### 2. Classification Metrics for Imbalanced Datasets
- **Confusion Matrix:** True Positives ($TP$), False Positives ($FP$), True Negatives ($TN$), False Negatives ($FN$).
- **Precision:** $P = \\frac{TP}{TP + FP}$ (Quality of positive predictions).
- **Recall (Sensitivity / True Positive Rate):** $R = \\frac{TP}{TP + FN}$ (Completeness of detection).
- **$F_1$-Score & $F_\\beta$-Score:**
  $$F_\\beta = (1 + \\beta^2) \\frac{P \\cdot R}{\\beta^2 P + R}$$
  - $\\beta = 2$: Weights Recall twice as heavily as Precision (medical diagnosis, fraud detection).
  - $\\beta = 0.5$: Weights Precision twice as heavily as Recall (spam filters).

#### 3. ROC-AUC vs. Precision-Recall AUC (PR-AUC)
- **ROC Curve:** Plots $TPR = \\frac{TP}{TP+FN}$ vs $FPR = \\frac{FP}{FP+TN}$. Invariant to class distribution; can be misleadingly high on extreme class imbalance ($99.9\\%$ negative).
- **PR Curve:** Plots Precision vs Recall. Much more sensitive and rigorous for severe class imbalance!`,
    quickRevisionNotes: [
      'Stratified K-Fold CV preserves class proportions across all training folds.',
      'Precision = TP / (TP + FP); Recall = TP / (TP + FN).',
      'F2-score prioritizes recall (catching all positives); F0.5-score prioritizes precision.',
      'Use PR-AUC instead of ROC-AUC when evaluating severely imbalanced datasets.'
    ],
    formulaSheets: [
      {
        name: 'F-Beta Metric Formula',
        formula: 'F_\\beta = (1 + \\beta^2) \\frac{\\text{Precision} \\times \\text{Recall}}{\\beta^2 \\text{Precision} + \\text{Recall}}',
        description: 'Generalized harmonic mean balancing precision and recall with weight parameter beta.'
      },
      {
        name: 'False Positive Rate (FPR)',
        formula: '\\text{FPR} = \\frac{FP}{FP + TN} = 1 - \\text{Specificity}',
        description: 'X-axis coordinate of standard ROC curve.'
      }
    ],
    definitions: [
      {
        term: 'Stratified K-Fold',
        explanation: 'A cross-validation variation that ensures each fold contains approximately the same percentage of samples of each target class as the complete dataset.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Precision-Recall Curve and Optimal Threshold Tuning for Imbalanced Data',
        code: `import numpy as np
from sklearn.metrics import precision_recall_curve, f1_score
from sklearn.model_selection import StratifiedKFold

# Generate probabilities from trained classifier
y_probs = model.predict_proba(X_val)[:, 1]

precisions, recalls, thresholds = precision_recall_curve(y_val, y_probs)

# Find threshold that maximizes F1-Score
f1_scores = 2 * (precisions * recalls) / (precisions + recalls + 1e-10)
best_idx = np.argmax(f1_scores)
best_threshold = thresholds[best_idx]
best_f1 = f1_scores[best_idx]

print(f"Optimal Decision Threshold: {best_threshold:.4f}")
print(f"Max Validation F1-Score: {best_f1:.4f}")

# Convert continuous probabilities to discrete predictions using optimal threshold
y_pred_tuned = (y_probs >= best_threshold).astype(int)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w3-q1',
        questionText: 'In a cancer detection model where failing to diagnose a positive patient (False Negative) is catastrophic, which metric should be prioritized during threshold optimization?',
        options: ['Recall (Sensitivity)', 'Precision', 'Specificity', 'Accuracy'],
        correctOptionIndex: 0,
        solution: 'Recall measures TP / (TP + FN). Maximizing recall minimizes False Negatives, ensuring all positive cancer cases are detected.',
        hints: ['Minimize False Negatives -> Maximize Recall.']
      }
    ],
    examTips: [
      'Accuracy is a misleading metric for imbalanced data (predicting 100% negative gives 99% accuracy on 1% positive dataset).',
      'Always use `StratifiedKFold(shuffle=True, random_state=42)` rather than standard `KFold` for classification.'
    ],
    handwrittenMnemonic: 'Recall catches all Positives; Precision trusts Positives; PR-AUC for imbalanced data!'
  },
  {
    id: 'note-mlp-w4',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 4,
    title: 'Decision Trees: CART Algorithm, Splitting Criteria (Gini, Entropy, MSE) & Cost-Complexity Pruning',
    detailedNotes: `### Week 4: Decision Trees & Cost-Complexity Pruning

#### 1. Splitting Criteria for Classification
- **Gini Impurity (CART Default):**
  $$G(t) = 1 - \\sum_{k=1}^K p_k^2 \\quad (G \\in [0, 0.5] \\text{ for binary})$$
- **Entropy (Information Gain - ID3 / C4.5):**
  $$H(t) = -\\sum_{k=1}^K p_k \\log_2(p_k) \\quad (H \\in [0, 1] \\text{ for binary})$$
- **Information Gain:**
  $$\\Delta I = I(\\text{Parent}) - \\sum_{c \\in \\{\\text{Left, Right}\\}} \\frac{N_c}{N_{\\text{Parent}}} I(c)$$

#### 2. Regression Trees (MSE Splitting)
Minimizes total squared error in child partitions:
$$\\text{MSE}(t) = \\frac{1}{N_t} \\sum_{i \\in t} (y_i - \\bar{y}_t)^2$$
- Node prediction $\\bar{y}_t$ is the arithmetic mean of all sample values falling into node $t$.

#### 3. Minimal Cost-Complexity Pruning ($\\alpha$-Pruning)
Prevents overfitting by penalizing tree size (number of leaf nodes $|T|$):
$$R_\\alpha(T) = R(T) + \\alpha |T|$$
- **Cost-Complexity Parameter $\\alpha \\ge 0$:**
  - $\\alpha = 0$: Full unpruned tree.
  - Large $\\alpha$: Heavily pruned tree (approaches root node).
- Selected via cross-validation using \`ccp_alpha\` in Scikit-Learn!`,
    quickRevisionNotes: [
      'Gini impurity $1 - \\sum p_k^2$ is computationally faster than entropy as it avoids logarithms.',
      'Regression trees split by minimizing variance (MSE) and predict the mean of leaf samples.',
      'Cost-complexity pruning parameter ccp_alpha penalizes tree complexity R(T) + alpha*|T|.'
    ],
    formulaSheets: [
      {
        name: 'Gini Impurity Formula',
        formula: 'Gini(t) = 1 - \\sum_{k=1}^K p_k^2',
        description: 'Impurity index used by CART decision trees.'
      },
      {
        name: 'Cost-Complexity Pruned Objective',
        formula: 'R_\\alpha(T) = R(T) + \\alpha |T|',
        description: 'Tree cost function penalizing total leaf node count.'
      }
    ],
    definitions: [
      {
        term: 'Cost-Complexity Pruning',
        explanation: 'A post-pruning technique that trims subtrees from a fully grown decision tree to minimize an objective function balancing training error and tree size.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Post-Pruning Decision Tree via Cost-Complexity Path (ccp_alpha)',
        code: `import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score

# Step 1: Extract effective alphas from fully grown tree
clf = DecisionTreeClassifier(random_state=42)
path = clf.cost_complexity_pruning_path(X_train, y_train)
ccp_alphas = path.ccp_alphas[:-1] # Exclude maximum alpha that leaves only root

# Train tree for each alpha and pick best on validation set
clfs = [DecisionTreeClassifier(random_state=42, ccp_alpha=alpha).fit(X_train, y_train) for alpha in ccp_alphas]
scores = [clf.score(X_val, y_val) for clf in clfs]

best_alpha = ccp_alphas[np.argmax(scores)]
print(f"Optimal ccp_alpha: {best_alpha:.5f}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w4-q1',
        questionText: 'What is the Gini Impurity of a node containing 50 positive samples and 50 negative samples?',
        options: ['0.5', '1.0', '0.0', '0.25'],
        correctOptionIndex: 0,
        solution: 'p1 = 0.5, p2 = 0.5. Gini = 1 - (0.5^2 + 0.5^2) = 1 - (0.25 + 0.25) = 1 - 0.5 = 0.5.',
        hints: ['Gini = 1 - (p1^2 + p2^2).']
      }
    ],
    examTips: [
      'Decision Trees do NOT require feature scaling; monotonicity of threshold splits is invariant to monotonic transformations!',
      'Decision trees have high variance and are prone to overfitting without depth constraints or pruning.'
    ],
    handwrittenMnemonic: 'Gini needs no logs; Tree splits are invariant to scaling!'
  },
  {
    id: 'note-mlp-w5',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 5,
    title: 'Ensemble Learning: Bootstrap Aggregation (Bagging), Random Forests & Out-of-Bag (OOB) Evaluation',
    detailedNotes: `### Week 5: Bagging, Random Forests & Feature Subspace Sampling

#### 1. Bootstrap Aggregation (Bagging) Theory
Given dataset $\\mathcal{D}$ of $n$ samples:
- Generate $B$ bootstrap datasets $\\mathcal{D}_1, \\dots, \\mathcal{D}_B$ by sampling $n$ instances **with replacement**.
- Train an unpruned, high-variance base learner $h_b(x)$ on each bootstrap sample.
- **Ensemble Prediction:** $\\hat{y}(x) = \\frac{1}{B} \\sum_{b=1}^B h_b(x)$ (Regression) or Majority Vote (Classification).
- **Variance Reduction:** If $B$ independent models each have variance $\\sigma^2$, the ensemble average has variance $\\frac{\\sigma^2}{B}$.

#### 2. Out-of-Bag (OOB) Error Estimation
The probability that a specific sample is NOT selected in a bootstrap sample of size $n$:
$$P(\\text{Not picked in } n \\text{ draws}) = \\left(1 - \\frac{1}{n}\\right)^n \\xrightarrow{n \\to \\infty} \\frac{1}{e} \\approx 0.368 \\quad (36.8\\%)$$
- ~63.2% unique samples appear in training; the remaining **36.8% OOB samples** serve as an intrinsic built-in validation test set without requiring separate cross-validation!

#### 3. Random Forests (Breiman Algorithm)
Random Forests introduce **Random Feature Subspace Sampling** at every split node to **decorrelate trees**:
- At each node, select a random subset of $m$ features out of $d$ total features ($m = \\sqrt{d}$ for classification, $m = d/3$ for regression).`,
    quickRevisionNotes: [
      'Bagging reduces Variance without increasing Bias by averaging decorrelated base estimators.',
      'Each bootstrap sample contains ~63.2% unique original samples; 36.8% are Out-of-Bag (OOB).',
      'Random Forests select a random subset of sqrt(d) features at every split to decorrelate individual trees.'
    ],
    formulaSheets: [
      {
        name: 'OOB Probability Limit',
        formula: '\\lim_{n \\to \\infty} \\left(1 - \\frac{1}{n}\\right)^n = \\frac{1}{e} \\approx 0.3679',
        description: 'Fraction of data points excluded from any single bootstrap sample.'
      },
      {
        name: 'Tree Decorrelation Variance Formula',
        formula: '\\text{Var}(\\bar{T}) = \\rho \\sigma^2 + \\frac{1 - \\rho}{B} \\sigma^2',
        description: 'Variance of ensemble of B trees with pairwise correlation rho.'
      }
    ],
    definitions: [
      {
        term: 'Feature Subspace Sampling',
        explanation: 'Random selection of a subset of features at each node split to prevent dominant features from creating correlated trees.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Random Forest with OOB Score and Feature Importances',
        code: `from sklearn.ensemble import RandomForestClassifier
import pandas as pd

rf = RandomForestClassifier(
    n_estimators=300,
    max_features='sqrt',
    oob_score=True,
    n_jobs=-1,
    random_state=42
)
rf.fit(X_train, y_train)

print(f"OOB Evaluation Accuracy: {rf.oob_score_:.4f}")

# Extract MDI Feature Importances
importances = pd.Series(rf.feature_importances_, index=feature_names).sort_values(ascending=False)
print("Top 5 Important Features:")
print(importances.head(5))`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w5-q1',
        questionText: 'Approximately what percentage of the training data is included in a standard bootstrap sample as n approaches infinity?',
        options: ['63.2%', '36.8%', '50.0%', '80.0%'],
        correctOptionIndex: 0,
        solution: 'Since 1/e ~ 36.8% is left out (OOB), the fraction included is 1 - 1/e ~ 63.2%.',
        hints: ['1 - (1/e) = 1 - 0.368.']
      }
    ],
    examTips: [
      'Setting `oob_score=True` provides an unbiased validation score without spending extra time on K-Fold CV.',
      'Random Forests cannot extrapolate beyond the minimum and maximum target values seen during training in regression tasks!'
    ],
    handwrittenMnemonic: '63.2% trained, 36.8% OOB validated; Sqrt(d) features decorrelate trees!'
  },
  {
    id: 'note-mlp-w6',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 6,
    title: 'Gradient Boosting: AdaBoost, GBDT, XGBoost, LightGBM & CatBoost Architecture',
    detailedNotes: `### Week 6: Boosting Algorithms & Scalable Gradient Boosted Decision Trees

#### 1. Boosting Paradigm (Sequential Error Correction)
Unlike Bagging (independent parallel trees), Boosting trains weak base learners **sequentially**, with each new learner focusing on instances misclassified or poorly predicted by previous iterations.

#### 2. Gradient Boosted Decision Trees (GBDT)
GBDT treats boosting as gradient descent in function space.
At step $m$, fit base tree $h_m(x)$ to the **pseudo-residuals (negative gradient of loss)**:
$$r_{im} = -\\left[ \\frac{\\partial \\mathcal{L}(y_i, F(x_i))}{\\partial F(x_i)} \\right]_{F(x) = F_{m-1}(x)}$$
- For MSE Loss: $r_{im} = y_i - F_{m-1}(x_i)$ (Exact Residuals!).
- **Model Update with Learning Rate $\\eta$ (Shrinkage):**
  $$F_m(x) = F_{m-1}(x) + \\eta \\cdot h_m(x) \\quad (\\eta \\in (0, 1])$$

#### 3. Modern Boosting Implementations Comparison
- **XGBoost (Extreme Gradient Boosting):** Exact 2nd-order Taylor expansion (uses Hessian $h_i$ + Gradient $g_i$), explicit tree regularization ($\\gamma, \\lambda$), cache-aware block structure, weighted quantile sketch.
- **LightGBM (Microsoft):** **GOSS (Gradient-based One-Side Sampling)** retains large-gradient samples and subsamples small-gradient ones; **EFB (Exclusive Feature Bundling)** merges mutually exclusive sparse features; **Leaf-wise tree growth**.
- **CatBoost (Yandex):** **Ordered Target Encoding** eliminates target leakage on high-cardinality categoricals; Symmetric (Oblivious) Trees.`,
    quickRevisionNotes: [
      'GBDT fits each new tree to the negative gradient (residuals) of the loss function.',
      'Learning rate (shrinkage) controls how aggressively each tree corrects residuals; lower learning rates require more estimators.',
      'LightGBM uses leaf-wise growth and GOSS; CatBoost excels natively on categorical features without one-hot encoding.'
    ],
    formulaSheets: [
      {
        name: 'XGBoost 2nd-Order Taylor Loss Approximation',
        formula: '\\tilde{\\mathcal{L}}^{(t)} \\approx \\sum_{i=1}^n \\left[ g_i f_t(x_i) + \\frac{1}{2} h_i f_t^2(x_i) \\right] + \\gamma T + \\frac{1}{2} \\lambda \\sum_{j=1}^T w_j^2',
        description: 'XGBoost objective with 1st gradient g_i, 2nd Hessian h_i, leaf count penalty gamma, and L2 weight shrinkage lambda.'
      }
    ],
    definitions: [
      {
        term: 'Shrinkage (Learning Rate)',
        explanation: 'Regularization technique in boosting that scales the contribution of each tree by factor eta to prevent overfitting.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Training LightGBM with Early Stopping and Validation',
        code: `import lightgbm as lgb

train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

params = {
    'objective': 'binary',
    'metric': 'auc',
    'boosting_type': 'gbdt',
    'learning_rate': 0.05,
    'num_leaves': 31,
    'random_state': 42
}

model = lgb.train(
    params,
    train_data,
    num_boost_round=1000,
    valid_sets=[train_data, val_data],
    callbacks=[lgb.early_stopping(stopping_rounds=50), lgb.log_evaluation(50)]
)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w6-q1',
        questionText: 'What mathematical advantage does XGBoost utilize over standard GBDT during split finding?',
        options: ['Second-order Taylor expansion using both first-order gradients and second-order Hessians', 'Linear programming relaxation', 'Exact integer programming', 'Simulated annealing optimization'],
        correctOptionIndex: 0,
        solution: 'XGBoost uses a second-order Taylor expansion of the objective function, incorporating both first gradients (g) and Hessians (h) to optimize split candidates.',
        hints: ['Think of 2nd derivative information (Hessian).']
      }
    ],
    examTips: [
      'Early stopping with a held-out validation set is the best defense against boosting overfitting.',
      'Unlike Random Forests where increasing trees cannot overfit, Boosting WILL overfit if `n_estimators` is set too high without proper learning rate shrinkage.'
    ],
    handwrittenMnemonic: 'GBDT descends in function space; LightGBM grows leaf-wise!'
  },
  {
    id: 'note-mlp-w7',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 7,
    title: 'Support Vector Machines (SVM): Maximum Margin, Soft-Margin (C), Kernels (RBF, Poly) & SVR',
    detailedNotes: `### Week 7: Maximum Margin Hyperplanes & Kernelized SVMs

#### 1. Hard-Margin vs. Soft-Margin SVM Primal Formulation
Given labeled training data $\\{(x_i, y_i)\\}_{i=1}^n$ with $y_i \\in \\{-1, +1\\}$:
- **Margin Width:** $\\frac{2}{\\|w\\|_2}$. Maximizing margin $\\equiv \\min \\frac{1}{2} \\|w\\|_2^2$.
- **Soft-Margin SVM with Slack Variables ($\\xi_i \\ge 0$):**
  $$\\min_{w, b, \\xi} \\frac{1}{2} \\|w\\|_2^2 + C \\sum_{i=1}^n \\xi_i \\quad \\text{s.t.} \\quad y_i(w^T x_i + b) \\ge 1 - \\xi_i, \\quad \\xi_i \\ge 0$$
- **Role of Parameter $C$ (Regularization Tradeoff):**
  - **Large $C$:** Heavy penalty on margin violations $\\implies$ narrow margin, fits data tightly (high variance, risk of overfitting).
  - **Small $C$:** Tolerates margin violations $\\implies$ wide margin, smoother decision boundary (high bias).

#### 2. Dual Formulation & The Kernel Trick
- **Dual Problem:**
  $$\\max_\\alpha \\sum_{i=1}^n \\alpha_i - \\frac{1}{2} \\sum_{i,j=1}^n \\alpha_i \\alpha_j y_i y_j K(x_i, x_j) \\quad \\text{s.t.} \\quad 0 \\le \\alpha_i \\le C, \\ \\sum \\alpha_i y_i = 0$$
- **Support Vectors:** Points with $\\alpha_i > 0$ that lie directly on or inside the margin boundaries.
- **Popular Kernels $K(x, z) = \\langle \\phi(x), \\phi(z) \\rangle$:**
  - **Linear Kernel:** $K(x, z) = x^T z$
  - **Polynomial Kernel:** $K(x, z) = (\\gamma x^T z + r)^d$
  - **RBF (Gaussian) Kernel (Infinite-Dimensional Hilbert Space!):**
    $$K(x, z) = \\exp\\left( -\\gamma \\|x - z\\|_2^2 \\right) \\quad \\left( \\gamma = \\frac{1}{2\\sigma^2} \\right)$$`,
    quickRevisionNotes: [
      'SVM maximizes the geometric margin 2/||w|| between supporting hyperplanes.',
      'Parameter C controls slack tolerance: Large C = narrow margin (overfit); Small C = wide margin (underfit).',
      'The Kernel Trick computes inner products in high-dimensional feature spaces without explicitly mapping coordinates.',
      'RBF kernel parameter gamma controls influence radius: High gamma creates tight non-linear islands around points.'
    ],
    formulaSheets: [
      {
        name: 'RBF (Gaussian) Kernel',
        formula: 'K(\\mathbf{x}, \\mathbf{z}) = \\exp\\left(-\\gamma \\|\\mathbf{x} - \\mathbf{z}\\|^2\\right)',
        description: 'Radial Basis Function kernel projecting inputs into infinite-dimensional reproducing kernel Hilbert space.'
      }
    ],
    definitions: [
      {
        term: 'Support Vectors',
        explanation: 'The critical subset of training points that lie closest to the decision boundary and directly determine the position and orientation of the optimal separating hyperplane.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Support Vector Classification with RBF Kernel and Grid Search',
        code: `from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV

param_grid = {
    'C': [0.1, 1, 10, 100],
    'gamma': ['scale', 'auto', 0.01, 0.1, 1.0],
    'kernel': ['rbf']
}

grid_svc = GridSearchCV(SVC(probability=True), param_grid, cv=5, scoring='roc_auc', n_jobs=-1)
grid_svc.fit(X_train_scaled, y_train)

print(f"Best Parameters: {grid_svc.best_params_}")
print(f"Number of Support Vectors: {grid_svc.best_estimator_.support_vectors_.shape[0]}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w7-q1',
        questionText: 'What happens to the decision boundary of an SVM with an RBF kernel as the parameter gamma approaches infinity?',
        options: ['The decision boundary creates tight, isolated Gaussian islands around individual training points, resulting in severe overfitting', 'The decision boundary becomes a flat linear hyperplane', 'All support vectors are deleted', 'Training speed increases by 100x'],
        correctOptionIndex: 0,
        solution: 'Gamma is the inverse of the Gaussian variance (1 / 2*sigma^2). High gamma means tiny influence radius, causing the model to overfit heavily around each individual sample.',
        hints: ['High gamma -> tiny influence radius -> overfitting islands.']
      }
    ],
    examTips: [
      'SVMs are sensitive to feature scales; ALWAYS standardize features with `StandardScaler` before training SVC!',
      'For large datasets ($N > 50,000$), standard kernelized SVC with $O(N^2)$ to $O(N^3)$ training complexity is slow; use `LinearSVC` or `SGDClassifier(loss="hinge")` instead.'
    ],
    handwrittenMnemonic: 'Large C = Low tolerance = Overfit; High Gamma = Narrow bell curves = Overfit!'
  },
  {
    id: 'note-mlp-w8',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 8,
    title: 'K-Nearest Neighbors (KNN), Distance Metrics, Curse of Dimensionality & KD-Trees',
    detailedNotes: `### Week 8: Nearest Neighbors & Spatial Indexing

#### 1. K-Nearest Neighbors (Lazy Non-Parametric Learner)
- Stores entire training dataset in memory; does zero training computation (**Lazy Learner**).
- **Classification:** Majority vote among $k$ nearest neighbors:
  $$\\hat{y}(x) = \\arg\\max_{c} \\sum_{i \\in N_k(x)} \\mathbb{I}(y_i = c)$$
- **Regression:** Distance-weighted average:
  $$\\hat{y}(x) = \\frac{\\sum_{i \\in N_k(x)} w_i y_i}{\\sum w_i}, \\quad w_i = \\frac{1}{d(x, x_i)}$$

#### 2. Distance Metrics in $\\mathbb{R}^d$
- **Minkowski Distance ($L_p$ Norm):**
  $$D(x, z) = \\left( \\sum_{j=1}^d |x_j - z_j|^p \\right)^{1/p}$$
  - $p = 1$: Manhattan (City-Block) Distance ($L_1$).
  - $p = 2$: Euclidean Distance ($L_2$).
  - $p = \\infty$: Chebyshev Distance (Maximum coordinate difference).
- **Cosine Distance:** $1 - \\frac{x \\cdot z}{\\|x\\|_2 \\|z\\|_2}$ (Invariant to vector magnitude, ideal for text/embeddings).

#### 3. The Curse of Dimensionality & Spatial Indexing
- In high dimensions ($d > 50$), the volume of space grows exponentially ($V \\propto r^d$), causing all pairwise Euclidean distances to concentrate and become equidistant (ratio of $\\frac{d_{\\max} - d_{\\min}}{d_{\\min}} \\to 0$).
- **KD-Tree & Ball Tree:** Spatial partitioning data structures accelerating nearest neighbor queries from brute-force $O(N \\cdot d)$ to average $O(\\log N \\cdot d)$ in low-to-medium dimensions.`,
    quickRevisionNotes: [
      'KNN is a non-parametric lazy learner with O(1) training and O(N*d) query time.',
      'Small k (e.g. k=1) gives low bias and high variance (overfitting); large k creates smooth decision boundaries.',
      'Curse of dimensionality makes Euclidean distances converge in high dimensions.',
      'KD-Trees and Ball-Trees reduce query time from linear scan to O(log N).'
    ],
    formulaSheets: [
      {
        name: 'Minkowski Distance Metric',
        formula: 'D_p(\\mathbf{x}, \\mathbf{z}) = \\left( \\sum_{i=1}^d |x_i - z_i|^p \\right)^{\\frac{1}{p}}',
        description: 'Generalized geometric distance metric spanning Manhattan (p=1) and Euclidean (p=2).'
      }
    ],
    definitions: [
      {
        term: 'Curse of Dimensionality',
        explanation: 'The phenomenon where data becomes extremely sparse and equidistant in high-dimensional vector spaces, degrading distance-based machine learning algorithms.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'KNN with KD-Tree and Distance-Weighted Voting in Scikit-Learn',
        code: `from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

# Pipeline guarantees scaling before distance calculation
knn_pipeline = make_pipeline(
    StandardScaler(),
    KNeighborsClassifier(
        n_neighbors=7,
        weights='distance', # Inverse distance weighting: 1 / d
        algorithm='kd_tree',
        p=2 # Euclidean distance
    )
)

knn_pipeline.fit(X_train, y_train)
acc = knn_pipeline.score(X_test, y_test)
print(f"KNN Test Accuracy: {acc:.4f}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w8-q1',
        questionText: 'What is the effect on the decision boundary of setting k=1 in a K-Nearest Neighbors classifier?',
        options: ['The decision boundary becomes highly intricate and sensitive to individual noise points, resulting in zero training error but high variance (overfitting)', 'The decision boundary becomes a single straight line', 'The model behaves like logistic regression', 'The model fails to converge'],
        correctOptionIndex: 0,
        solution: 'At k=1, the model creates Voronoi cells around every individual data point. This yields 100% training accuracy but makes the classifier fragile to noise and outliers (high variance).',
        hints: ['k=1 perfectly fits training points including noise.']
      }
    ],
    examTips: [
      'Always choose an odd value for $k$ in binary classification to prevent tie-breaking ambiguity in majority voting.',
      'For sparse text TF-IDF matrices, use `metric="cosine"` with `algorithm="brute"` rather than Euclidean KD-trees.'
    ],
    handwrittenMnemonic: 'KNN: Scale features first; Small k = High variance; Odd k avoids ties!'
  },
  {
    id: 'note-mlp-w9',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 9,
    title: 'Unsupervised Learning: K-Means Clustering, K-Means++, Hierarchical & DBSCAN',
    detailedNotes: `### Week 9: Clustering Algorithms & Density-Based Spatial Clustering

#### 1. K-Means Algorithm & K-Means++ Initialization
Minimizes Within-Cluster Sum of Squares (**Inertia / WCSS**):
$$J = \\sum_{k=1}^K \\sum_{x_i \\in C_k} \\|x_i - \\mu_k\\|_2^2$$
- **Lloyd Algorithm:** 1. Assign points to nearest centroid $\\mu_k$. 2. Recompute centroids as partition means.
- **K-Means++:** Chooses next initial centroid with probability proportional to squared distance from closest existing centroid:
  $$P(x) = \\frac{D(x)^2}{\\sum_{x\'} D(x\')^2} \\implies \\text{Guarantees } O(\\log K) \\text{ competitive error bound!}$$

#### 2. DBSCAN (Density-Based Spatial Clustering of Applications with Noise)
Discovers arbitrary-shaped non-convex clusters and isolates noise outliers:
- **Parameters:** $\\epsilon$ (neighborhood radius) and $\\text{MinPts}$ (minimum points threshold).
- **Point Classifications:**
  - **Core Point:** $|N_\\epsilon(p)| \\ge \\text{MinPts}$.
  - **Border Point:** $|N_\\epsilon(p)| < \\text{MinPts}$, but lies in $\\epsilon$-neighborhood of a Core Point.
  - **Noise / Outlier Point:** Neither Core nor Border.

#### 3. Hierarchical Agglomerative Clustering
Bottom-up clustering building a **Dendrogram**:
- **Linkage Criteria:** Single (minimum pairwise distance - chaining risk), Complete (maximum distance), Average, and **Ward Linkage** (minimizes total within-cluster variance increase).`,
    quickRevisionNotes: [
      'K-Means minimizes inertia (WCSS); sensitive to initialization (use k-means++).',
      'DBSCAN identifies non-convex clusters and labels noise without requiring cluster count K.',
      'Silhouette coefficient s in [-1, +1] evaluates cluster cohesion vs separation (s > 0.5 is good).',
      'Ward linkage in hierarchical clustering minimizes total within-cluster variance.'
    ],
    formulaSheets: [
      {
        name: 'Silhouette Coefficient',
        formula: 's(i) = \\frac{b(i) - a(i)}{\\max(a(i), b(i))}',
        description: 'Cluster validation metric comparing mean intra-cluster distance a(i) to nearest cluster distance b(i).'
      }
    ],
    definitions: [
      {
        term: 'DBSCAN Core Point',
        explanation: 'A data point that contains at least MinPts within its epsilon-radius neighborhood, serving as the nucleus of a density-connected cluster.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'DBSCAN Clustering with Nearest Neighbors Epsilon Estimation',
        code: `from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
import numpy as np

# Estimate optimal epsilon using k-distance elbow plot (k = MinPts = 5)
neighbors = NearestNeighbors(n_neighbors=5).fit(X_scaled)
distances, _ = neighbors.kneighbors(X_scaled)
k_distances = np.sort(distances[:, -1])

# Fit DBSCAN
dbscan = DBSCAN(eps=0.45, min_samples=5)
cluster_labels = dbscan.fit_predict(X_scaled)

n_clusters = len(set(cluster_labels)) - (1 if -1 in cluster_labels else 0)
n_noise = list(cluster_labels).count(-1)

print(f"Discovered Clusters: {n_clusters}")
print(f"Identified Noise Points: {n_noise}")`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w9-q1',
        questionText: 'Which clustering algorithm is best suited for identifying concentric circular rings or irregularly shaped clusters with noise outliers?',
        options: ['DBSCAN', 'Standard K-Means', 'Gaussian Mixture Models with spherical covariance', 'Agglomerative clustering with complete linkage'],
        correctOptionIndex: 0,
        solution: 'DBSCAN forms clusters based on contiguous dense regions rather than spherical Voronoi partitions, allowing it to discover arbitrary geometric shapes and label noise.',
        hints: ['Density-based clustering discovers arbitrary shapes.']
      }
    ],
    examTips: [
      'In DBSCAN, noise outliers are assigned cluster label `-1`.',
      'K-Means assumes isotropic spherical clusters of equal size; it fails on elongated or varying density clusters.'
    ],
    handwrittenMnemonic: 'K-Means for spheres; DBSCAN for arbitrary density shapes; Noise is -1!'
  },
  {
    id: 'note-mlp-w10',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 10,
    title: 'Dimensionality Reduction: Principal Component Analysis (PCA), SVD & t-SNE',
    detailedNotes: `### Week 10: Dimensionality Reduction & Manifold Learning

#### 1. Principal Component Analysis (PCA)
Linear dimensionality reduction maximizing variance and minimizing reconstruction error:
- Given centered data matrix $X \\in \\mathbb{R}^{n \\times d}$ ($\\mu = 0$):
  - **Sample Covariance Matrix:** $\\Sigma = \\frac{1}{n-1} X^T X \\in \\mathbb{R}^{d \\times d}$.
  - **Eigendecomposition:** $\\Sigma v_j = \\lambda_j v_j$.
  - **Principal Components:** Eigenvectors $v_1, \\dots, v_k$ sorted by descending eigenvalues $\\lambda_1 \\ge \\lambda_2 \\ge \\dots \\ge \\lambda_d$.
- **Explained Variance Ratio:**
  $$\\text{EVR}_k = \\frac{\\lambda_k}{\\sum_{j=1}^d \\lambda_j}$$

#### 2. Singular Value Decomposition (SVD)
Direct factorization of centered matrix $X$ without computing full $d \\times d$ covariance:
$$X = U \\Sigma V^T$$
- Right singular vectors $V$ are the exact principal component loading vectors!
- \`TruncatedSVD\` efficiently operates on sparse matrices without centering (crucial for TF-IDF).

#### 3. t-Distributed Stochastic Neighbor Embedding (t-SNE)
Non-linear probabilistic manifold learning for 2D/3D visualization:
- Converts Euclidean distances between points into conditional probabilities $p_{j|i}$ (Gaussian in high dimensions, Student-t with 1 degree of freedom in low-dimensional map $q_{ij}$).
- Uses Student-t distribution heavy tails to solve the **Crowding Problem**!`,
    quickRevisionNotes: [
      'PCA finds orthogonal directions of maximum variance via covariance eigendecomposition.',
      'Always center and scale data before PCA so large-scale features do not dominate variance.',
      'TruncatedSVD works directly on sparse matrices without dense zero-centering.',
      't-SNE uses Student-t distributions to visualize high-dimensional non-linear manifolds in 2D.'
    ],
    formulaSheets: [
      {
        name: 'PCA Explained Variance Ratio',
        formula: '\\text{Explained Variance Ratio} = \\frac{\\lambda_k}{\\sum_{j=1}^d \\lambda_j}',
        description: 'Fraction of total dataset variance captured by the k-th principal component.'
      }
    ],
    definitions: [
      {
        term: 'Crowding Problem',
        explanation: 'The volume mismatch in dimensionality reduction where 2D space has insufficient volume to preserve all moderate-distance relationships from high-dimensional spaces.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'PCA Cumulative Variance Analysis and t-SNE Visualization',
        code: `from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import numpy as np

# PCA keeping 95% of total variance
pca = PCA(n_components=0.95, random_state=42)
X_pca = pca.fit_transform(X_scaled)

print(f"Original Dimensions: {X_scaled.shape[1]}")
print(f"Retained Dimensions: {X_pca.shape[1]}")
print(f"Cumulative Explained Variance: {np.sum(pca.explained_variance_ratio_):.4f}")

# 2D Non-linear Visualization with t-SNE
tsne = TSNE(n_components=2, perplexity=30.0, learning_rate='auto', init='pca', random_state=42)
X_tsne_2d = tsne.fit_transform(X_scaled)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w10-q1',
        questionText: 'Why is it mandatory to standardize features with zero mean and unit variance before fitting Principal Component Analysis (PCA)?',
        options: ['Without standardization, features with artificially large numerical ranges (e.g. salary in thousands vs age in tens) will falsely dominate the largest eigenvalues and principal directions', 'PCA fails if data is non-negative', 'PCA requires labels to compute variance', 'Standardization makes eigenvectors orthogonal'],
        correctOptionIndex: 0,
        solution: 'PCA projects along directions of maximum variance. If a feature has large raw units, its variance will dominate the covariance matrix regardless of whether it is informative.',
        hints: ['Prevents arbitrary units from dominating variance calculations.']
      }
    ],
    examTips: [
      'In PCA, passing a float between 0 and 1 (e.g. `n_components=0.95`) automatically selects the minimum components needed to explain 95% variance.',
      't-SNE is exclusively for visualization; never use t-SNE transformed features as inputs to downstream predictive ML models because perplexity and distances do not generalize to test data.'
    ],
    handwrittenMnemonic: 'Scale before PCA; n_components=0.95 for 95% variance; t-SNE is for visualization only!'
  },
  {
    id: 'note-mlp-w11',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 11,
    title: 'Hyperparameter Tuning: GridSearch, RandomizedSearch, Bayesian Optimization & Optuna',
    detailedNotes: `### Week 11: Hyperparameter Optimization & Efficient Search Strategies

#### 1. Optimization Strategies Comparison
- **GridSearchCV:** Exhaustive Cartesian product evaluation over all parameter combinations. Computationally prohibitive for large grids ($O(\\prod |P_i|)$).
- **RandomizedSearchCV (Bergstra & Bengio):** Samples fixed budget of $N$ configurations from statistical distributions. Mathematically proven to find near-optimal configurations with far fewer trials because most parameters have low effective dimensionality.
- **HalvingGridSearchCV / HalvingRandomSearchCV:** Uses **Successive Halving** (trains on small data subset, keeps top $1/r$ candidates, doubles data budget).

#### 2. Bayesian Optimization & Tree-structured Parzen Estimators (TPE)
Treats hyperparameter search as a surrogate optimization problem:
- Models objective $f(\\theta)$ using a Gaussian Process or TPE surrogate.
- **Acquisition Function (Expected Improvement - EI):**
  $$\\text{EI}(\\theta) = \\mathbb{E}[\\max(0, f(\\theta) - f(\\theta^+))]$$
- Balances **Exploration** (uncertain parameter regions) and **Exploitation** (regions near known optima).

#### 3. Optuna Framework
- Defines hyperparameter search spaces dynamically using native Python loops (\`trial.suggest_float\`, \`trial.suggest_int\`).
- **Pruning (Asynchronous Successive Halving):** Automatically terminates unpromising trial runs mid-training based on early validation epochs!`,
    quickRevisionNotes: [
      'RandomizedSearchCV is exponentially more efficient than GridSearch in high dimensions.',
      'Successive Halving allocates small data budgets to many configurations and promotes top candidates.',
      'Bayesian Optimization (Optuna/TPE) guides search by modeling past trial performance.',
      'Optuna pruners terminate poor trials early to save compute time.'
    ],
    formulaSheets: [
      {
        name: 'Expected Improvement (EI)',
        formula: '\\text{EI}(\\mathbf{x}) = (\\mu(\\mathbf{x}) - f^+) \\Phi\\left(\\frac{\\mu(\\mathbf{x}) - f^+}{\\sigma(\\mathbf{x})}\\right) + \\sigma(\\mathbf{x}) \\phi\\left(\\frac{\\mu(\\mathbf{x}) - f^+}{\\sigma(\\mathbf{x})}\\right)',
        description: 'Bayesian acquisition function balancing exploration and exploitation.'
      }
    ],
    definitions: [
      {
        term: 'Tree-structured Parzen Estimator (TPE)',
        explanation: 'A sequential model-based optimization algorithm that builds two non-parametric probability density models: one for good hyperparameter configurations and one for bad ones.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Optuna Automated Hyperparameter Search with Median Pruning',
        code: `import optuna
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import cross_val_score

def objective(trial):
    params = {
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
        'max_iter': trial.suggest_int('max_iter', 50, 300),
        'max_leaf_nodes': trial.suggest_int('max_leaf_nodes', 15, 127),
        'min_samples_leaf': trial.suggest_int('min_samples_leaf', 10, 100),
        'l2_regularization': trial.suggest_float('l2_regularization', 1e-4, 10.0, log=True),
        'random_state': 42
    }
    
    clf = HistGradientBoostingClassifier(**params)
    score = cross_val_score(clf, X_train, y_train, cv=5, scoring='roc_auc').mean()
    return score

study = optuna.create_study(direction='maximize', pruner=optuna.pruners.MedianPruner())
study.optimize(objective, n_trials=50, timeout=600)

print(f"Best ROC-AUC: {study.best_value:.4f}")
print("Best Hyperparameters:", study.best_params)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w11-q1',
        questionText: 'Why is Randomized Search mathematically superior to Grid Search when tuning machine learning models with 10 hyperparameters where only 2 actually have high impact on accuracy?',
        options: ['Random Search tests N distinct values for the 2 critical parameters, whereas Grid Search tests only a tiny fraction of distinct values while repeatedly testing irrelevant combinations', 'Random Search uses quantum mechanics', 'Grid Search has no random seed', 'Random Search runs in C++'],
        correctOptionIndex: 0,
        solution: 'In high-dimensional spaces where only a few hyperparameters matter (effective dimensionality), Grid Search wastes compute re-testing identical coordinates along the unimportant axes, while Random Search tests unique values on every trial.',
        hints: ['Tests more unique values across the important parameters.']
      }
    ],
    examTips: [
      'Use `log=True` when sampling parameters that span several orders of magnitude (e.g. learning rate $10^{-4}$ to $10^{-1}$, SVM $C$).',
      'Always set `n_jobs=-1` in GridSearchCV / RandomizedSearchCV to parallelize evaluation across CPU cores.'
    ],
    handwrittenMnemonic: 'RandomSearch beats GridSearch; Optuna uses TPE + Pruning to save time!'
  },
  {
    id: 'note-mlp-w12',
    courseId: 'course-mlp',
    courseTitle: 'Machine Learning Practice',
    courseCode: 'DS2002',
    level: 'Diploma',
    subLevel: 'Diploma in Data Science',
    weekNumber: 12,
    title: 'Model Interpretability: Permutation Importance, SHAP (Shapley Additive Explanations) & LIME',
    detailedNotes: `### Week 12: Explainable AI (XAI) & Model Interpretability

#### 1. Limitations of Impurity-Based Feature Importance (MDI)
- **MDI (Mean Decrease in Impurity / Gini Importance):**
  - Severely biased towards **high-cardinality features** (e.g. numerical IDs with thousands of distinct values).
  - Computed on training folds, failing to reflect true generalization value.

#### 2. Permutation Feature Importance (PFI)
Model-agnostic evaluation on a held-out test/validation set:
1. Compute baseline score $S_{\\text{base}}$ on validation set.
2. For each feature $j$:
   - Randomly shuffle column $j$, breaking its relationship with target $y$.
   - Recompute validation score $S_j^{\\text{perm}}$.
   - **Importance Metric:** $\\Delta S_j = S_{\\text{base}} - S_j^{\\text{perm}}$.
3. Unbiased and immune to high-cardinality inflation!

#### 3. SHAP (Shapley Additive Explanations - Game Theory)
Fairly attributes the marginal contribution $\\phi_j$ of each feature to the model prediction $f(x)$ based on cooperative game theory:
$$\\phi_j(x) = \\sum_{S \\subseteq F \\setminus \\{j\\}} \\frac{|S|!(|F| - |S| - 1)!}{|F|!} \\left[ f(S \\cup \\{j\\}) - f(S) \\right]$$
- **Efficiency Property:** $\\sum_{j=1}^d \\phi_j(x) = f(x) - \\mathbb{E}[f(X)]$.
- **TreeSHAP:** Exact, high-speed polynomial-time ($O(T \\cdot L \\cdot D^2)$) calculation for tree ensembles (XGBoost, LightGBM, Random Forests).`,
    quickRevisionNotes: [
      'MDI (Gini importance) is biased towards high-cardinality features; PFI is model-agnostic and unbiased.',
      'Permutation importance evaluates score degradation after randomly shuffling feature columns on test data.',
      'SHAP uses cooperative game theory Shapley values to provide exact local and global feature attribution.',
      'TreeSHAP computes exact Shapley explanations in polynomial time for tree ensembles.'
    ],
    formulaSheets: [
      {
        name: 'Shapley Value Attribution Formula',
        formula: '\\phi_i = \\sum_{S \\subseteq N \\setminus \\{i\\}} \\frac{|S|!(|N|-|S|-1)!}{|N|!} (v(S \\cup \\{i\\}) - v(S))',
        description: 'Axiomatic game-theoretic marginal contribution weighting for feature attribution.'
      }
    ],
    definitions: [
      {
        term: 'TreeSHAP',
        explanation: 'A fast algorithm for computing exact SHAP (Shapley Additive Explanations) values for tree-based ensemble models in polynomial time.'
      }
    ],
    codeSnippets: [
      {
        language: 'python',
        title: 'Model Interpretability with Permutation Importance and TreeSHAP',
        code: `import shap
from sklearn.inspection import permutation_importance
import matplotlib.pyplot as plt

# 1. Model-Agnostic Permutation Importance on Validation Data
perm_importance = permutation_importance(model, X_val, y_val, n_repeats=10, random_state=42, n_jobs=-1)
sorted_importances_idx = perm_importance.importances_mean.argsort()[::-1]

# 2. TreeSHAP Local & Global Explanations
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_val)

# Summary Beeswarm Plot showing feature impact & directionality
shap.summary_plot(shap_values, X_val, show=False)`
      }
    ],
    practiceQuestions: [
      {
        id: 'mlp-w12-q1',
        questionText: 'Why does Permutation Feature Importance computed on a held-out test dataset provide a more reliable measure than Random Forest default `feature_importances_` (MDI)?',
        options: ['Permutation Importance measures actual generalization performance degradation on unseen test data, whereas MDI is computed on training splits and artificially favors high-cardinality noisy features', 'Permutation Importance uses linear regression', 'MDI deletes tree splits', 'They give identical outputs'],
        correctOptionIndex: 0,
        solution: 'MDI measures training set impurity drops and is biased towards features with many unique levels (high cardinality). Permutation importance on the validation set measures genuine predictive degradation.',
        hints: ['Measures degradation on held-out test data and resists high-cardinality bias.']
      }
    ],
    examTips: [
      'SHAP values sum up exactly to the difference between the model prediction and the base expected value ($f(x) - E[f(x)]$).',
      'In SHAP summary plots, the color indicates feature value (red = high, blue = low) and the X-axis shows whether it increases or decreases the output log-odds.'
    ],
    handwrittenMnemonic: 'Permutation tests generalization; SHAP sums to f(x) - E[f(x)]; Red/Blue shows feature value!'
  }
];

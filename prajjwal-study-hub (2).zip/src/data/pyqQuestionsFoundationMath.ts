import { Question } from '../types';

export const FOUNDATION_MATH_QUESTIONS: Question[] = [
  // ==========================================
  // MATHEMATICS FOR DATA SCIENCE 1
  // ==========================================
  {
    id: 'pyq-m1-line-dist-nat',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'NAT',
    questionText: 'Calculate the perpendicular distance from the point $P(4, -2)$ to the straight line given by $3x - 4y + 5 = 0$. (Enter your numerical answer as an exact value or decimal).',
    options: [],
    correctNumericAnswer: 5,
    numericTolerance: 0.01,
    toleranceRange: [4.99, 5.01],
    explanation: `Perpendicular Distance Formula:
$$d = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}$$
1. Here $A = 3$, $B = -4$, $C = 5$, and $(x_0, y_0) = (4, -2)$.
2. Numerator:
   $$|3(4) + (-4)(-2) + 5| = |12 + 8 + 5| = |25| = 25$$
3. Denominator:
   $$\\sqrt{3^2 + (-4)^2} = \\sqrt{9 + 16} = \\sqrt{25} = 5$$
4. Perpendicular distance:
   $$d = \\frac{25}{5} = 5$$`,
    hints: [
      'Use the standard formula $d = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}$.',
      'Be careful with negative signs when substituting $y_0 = -2$ with $B = -4$.'
    ],
    formulaRef: 'd = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Jan 2023 (Quiz 1)',
    tags: ['Coordinate Geometry', 'Lines', 'Perpendicular Distance'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m1-matrix-det-inv-msq',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'MSQ',
    questionText: 'Let $A = \\begin{bmatrix} 2 & k \\\\ 4 & 6 \\end{bmatrix}$ be a $2 \\times 2$ matrix with real entries. Which of the following statements are TRUE?',
    options: [
      'The matrix $A$ is singular (non-invertible) if and only if $k = 3$.',
      'If $k = 1$, then the determinant $\\det(A) = 8$.',
      'For $k = 3$, the system $A\\mathbf{x} = \\mathbf{0}$ has infinitely many non-trivial solutions.',
      'The trace of matrix $A$ is independent of the value of $k$ and equals 8.'
    ],
    correctOptionIndices: [0, 1, 2, 3],
    explanation: `Detailed Matrix Verification:
1. Determinant formula: $\\det(A) = (2)(6) - (k)(4) = 12 - 4k$.
   - For singularity, $\\det(A) = 0 \\implies 12 - 4k = 0 \\implies k = 3$ (Option A is TRUE).
2. When $k = 1$: $\\det(A) = 12 - 4(1) = 8$ (Option B is TRUE).
3. When $k = 3$, $\\det(A) = 0$, so $\\text{rank}(A) < 2$. Hence, the homogeneous system $A\\mathbf{x} = \\mathbf{0}$ has nullity $\\ge 1$, yielding infinitely many non-trivial solutions (Option C is TRUE).
4. Trace is the sum of main diagonal entries: $\\text{Tr}(A) = 2 + 6 = 8$, which is independent of off-diagonal parameter $k$ (Option D is TRUE).
All 4 statements are correct!`,
    hints: [
      'A matrix is singular if and only if its determinant is zero.',
      'Trace is the sum of the main diagonal elements: $a_{11} + a_{22}$.'
    ],
    formulaRef: '\\det(A) = ad - bc, \\quad \\text{Tr}(A) = a + d',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['Matrices', 'Determinants', 'Linear Systems', 'Singularity'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m1-taylor-limit-mcq',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'MCQ',
    questionText: 'Evaluate the limit using Taylor expansions or L\'Hôpital\'s Rule:\n$$\\lim_{x \\to 0} \\frac{e^{2x} - 1 - 2x}{x^2}$$',
    options: [
      '2',
      '1',
      '4',
      '0'
    ],
    correctOptionIndex: 0,
    explanation: `Taylor Expansion Method:
1. Recall the Taylor series for $e^u = 1 + u + \\frac{u^2}{2!} + \\frac{u^3}{3!} + \\dots$
2. For $u = 2x$:
   $$e^{2x} = 1 + 2x + \\frac{(2x)^2}{2!} + O(x^3) = 1 + 2x + 2x^2 + O(x^3)$$
3. Substitute into the numerator:
   $$e^{2x} - 1 - 2x = 1 + 2x + 2x^2 + O(x^3) - 1 - 2x = 2x^2 + O(x^3)$$
4. Taking the limit:
   $$\\lim_{x \\to 0} \\frac{2x^2 + O(x^3)}{x^2} = \\lim_{x \\to 0} \\left(2 + O(x)\\right) = 2$$`,
    hints: [
      'Use the series $e^{2x} = 1 + 2x + \\frac{4x^2}{2} + \\dots$',
      'Alternatively, apply L\'Hôpital\'s Rule twice for $\\frac{0}{0}$ indeterminate form.'
    ],
    formulaRef: 'e^u = 1 + u + \\frac{u^2}{2!} + \\dots',
    difficulty: 'Medium',
    marks: 2,
    negativeMarks: 0.5,
    term: 'Term 1',
    pyqYear: 'Sept 2024 (End Term)',
    tags: ['Calculus', 'Limits', 'Taylor Series', 'L\'Hopital'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m1-rank-nullity-nat',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'NAT',
    questionText: 'Let $T: \\mathbb{R}^5 \\to \\mathbb{R}^3$ be a linear transformation whose matrix representation has rank equal to $2$. According to the Rank-Nullity Theorem, what is the dimension of the kernel (nullity) of $T$?',
    options: [],
    correctNumericAnswer: 3,
    numericTolerance: 0,
    toleranceRange: [3, 3],
    explanation: `Rank-Nullity Theorem:
$$\\text{dim}(\\text{Domain}) = \\text{Rank}(T) + \\text{Nullity}(T)$$
1. Dimension of domain $\\mathbb{R}^5$ is $n = 5$.
2. Given $\\text{Rank}(T) = 2$.
3. $\\text{Nullity}(T) = \\text{dim}(\\text{Domain}) - \\text{Rank}(T) = 5 - 2 = 3$.`,
    hints: [
      'Rank-Nullity states $\\text{dim}(V) = \\text{rank}(T) + \\text{nullity}(T)$.',
      'The domain is $\\mathbb{R}^5$, so $n = 5$.'
    ],
    formulaRef: '\\text{rank}(T) + \\text{nullity}(T) = \\dim(V)',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Jan 2025 (Quiz 2)',
    tags: ['Linear Algebra', 'Rank-Nullity', 'Vector Spaces'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ==========================================
  // MATHEMATICS FOR DATA SCIENCE 2
  // ==========================================
  {
    id: 'pyq-m2-hessian-classification-mcq',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 2',
    type: 'MCQ',
    questionText: 'Consider the multivariable function $f(x, y) = x^3 - 3xy^2 + y^2$. At the critical point $(0, 0)$, what is the nature of the critical point based on the Hessian matrix $H(x, y)$?',
    options: [
      'Saddle point because the Hessian determinant is negative (indefinite)',
      'Local minimum because all second partial derivatives are non-negative',
      'Local maximum because the trace is negative',
      'The second derivative test is inconclusive'
    ],
    correctOptionIndex: 0,
    explanation: `Hessian Matrix Derivation:
1. First partial derivatives:
   $$f_x = 3x^2 - 3y^2, \\quad f_y = -6xy + 2y$$
2. At $(0,0)$, $f_x(0,0) = 0$ and $f_y(0,0) = 0$ (critical point).
3. Second partial derivatives:
   $$f_{xx} = 6x \\implies f_{xx}(0,0) = 0$$
   $$f_{yy} = -6x + 2 \\implies f_{yy}(0,0) = 2$$
   $$f_{xy} = -6y \\implies f_{xy}(0,0) = 0$$
4. Hessian matrix at $(0,0)$:
   $$H = \\begin{bmatrix} 0 & 0 \\\\ 0 & 2 \\end{bmatrix}$$
5. Notice along the line $y = 0$, $f(x, 0) = x^3$, which changes sign from negative (for $x < 0$) to positive (for $x > 0$). Hence, $(0,0)$ is a saddle point.`,
    hints: [
      'Compute the Hessian matrix $H = \\begin{bmatrix} f_{xx} & f_{xy} \\\\ f_{yx} & f_{yy} \\end{bmatrix}$.',
      'Examine behavior along curves such as $y = 0 \\implies f(x,0) = x^3$.'
    ],
    formulaRef: 'H = \\begin{bmatrix} f_{xx} & f_{xy} \\\\ f_{yx} & f_{yy} \\end{bmatrix}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0.5,
    term: 'Term 2',
    pyqYear: 'May 2024 (Quiz 1)',
    tags: ['Multivariable Calculus', 'Hessian Matrix', 'Critical Points', 'Saddle Point'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m2-lagrange-multipliers-nat',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 2',
    type: 'NAT',
    questionText: 'Find the maximum value of $f(x, y) = xy$ subject to the linear constraint $x + y = 10$ with $x, y \\ge 0$. (Enter your numeric answer).',
    options: [],
    correctNumericAnswer: 25,
    numericTolerance: 0.01,
    toleranceRange: [24.99, 25.01],
    explanation: `Lagrange Multiplier Derivation:
1. Define Lagrangian $\\mathcal{L}(x, y, \\lambda) = xy - \\lambda(x + y - 10)$.
2. Set partial derivatives to zero:
   $$\\frac{\\partial \\mathcal{L}}{\\partial x} = y - \\lambda = 0 \\implies y = \\lambda$$
   $$\\frac{\\partial \\mathcal{L}}{\\partial y} = x - \\lambda = 0 \\implies x = \\lambda$$
   $$\\frac{\\partial \\mathcal{L}}{\\partial \\lambda} = -(x + y - 10) = 0 \\implies x + y = 10$$
3. Equating $x = y = \\lambda$:
   $$x + x = 10 \\implies 2x = 10 \\implies x = 5, \\; y = 5$$
4. Maximum value:
   $$f(5, 5) = 5 \\times 5 = 25$$`,
    hints: [
      'AM-GM inequality: $xy \\le \\left(\\frac{x+y}{2}\\right)^2 = \\left(\\frac{10}{2}\\right)^2 = 25$.',
      'Or set up the Lagrange condition $\\nabla f = \\lambda \\nabla g$.'
    ],
    formulaRef: '\\nabla f(x, y) = \\lambda \\nabla g(x, y)',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 2',
    pyqYear: 'Sept 2024 (Quiz 2)',
    tags: ['Optimization', 'Lagrange Multipliers', 'Multivariable'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'pyq-m2-directional-derivative-nat',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    level: 'Foundation',
    subLevel: 'Foundation',
    subject: 'Mathematics for Data Science 2',
    type: 'NAT',
    questionText: 'Find the directional derivative of $f(x, y) = 2x^2 + 3y^2$ at the point $P(1, 2)$ in the direction of the unit vector $\\mathbf{u} = \\left(\\frac{3}{5}, \\frac{4}{5}\\right)$. (Enter the numeric value).',
    options: [],
    correctNumericAnswer: 12,
    numericTolerance: 0.01,
    toleranceRange: [11.99, 12.01],
    explanation: `Directional Derivative Calculation:
1. Compute the gradient vector $\\nabla f(x, y) = \\left(\\frac{\\partial f}{\\partial x}, \\frac{\\partial f}{\\partial y}\\right)$:
   $$\\nabla f(x, y) = (4x, 6y)$$
2. Evaluate gradient at $P(1, 2)$:
   $$\\nabla f(1, 2) = (4(1), 6(2)) = (4, 12)$$
3. Directional derivative along unit vector $\\mathbf{u} = (0.6, 0.8)$:
   $$D_{\\mathbf{u}} f(1, 2) = \\nabla f(1, 2) \\cdot \\mathbf{u} = 4\\left(\\frac{3}{5}\\right) + 12\\left(\\frac{4}{5}\\right)$$
   $$D_{\\mathbf{u}} f(1, 2) = \\frac{12 + 48}{5} = \\frac{60}{5} = 12$$`,
    hints: [
      'Directional derivative is the dot product $D_{\\mathbf{u}} f = \\nabla f \\cdot \\mathbf{u}$.',
      'Verify that $\\mathbf{u}$ has unit length: $\\sqrt{(3/5)^2 + (4/5)^2} = 1$.'
    ],
    formulaRef: 'D_{\\mathbf{u}} f(\\mathbf{x}) = \\nabla f(\\mathbf{x}) \\cdot \\mathbf{u}',
    difficulty: 'Medium',
    marks: 3,
    negativeMarks: 0,
    term: 'Term 2',
    pyqYear: 'Jan 2025 (End Term)',
    tags: ['Multivariable Calculus', 'Gradients', 'Directional Derivatives'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

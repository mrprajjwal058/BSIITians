import { AcademicLevel } from '../types';

export interface RichFormulaCard {
  id: string;
  courseId: string;
  courseTitle: string;
  courseCode: string;
  level: AcademicLevel;
  category: 'Calculus' | 'Linear Algebra' | 'Coordinate Geometry' | 'Probability' | 'Statistics' | 'Algorithms' | 'Machine Learning' | 'Deep Learning' | 'Software Engineering' | 'Databases & Systems';
  title: string;
  formula: string;
  latex: string;
  explanation: string;
  handwrittenNote?: string;
  variables: Array<{ symbol: string; name: string; description: string }>;
  keyInsights: string[];
  tags: string[];
}

export const RICH_FORMULA_SHEETS: RichFormulaCard[] = [
  // ==========================================
  // 1. COORDINATE GEOMETRY & LINES (MATH 1)
  // ==========================================
  {
    id: 'f-m1-dist-line',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    category: 'Coordinate Geometry',
    title: 'Perpendicular Distance from Point to Straight Line',
    formula: 'd = |Ax0 + By0 + C| / sqrt(A^2 + B^2)',
    latex: 'd = \\frac{|A x_0 + B y_0 + C|}{\\sqrt{A^2 + B^2}}',
    explanation: 'Finds the exact perpendicular (shortest) Euclidean distance from an arbitrary 2D point P(x0, y0) to the line Ax + By + C = 0.',
    handwrittenNote: 'Remember: Denominator is just the norm of the normal vector n = (A, B). If point is on the line, numerator = 0.',
    variables: [
      { symbol: 'd', name: 'Distance', description: 'Perpendicular Euclidean distance (d >= 0)' },
      { symbol: '(x_0, y_0)', name: 'Target Point', description: 'Coordinates of the given point' },
      { symbol: 'A, B, C', name: 'Line Parameters', description: 'Coefficients of the linear equation Ax + By + C = 0' }
    ],
    keyInsights: [
      'The sign of (Ax_0 + By_0 + C) determines which half-plane the point lies in.',
      'For parallel lines Ax + By + C_1 = 0 and Ax + By + C_2 = 0, the separation distance is d = |C_1 - C_2| / \\sqrt{A^2 + B^2}.'
    ],
    tags: ['Coordinate Geometry', 'Lines', 'Euclidean Distance', 'Math 1']
  },
  {
    id: 'f-m1-angle-lines',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    courseCode: 'MA1001',
    level: 'Foundation',
    category: 'Coordinate Geometry',
    title: 'Acute Angle Between Two Intersecting Lines',
    formula: 'tan(theta) = |(m2 - m1) / (1 + m1 * m2)|',
    latex: '\\tan \\theta = \\left| \\frac{m_2 - m_1}{1 + m_1 m_2} \\right|',
    explanation: 'Calculates the acute angle theta between two non-vertical lines having slopes m1 and m2.',
    handwrittenNote: 'If lines are perpendicular: m1 * m2 = -1. If parallel: m1 = m2. Watch out for vertical lines with undefined slope!',
    variables: [
      { symbol: '\\theta', name: 'Intersection Angle', description: 'Acute angle between the lines (0 <= theta <= pi/2)' },
      { symbol: 'm_1, m_2', name: 'Line Slopes', description: 'Gradients m = tan(alpha) for each respective line' }
    ],
    keyInsights: [
      'Orthogonality condition: 1 + m_1 m_2 = 0 \\implies m_1 m_2 = -1.',
      'Parallelism condition: m_1 - m_2 = 0 \\implies m_1 = m_2.'
    ],
    tags: ['Coordinate Geometry', 'Slopes', 'Angle', 'Math 1']
  },

  // ==========================================
  // 2. MULTIVARIABLE CALCULUS & OPTIMIZATION (MATH 2)
  // ==========================================
  {
    id: 'f-m2-grad-descent',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    category: 'Calculus',
    title: 'Multivariable Gradient Descent Parameter Update',
    formula: 'w_{t+1} = w_t - eta * grad f(w_t)',
    latex: '\\mathbf{w}_{t+1} = \\mathbf{w}_t - \\eta \\nabla f(\\mathbf{w}_t)',
    explanation: 'Iterative optimization algorithm updating parameter vector in the direction of steepest loss decrease proportional to learning rate eta.',
    handwrittenNote: 'Learning rate eta is critical! If too large, oscillations or divergence occur; if too small, convergence is painfully slow.',
    variables: [
      { symbol: '\\mathbf{w}_t', name: 'Parameter Vector', description: 'Weights at iteration step t' },
      { symbol: '\\eta', name: 'Learning Rate', description: 'Step size hyperparameter (eta > 0)' },
      { symbol: '\\nabla f(\\mathbf{w}_t)', name: 'Gradient Vector', description: 'Vector of partial derivatives at current point' }
    ],
    keyInsights: [
      'For convex quadratic loss f(w) = 1/2 w^T A w - b^T w, convergence occurs if 0 < eta < 2 / lambda_max(A).',
      'At stationary points, \\nabla f(\\mathbf{w}^*) = \\mathbf{0}.'
    ],
    tags: ['Calculus', 'Optimization', 'Gradient Descent', 'Math 2']
  },
  {
    id: 'f-m2-hessian-test',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    category: 'Calculus',
    title: 'Second-Order Hessian Curvature Matrix & Critical Point Test',
    formula: 'H = [[f_xx, f_xy], [f_yx, f_yy]]',
    latex: 'H(\\mathbf{x}) = \\begin{bmatrix} \\frac{\\partial^2 f}{\\partial x^2} & \\frac{\\partial^2 f}{\\partial x \\partial y} \\\\[6pt] \\frac{\\partial^2 f}{\\partial y \\partial x} & \\frac{\\partial^2 f}{\\partial y^2} \\end{bmatrix}, \\quad D = \\det(H)',
    explanation: 'Evaluates the nature of stationary points (where gradient = 0) in multivariable functions.',
    handwrittenNote: 'Check D = f_xx * f_yy - (f_xy)^2. If D > 0 and f_xx > 0 ==> Local Min! If D < 0 ==> Saddle point!',
    variables: [
      { symbol: 'H', name: 'Hessian Matrix', description: 'Square symmetric matrix of 2nd partial derivatives' },
      { symbol: 'D', name: 'Determinant / Discriminant', description: 'D = f_{xx} f_{yy} - (f_{xy})^2' }
    ],
    keyInsights: [
      'Positive Definite (all eigenvalues > 0) \\implies Strict Local Minimum.',
      'Negative Definite (all eigenvalues < 0) \\implies Strict Local Maximum.',
      'Indefinite (mixed signs) \\implies Saddle Point.'
    ],
    tags: ['Calculus', 'Hessian', 'Curvature', 'Math 2']
  },

  // ==========================================
  // 3. LINEAR ALGEBRA & SPECTRAL DECOMPOSITION (MATH 2)
  // ==========================================
  {
    id: 'f-m2-eigen-char',
    courseId: 'course-math-2',
    courseTitle: 'Mathematics for Data Science 2',
    courseCode: 'MA1002',
    level: 'Foundation',
    category: 'Linear Algebra',
    title: 'Eigenvalue Characteristic Equation & Trace/Determinant Invariants',
    formula: 'det(A - lambda * I) = 0',
    latex: '\\det(A - \\lambda I) = 0, \\quad \\text{Tr}(A) = \\sum_{i=1}^n \\lambda_i, \\quad \\det(A) = \\prod_{i=1}^n \\lambda_i',
    explanation: 'Finds scalar eigenvalues lambda and non-zero eigenvectors v satisfying A v = lambda v.',
    handwrittenNote: 'Instant Sanity Check in Exams: Sum of your eigenvalues MUST equal the trace (sum of diagonal entries)!',
    variables: [
      { symbol: 'A', name: 'Square Matrix', description: 'Real n x n matrix transformation' },
      { symbol: '\\lambda', name: 'Eigenvalue', description: 'Scaling scalar root of characteristic polynomial' },
      { symbol: 'I', name: 'Identity Matrix', description: 'n x n Identity matrix' }
    ],
    keyInsights: [
      'Symmetric matrices (A = A^T) always yield strictly real eigenvalues and orthogonal eigenvectors.',
      'If A is singular (det(A) = 0), at least one eigenvalue is 0.'
    ],
    tags: ['Linear Algebra', 'Eigenvalues', 'Trace', 'Math 2']
  },

  // ==========================================
  // 4. PROBABILITY & BAYES (STATS 1)
  // ==========================================
  {
    id: 'f-s1-bayes-rule',
    courseId: 'course-stat-1',
    courseTitle: 'Statistics for Data Science 1',
    courseCode: 'ST1001',
    level: 'Foundation',
    category: 'Probability',
    title: 'Bayes Theorem with Law of Total Probability',
    formula: 'P(B_j|A) = [P(A|B_j) * P(B_j)] / sum(P(A|B_i) * P(B_i))',
    latex: 'P(B_j | A) = \\frac{P(A | B_j) P(B_j)}{\\sum_{i=1}^k P(A | B_i) P(B_i)}',
    explanation: 'Calculates the updated posterior probability of event Bj given empirical observation A.',
    handwrittenNote: 'Posterior = (Likelihood x Prior) / Total Marginal Evidence. Draw a tree diagram to avoid probability summation errors!',
    variables: [
      { symbol: 'P(B_j | A)', name: 'Posterior Probability', description: 'Updated belief after seeing evidence A' },
      { symbol: 'P(A | B_j)', name: 'Likelihood', description: 'Probability of evidence given hypothesis B_j' },
      { symbol: 'P(B_j)', name: 'Prior Probability', description: 'Initial belief before observing evidence' }
    ],
    keyInsights: [
      'Denominator P(A) is the marginal evidence normalizing constant ensuring sum of posteriors = 1.',
      'Two non-zero events can NEVER be both mutually exclusive and independent.'
    ],
    tags: ['Probability', 'Bayes Theorem', 'Conditioning', 'Stats 1']
  },

  // ==========================================
  // 5. STATISTICAL INFERENCE & CLT (STATS 2)
  // ==========================================
  {
    id: 'f-s2-clt-ci',
    courseId: 'course-stat-2',
    courseTitle: 'Statistics for Data Science 2',
    courseCode: 'ST1002',
    level: 'Foundation',
    category: 'Statistics',
    title: 'Central Limit Theorem & Normal Confidence Interval',
    formula: 'CI = x_bar +/- z_(alpha/2) * (sigma / sqrt(n))',
    latex: '\\bar{X} \\xrightarrow{d} \\mathcal{N}\\left(\\mu, \\frac{\\sigma^2}{n}\\right), \\quad \\text{CI}_{1-\\alpha} = \\left[ \\bar{x} - z_{\\alpha/2}\\frac{\\sigma}{\\sqrt{n}}, \\, \\bar{x} + z_{\\alpha/2}\\frac{\\sigma}{\\sqrt{n}} \\right]',
    explanation: 'As sample size n >= 30 grows, the distribution of sample mean converges to Gaussian with standard error sigma / sqrt(n).',
    handwrittenNote: 'To halve the margin of error, you MUST quadruple sample size (n -> 4n) because of the square root!',
    variables: [
      { symbol: '\\bar{X}', name: 'Sample Mean', description: 'Unbiased estimator of population mean mu' },
      { symbol: '\\sigma / \\sqrt{n}', name: 'Standard Error (SE)', description: 'Standard deviation of the sampling distribution' },
      { symbol: 'z_{\\alpha/2}', name: 'Critical Z-score', description: '1.96 for 95% confidence, 2.576 for 99% confidence' }
    ],
    keyInsights: [
      'CLT applies even if the underlying population distribution is skewed, exponential, or uniform.',
      'When population sigma is unknown, replace sigma with sample s and use Student-t distribution with df = n - 1.'
    ],
    tags: ['Statistics', 'CLT', 'Confidence Intervals', 'Stats 2']
  },

  // ==========================================
  // 6. ALGORITHMS & MASTER THEOREM (PDSA)
  // ==========================================
  {
    id: 'f-pdsa-master-thm',
    courseId: 'course-pdsa',
    courseTitle: 'Programming, Data Structures & Algorithms',
    courseCode: 'CS2003',
    level: 'Diploma',
    category: 'Algorithms',
    title: 'Master Theorem for Divide-and-Conquer Recurrences',
    formula: 'T(n) = a T(n/b) + O(n^d)',
    latex: 'T(n) = a T(n/b) + O(n^d) \\implies \\begin{cases} O(n^d) & \\text{if } d > \\log_b a \\\\[4pt] O(n^d \\log n) & \\text{if } d = \\log_b a \\\\[4pt] O(n^{\\log_b a}) & \\text{if } d < \\log_b a \\end{cases}',
    explanation: 'Determines the exact asymptotic runtime complexity of divide-and-conquer recursive relations.',
    handwrittenNote: 'Quick trick: Compare f(n) = n^d against the critical exponent c_crit = log_b(a). The larger exponent dominates!',
    variables: [
      { symbol: 'a', name: 'Subproblem Count', description: 'Number of recursive child branches (a >= 1)' },
      { symbol: 'b', name: 'Division Factor', description: 'Factor by which problem size is shrunk (b > 1)' },
      { symbol: 'd', name: 'Work Exponent', description: 'Polynomial power of work done outside recursive calls' }
    ],
    keyInsights: [
      'MergeSort: T(n) = 2T(n/2) + O(n) ==> a=2, b=2, d=1 ==> d = log_2(2) ==> O(n log n).',
      'Binary Search: T(n) = T(n/2) + O(1) ==> a=1, b=2, d=0 ==> d = log_2(1) ==> O(log n).'
    ],
    tags: ['Algorithms', 'Master Theorem', 'Recurrences', 'PDSA']
  },

  // ==========================================
  // 7. MACHINE LEARNING & LOSS FUNCTIONS (MLF)
  // ==========================================
  {
    id: 'f-mlf-ridge-lasso',
    courseId: 'course-mlf-mlt',
    courseTitle: 'Machine Learning Foundations & Techniques',
    courseCode: 'DS2001',
    level: 'Diploma',
    category: 'Machine Learning',
    title: 'Ridge (L2) vs Lasso (L1) Regularized Loss & Feature Selection',
    formula: 'J_Ridge(w) = ||y - Xw||^2 + lambda * ||w||_2^2',
    latex: 'J_{\\text{Ridge}}(\\mathbf{w}) = \\|\\mathbf{y} - X\\mathbf{w}\\|^2 + \\lambda \\sum_{j=1}^p w_j^2, \\quad J_{\\text{Lasso}}(\\mathbf{w}) = \\|\\mathbf{y} - X\\mathbf{w}\\|^2 + \\lambda \\sum_{j=1}^p |w_j|',
    explanation: 'Regularization techniques adding penalty on weight magnitudes to control model complexity and prevent overfitting.',
    handwrittenNote: 'Lasso L1 has diamond constraint with sharp corners on axes -> forces coefficients to EXACTLY zero (Feature selection)!',
    variables: [
      { symbol: '\\lambda', name: 'Regularization Parameter', description: 'Hyperparameter controlling penalty strength (lambda >= 0)' },
      { symbol: '\\|\\mathbf{w}\\|_2', name: 'L2 Euclidean Norm', description: 'Sum of squared weights' },
      { symbol: '\\|\\mathbf{w}\\|_1', name: 'L1 Manhattan Norm', description: 'Sum of absolute weights' }
    ],
    keyInsights: [
      'Ridge closed-form: w = (X^T X + lambda I)^(-1) X^T y (guarantees invertibility even when X^T X is singular).',
      'Lasso has no closed-form solution; solved via coordinate descent or subgradient methods.'
    ],
    tags: ['Machine Learning', 'Regularization', 'Lasso', 'Ridge', 'MLF']
  },

  // ==========================================
  // 8. DEEP LEARNING & TRANSFORMER ATTENTION (DL)
  // ==========================================
  {
    id: 'f-dl-attention',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning',
    courseCode: 'DS3001',
    level: 'Degree',
    category: 'Deep Learning',
    title: 'Scaled Dot-Product Self-Attention in Transformers',
    formula: 'Attention(Q, K, V) = softmax(Q K^T / sqrt(d_k)) * V',
    latex: '\\text{Attention}(Q, K, V) = \\text{softmax}\\left( \\frac{Q K^T}{\\sqrt{d_k}} \\right) V',
    explanation: 'Core calculation mechanism in Transformer architectures mapping queries and keys to attention weights applied over values.',
    handwrittenNote: 'Why divide by sqrt(d_k)? Without scaling, dot products grow huge in large dimensions, pushing softmax into tiny gradient regions!',
    variables: [
      { symbol: 'Q, K, V', name: 'Query, Key, Value', description: 'Linear projections of input embeddings' },
      { symbol: 'd_k', name: 'Key Dimension', description: 'Dimensionality of projection space preventing gradient vanishing' },
      { symbol: '\\text{softmax}', name: 'Normalized Weights', description: 'Exponentiated row-wise probability distribution' }
    ],
    keyInsights: [
      'Computational complexity is O(N^2 * d) where N is sequence context length.',
      'Multi-Head Attention projects inputs into h distinct subspaces: MultiHead(Q, K, V) = Concat(head_1, ..., head_h) W^O.'
    ],
    tags: ['Deep Learning', 'Transformers', 'Self-Attention', 'NLP']
  },
  {
    id: 'f-dl-cnn-size',
    courseId: 'course-dl',
    courseTitle: 'Deep Learning',
    courseCode: 'DS3001',
    level: 'Degree',
    category: 'Deep Learning',
    title: 'Convolutional Layer Spatial Dimension & Parameter Formula',
    formula: 'W_out = floor((W_in - K + 2P) / S) + 1',
    latex: 'W_{\\text{out}} = \\left\\lfloor \\frac{W_{\\text{in}} - K + 2P}{S} \\right\\rfloor + 1, \\quad \\text{Params} = (K_h \\times K_w \\times C_{\\text{in}} + 1) \\times C_{\\text{out}}',
    explanation: 'Calculates the output feature map resolution and total learnable weight parameters in a 2D convolutional layer.',
    handwrittenNote: 'Remember: +1 in parameter count is for the bias term per output channel filter!',
    variables: [
      { symbol: 'W_{\\text{in}}, W_{\\text{out}}', name: 'Spatial Resolution', description: 'Input and output width/height dimensions' },
      { symbol: 'K, P, S', name: 'Hyperparameters', description: 'Kernel size (K), Zero Padding (P), and Stride (S)' },
      { symbol: 'C_{\\text{in}}, C_{\\text{out}}', name: 'Channels', description: 'Input channels and output filter count' }
    ],
    keyInsights: [
      'Same Padding condition: P = (K - 1)/2 with S = 1 preserves exact spatial dimensions (W_out = W_in).',
      'Max Pooling has stride S > 1 with zero learnable parameters.'
    ],
    tags: ['Deep Learning', 'CNN', 'Convolution', 'Feature Maps']
  },

  // ==========================================
  // 9. SOFTWARE TESTING & METRICS (SE)
  // ==========================================
  {
    id: 'f-se-cyclomatic',
    courseId: 'course-st-se',
    courseTitle: 'Software Testing & Software Engineering',
    courseCode: 'CS3002',
    level: 'Degree',
    category: 'Software Engineering',
    title: 'McCabe Cyclomatic Complexity & Independent Paths',
    formula: 'V(G) = E - N + 2P',
    latex: 'V(G) = E - N + 2P = \\text{Predicate Nodes} + 1',
    explanation: 'Quantitative software metric indicating the minimum number of test cases required for 100% basis path execution coverage.',
    handwrittenNote: 'CFG Shortcut: Count binary decision nodes (if / while / for branches) and add 1! Simple and foolproof.',
    variables: [
      { symbol: 'E', name: 'Edges', description: 'Number of directed flow edges in Control Flow Graph (CFG)' },
      { symbol: 'N', name: 'Nodes', description: 'Number of basic block statement nodes' },
      { symbol: 'P', name: 'Connected Components', description: 'Usually P = 1 for a single routine/program' }
    ],
    keyInsights: [
      'V(G) between 1-10: Simple program with low defect risk.',
      'V(G) > 20: High complexity, difficult to test and maintain.',
      'Compound predicates (e.g., if A and B) must be split into two separate predicate nodes.'
    ],
    tags: ['Software Testing', 'Cyclomatic Complexity', 'Control Flow']
  },

  // ==========================================
  // 10. BS DEGREE LEVEL (TERMS 9-12 / 4TH YEAR ADVANCED)
  // ==========================================
  {
    id: 'f-bs-genai-diffusion',
    courseId: 'course-bs-genai',
    courseTitle: 'Deep Learning & Advanced Generative AI',
    courseCode: 'DS4001',
    level: 'BS Degree',
    category: 'Deep Learning',
    title: 'Denoising Diffusion Probabilistic Model (DDPM) Sampling & Loss',
    formula: 'q(x_t|x_0) = N(x_t; sqrt(alpha_bar_t) * x_0, (1 - alpha_bar_t) * I)',
    latex: 'q(x_t | x_0) = \\mathcal{N}\\left(x_t; \\sqrt{\\bar{\\alpha}_t} x_0, (1 - \\bar{\\alpha}_t) \\mathbf{I}\\right), \\quad \\mathcal{L}_{\\text{simple}}(\\theta) = \\mathbb{E}_{t, x_0, \\epsilon}\\left[\\|\\epsilon - \\epsilon_\\theta(x_t, t)\\|^2\\right]',
    explanation: 'Calculates the closed-form forward Gaussian diffusion state x_t from initial data x_0, and defines the simplified mean-squared error noise prediction training loss.',
    handwrittenNote: 'Trick: alpha_bar_t is the cumulative product of (1 - beta_s). At t = T, alpha_bar_t ≈ 0, turning any image into pure white Gaussian noise.',
    variables: [
      { symbol: 'x_t', name: 'Noisy Latent', description: 'Sample representation at forward diffusion timestep t' },
      { symbol: '\\bar{\\alpha}_t', name: 'Signal Ratio', description: 'Cumulative product \\prod_{s=1}^t (1 - \\beta_s)' },
      { symbol: '\\epsilon_\\theta(x_t, t)', name: 'Neural Estimator', description: 'U-Net neural network trained to predict standard Gaussian noise \\epsilon' }
    ],
    keyInsights: [
      'Allows jump-sampling any diffusion step t directly without simulating intermediate steps 1 to t-1.',
      'LoRA fine-tuning freezes base U-Net weights and optimizes low-rank matrices B * A on attention projections.'
    ],
    tags: ['Generative AI', 'Diffusion Models', 'DDPM', 'LoRA', 'Score Matching']
  },
  {
    id: 'f-bs-rl-bellman',
    courseId: 'course-bs-rl',
    courseTitle: 'AI Search Methods & Reinforcement Learning',
    courseCode: 'CS4001',
    level: 'BS Degree',
    category: 'Algorithms',
    title: 'Bellman Optimality Equation & Q-Learning TD Control',
    formula: 'Q*(s, a) = R(s, a) + gamma * sum(P(s\'|s, a) * max_a\' Q*(s\', a\'))',
    latex: 'Q^*(s, a) = \\sum_{s\', r} p(s\', r | s, a) \\left[ r + \\gamma \\max_{a\'} Q^*(s\', a\') \\right], \\quad Q(s, a) \\leftarrow Q(s, a) + \\alpha \\delta_t',
    explanation: 'Fundamental dynamic programming relation defining optimal action-value functions, and the off-policy temporal difference update rule.',
    handwrittenNote: 'TD Error: delta_t = R_{t+1} + gamma * max_a Q(S_{t+1}, a) - Q(S_t, A_t). Notice max operator makes it off-policy!',
    variables: [
      { symbol: 'Q^*(s, a)', name: 'Optimal Action-Value', description: 'Expected discounted return from state s taking action a under optimal policy' },
      { symbol: '\\gamma', name: 'Discount Factor', description: 'Temporal horizon discount (0 <= \\gamma < 1)' },
      { symbol: '\\alpha', name: 'Learning Rate', description: 'Step size for stochastic gradient/TD updates' }
    ],
    keyInsights: [
      'Bellman optimality operator is a contraction mapping with contraction factor \\gamma in L_infinity norm.',
      'Policy Gradient Theorem: \\nabla_\\theta J(\\theta) = E[\\nabla_\\theta \\log \\pi_\\theta(a|s) Q^\\pi(s, a)].'
    ],
    tags: ['Reinforcement Learning', 'Bellman Equation', 'Q-Learning', 'Policy Gradient']
  },
  {
    id: 'f-bs-nlp-rope',
    courseId: 'course-bs-nlp-speech',
    courseTitle: 'Natural Language Processing (NLP) & Speech Technology',
    courseCode: 'DS4002',
    level: 'BS Degree',
    category: 'Machine Learning',
    title: 'Rotary Position Embedding (RoPE) Relative Attention',
    formula: '<R_m q, R_n k> = g(q, k, m - n)',
    latex: '\\mathbf{q}_m = \\mathbf{R}_{\\Theta, m}^d \\mathbf{W}_q \\mathbf{x}_m, \\quad \\langle \\mathbf{q}_m, \\mathbf{k}_n \\rangle = \\text{Re}\\left[ (\\mathbf{W}_q \\mathbf{x}_m)^* (\\mathbf{W}_k \\mathbf{x}_n) e^{i(m-n)\\theta} \\right]',
    explanation: 'Encodes positional information into transformer representations through complex 2D rotation blocks, yielding dot product attention that naturally decays with relative token distance.',
    handwrittenNote: 'Why RoPE dominates: Absolute vectors are never added to input embeddings! Rotary phase difference (m - n) preserves relative context effortlessly.',
    variables: [
      { symbol: '\\mathbf{R}_{\\Theta, m}^d', name: 'Rotation Matrix', description: 'Orthogonal block diagonal matrix rotating 2D subspace by m * \\theta_i' },
      { symbol: 'm, n', name: 'Token Positions', description: 'Sequence index of Query and Key tokens' },
      { symbol: '\\theta_i', name: 'Base Frequency', description: '\\theta_i = 10000^{-2(i-1)/d}' }
    ],
    keyInsights: [
      'Multi-Query Attention (MQA) & Grouped-Query Attention (GQA) reduce KV cache memory by sharing Key/Value heads across Query heads.',
      'CTC loss aligns speech acoustic frames by summing probabilities across all valid duplicate/blank collapsing paths.'
    ],
    tags: ['NLP', 'Transformers', 'RoPE', 'Attention', 'Speech Technology']
  },
  {
    id: 'f-bs-robotics-ekf',
    courseId: 'course-bs-robotics-ai',
    courseTitle: 'Autonomous Systems & Robotics AI',
    courseCode: 'CS4003',
    level: 'BS Degree',
    category: 'Databases & Systems',
    title: 'Extended Kalman Filter (EKF) Gain & Covariance Update',
    formula: 'K_k = P_k^- * H_k^T * (H_k * P_k^- * H_k^T + R_k)^(-1)',
    latex: '\\mathbf{K}_k = \\mathbf{P}_k^- \\mathbf{H}_k^T \\left( \\mathbf{H}_k \\mathbf{P}_k^- \\mathbf{H}_k^T + \\mathbf{R}_k \\right)^{-1}, \\quad \\mathbf{P}_k = (\\mathbf{I} - \\mathbf{K}_k \\mathbf{H}_k) \\mathbf{P}_k^-',
    explanation: 'Calculates the optimal Kalman Gain matrix for non-linear robot state estimation and computes the reduced posterior error covariance.',
    handwrittenNote: 'Intuition: K is the ratio of prediction uncertainty P^- to total uncertainty (P^- + R). High sensor noise R => smaller gain K.',
    variables: [
      { symbol: '\\mathbf{K}_k', name: 'Kalman Gain', description: 'Weighting matrix balancing motion model vs sensor observation' },
      { symbol: '\\mathbf{P}_k^-', name: 'Prior Covariance', description: 'Predicted state covariance matrix before sensor measurement' },
      { symbol: '\\mathbf{H}_k', name: 'Measurement Jacobian', description: 'First-order Taylor expansion matrix of sensor observation function h(x)' },
      { symbol: '\\mathbf{R}_k', name: 'Sensor Noise', description: 'Measurement noise covariance matrix' }
    ],
    keyInsights: [
      'In SLAM (Simultaneous Localization & Mapping), state vector x contains both robot pose (x, y, \\theta) and landmark coordinates (m_1, ..., m_N).',
      'Loop closure constraints add off-diagonal blocks to information matrix, eliminating accumulated drift.'
    ],
    tags: ['Robotics', 'EKF', 'Kalman Filter', 'SLAM', 'State Estimation']
  },
  {
    id: 'f-bs-capstone-cohen',
    courseId: 'course-bs-capstone-viva',
    courseTitle: 'Capstone Research Project & Mock Viva',
    courseCode: 'DS4004',
    level: 'BS Degree',
    category: 'Statistics',
    title: 'Cohen\'s d Effect Size & Multi-Hypothesis Bonferroni Correction',
    formula: 'd = (x_bar_1 - x_bar_2) / s_pooled, alpha_corr = alpha / k',
    latex: 'd = \\frac{\\bar{x}_1 - \\bar{x}_2}{s_{\\text{pooled}}}, \\quad s_{\\text{pooled}} = \\sqrt{\\frac{(n_1 - 1)s_1^2 + (n_2 - 1)s_2^2}{n_1 + n_2 - 2}}, \\quad \\alpha_{\\text{Bonferroni}} = \\frac{\\alpha}{k}',
    explanation: 'Standardized statistical effect size metric measuring true practical impact of a proposed ML method regardless of sample size, alongside family-wise error rate control.',
    handwrittenNote: 'Viva Gold: p-value tests "is difference non-zero?"; Cohen\'s d tests "is difference large enough to matter?" (d >= 0.8 is large).',
    variables: [
      { symbol: 'd', name: 'Effect Size', description: 'Standardized mean difference (0.2: small, 0.5: medium, 0.8: large)' },
      { symbol: '\\bar{x}_1, \\bar{x}_2', name: 'Sample Means', description: 'Mean metric scores (e.g. Accuracy or BLEU) for Proposed Model vs Baseline' },
      { symbol: 'k', name: 'Comparisons', description: 'Total number of hypothesis tests / datasets evaluated' }
    ],
    keyInsights: [
      'Guarantees Family-Wise Error Rate (FWER) <= \\alpha when performing k benchmark comparisons.',
      'Ablation studies must evaluate statistical significance across repeated seeded runs (e.g. 5 seeds with confidence intervals).'
    ],
    tags: ['Capstone', 'Statistical Power', 'Effect Size', 'Ablation Study', 'Viva Prep']
  }
];

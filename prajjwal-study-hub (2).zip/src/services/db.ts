import { 
  Program, 
  Course, 
  Module, 
  Topic, 
  Note, 
  FormulaSheet, 
  Question, 
  MockTest, 
  StudyPlanTask, 
  BookmarkItem, 
  TestAttempt,
  ContactMessage
} from '../types';
import { db } from './firebase';
import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  deleteDoc, 
  updateDoc 
} from 'firebase/firestore';
import { PYQ_QUESTIONS, FULL_CBT_MOCK_TESTS } from '../data/pyqQuestionBank';

// Keys for local storage persistence
const STORAGE_KEYS = {
  PROGRAMS: 'psh_programs',
  COURSES: 'psh_courses',
  MODULES: 'psh_modules',
  TOPICS: 'psh_topics',
  NOTES: 'psh_notes',
  FORMULAS: 'psh_formulas',
  QUESTIONS: 'psh_questions',
  MOCK_TESTS: 'psh_mock_tests',
  STUDY_PLANS: 'psh_study_plans',
  BOOKMARKS: 'psh_bookmarks',
  TEST_ATTEMPTS: 'psh_test_attempts',
  CONTACT_MESSAGES: 'psh_contact_messages',
};

// Initial Seed Data (Foundation, Diploma, Degree Levels for IIT Madras BS Degree Independent Preparation)
const SEED_PROGRAMS: Program[] = [
  {
    id: 'prog-bs-foundation',
    title: 'Foundation Level (Term 1 & 2)',
    code: 'BS-FOUNDATION',
    description: 'Foundational mathematics, computational thinking, statistics, Python programming, and academic English.',
    level: 'Foundation',
    published: true,
    coursesCount: 7,
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prog-diploma-ds',
    title: 'Diploma Level (Programming & Data Science)',
    code: 'DIP-DS',
    description: 'Advanced Java programming, DBMS, PDSA, Machine Learning Foundations & Practice, and Business Analytics.',
    level: 'Diploma',
    published: true,
    coursesCount: 6,
    createdAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prog-degree-bs',
    title: 'BSc Degree Level (Advanced Specializations)',
    code: 'DEG-BS',
    description: 'Deep Learning, AI Search Methods, Software Testing & Engineering, and Big Data & Cloud Computing.',
    level: 'Degree',
    published: true,
    coursesCount: 4,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_COURSES: Course[] = [
  // Foundation
  {
    id: 'course-math-1',
    programId: 'prog-bs-foundation',
    title: 'Mathematics for Data Science 1',
    code: 'MA1001',
    description: 'Linear equations, matrices, determinants, vector spaces, coordinate geometry, functions, limits, continuity, and single variable differentiation.',
    term: 'Term 1',
    credit: 4,
    category: 'Mathematics',
    color: 'blue',
    iconName: 'Calculator',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-math-2',
    programId: 'prog-bs-foundation',
    title: 'Mathematics for Data Science 2',
    code: 'MA1002',
    description: 'Multivariable calculus, partial derivatives, gradients, Hessians, unconstrained optimization, linear algebra transformations, eigenvalues and eigenvectors.',
    term: 'Term 2',
    credit: 4,
    category: 'Mathematics',
    color: 'indigo',
    iconName: 'Sigma',
    published: true,
    createdAt: new Date(Date.now() - 26 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-stat-1',
    programId: 'prog-bs-foundation',
    title: 'Statistics for Data Science 1',
    code: 'ST1001',
    description: 'Descriptive statistics, probability theory, discrete and continuous random variables, probability mass and density functions, and expectation.',
    term: 'Term 1',
    credit: 4,
    category: 'Statistics',
    color: 'emerald',
    iconName: 'BarChart3',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-stat-2',
    programId: 'prog-bs-foundation',
    title: 'Statistics for Data Science 2',
    code: 'ST1002',
    description: 'Sampling distributions, central limit theorem, hypothesis testing, p-values, confidence intervals, ANOVA, and simple linear regression.',
    term: 'Term 2',
    credit: 4,
    category: 'Statistics',
    color: 'teal',
    iconName: 'LineChart',
    published: true,
    createdAt: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-ct',
    programId: 'prog-bs-foundation',
    title: 'Computational Thinking',
    code: 'CS1001',
    description: 'Algorithmic reasoning, flowchart synthesis, data dataset pattern matching, loop invariants, state transitions, and pseudocode design.',
    term: 'Term 1',
    credit: 4,
    category: 'Core CS',
    color: 'violet',
    iconName: 'Cpu',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-python',
    programId: 'prog-bs-foundation',
    title: 'Introduction to Python Programming',
    code: 'CS1002',
    description: 'Core Python syntax, control flow, functions, recursion, list comprehensions, dictionary indexing, file I/O, and OOP principles.',
    term: 'Term 1',
    credit: 4,
    category: 'Programming',
    color: 'amber',
    iconName: 'Code',
    published: true,
    createdAt: new Date(Date.now() - 27 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-eng-1-2',
    programId: 'prog-bs-foundation',
    title: 'English 1 & 2',
    code: 'ENG1001',
    description: 'Academic reading comprehension, professional vocabulary, grammatical syntax, error analysis, and essay structuring.',
    term: 'Term 1 & 2',
    credit: 4,
    category: 'Humanities',
    color: 'sky',
    iconName: 'BookOpen',
    published: true,
    createdAt: new Date(Date.now() - 27 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },

  // Diploma Level
  {
    id: 'course-java',
    programId: 'prog-diploma-ds',
    title: 'Programming in Java',
    code: 'CS2002',
    description: 'Object-oriented programming, inheritance, polymorphism, encapsulation, generics, collections, multithreading, and stream API.',
    term: 'Term 3',
    credit: 4,
    category: 'Programming',
    color: 'orange',
    iconName: 'Coffee',
    published: true,
    createdAt: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-dbms',
    programId: 'prog-diploma-ds',
    title: 'Database Management Systems',
    code: 'CS2001',
    description: 'Relational data models, SQL queries, relational algebra, normal forms (1NF to BCNF), indexing, transaction management, and ACID properties.',
    term: 'Term 3',
    credit: 4,
    category: 'Core CS',
    color: 'cyan',
    iconName: 'Database',
    published: true,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-pdsa',
    programId: 'prog-diploma-ds',
    title: 'Programming, Data Structures & Algorithms (PDSA)',
    code: 'CS2003',
    description: 'Algorithm complexity, asymptotic bounds, sorting, searching, binary search trees, heaps, graph algorithms, and dynamic programming.',
    term: 'Term 4',
    credit: 4,
    category: 'Programming',
    color: 'purple',
    iconName: 'Binary',
    published: true,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-mlf-mlt',
    programId: 'prog-diploma-ds',
    title: 'Machine Learning Foundations & Techniques',
    code: 'DS2001',
    description: 'Supervised & unsupervised paradigms, regularized regression, gradient descent, SVM, decision trees, boosting, bagging, and PCA.',
    term: 'Term 4',
    credit: 4,
    category: 'Data Science',
    color: 'rose',
    iconName: 'BrainCircuit',
    published: true,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-mlp',
    programId: 'prog-diploma-ds',
    title: 'Machine Learning Practice (MLP)',
    code: 'DS2003',
    description: 'Hands-on scikit-learn model building, pipeline engineering, hyperparameter cross validation, and performance evaluation metrics.',
    term: 'Term 5',
    credit: 4,
    category: 'Data Science',
    color: 'pink',
    iconName: 'Cpu',
    published: true,
    createdAt: new Date(Date.now() - 19 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-ba-dv',
    programId: 'prog-diploma-ds',
    title: 'Business Analytics & Data Visualization',
    code: 'BA2001',
    description: 'Exploratory data analysis, visual storytelling, business KPI synthesis, cohort retention metrics, and dashboard design principles.',
    term: 'Term 5',
    credit: 4,
    category: 'Data Science',
    color: 'yellow',
    iconName: 'PieChart',
    published: true,
    createdAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },

  // Degree Level
  {
    id: 'course-dl',
    programId: 'prog-degree-bs',
    title: 'Deep Learning (DL)',
    code: 'DS3001',
    description: 'Multilayer perceptrons, backpropagation calculus, CNN convolutions, RNN/LSTM/GRU networks, and attention mechanisms.',
    term: 'Term 6',
    credit: 4,
    category: 'Data Science',
    color: 'fuchsia',
    iconName: 'Layers',
    published: true,
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-ai-search',
    programId: 'prog-degree-bs',
    title: 'Artificial Intelligence: Search Methods',
    code: 'CS3001',
    description: 'Uninformed & informed search, A* heuristic admissibility proofs, minimax with alpha-beta pruning, CSP, and local beam search.',
    term: 'Term 6',
    credit: 4,
    category: 'Core CS',
    color: 'red',
    iconName: 'Search',
    published: true,
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-st-se',
    programId: 'prog-degree-bs',
    title: 'Software Testing & Software Engineering',
    code: 'CS3002',
    description: 'Control flow graphs, McCabe cyclomatic complexity, basis path testing, boundary value analysis, equivalence partitioning, and CI/CD.',
    term: 'Term 7',
    credit: 4,
    category: 'Core CS',
    color: 'emerald',
    iconName: 'ShieldCheck',
    published: true,
    createdAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'course-bigdata-cloud',
    programId: 'prog-degree-bs',
    title: 'Big Data & Cloud Computing',
    code: 'CS3003',
    description: 'MapReduce paradigm, Apache Spark RDD/DataFrames, HDFS distributed storage, CAP theorem trade-offs, and cloud scalability.',
    term: 'Term 7',
    credit: 4,
    category: 'Core CS',
    color: 'cyan',
    iconName: 'Cloud',
    published: true,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_MODULES: Module[] = [
  {
    id: 'mod-m1-w1',
    courseId: 'course-math-1',
    title: 'Week 1: Real Numbers, Coordinate Geometry & Lines',
    weekNumber: 1,
    description: 'Number sets, Cartesian planes, equations of lines, slopes, intercepts, and Euclidean distances.',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'mod-m1-w2',
    courseId: 'course-math-1',
    title: 'Week 2: Functions, Domain & Range',
    weekNumber: 2,
    description: 'Function mappings, injectivity, surjectivity, composition, inverse functions, and polynomial properties.',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'mod-m1-w3',
    courseId: 'course-math-1',
    title: 'Week 3: Quadratic Functions & Polynomials',
    weekNumber: 3,
    description: 'Roots, discriminant analysis, vertex formulas, parabolic curves, and polynomial division.',
    published: true,
    createdAt: new Date(Date.now() - 27 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'mod-s1-w1',
    courseId: 'course-stat-1',
    title: 'Week 1: Introduction to Data & Descriptive Statistics',
    weekNumber: 1,
    description: 'Types of variables, frequency tables, histograms, measures of central tendency (mean, median, mode).',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'mod-s1-w2',
    courseId: 'course-stat-1',
    title: 'Week 2: Measures of Dispersion & Association',
    weekNumber: 2,
    description: 'Variance, standard deviation, IQR, box plots, covariance, and Pearson correlation coefficients.',
    published: true,
    createdAt: new Date(Date.now() - 27 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'mod-py-w1',
    courseId: 'course-python',
    title: 'Week 1: Fundamentals of Python & Control Structures',
    weekNumber: 1,
    description: 'Data types, operators, conditional branching (if/elif/else), and iterative loops (for/while).',
    published: true,
    createdAt: new Date(Date.now() - 26 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_TOPICS: Topic[] = [
  {
    id: 'top-m1-w1-t1',
    moduleId: 'mod-m1-w1',
    courseId: 'course-math-1',
    title: 'Slope-Intercept & Point-Slope Forms',
    order: 1,
    description: 'Derivation and geometric interpretation of linear equations in 2D space.',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'top-m1-w1-t2',
    moduleId: 'mod-m1-w1',
    courseId: 'course-math-1',
    title: 'Distance Between Points and Lines',
    order: 2,
    description: 'Perpendicular distance formula and intersection coordinates.',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'top-s1-w1-t1',
    moduleId: 'mod-s1-w1',
    courseId: 'course-stat-1',
    title: 'Mean, Median, and Mode Calculation',
    order: 1,
    description: 'Formulas and robust statistical properties in skewed distributions.',
    published: true,
    createdAt: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'top-py-w1-t1',
    moduleId: 'mod-py-w1',
    courseId: 'course-python',
    title: 'Loops and List Operations in Python',
    order: 1,
    description: 'Iterating sequences, list slicing, appending, and accumulator patterns.',
    published: true,
    createdAt: new Date(Date.now() - 26 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_NOTES: Note[] = [
  {
    id: 'note-math-1-w1',
    title: 'Mathematics I: Coordinate Geometry & Straight Lines Summary',
    description: 'Complete revision notes covering slope calculation, parallel and perpendicular lines, intercepts, and distance formulas with solved examples.',
    programId: 'prog-bs-foundation',
    courseId: 'course-math-1',
    moduleId: 'mod-m1-w1',
    topicId: 'top-m1-w1-t1',
    authorName: 'Prajjwal Study Team',
    uploadedBy: 'admin',
    tags: ['Coordinate Geometry', 'Straight Lines', 'Slope', 'Week 1', 'Math 1'],
    readingTimeMinutes: 12,
    fileSize: '1.4 MB',
    fileName: 'Math1_Week1_Coordinate_Geometry_Summary.pdf',
    fileUrl: '#',
    contentMarkdown: `### 1. Straight Lines & Coordinate Geometry

A straight line in two dimensions can be expressed in various standard forms:

- **Slope-Intercept Form:**
  $$y = mx + c$$
  where $m$ is the slope ($\\tan \\theta$) and $c$ is the y-intercept.

- **Point-Slope Form:**
  $$y - y_1 = m(x - x_1)$$

- **Two-Point Form:**
  $$y - y_1 = \\frac{y_2 - y_1}{x_2 - x_1}(x - x_1)$$

- **General Form:**
  $$Ax + By + C = 0$$
  Slope $m = -\\frac{A}{B}$, x-intercept $= -\\frac{C}{A}$, y-intercept $= -\\frac{C}{B}$.

### 2. Angle and Relationships Between Two Lines
Let two lines have slopes $m_1$ and $m_2$:
- **Parallel Lines:** $m_1 = m_2$
- **Perpendicular Lines:** $m_1 \\cdot m_2 = -1$ (or $A_1 A_2 + B_1 B_2 = 0$)
- **Acute Angle $\\theta$ between them:**
  $$\\tan \\theta = \\left| \\frac{m_2 - m_1}{1 + m_1 m_2} \\right|$$

### 3. Perpendicular Distance Formula
The perpendicular distance $d$ from point $(x_0, y_0)$ to line $Ax + By + C = 0$ is:
$$d = \\frac{|A x_0 + B y_0 + C|}{\\sqrt{A^2 + B^2}}$$
`,
    published: true,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'note-stat-1-w1',
    title: 'Statistics I: Descriptive Statistics & Summary Measures',
    description: 'Concise summary of central tendencies, dispersion, standard deviation, interquartile range (IQR), and skewness with visual breakdown.',
    programId: 'prog-bs-foundation',
    courseId: 'course-stat-1',
    moduleId: 'mod-s1-w1',
    topicId: 'top-s1-w1-t1',
    authorName: 'Prajjwal Study Team',
    uploadedBy: 'admin',
    tags: ['Descriptive Statistics', 'Mean', 'Median', 'Variance', 'Week 1', 'Stats 1'],
    readingTimeMinutes: 15,
    fileSize: '2.1 MB',
    fileName: 'Stats1_Week1_Descriptive_Statistics.pdf',
    fileUrl: '#',
    contentMarkdown: `### 1. Measures of Central Tendency

- **Arithmetic Mean (Sample):**
  $$\\bar{x} = \\frac{1}{n}\\sum_{i=1}^n x_i$$

- **Median:**
  The middle observation when data is arranged in ascending order.
  - If $n$ is odd: value at $\\frac{n+1}{2}$-th position.
  - If $n$ is even: average of $\\frac{n}{2}$-th and $(\\frac{n}{2}+1)$-th values.

- **Mode:**
  The value that appears with highest frequency.

### 2. Measures of Dispersion
- **Sample Variance ($s^2$):**
  $$s^2 = \\frac{1}{n-1}\\sum_{i=1}^n (x_i - \\bar{x})^2$$

- **Standard Deviation ($s$):**
  $$s = \\sqrt{s^2}$$

- **Interquartile Range (IQR):**
  $$IQR = Q_3 - Q_1$$
  - Lower Outlier Threshold: $Q_1 - 1.5 \\times IQR$
  - Upper Outlier Threshold: $Q_3 + 1.5 \\times IQR$
`,
    published: true,
    createdAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'note-python-w1',
    title: 'Python Programming: Syntax, Collections & Control Flow Handbook',
    description: 'High-yield cheat sheet of Python expressions, data types, mutable vs immutable structures, iteration patterns, and list comprehensions.',
    programId: 'prog-bs-foundation',
    courseId: 'course-python',
    moduleId: 'mod-py-w1',
    topicId: 'top-py-w1-t1',
    authorName: 'Prajjwal Study Team',
    uploadedBy: 'admin',
    tags: ['Python', 'Lists', 'Dictionaries', 'Loops', 'Cheat Sheet'],
    readingTimeMinutes: 10,
    fileSize: '1.1 MB',
    fileName: 'Python_Foundations_Core_Syntax.pdf',
    fileUrl: '#',
    contentMarkdown: `### Python Key Fundamentals

#### 1. Core Data Structures
- **Lists (Mutable):** \`nums = [1, 2, 3]\` -> \`nums.append(4)\`
- **Tuples (Immutable):** \`coords = (10.5, 20.3)\`
- **Sets (Unique elements):** \`uniq = {1, 2, 3, 3}\` -> \`{1, 2, 3}\`
- **Dictionaries (Key-Value):** \`scores = {'alice': 95, 'bob': 88}\`

#### 2. Comprehensions
\`\`\`python
# Squared even numbers
evens_squared = [x**2 for x in range(10) if x % 2 == 0]
# Output: [0, 4, 16, 36, 64]
\`\`\`

#### 3. Common Pitfalls
- **Default mutable arguments:** Avoid \`def func(items=[])\`, use \`def func(items=None)\`.
- **Deep copy vs shallow copy:** Use \`import copy; copy.deepcopy(obj)\` for nested structures.
`,
    published: true,
    createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_FORMULAS: FormulaSheet[] = [
  {
    id: 'form-m1-01',
    title: 'Distance of a Point from a Straight Line',
    courseId: 'course-math-1',
    topicId: 'top-m1-w1-t2',
    formula: 'd = |Ax_0 + By_0 + C| / sqrt(A^2 + B^2)',
    latex: 'd = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}',
    explanation: 'Calculates the shortest perpendicular Euclidean distance from an arbitrary point (x0, y0) to the line represented by Ax + By + C = 0.',
    keyPoints: [
      'Applicable in 2D Cartesian plane',
      'The sign inside modulus indicates on which side of the line the point lies',
      'Denominator represents the Euclidean norm of the normal vector (A, B)'
    ],
    variables: [
      { symbol: 'd', meaning: 'Perpendicular distance' },
      { symbol: '(x_0, y_0)', meaning: 'Coordinates of the given point' },
      { symbol: 'A, B, C', meaning: 'Coefficients of the general line equation' }
    ],
    tags: ['Coordinate Geometry', 'Distance Formula', 'Lines', 'Math 1'],
    published: true,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'form-m1-02',
    title: 'Angle Between Two Straight Lines',
    courseId: 'course-math-1',
    topicId: 'top-m1-w1-t1',
    formula: 'tan(theta) = |(m_2 - m_1) / (1 + m_1 * m_2)|',
    latex: '\\tan \\theta = \\left| \\frac{m_2 - m_1}{1 + m_1 m_2} \\right|',
    explanation: 'Gives the tangent of the acute angle theta formed between two intersecting non-vertical lines with slopes m1 and m2.',
    keyPoints: [
      'Lines are perpendicular when m1 * m2 = -1',
      'Lines are parallel when m1 = m2',
      'If 1 + m1*m2 = 0, angle is 90 degrees'
    ],
    variables: [
      { symbol: 'm_1, m_2', meaning: 'Slopes of line 1 and line 2' },
      { symbol: '\\theta', meaning: 'Acute angle between the lines' }
    ],
    tags: ['Slopes', 'Angles', 'Perpendicularity', 'Math 1'],
    published: true,
    createdAt: new Date(Date.now() - 19 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'form-s1-01',
    title: 'Sample Variance & Standard Deviation',
    courseId: 'course-stat-1',
    topicId: 'top-s1-w1-t1',
    formula: 's^2 = sum((x_i - mean)^2) / (n - 1)',
    latex: 's^2 = \\frac{1}{n-1}\\sum_{i=1}^n (x_i - \\bar{x})^2',
    explanation: 'Unbiased sample variance using Bessel correction (n - 1 degrees of freedom) to estimate true population variance from sample data.',
    keyPoints: [
      'Division by (n - 1) corrects downward bias in sample variance',
      'Standard deviation is the square root of variance, measuring spread in original units'
    ],
    variables: [
      { symbol: 's^2', meaning: 'Sample variance' },
      { symbol: 'x_i', meaning: 'Individual data observation' },
      { symbol: '\\bar{x}', meaning: 'Sample mean' },
      { symbol: 'n', meaning: 'Sample size' }
    ],
    tags: ['Dispersion', 'Variance', 'Standard Deviation', 'Stats 1'],
    published: true,
    createdAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'form-s1-02',
    title: 'Pearson Product-Moment Correlation Coefficient',
    courseId: 'course-stat-1',
    topicId: 'top-s1-w1-t1',
    formula: 'r = Cov(X, Y) / (s_x * s_y)',
    latex: 'r = \\frac{\\sum (x_i - \\bar{x})(y_i - \\bar{y})}{\\sqrt{\\sum (x_i - \\bar{x})^2 \\sum (y_i - \\bar{y})^2}}',
    explanation: 'Measures linear relationship strength and direction between two continuous variables X and Y, bounded strictly between -1 and +1.',
    keyPoints: [
      '-1 indicates perfect negative linear correlation',
      '+1 indicates perfect positive linear correlation',
      '0 indicates no linear association (does not rule out non-linear relationships)'
    ],
    variables: [
      { symbol: 'r', meaning: 'Pearson correlation coefficient' },
      { symbol: 's_x, s_y', meaning: 'Standard deviations of X and Y' }
    ],
    tags: ['Correlation', 'Bivariate Analysis', 'Stats 1'],
    published: true,
    createdAt: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_QUESTIONS: Question[] = [
  ...PYQ_QUESTIONS,
  {
    id: 'q-m1-01',
    courseId: 'course-math-1',
    courseTitle: 'Mathematics for Data Science 1',
    level: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    type: 'MCQ',
    questionText: 'What is the slope of a line that is perpendicular to the line given by 3x - 4y + 12 = 0?',
    options: ['3/4', '-4/3', '4/3', '-3/4'],
    correctOptionIndex: 1,
    explanation: 'First, find the slope of 3x - 4y + 12 = 0 => 4y = 3x + 12 => y = (3/4)x + 3. The slope m1 = 3/4. For a perpendicular line, m2 = -1 / m1 = -1 / (3/4) = -4/3.',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Qualifier 2022',
    tags: ['Coordinate Geometry', 'Slopes'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'q-s1-01',
    courseId: 'course-stat-1',
    courseTitle: 'Statistics for Data Science 1',
    level: 'Foundation',
    subject: 'Statistics for Data Science 1',
    type: 'MCQ',
    questionText: 'If a dataset has values [4, 8, 6, 5, 3, 7], what is the sample median?',
    options: ['5.0', '5.5', '6.0', '5.8'],
    correctOptionIndex: 1,
    explanation: 'First, arrange data in ascending order: [3, 4, 5, 6, 7, 8]. Since n = 6 (even), the median is the mean of the 3rd and 4th values: (5 + 6) / 2 = 5.5.',
    difficulty: 'Easy',
    marks: 2,
    negativeMarks: 0,
    term: 'Term 1',
    pyqYear: 'Qualifier 2022',
    tags: ['Descriptive Statistics', 'Median'],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

const SEED_MOCK_TESTS: MockTest[] = [
  ...FULL_CBT_MOCK_TESTS,
  {
    id: 'test-m1-quiz1',
    title: 'Mathematics 1: Term 1 Speed & Foundations Mock',
    courseId: 'course-math-1',
    level: 'Foundation',
    subject: 'Mathematics for Data Science 1',
    programId: 'prog-bs-foundation',
    type: 'Quiz 1',
    durationMinutes: 60,
    totalMarks: 50,
    passingMarks: 20,
    totalQuestions: 25,
    difficulty: 'Exam Standard',
    instructions: [
      'Independent practice test strictly modelled after the BS Foundation Quiz 1 syllabus (Weeks 1-4).',
      'Scientific calculator is permitted.',
      'Mark each question carefully; review flagged questions before final submission.'
    ],
    questionIds: ['pyq-m1-01', 'pyq-m1-02', 'q-m1-01'],
    availableFrom: new Date().toISOString(),
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'test-s1-quiz1',
    title: 'Statistics 1: Descriptive Stats & Probability Practice',
    courseId: 'course-stat-1',
    level: 'Foundation',
    subject: 'Statistics for Data Science 1',
    programId: 'prog-bs-foundation',
    type: 'Quiz 1',
    durationMinutes: 60,
    totalMarks: 50,
    passingMarks: 20,
    totalQuestions: 25,
    difficulty: 'Exam Standard',
    instructions: [
      'Covers Descriptive Statistics, Probability Axioms, and Conditional Probability.',
      'Each question has four options with single correct answer.'
    ],
    questionIds: ['pyq-s1-01', 'q-s1-01'],
    availableFrom: new Date().toISOString(),
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'test-py-quiz1',
    title: 'Python Programming: Loops & Recursion Timed CBT',
    courseId: 'course-python',
    level: 'Foundation',
    subject: 'Introduction to Python Programming',
    programId: 'prog-bs-foundation',
    type: 'Quiz 1',
    durationMinutes: 45,
    totalMarks: 40,
    passingMarks: 16,
    totalQuestions: 20,
    difficulty: 'Medium',
    instructions: [
      'Tests dry run of Python code snippets, recursion traces, and algorithm time complexity.',
      'No IDE execution allowed during mock attempt.'
    ],
    questionIds: ['pyq-py-01', 'pyq-ct-01'],
    availableFrom: new Date().toISOString(),
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

// Helper to load or initialize local data and ensure new seed entries are merged
function getStored<T>(key: string, seed: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) {
      localStorage.setItem(key, JSON.stringify(seed));
      return seed;
    }
    const parsed = JSON.parse(item);
    if (Array.isArray(parsed) && Array.isArray(seed)) {
      const existingIds = new Set(parsed.map((x: any) => x?.id));
      let hasUpdates = false;
      const merged = [...parsed];
      for (const s of seed) {
        if (s?.id && !existingIds.has(s.id)) {
          merged.push(s);
          existingIds.add(s.id);
          hasUpdates = true;
        }
      }
      if (hasUpdates) {
        localStorage.setItem(key, JSON.stringify(merged));
      }
      return merged as T;
    }
    return parsed;
  } catch (err) {
    console.error(`Error reading ${key} from storage:`, err);
    return seed;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error writing ${key} to storage:`, err);
  }
}

export const dbService = {
  // Programs
  getPrograms: (): Program[] => getStored<Program[]>(STORAGE_KEYS.PROGRAMS, SEED_PROGRAMS),
  saveProgram: (program: Program): void => {
    const list = dbService.getPrograms();
    const index = list.findIndex(p => p.id === program.id);
    if (index >= 0) {
      list[index] = { ...program, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...program, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.PROGRAMS, list);
  },
  deleteProgram: (id: string): void => {
    const list = dbService.getPrograms().filter(p => p.id !== id);
    setStored(STORAGE_KEYS.PROGRAMS, list);
  },

  // Courses
  getCourses: (): Course[] => getStored<Course[]>(STORAGE_KEYS.COURSES, SEED_COURSES),
  saveCourse: (course: Course): void => {
    const list = dbService.getCourses();
    const index = list.findIndex(c => c.id === course.id);
    if (index >= 0) {
      list[index] = { ...course, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...course, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.COURSES, list);
  },
  deleteCourse: (id: string): void => {
    const list = dbService.getCourses().filter(c => c.id !== id);
    setStored(STORAGE_KEYS.COURSES, list);
  },

  // Modules
  getModules: (courseId?: string): Module[] => {
    const list = getStored<Module[]>(STORAGE_KEYS.MODULES, SEED_MODULES);
    if (courseId) return list.filter(m => m.courseId === courseId);
    return list;
  },
  saveModule: (module: Module): void => {
    const list = getStored<Module[]>(STORAGE_KEYS.MODULES, SEED_MODULES);
    const index = list.findIndex(m => m.id === module.id);
    if (index >= 0) {
      list[index] = { ...module, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...module, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.MODULES, list);
  },
  deleteModule: (id: string): void => {
    const list = getStored<Module[]>(STORAGE_KEYS.MODULES, SEED_MODULES).filter(m => m.id !== id);
    setStored(STORAGE_KEYS.MODULES, list);
  },

  // Topics
  getTopics: (moduleId?: string): Topic[] => {
    const list = getStored<Topic[]>(STORAGE_KEYS.TOPICS, SEED_TOPICS);
    if (moduleId) return list.filter(t => t.moduleId === moduleId);
    return list;
  },
  saveTopic: (topic: Topic): void => {
    const list = getStored<Topic[]>(STORAGE_KEYS.TOPICS, SEED_TOPICS);
    const index = list.findIndex(t => t.id === topic.id);
    if (index >= 0) {
      list[index] = { ...topic, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...topic, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.TOPICS, list);
  },
  deleteTopic: (id: string): void => {
    const list = getStored<Topic[]>(STORAGE_KEYS.TOPICS, SEED_TOPICS).filter(t => t.id !== id);
    setStored(STORAGE_KEYS.TOPICS, list);
  },

  // Notes
  getNotes: (): Note[] => getStored<Note[]>(STORAGE_KEYS.NOTES, SEED_NOTES),
  getNoteById: (id: string): Note | undefined => dbService.getNotes().find(n => n.id === id),
  saveNote: (note: Note): void => {
    const list = dbService.getNotes();
    const index = list.findIndex(n => n.id === note.id);
    if (index >= 0) {
      list[index] = { ...note, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...note, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.NOTES, list);
  },
  deleteNote: (id: string): void => {
    const list = dbService.getNotes().filter(n => n.id !== id);
    setStored(STORAGE_KEYS.NOTES, list);
  },

  // Formula Sheets
  getFormulas: (): FormulaSheet[] => getStored<FormulaSheet[]>(STORAGE_KEYS.FORMULAS, SEED_FORMULAS),
  saveFormula: (formula: FormulaSheet): void => {
    const list = dbService.getFormulas();
    const index = list.findIndex(f => f.id === formula.id);
    if (index >= 0) {
      list[index] = { ...formula, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...formula, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.FORMULAS, list);
  },
  deleteFormula: (id: string): void => {
    const list = dbService.getFormulas().filter(f => f.id !== id);
    setStored(STORAGE_KEYS.FORMULAS, list);
  },

  // Questions & Bank
  getQuestions: (): Question[] => getStored<Question[]>(STORAGE_KEYS.QUESTIONS, SEED_QUESTIONS),
  saveQuestion: (question: Question): void => {
    const list = dbService.getQuestions();
    const index = list.findIndex(q => q.id === question.id);
    if (index >= 0) {
      list[index] = { ...question, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...question, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.QUESTIONS, list);
  },
  deleteQuestion: (id: string): void => {
    const list = dbService.getQuestions().filter(q => q.id !== id);
    setStored(STORAGE_KEYS.QUESTIONS, list);
  },

  // Mock Tests
  getMockTests: (): MockTest[] => getStored<MockTest[]>(STORAGE_KEYS.MOCK_TESTS, SEED_MOCK_TESTS),
  saveMockTest: (test: MockTest): void => {
    const list = dbService.getMockTests();
    const index = list.findIndex(t => t.id === test.id);
    if (index >= 0) {
      list[index] = { ...test, updatedAt: new Date().toISOString() };
    } else {
      list.push({ ...test, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.MOCK_TESTS, list);
  },
  deleteMockTest: (id: string): void => {
    const list = dbService.getMockTests().filter(t => t.id !== id);
    setStored(STORAGE_KEYS.MOCK_TESTS, list);
  },

  // Study Plan Tasks (User-specific)
  getStudyTasks: (userId: string): StudyPlanTask[] => {
    const all = getStored<StudyPlanTask[]>(STORAGE_KEYS.STUDY_PLANS, []);
    return all.filter(t => t.userId === userId);
  },
  saveStudyTask: (task: StudyPlanTask): void => {
    const all = getStored<StudyPlanTask[]>(STORAGE_KEYS.STUDY_PLANS, []);
    const index = all.findIndex(t => t.id === task.id);
    if (index >= 0) {
      all[index] = { ...task, updatedAt: new Date().toISOString() };
    } else {
      all.push({ ...task, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    setStored(STORAGE_KEYS.STUDY_PLANS, all);
  },
  deleteStudyTask: (id: string): void => {
    const all = getStored<StudyPlanTask[]>(STORAGE_KEYS.STUDY_PLANS, []).filter(t => t.id !== id);
    setStored(STORAGE_KEYS.STUDY_PLANS, all);
  },

  // Bookmarks (User-specific)
  getBookmarks: (userId: string): BookmarkItem[] => {
    const all = getStored<BookmarkItem[]>(STORAGE_KEYS.BOOKMARKS, []);
    return all.filter(b => b.userId === userId);
  },
  toggleBookmark: (item: Omit<BookmarkItem, 'id' | 'createdAt'>): boolean => {
    const all = getStored<BookmarkItem[]>(STORAGE_KEYS.BOOKMARKS, []);
    const existingIndex = all.findIndex(b => b.userId === item.userId && b.itemType === item.itemType && b.itemId === item.itemId);
    if (existingIndex >= 0) {
      all.splice(existingIndex, 1);
      setStored(STORAGE_KEYS.BOOKMARKS, all);
      return false; // removed
    } else {
      const newBookmark: BookmarkItem = {
        ...item,
        id: `bm-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        title: item.title || item.itemTitle || 'Bookmark',
        itemTitle: item.itemTitle || item.title || 'Bookmark',
        courseTitle: item.courseTitle || item.courseName,
        courseName: item.courseName || item.courseTitle,
        createdAt: new Date().toISOString(),
      };
      all.push(newBookmark);
      setStored(STORAGE_KEYS.BOOKMARKS, all);
      return true; // added
    }
  },
  removeBookmark: (id: string): void => {
    const all = getStored<BookmarkItem[]>(STORAGE_KEYS.BOOKMARKS, []).filter(b => b.id !== id);
    setStored(STORAGE_KEYS.BOOKMARKS, all);
  },
  isBookmarked: (userId: string, itemType: string, itemId: string): boolean => {
    const all = getStored<BookmarkItem[]>(STORAGE_KEYS.BOOKMARKS, []);
    return all.some(b => b.userId === userId && b.itemType === itemType && b.itemId === itemId);
  },

  // Test Attempts (User-specific)
  getTestAttempts: (userId: string): TestAttempt[] => {
    const all = getStored<TestAttempt[]>(STORAGE_KEYS.TEST_ATTEMPTS, []);
    return all.filter(a => a.userId === userId);
  },
  saveTestAttempt: (attempt: TestAttempt): void => {
    const all = getStored<TestAttempt[]>(STORAGE_KEYS.TEST_ATTEMPTS, []);
    all.push(attempt);
    setStored(STORAGE_KEYS.TEST_ATTEMPTS, all);
  },

  // Contact Messages
  saveContactMessage: (msg: Omit<ContactMessage, 'id' | 'createdAt' | 'status'>): void => {
    const all = getStored<ContactMessage[]>(STORAGE_KEYS.CONTACT_MESSAGES, []);
    const newMsg: ContactMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'pending'
    };
    all.push(newMsg);
    setStored(STORAGE_KEYS.CONTACT_MESSAGES, all);
  },
  getContactMessages: (): ContactMessage[] => {
    return getStored<ContactMessage[]>(STORAGE_KEYS.CONTACT_MESSAGES, []);
  },
  updateContactMessageStatus: (id: string, status: 'pending' | 'reviewed' | 'replied'): void => {
    const all = getStored<ContactMessage[]>(STORAGE_KEYS.CONTACT_MESSAGES, []);
    const target = all.find(m => m.id === id);
    if (target) {
      target.status = status;
      setStored(STORAGE_KEYS.CONTACT_MESSAGES, all);
    }
  },
  deleteContactMessage: (id: string): void => {
    const all = getStored<ContactMessage[]>(STORAGE_KEYS.CONTACT_MESSAGES, []).filter(m => m.id !== id);
    setStored(STORAGE_KEYS.CONTACT_MESSAGES, all);
  }
};

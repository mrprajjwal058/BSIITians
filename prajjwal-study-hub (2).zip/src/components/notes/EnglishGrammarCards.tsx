import React, { useState } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sparkles, 
  Lightbulb, 
  Pin, 
  Bookmark, 
  Search, 
  Layers, 
  ArrowRight,
  Filter,
  Eye,
  Check,
  Copy,
  ChevronDown,
  ChevronUp,
  Volume2
} from 'lucide-react';
import { Badge } from '../common/Badge';
import { Button } from '../common/Button';
import { 
  ENGLISH_GRAMMAR_RULES, 
  ENGLISH_COMMON_ERRORS, 
  ACADEMIC_VOCABULARY_LIST, 
  READING_COMPREHENSION_STRATEGIES,
  GrammarRule,
  CommonErrorEntry,
  AcademicVocabWord,
  ReadingComprehensionStrategy
} from '../../data/englishCurriculumData';

interface EnglishGrammarCardsProps {
  onBookmarkToggle?: (id: string) => void;
  bookmarkedIds?: string[];
}

export const EnglishGrammarCards: React.FC<EnglishGrammarCardsProps> = ({
  onBookmarkToggle,
  bookmarkedIds = []
}) => {
  const [activeTab, setActiveTab] = useState<'rules' | 'errors' | 'vocab' | 'strategies'>('rules');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrammarCategory, setSelectedGrammarCategory] = useState<string>('All');
  const [expandedRuleId, setExpandedRuleId] = useState<string | null>('gr-sva-1');
  const [flippedVocabId, setFlippedVocabId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Filtered Rules
  const filteredRules = ENGLISH_GRAMMAR_RULES.filter(r => {
    if (selectedGrammarCategory !== 'All' && r.category !== selectedGrammarCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return r.title.toLowerCase().includes(q) || 
             r.ruleStatement.toLowerCase().includes(q) || 
             r.examTrap.toLowerCase().includes(q);
    }
    return true;
  });

  // Filtered Errors
  const filteredErrors = ENGLISH_COMMON_ERRORS.filter(e => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return e.topic.toLowerCase().includes(q) || 
             e.incorrectSentence.toLowerCase().includes(q) || 
             e.correctSentence.toLowerCase().includes(q) ||
             e.explanation.toLowerCase().includes(q);
    }
    return true;
  });

  // Filtered Vocab
  const filteredVocab = ACADEMIC_VOCABULARY_LIST.filter(v => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return v.word.toLowerCase().includes(q) || 
             v.definition.toLowerCase().includes(q) || 
             v.synonyms.some(s => s.toLowerCase().includes(q)) ||
             v.academicUsage.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* English Hub Header & Section Description */}
      <div className="p-5 rounded-2xl bg-[#fdfbf7] dark:bg-[#131a2a] border border-amber-200/80 dark:border-slate-800 shadow-xs relative overflow-hidden">
        <div 
          className="absolute left-6 top-0 bottom-0 w-[1.5px] bg-rose-400/40 dark:bg-rose-500/30 pointer-events-none" 
          aria-hidden="true" 
        />
        <div className="pl-6 sm:pl-8 space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 font-mono">
              ENG1001 / ENG1002
            </span>
            <Badge variant="info" size="sm">IITM Foundation English</Badge>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
            English 1 & 2 Handwritten Cheat Sheets & Diagnostic Hub
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
            High-frequency grammar rules, common error correction tables, academic vocabulary cards, and reading comprehension heuristics tailored for IIT Madras English in-term and qualifier exams.
          </p>
        </div>
      </div>

      {/* Interactive Tabs & Search Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
          <button
            id="eng-tab-rules"
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'rules'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Grammar Rules ({ENGLISH_GRAMMAR_RULES.length})
          </button>
          <button
            id="eng-tab-errors"
            onClick={() => setActiveTab('errors')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'errors'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Error Spotting Tables ({ENGLISH_COMMON_ERRORS.length})
          </button>
          <button
            id="eng-tab-vocab"
            onClick={() => setActiveTab('vocab')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'vocab'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Vocabulary Cards ({ACADEMIC_VOCABULARY_LIST.length})
          </button>
          <button
            id="eng-tab-strategies"
            onClick={() => setActiveTab('strategies')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'strategies'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Reading Strategies ({READING_COMPREHENSION_STRATEGIES.length})
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="eng-search-input"
            type="text"
            placeholder="Search grammar, words, rules..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* 1. GRAMMAR RULES TAB */}
      {activeTab === 'rules' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
            <span className="font-semibold text-slate-500">
              Showing {filteredRules.length} High-Yield Rules
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto">
              {['All', 'Subject-Verb Agreement', 'Tenses & Conditionals', 'Active & Passive Voice', 'Modifiers & Parallelism'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedGrammarCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${
                    selectedGrammarCategory === cat
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {filteredRules.map((rule) => {
              const isExpanded = expandedRuleId === rule.id;
              const isBookmarked = bookmarkedIds.includes(rule.id);

              return (
                <div
                  key={rule.id}
                  id={`grammar-card-${rule.id}`}
                  className="rounded-2xl border border-amber-200/80 dark:border-slate-800 bg-[#fdfbf7] dark:bg-[#131a2a] notebook-paper-light dark:notebook-paper-dark p-5 relative overflow-hidden transition-all shadow-xs"
                >
                  {/* Left Red Margin Line */}
                  <div 
                    className="absolute left-6 top-0 bottom-0 w-[1.5px] bg-rose-400/40 dark:bg-rose-500/30 pointer-events-none" 
                    aria-hidden="true" 
                  />

                  <div className="pl-6 sm:pl-8 space-y-4">
                    {/* Header */}
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <Badge variant="warning" size="sm">
                          {rule.category}
                        </Badge>
                        <h3 className="text-base font-bold text-slate-900 dark:text-white">
                          {rule.title}
                        </h3>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {onBookmarkToggle && (
                          <button
                            onClick={() => onBookmarkToggle(rule.id)}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              isBookmarked
                                ? 'bg-amber-50 dark:bg-amber-950 border-amber-300 text-amber-600'
                                : 'border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-600'
                            }`}
                            title="Bookmark Rule"
                          >
                            <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-500' : ''}`} />
                          </button>
                        )}
                        <button
                          onClick={() => setExpandedRuleId(isExpanded ? null : rule.id)}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                          title={isExpanded ? 'Collapse' : 'Expand'}
                        >
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {/* Rule Statement */}
                    <div className="p-3.5 rounded-xl bg-white/90 dark:bg-slate-900/90 border border-indigo-100 dark:border-indigo-950/60 shadow-xs text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-sans">
                      <span className="font-bold text-indigo-700 dark:text-indigo-400 block mb-1">
                        Rule Statement:
                      </span>
                      {rule.ruleStatement}
                    </div>

                    {/* Handwritten Sticky Tip */}
                    <div className="p-3 rounded-xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300/70 dark:border-amber-900/60 flex items-start gap-2.5">
                      <Pin className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300 block mb-0.5">
                          Handwritten Margin Shortcut:
                        </span>
                        <p className="font-handwritten text-base sm:text-lg text-amber-950 dark:text-amber-200 leading-snug">
                          {rule.handwrittenTip}
                        </p>
                      </div>
                    </div>

                    {/* Expandable Details: Correct vs Incorrect & Exam Trap */}
                    {isExpanded && (
                      <div className="space-y-3 pt-2 border-t border-amber-200/50 dark:border-slate-800">
                        {/* Examples Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                          {/* Correct */}
                          <div className="p-3 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/40 space-y-1.5">
                            <div className="flex items-center gap-1.5 font-bold text-emerald-800 dark:text-emerald-300">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              Correct Formulations:
                            </div>
                            <ul className="space-y-1 text-slate-700 dark:text-slate-300">
                              {rule.correctExamples.map((ex, i) => (
                                <li key={i} className="pl-2 border-l-2 border-emerald-400">
                                  {ex}
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Incorrect */}
                          <div className="p-3 rounded-xl bg-rose-50/80 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-900/40 space-y-1.5">
                            <div className="flex items-center gap-1.5 font-bold text-rose-800 dark:text-rose-300">
                              <XCircle className="w-3.5 h-3.5 text-rose-600" />
                              Common False Traps:
                            </div>
                            <ul className="space-y-1 text-slate-700 dark:text-slate-300">
                              {rule.incorrectExamples.map((ex, i) => (
                                <li key={i} className="pl-2 border-l-2 border-rose-400 line-through text-slate-500">
                                  {ex}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Exam Trap Warning */}
                        <div className="p-3 rounded-xl bg-purple-50/80 dark:bg-purple-950/30 border border-purple-200/80 dark:border-purple-900/40 flex items-start gap-2 text-xs">
                          <AlertTriangle className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-bold text-purple-900 dark:text-purple-300">
                              IIT Madras Qualifier & Quiz Trap:
                            </span>
                            <p className="text-slate-700 dark:text-slate-300 mt-0.5">
                              {rule.examTrap}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. ERROR SPOTTING DIAGNOSTIC TABLES */}
      {activeTab === 'errors' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-x-auto shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                Error Spotting Diagnostic Matrix (Incorrect $\\to$ Correct)
              </h3>
              <span className="text-xs text-slate-400">
                {filteredErrors.length} Diagnostic Pairs
              </span>
            </div>

            <div className="space-y-3">
              {filteredErrors.map((err) => (
                <div
                  key={err.id}
                  className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-indigo-700 dark:text-indigo-400">
                      Topic: {err.topic}
                    </span>
                    <Badge variant="outline" size="sm">
                      {err.ruleCategory}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {/* Incorrect */}
                    <div className="p-2.5 rounded-lg bg-rose-50/70 dark:bg-rose-950/40 border border-rose-200/60 text-rose-950 dark:text-rose-200 flex items-start gap-2">
                      <XCircle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold block text-[10px] text-rose-700 dark:text-rose-400 uppercase">Incorrect (Exam Trap):</span>
                        <span className="line-through">{err.incorrectSentence}</span>
                      </div>
                    </div>

                    {/* Correct */}
                    <div className="p-2.5 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200/60 text-emerald-950 dark:text-emerald-200 flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold block text-[10px] text-emerald-700 dark:text-emerald-400 uppercase">Corrected Form:</span>
                        <span className="font-semibold">{err.correctSentence}</span>
                      </div>
                    </div>
                  </div>

                  {/* Explanation */}
                  <p className="text-slate-600 dark:text-slate-400 pt-1 text-[11px] leading-relaxed">
                    <strong className="text-slate-800 dark:text-slate-200">Why: </strong>
                    {err.explanation}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. ACADEMIC VOCABULARY FLASHCARDS */}
      {activeTab === 'vocab' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredVocab.map((vocab) => {
              const isFlipped = flippedVocabId === vocab.id;

              return (
                <div
                  key={vocab.id}
                  id={`vocab-card-${vocab.id}`}
                  className="rounded-2xl border border-amber-200/80 dark:border-slate-800 bg-[#fdfbf7] dark:bg-[#131a2a] notebook-paper-light dark:notebook-paper-dark p-5 relative overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md transition-all"
                >
                  {/* Left Red Margin Line */}
                  <div 
                    className="absolute left-5 top-0 bottom-0 w-[1.5px] bg-rose-400/40 dark:bg-rose-500/30 pointer-events-none" 
                    aria-hidden="true" 
                  />

                  <div className="pl-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] px-2 py-0.5 rounded-md font-mono font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                        {vocab.partOfSpeech}
                      </span>
                      <button
                        onClick={() => handleCopyText(vocab.id, `${vocab.word} - ${vocab.definition}`)}
                        className="p-1 rounded-md text-slate-400 hover:text-slate-600"
                        title="Copy Word"
                      >
                        {copiedId === vocab.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    <div>
                      <h4 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                        {vocab.word}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                        {vocab.definition}
                      </p>
                    </div>

                    {/* Academic Usage */}
                    <div className="p-2.5 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-slate-200/70 dark:border-slate-800 text-[11px] text-slate-700 dark:text-slate-300 italic">
                      "{vocab.academicUsage}"
                    </div>

                    {/* Synonyms / Antonyms */}
                    <div className="space-y-1 text-[10px]">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-emerald-700 dark:text-emerald-400">Synonyms:</span>
                        {vocab.synonyms.map(s => (
                          <span key={s} className="px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                            {s}
                          </span>
                        ))}
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-rose-700 dark:text-rose-400">Antonyms:</span>
                        {vocab.antonyms.map(a => (
                          <span key={a} className="px-1.5 py-0.5 rounded bg-rose-50 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300">
                            {a}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Handwritten Mnemonic */}
                    {vocab.handwrittenMnemonic && (
                      <div className="p-2.5 rounded-xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300/60 flex items-start gap-1.5">
                        <Pin className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <p className="font-handwritten text-sm text-amber-950 dark:text-amber-200 leading-tight">
                          {vocab.handwrittenMnemonic}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. READING & LISTENING COMPREHENSION STRATEGIES */}
      {activeTab === 'strategies' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {READING_COMPREHENSION_STRATEGIES.map((strat) => (
            <div
              key={strat.id}
              className="p-5 rounded-2xl border border-amber-200/80 dark:border-slate-800 bg-[#fdfbf7] dark:bg-[#131a2a] notebook-paper-light dark:notebook-paper-dark relative overflow-hidden flex flex-col justify-between shadow-xs"
            >
              {/* Left Red Margin Line */}
              <div 
                className="absolute left-5 top-0 bottom-0 w-[1.5px] bg-rose-400/40 dark:bg-rose-500/30 pointer-events-none" 
                aria-hidden="true" 
              />

              <div className="pl-5 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  <Sparkles className="w-4 h-4" />
                  <span>IITM RC Strategy</span>
                </div>
                <h4 className="font-bold text-base text-slate-900 dark:text-white">
                  {strat.strategyName}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {strat.description}
                </p>

                <div className="space-y-1.5 pt-2 border-t border-amber-200/60 dark:border-slate-800 text-xs">
                  <span className="font-bold text-slate-800 dark:text-slate-200 text-[11px] block">
                    Execution Steps:
                  </span>
                  {strat.steps.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-slate-600 dark:text-slate-400 text-[11px]">
                      <span className="w-4 h-4 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[10px]">
                        {idx + 1}
                      </span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>

                {/* Handwritten Shortcut */}
                <div className="p-3 rounded-xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300/60 flex items-start gap-2 mt-2">
                  <Pin className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <p className="font-handwritten text-base text-amber-950 dark:text-amber-200 leading-tight">
                    {strat.handwrittenShortcut}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};

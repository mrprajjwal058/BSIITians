import React, { useState } from 'react';
import { 
  Bookmark, 
  FileDown, 
  Sparkles, 
  Pin, 
  ChevronDown, 
  ChevronUp, 
  Code, 
  BookOpen, 
  Check, 
  Copy,
  Lightbulb,
  CheckCircle2,
  Calendar,
  Layers,
  HelpCircle,
  Eye,
  EyeOff,
  CheckCircle,
  XCircle,
  Tag,
  Share2,
  ExternalLink
} from 'lucide-react';
import { Badge } from '../common/Badge';
import { MathRenderer } from '../common/MathRenderer';
import { WeeklyStudyMaterial } from '../../types';
import { getSubjectTheme } from '../../utils/subjectTheme';

export function extractSubTopics(note: WeeklyStudyMaterial): string[] {
  const subtopics: string[] = [];
  const text = note.detailedNotes || note.markdownContent || '';

  // 1. Match headings like "#### 1. Topic" or "#### Topic" or "### Topic"
  const headingMatches = text.match(/#{3,4}\s+(?:\d+[\.\)]\s*)?([^\n#]+)/g);
  if (headingMatches && headingMatches.length > 0) {
    headingMatches.forEach(h => {
      const cleaned = h.replace(/#{3,4}\s+/, '').replace(/^\d+[\.\)]\s*/, '').trim();
      if (
        cleaned && 
        !cleaned.toLowerCase().startsWith('week ') && 
        !cleaned.toLowerCase().startsWith('foundations of') &&
        !subtopics.includes(cleaned)
      ) {
        subtopics.push(cleaned);
      }
    });
  }

  // 2. Definitions terms
  if (note.definitions && note.definitions.length > 0) {
    note.definitions.forEach(d => {
      if (d.term && !subtopics.includes(d.term) && subtopics.length < 6) {
        subtopics.push(d.term);
      }
    });
  }

  // 3. Formula sheet titles
  if (note.formulaSheets && note.formulaSheets.length > 0) {
    note.formulaSheets.forEach(f => {
      if (f.name && !subtopics.includes(f.name) && subtopics.length < 6) {
        subtopics.push(f.name);
      }
    });
  }

  // 4. Fallback from title
  if (subtopics.length === 0 && note.title) {
    const parts = note.title.split(/[,:&|]/).map(s => s.trim()).filter(Boolean);
    parts.forEach(p => {
      if (!subtopics.includes(p)) subtopics.push(p);
    });
  }

  return subtopics.slice(0, 5);
}

interface WeeklyAccordionNoteCardProps {
  note: WeeklyStudyMaterial;
  isExpanded: boolean;
  onToggleExpand: () => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onDownloadPdf?: () => void;
  onNavigatePractice?: () => void;
}

export const WeeklyAccordionNoteCard: React.FC<WeeklyAccordionNoteCardProps> = ({
  note,
  isExpanded,
  onToggleExpand,
  isBookmarked,
  onToggleBookmark,
  onDownloadPdf,
  onNavigatePractice
}) => {
  const [activeTab, setActiveTab] = useState<'detailed' | 'revision' | 'formulas' | 'practice'>('detailed');
  const [copiedSnippetId, setCopiedSnippetId] = useState<string | null>(null);

  // Interactive Practice State
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [revealedSolutions, setRevealedSolutions] = useState<Record<string, boolean>>({});
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({});

  const theme = getSubjectTheme(note.courseTitle || note.courseCode, note.subLevel || '');
  const subtopics = extractSubTopics(note);

  const detailedText = note.detailedNotes || note.markdownContent || '';
  const revisionPoints = note.quickRevisionNotes || note.keyTakeaways || [];
  const formulas = note.formulaSheets || (note.definitions?.filter(d => d.formula).map(d => ({
    name: d.term,
    formula: d.formula || '',
    description: d.explanation
  })) || []);
  const practiceProblems = note.practiceQuestions || [];

  const handleCopyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSnippetId(id);
    setTimeout(() => setCopiedSnippetId(null), 2000);
  };

  const handleSelectOption = (questionId: string, optIdx: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optIdx
    }));
  };

  const toggleSolution = (questionId: string) => {
    setRevealedSolutions(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  const toggleHint = (questionId: string) => {
    setRevealedHints(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  // Qualifier / Term Phase Badge
  const getPhaseBadge = (week: number) => {
    if (week <= 4) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
          ★ Qualifier / Quiz 1 Scope
        </span>
      );
    }
    if (week <= 8) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
          ◈ Quiz 2 Milestone
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
        ❖ End Term Scope
      </span>
    );
  };

  return (
    <div
      id={`week-accordion-${note.id}`}
      className={`rounded-2xl transition-all duration-200 border ${
        isExpanded 
          ? `${theme.cardBorder} bg-[#111318] shadow-xl ring-1 ring-white/10` 
          : 'border-white/10 bg-[#111318]/90 hover:border-white/20 shadow-md'
      } overflow-hidden`}
    >
      {/* Accordion Top Header Bar (Clickable) */}
      <div 
        onClick={onToggleExpand}
        className="px-5 py-4 cursor-pointer select-none hover:bg-white/[0.02] transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
      >
        <div className="flex items-start md:items-center gap-3.5 flex-1 min-w-0">
          {/* Week Number Box */}
          <div className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center shrink-0 border ${theme.badgeClass}`}>
            <span className="text-[10px] uppercase font-bold tracking-wider leading-none">Week</span>
            <span className="text-lg font-black leading-tight">{note.weekNumber}</span>
          </div>

          <div className="flex-1 min-w-0">
            {/* Metadata Tags */}
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-md border ${theme.badgeClass} font-mono`}>
                {note.courseCode}
              </span>
              <span className="text-[11px] font-semibold text-slate-400">
                {note.courseTitle}
              </span>
              {getPhaseBadge(note.weekNumber)}
            </div>

            {/* Main Topic Title */}
            <h3 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug truncate">
              Week {note.weekNumber}: {note.title}
            </h3>

            {/* Sub-topics preview chips if collapsed */}
            {!isExpanded && subtopics.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap mt-2">
                <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                  <Tag className="w-2.5 h-2.5" /> Topics:
                </span>
                {subtopics.map((st, i) => (
                  <span 
                    key={i} 
                    className="text-[11px] px-2 py-0.5 rounded-md bg-white/5 text-slate-300 border border-white/5 truncate max-w-[200px]"
                  >
                    {st}
                  </span>
                ))}
                {subtopics.length > 0 && (
                  <span className="text-[10px] font-semibold text-indigo-400">
                    +{formulas.length} formulas
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Side Actions & Accordion Toggle */}
        <div className="flex items-center justify-end gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-white/5">
          {onDownloadPdf && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDownloadPdf();
              }}
              className="p-2 rounded-xl border border-white/10 bg-[#161920] text-slate-300 hover:text-white hover:border-indigo-500/50 hover:bg-indigo-600/10 transition-colors"
              title="Download Week Note (PDF)"
              aria-label="Download Week Note (PDF)"
            >
              <FileDown className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleBookmark();
            }}
            className={`p-2 rounded-xl border transition-colors ${
              isBookmarked
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'border-white/10 bg-[#161920] text-slate-400 hover:text-white hover:border-white/20'
            }`}
            title="Bookmark Week Note"
            aria-label="Bookmark Week Note"
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400' : ''}`} />
          </button>

          <div className="flex items-center gap-1 pl-1">
            <span className="text-xs font-semibold text-slate-400 hidden sm:inline">
              {isExpanded ? 'Collapse' : 'Explore'}
            </span>
            <div className={`p-2 rounded-xl border border-white/10 bg-[#161920] text-slate-300 group-hover:text-white transition-transform ${isExpanded ? 'rotate-180 bg-white/10' : ''}`}>
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Accordion Expanded Body */}
      {isExpanded && (
        <div className="px-5 pb-6 pt-2 space-y-5 border-t border-white/10 bg-[#111318]">
          
          {/* 1. Sub-topics Breakdown Grid */}
          {subtopics.length > 0 && (
            <div className="p-4 rounded-xl bg-[#161920]/80 border border-white/10 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-indigo-400" />
                  Key Sub-topics Covered in Week {note.weekNumber}:
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  {subtopics.length} Modules
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {subtopics.map((topic, tIdx) => (
                  <div 
                    key={tIdx} 
                    className="p-2.5 rounded-lg bg-[#111318] border border-white/5 flex items-start gap-2 text-xs text-slate-200"
                  >
                    <span className="w-5 h-5 rounded-md bg-indigo-500/20 text-indigo-300 font-mono font-bold flex items-center justify-center shrink-0 text-[10px]">
                      {tIdx + 1}
                    </span>
                    <span className="font-medium leading-snug">{topic}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. High-Yield Exam Memory Cue / Mnemonic (if present) */}
          {note.handwrittenMnemonic && (
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-3">
              <Pin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block mb-0.5">
                  IIT Madras High-Yield Memory Cue:
                </span>
                <p className="text-xs sm:text-sm font-medium text-amber-200 leading-snug">
                  {note.handwrittenMnemonic}
                </p>
              </div>
            </div>
          )}

          {/* 3. Three Dedicated Tabs/Action Buttons */}
          <div className="flex items-center gap-2 p-1.5 bg-[#161920] rounded-xl border border-white/10 overflow-x-auto">
            <button
              id={`tab-detailed-${note.id}`}
              onClick={() => setActiveTab('detailed')}
              className={`flex-1 min-w-[140px] px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${
                activeTab === 'detailed'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Detailed Notes</span>
            </button>

            <button
              id={`tab-revision-${note.id}`}
              onClick={() => setActiveTab('revision')}
              className={`flex-1 min-w-[150px] px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${
                activeTab === 'revision'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Quick Revision Summary ({revisionPoints.length})</span>
            </button>

            <button
              id={`tab-formulas-${note.id}`}
              onClick={() => setActiveTab('formulas')}
              className={`flex-1 min-w-[150px] px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${
                activeTab === 'formulas'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-sky-400" />
              <span>Formula &amp; Syntax Cheatsheet ({formulas.length})</span>
            </button>

            {practiceProblems.length > 0 && (
              <button
                id={`tab-practice-${note.id}`}
                onClick={() => setActiveTab('practice')}
                className={`flex-1 min-w-[140px] px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${
                  activeTab === 'practice'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Practice Drills ({practiceProblems.length})</span>
              </button>
            )}
          </div>

          {/* TAB 1: DETAILED NOTES */}
          {activeTab === 'detailed' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-[#161920] border border-white/10 text-xs sm:text-sm text-slate-200 space-y-3 leading-relaxed">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="font-bold text-white flex items-center gap-2 text-xs uppercase tracking-wider">
                    <BookOpen className="w-4 h-4 text-indigo-400" />
                    Full Theory, Mathematical Derivations &amp; Concepts
                  </span>
                  <span className="text-xs text-slate-400 font-mono">Week {note.weekNumber}</span>
                </div>
                <div className="space-y-2 whitespace-pre-line text-slate-300">
                  <MathRenderer text={detailedText} />
                </div>
              </div>

              {/* Definitions & Formal Theorems */}
              {note.definitions && note.definitions.length > 0 && (
                <div className="space-y-3 pt-1">
                  <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    Key Definitions &amp; Formal Statements
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {note.definitions.map((def, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-xl bg-[#161920] border border-white/10 text-xs space-y-2 shadow-sm"
                      >
                        <span className="font-bold text-indigo-300 block text-sm">
                          {def.term}
                        </span>
                        <p className="text-slate-300 leading-relaxed">
                          <MathRenderer text={def.explanation} />
                        </p>
                        {def.formula && (
                          <div className="pt-2 pb-1 text-center bg-[#0A0C10] rounded-lg my-1 border border-white/10 text-indigo-200 overflow-x-auto">
                            <MathRenderer math={def.formula} block={true} />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Code Snippets if present */}
              {note.codeSnippets && note.codeSnippets.length > 0 && (
                <div className="space-y-3 pt-1">
                  <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Code className="w-3.5 h-3.5 text-sky-400" />
                    Reference Code Snippets &amp; Implementations
                  </span>
                  <div className="space-y-3">
                    {note.codeSnippets.map((snippet, sIdx) => {
                      const isCopied = copiedSnippetId === `snippet-${sIdx}`;
                      return (
                        <div key={sIdx} className="rounded-xl border border-white/10 bg-[#0A0C10] overflow-hidden">
                          <div className="px-4 py-2 bg-white/5 border-b border-white/10 flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-300 font-mono">
                              {snippet.title || `Snippet #${sIdx + 1}`}
                            </span>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">
                                {snippet.language}
                              </span>
                              <button
                                onClick={() => handleCopyCode(`snippet-${sIdx}`, snippet.code)}
                                className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                                title="Copy Code"
                              >
                                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          </div>
                          <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed">
                            <code>{snippet.code}</code>
                          </pre>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: QUICK REVISION SUMMARY */}
          {activeTab === 'revision' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-[#161920] border border-indigo-500/20 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    High-Yield Quick Revision Bullet Points &amp; Exam Takeaways
                  </span>
                  <span className="text-xs text-slate-400 font-mono">{revisionPoints.length} Points</span>
                </div>
                <ul className="space-y-2.5 text-xs sm:text-sm text-slate-200">
                  {revisionPoints.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3 p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                      <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                      <span className="leading-relaxed text-slate-200">
                        <MathRenderer text={item} />
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Exam Tips if present */}
              {note.examTips && note.examTips.length > 0 && (
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 space-y-2">
                  <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-amber-400" />
                    Pro Exam Strategies &amp; Common Pitfalls:
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {note.examTips.map((tip, tipIdx) => (
                      <li key={tipIdx} className="flex items-start gap-2">
                        <span className="text-amber-400 font-bold">•</span>
                        <span><MathRenderer text={tip} /></span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FORMULA & SYNTAX CHEATSHEET */}
          {activeTab === 'formulas' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {formulas.length === 0 ? (
                  <div className="p-6 rounded-xl bg-[#161920] border border-white/10 text-center col-span-2 text-slate-400 text-xs">
                    No explicit standalone mathematical formulas for this chapter. Check the Detailed Notes for theoretical derivations.
                  </div>
                ) : (
                  formulas.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl bg-[#161920] border border-white/10 text-xs space-y-3 shadow-md hover:border-indigo-500/30 transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between pb-2 border-b border-white/10">
                          <span className="font-bold text-white text-sm">
                            {item.name}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            #{idx + 1}
                          </span>
                        </div>

                        <div className="py-3 px-3 text-center bg-[#0A0C10] rounded-xl border border-white/10 my-2.5 overflow-x-auto text-indigo-200">
                          <MathRenderer math={item.formula} block={true} />
                        </div>

                        <p className="text-slate-300 leading-relaxed text-xs">
                          <MathRenderer text={item.description} />
                        </p>
                      </div>

                      {item.variables && item.variables.length > 0 && (
                        <div className="pt-2.5 border-t border-white/10 text-[11px] text-slate-400 space-y-1">
                          <span className="font-semibold text-slate-300 text-[10px] uppercase tracking-wider block">
                            Variables &amp; Notation:
                          </span>
                          <div className="grid grid-cols-1 gap-1">
                            {item.variables.map((v, vIdx) => (
                              <div key={vIdx} className="flex items-center gap-2">
                                <span className="font-mono font-bold text-indigo-400 shrink-0">{v.symbol}:</span>
                                <span className="truncate">{v.meaning}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 4: PRACTICE DRILLS & SOLVED PROBLEMS */}
          {activeTab === 'practice' && practiceProblems.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-1 border-b border-white/10">
                <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-emerald-400" />
                  Self-Check Practice Problems with Detailed Solutions
                </span>
                <span className="text-xs text-slate-400 font-mono">{practiceProblems.length} Problems</span>
              </div>

              <div className="space-y-4">
                {practiceProblems.map((q, qIdx) => {
                  const selected = selectedAnswers[q.id];
                  const isSolutionRevealed = revealedSolutions[q.id];
                  const isHintRevealed = revealedHints[q.id];
                  const isCorrect = selected !== undefined && q.correctOptionIndex !== undefined && selected === q.correctOptionIndex;

                  return (
                    <div
                      key={q.id || qIdx}
                      className="p-5 rounded-2xl bg-[#161920] border border-white/10 text-xs space-y-3.5 shadow-md"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-bold text-white text-sm leading-snug">
                          Q{qIdx + 1}. <MathRenderer text={q.questionText} />
                        </span>
                      </div>

                      {/* Options */}
                      {q.options && q.options.length > 0 && (
                        <div className="grid grid-cols-1 gap-2 pt-1">
                          {q.options.map((opt, optIdx) => {
                            const isThisSelected = selected === optIdx;
                            const isThisCorrect = q.correctOptionIndex === optIdx;
                            let optionClass = 'border-white/10 bg-[#0A0C10] text-slate-300 hover:border-indigo-500/50 hover:bg-white/5';

                            if (isThisSelected) {
                              if (isThisCorrect) {
                                optionClass = 'border-emerald-500/80 bg-emerald-500/20 text-emerald-200 font-medium';
                              } else {
                                optionClass = 'border-rose-500/80 bg-rose-500/20 text-rose-200 font-medium';
                              }
                            } else if (isSolutionRevealed && isThisCorrect) {
                              optionClass = 'border-emerald-500/80 bg-emerald-500/10 text-emerald-300 font-medium';
                            }

                            return (
                              <button
                                key={optIdx}
                                onClick={() => handleSelectOption(q.id, optIdx)}
                                className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between gap-2 ${optionClass}`}
                              >
                                <div className="flex items-center gap-2.5">
                                  <span className="w-5 h-5 rounded-full border border-white/20 flex items-center justify-center text-[10px] font-bold shrink-0">
                                    {String.fromCharCode(65 + optIdx)}
                                  </span>
                                  <span className="text-xs"><MathRenderer text={opt} /></span>
                                </div>
                                {isThisSelected && (
                                  isThisCorrect 
                                    ? <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                                    : <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Action Bar (Hints & Solutions) */}
                      <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
                        <div className="flex items-center gap-2">
                          {q.hints && q.hints.length > 0 && (
                            <button
                              onClick={() => toggleHint(q.id)}
                              className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                            >
                              <Lightbulb className="w-3.5 h-3.5" />
                              <span>{isHintRevealed ? 'Hide Hint' : 'View Hint'}</span>
                            </button>
                          )}
                        </div>

                        <button
                          onClick={() => toggleSolution(q.id)}
                          className="px-3 py-1 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-[11px] font-semibold text-indigo-300 transition-colors flex items-center gap-1.5"
                        >
                          {isSolutionRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          <span>{isSolutionRevealed ? 'Hide Solution' : 'Step-by-Step Solution'}</span>
                        </button>
                      </div>

                      {/* Hint Reveal */}
                      {isHintRevealed && q.hints && (
                        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs">
                          <span className="font-bold block mb-1">💡 Hint:</span>
                          <ul className="list-disc list-inside space-y-1">
                            {q.hints.map((h, hIdx) => (
                              <li key={hIdx}><MathRenderer text={h} /></li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Solution Reveal */}
                      {isSolutionRevealed && (
                        <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-200 text-xs space-y-2">
                          <span className="font-bold text-white block">
                            ✓ Step-by-Step Derivation:
                          </span>
                          <div className="leading-relaxed text-slate-200 whitespace-pre-line">
                            <MathRenderer text={q.solution} />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Card Bottom Quick Actions */}
          <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" />
              <span>Full curriculum aligned with IIT Madras BS Degree Assessment Portal</span>
            </div>

            <div className="flex items-center gap-2">
              {onNavigatePractice && (
                <button
                  onClick={onNavigatePractice}
                  className="px-3.5 py-1.5 rounded-xl border border-white/10 bg-[#161920] text-slate-300 hover:text-white hover:border-indigo-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Practice Week {note.weekNumber} PYQs</span>
                </button>
              )}
            </div>
          </div>

        </div>
      )}
    </div>
  );
};

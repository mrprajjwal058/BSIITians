import React, { useState } from 'react';
import { 
  Bookmark, 
  FileDown, 
  Sparkles, 
  Pin, 
  ChevronDown, 
  ChevronUp, 
  Code, 
  BookOpen, 
  Check, 
  Copy,
  Lightbulb,
  CheckCircle2,
  Calendar,
  Layers,
  HelpCircle,
  Eye,
  EyeOff,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { Badge } from '../common/Badge';
import { MathRenderer } from '../common/MathRenderer';
import { WeeklyStudyMaterial } from '../../types';

interface NotebookNoteCardProps {
  note: WeeklyStudyMaterial;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onDownloadPdf?: () => void;
  defaultExpanded?: boolean;
}

export const NotebookNoteCard: React.FC<NotebookNoteCardProps> = ({
  note,
  isBookmarked,
  onToggleBookmark,
  onDownloadPdf,
  defaultExpanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [activeTab, setActiveTab] = useState<'detailed' | 'revision' | 'formulas' | 'practice'>('detailed');
  const [copiedSnippetId, setCopiedSnippetId] = useState<string | null>(null);

  // State for interactive practice questions
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [revealedSolutions, setRevealedSolutions] = useState<Record<string, boolean>>({});
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({});

  const handleCopyCode = (id: string, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSnippetId(id);
    setTimeout(() => setCopiedSnippetId(null), 2000);
  };

  const handleSelectOption = (questionId: string, optIdx: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optIdx
    }));
  };

  const toggleSolution = (questionId: string) => {
    setRevealedSolutions(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  const toggleHint = (questionId: string) => {
    setRevealedHints(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  // Safe accessor fallbacks
  const detailedText = note.detailedNotes || note.markdownContent || '';
  const revisionPoints = note.quickRevisionNotes || note.keyTakeaways || [];
  const formulas = note.formulaSheets || (note.definitions?.filter(d => d.formula).map(d => ({
    name: d.term,
    formula: d.formula || '',
    description: d.explanation
  })) || []);
  const practiceProblems = note.practiceQuestions || [];

  return (
    <div
      id={`note-card-${note.id}`}
      className="relative rounded-2xl overflow-hidden border border-white/10 shadow-lg hover:border-indigo-500/40 transition-all duration-200 flex flex-col justify-between group
        bg-[#111318] text-slate-100"
    >
      {/* Top Accent Gradient Border */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 opacity-80" />

      {/* Header Bar */}
      <div className="relative px-5 pt-4 pb-3 border-b border-white/10 flex items-center justify-between gap-2 flex-wrap bg-[#161920]/60">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
            {note.courseCode}
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-lg bg-white/5 text-slate-200 border border-white/10">
            <Calendar className="w-3 h-3 text-indigo-400" />
            Week {note.weekNumber}
          </span>
          {/* Qualifier Core / Milestone Badge */}
          {note.weekNumber <= 4 ? (
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              ★ Qualifier Core
            </span>
          ) : note.weekNumber <= 8 ? (
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Quiz 2 Milestone
            </span>
          ) : (
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              End Term Scope
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5">
          {onDownloadPdf && (
            <button
              onClick={onDownloadPdf}
              className="p-1.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:border-indigo-500/50 transition-colors"
              title="Download Note as PDF"
              aria-label="Download Note as PDF"
            >
              <FileDown className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={onToggleBookmark}
            className={`p-1.5 rounded-xl border transition-colors ${
              isBookmarked
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20'
            }`}
            title="Bookmark Note"
            aria-label="Bookmark Note"
          >
            <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-400' : ''}`} />
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:border-indigo-500/50 transition-colors"
            title={isExpanded ? 'Collapse Full Notes' : 'Expand Full Notes'}
          >
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Card Content */}
      <div className="px-5 py-4 space-y-4">
        
        {/* Title */}
        <div>
          <span className="text-[11px] font-semibold text-slate-400 block mb-0.5">
            {note.courseTitle}
          </span>
          <h3 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
            {note.title}
          </h3>
        </div>

        {/* Marginal / High-Yield Tip */}
        {note.handwrittenMnemonic && (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 relative">
            <div className="flex items-start gap-2.5">
              <Pin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block mb-0.5">
                  High-Yield Memory Cue &amp; Exam Insight:
                </span>
                <p className="text-sm font-medium text-amber-200 leading-snug">
                  {note.handwrittenMnemonic}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Section Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-[#161920] rounded-xl border border-white/10 overflow-x-auto">
          <button
            onClick={() => { setActiveTab('detailed'); setIsExpanded(true); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'detailed' && isExpanded
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Detailed Notes</span>
          </button>

          <button
            onClick={() => { setActiveTab('revision'); setIsExpanded(true); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'revision' && isExpanded
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Quick Revision ({revisionPoints.length})</span>
          </button>

          {formulas.length > 0 && (
            <button
              onClick={() => { setActiveTab('formulas'); setIsExpanded(true); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === 'formulas' && isExpanded
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Formula Sheet ({formulas.length})</span>
            </button>
          )}

          {practiceProblems.length > 0 && (
            <button
              onClick={() => { setActiveTab('practice'); setIsExpanded(true); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeTab === 'practice' && isExpanded
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Practice Questions ({practiceProblems.length})</span>
            </button>
          )}
        </div>

        {/* Tab 1: Detailed Notes (Default Preview & Expanded View) */}
        {(!isExpanded || activeTab === 'detailed') && (
          <div className="space-y-3">
            <div className={`p-4 rounded-xl bg-[#161920] border border-white/10 text-xs text-slate-200 space-y-2.5 ${!isExpanded ? 'max-h-60 overflow-hidden relative' : ''}`}>
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="font-bold text-white flex items-center gap-1.5 text-xs">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                  Comprehensive Academic Explanations &amp; Theory:
                </span>
                <span className="text-[10px] text-slate-400">Week {note.weekNumber}</span>
              </div>
              <div className="leading-relaxed space-y-2 whitespace-pre-line text-slate-300">
                <MathRenderer text={detailedText} />
              </div>

              {!isExpanded && (
                <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[#161920] to-transparent flex items-end justify-center pb-2">
                  <button
                    onClick={() => setIsExpanded(true)}
                    className="px-3.5 py-1.5 rounded-full bg-indigo-600 text-white text-[11px] font-bold hover:bg-indigo-500 transition-colors shadow-lg shadow-indigo-600/30"
                  >
                    Read Full Detailed Notes ↓
                  </button>
                </div>
              )}
            </div>

            {/* Definitions & Theorem items if present */}
            {isExpanded && note.definitions && note.definitions.length > 0 && (
              <div className="space-y-2.5 pt-2">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  Key Definitions &amp; Formal Statements:
                </span>
                <div className="grid grid-cols-1 gap-2.5">
                  {note.definitions.map((def, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl bg-[#161920] border border-white/10 text-xs space-y-1.5"
                    >
                      <span className="font-bold text-indigo-300">
                        {def.term}
                      </span>
                      <p className="text-slate-300 leading-relaxed">
                        <MathRenderer text={def.explanation} />
                      </p>
                      {def.formula && (
                        <div className="pt-2 pb-1 text-center bg-[#0A0C10] rounded-lg my-1 border border-white/10">
                          <MathRenderer math={def.formula} block={true} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Quick Revision Notes */}
        {isExpanded && activeTab === 'revision' && (
          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-[#161920] border border-indigo-500/20 space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-400">
                <Sparkles className="w-3.5 h-3.5" />
                <span>High-Yield Quick Revision Bullet Points:</span>
              </div>
              <ul className="space-y-2 text-xs text-slate-200">
                {revisionPoints.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 p-2.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                    <span className="leading-relaxed text-slate-200">
                      <MathRenderer text={item} />
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Key Takeaways list if separate */}
            {note.keyTakeaways && note.keyTakeaways.length > 0 && note.quickRevisionNotes && (
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 space-y-2">
                <span className="text-xs font-bold text-amber-300">
                  Essential Takeaways for IIT Madras Assessments:
                </span>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {note.keyTakeaways.map((takeaway, tIdx) => (
                    <li key={tIdx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span><MathRenderer text={takeaway} /></span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Formula Sheets */}
        {isExpanded && activeTab === 'formulas' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 gap-3">
              {formulas.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-[#161920] border border-white/10 text-xs space-y-2.5 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">
                      {item.name}
                    </span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      Formula #{idx + 1}
                    </span>
                  </div>

                  <div className="py-2.5 px-3 text-center bg-[#0A0C10] rounded-lg border border-white/10 my-1.5 overflow-x-auto text-indigo-200">
                    <MathRenderer math={item.formula} block={true} />
                  </div>

                  <p className="text-slate-300 leading-relaxed">
                    <MathRenderer text={item.description} />
                  </p>

                  {item.variables && item.variables.length > 0 && (
                    <div className="pt-2 border-t border-white/10 text-[11px] text-slate-400 space-y-1">
                      <span className="font-semibold text-slate-300">Variable Notations:</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                        {item.variables.map((v, vIdx) => (
                          <div key={vIdx} className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-indigo-400">{v.symbol}:</span>
                            <span>{v.meaning}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Practice Questions & Solved Problems */}
        {isExpanded && activeTab === 'practice' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-1 border-b border-white/10">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
                Standard Week {note.weekNumber} Practice Problems &amp; Self-Assessments:
              </span>
              <span className="text-[11px] text-slate-400">{practiceProblems.length} Problems</span>
            </div>

            <div className="space-y-4">
              {practiceProblems.map((q, qIdx) => {
                const selected = selectedAnswers[q.id];
                const isSolutionRevealed = revealedSolutions[q.id];
                const isHintRevealed = revealedHints[q.id];
                const isCorrect = selected !== undefined && q.correctOptionIndex !== undefined && selected === q.correctOptionIndex;

                return (
                  <div
                    key={q.id || qIdx}
                    className="p-4 rounded-xl bg-[#161920] border border-white/10 text-xs space-y-3 shadow-md"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-bold text-white text-xs sm:text-sm">
                        Q{qIdx + 1}. <MathRenderer text={q.questionText} />
                      </span>
                    </div>

                    {/* Options (MCQ) */}
                    {q.options && q.options.length > 0 && (
                      <div className="grid grid-cols-1 gap-2 pt-1">
                        {q.options.map((opt, optIdx) => {
                          const isThisSelected = selected === optIdx;
                          const isThisCorrect = q.correctOptionIndex === optIdx;
                          let optionClass = 'border-white/10 bg-[#0A0C10] text-slate-300 hover:border-indigo-500/50 hover:bg-white/5';

                          if (isThisSelected) {
                            if (isThisCorrect) {
                              optionClass = 'border-emerald-500/80 bg-emerald-500/20 text-emerald-200 font-medium';
                            } else {
                              optionClass = 'border-rose-500/80 bg-rose-500/20 text-rose-200 font-medium';
                            }
                          } else if (isSolutionRevealed && isThisCorrect) {
                            optionClass = 'border-emerald-500/80 bg-emerald-500/10 text-emerald-300 font-medium';
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectOption(q.id, optIdx)}
                              className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between gap-2 ${optionClass}`}
                            >
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full border border-white/20 flex items-center justify-center text-[10px] font-bold shrink-0">
                                  {String.fromCharCode(65 + optIdx)}
                                </span>
                                <span><MathRenderer text={opt} /></span>
                              </div>
                              {isThisSelected && (
                                isThisCorrect 
                                  ? <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                                  : <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                              )}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Hint & Solution Actions */}
                    <div className="flex items-center gap-2 pt-2 border-t border-white/10 flex-wrap">
                      {q.hints && q.hints.length > 0 && (
                        <button
                          onClick={() => toggleHint(q.id)}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30 transition-colors flex items-center gap-1"
                        >
                          <Lightbulb className="w-3 h-3 text-amber-400" />
                          <span>{isHintRevealed ? 'Hide Hint' : 'Show Hint'}</span>
                        </button>
                      )}

                      <button
                        onClick={() => toggleSolution(q.id)}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/30 transition-colors flex items-center gap-1"
                      >
                        {isSolutionRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{isSolutionRevealed ? 'Hide Solution' : 'View Step-by-Step Solution'}</span>
                      </button>
                    </div>

                    {/* Revealed Hint */}
                    {isHintRevealed && q.hints && (
                      <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs">
                        <span className="font-bold block mb-0.5">Hint:</span>
                        {q.hints.map((h, hIdx) => (
                          <p key={hIdx}><MathRenderer text={h} /></p>
                        ))}
                      </div>
                    )}

                    {/* Revealed Solution */}
                    {isSolutionRevealed && (
                      <div className="p-3 rounded-lg bg-[#0A0C10] border border-indigo-500/30 text-slate-200 text-xs space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-indigo-400">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Step-by-Step Mathematical Solution:</span>
                        </div>
                        <div className="leading-relaxed pl-1 pt-1 text-slate-300">
                          <MathRenderer text={q.solution} />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Code Snippets if any */}
        {isExpanded && note.codeSnippets && note.codeSnippets.length > 0 && (
          <div className="space-y-2.5 pt-2">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Code className="w-3.5 h-3.5 text-indigo-400" />
              Reference Implementation Code:
            </span>
            {note.codeSnippets.map((snippet, sIdx) => {
              const sId = `snippet-${note.id}-${sIdx}`;
              return (
                <div
                  key={sIdx}
                  className="rounded-xl overflow-hidden border border-white/10 bg-[#0A0C10] text-slate-100 text-xs font-mono"
                >
                  <div className="px-3.5 py-2 bg-[#161920] border-b border-white/10 flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-300">
                      {snippet.title} ({snippet.language})
                    </span>
                    <button
                      onClick={() => handleCopyCode(sId, snippet.code)}
                      className="text-[10px] text-slate-300 hover:text-white flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 hover:bg-white/20 transition-colors"
                    >
                      {copiedSnippetId === sId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      {copiedSnippetId === sId ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="p-3.5 overflow-x-auto text-[11px] leading-relaxed text-slate-200">
                    <code>{snippet.code}</code>
                  </pre>
                </div>
              );
            })}
          </div>
        )}

        {/* Exam Tips */}
        {isExpanded && note.examTips && note.examTips.length > 0 && (
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-amber-300">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>IIT Madras Exam / Qualifier Tips:</span>
            </div>
            <ul className="space-y-1 text-slate-300">
              {note.examTips.map((tip, idx) => (
                <li key={idx} className="pl-2.5 border-l-2 border-amber-400">
                  <MathRenderer text={tip} />
                </li>
              ))}
            </ul>
          </div>
        )}

      </div>

      {/* Footer / Toggle Expand strip */}
      <div className="px-5 py-2.5 bg-[#161920]/70 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
        <span>{note.practiceRecommendation ? `Recommended: ${note.practiceRecommendation}` : `Week ${note.weekNumber} • Comprehensive IIT Madras Curriculum`}</span>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="font-bold text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
        >
          {isExpanded ? 'Collapse notes' : 'Expand full study material'}
        </button>
      </div>
    </div>
  );
};

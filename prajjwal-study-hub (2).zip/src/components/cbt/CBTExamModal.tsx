import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Bookmark, 
  ChevronLeft, 
  ChevronRight, 
  Send, 
  RotateCcw, 
  Award, 
  BarChart2, 
  Sparkles, 
  Layers, 
  Info,
  Maximize2,
  Minimize2,
  CheckSquare,
  Square,
  Hash,
  FileCode,
  ShieldAlert,
  ArrowRight,
  BookOpen,
  Download,
  Printer,
  FileDown,
  Calculator,
  Eye,
  EyeOff,
  Lightbulb,
  Play,
  Pause,
  Check,
  X,
  TrendingUp,
  Cpu,
  Target,
  Zap,
  CheckCheck,
  Volume2,
  VolumeX,
  Lock,
  Unlock,
  AlertTriangle,
  Hourglass,
  Activity,
  Timer
} from 'lucide-react';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { MockTest, Question, QuestionResponse, AcademicLevel } from '../../types';
import { downloadQuestionPaperPdf, downloadSolutionsPdf } from '../../utils/pdfExport';
import { ScientificCalculator } from './ScientificCalculator';
import { RichMathText, BlockMath, InlineMath } from '../common/MathRenderer';

// Official IIT Madras BS Exam Duration Helper
export function getOfficialIITMDuration(test: MockTest): number {
  const category = (test.examCategory || test.type || '').toLowerCase();
  const title = (test.title || '').toLowerCase();

  if (category.includes('qualifier') || title.includes('qualifier')) {
    return 240; // 4 Hours (240 mins)
  }
  if (category.includes('end term') || title.includes('end term') || category.includes('comprehensive')) {
    return 180; // 3 Hours (180 mins)
  }
  if (category.includes('quiz 1') || category.includes('quiz 2') || title.includes('quiz 1') || title.includes('quiz 2')) {
    return 90; // 90 mins
  }
  if (category.includes('oppe') || title.includes('oppe')) {
    return 90; // 90 mins
  }
  return test.durationMinutes || 90;
}

// Zero-dependency Web Audio API Synthesizer for subtle CBT audio chimes
const playExamAlertSound = (type: 'warning15' | 'critical5' | 'timesUp') => {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    if (type === 'warning15') {
      // Gentle two-tone melodic chime (E5 -> A5)
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc1.type = 'sine';
      osc2.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, ctx.currentTime);
      osc2.frequency.setValueAtTime(880.00, ctx.currentTime + 0.15);
      
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.7);
      
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      
      osc1.start(ctx.currentTime);
      osc1.stop(ctx.currentTime + 0.2);
      osc2.start(ctx.currentTime + 0.15);
      osc2.stop(ctx.currentTime + 0.7);
    } else if (type === 'critical5') {
      // 3-tone warning chime (C5 -> E5 -> G5)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      
      osc.frequency.setValueAtTime(523.25, ctx.currentTime);
      osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.15);
      osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.3);
      
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.6);
    } else if (type === 'timesUp') {
      // Distinct low end-tone
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(220, ctx.currentTime + 0.8);
      
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.9);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.9);
    }
  } catch (e) {
    // Graceful fallback if autoplay restrictions apply
  }
};

interface CBTExamModalProps {
  test: MockTest;
  questions: Question[];
  userName?: string;
  initialDurationMinutes?: number;
  initialPracticeMode?: boolean;
  onClose: () => void;
  onComplete: (result: {
    score: number;
    totalMarks: number;
    percentage: number;
    accuracy: number;
    timeSpentSeconds: number;
    correctAnswers: number;
    incorrectAnswers: number;
    unattempted: number;
    responses: Record<string, QuestionResponse>;
    isAutoSubmitted?: boolean;
  }) => void;
}

export const CBTExamModal: React.FC<CBTExamModalProps> = ({
  test,
  questions,
  userName = 'Candidate',
  initialDurationMinutes,
  initialPracticeMode = false,
  onClose,
  onComplete
}) => {
  // Determine effective test duration (minutes)
  const durationMins = initialDurationMinutes !== undefined 
    ? initialDurationMinutes 
    : getOfficialIITMDuration(test);
  
  const isUntimed = durationMins === 0;
  const initialSeconds = isUntimed ? 0 : durationMins * 60;

  // Live Timer states
  const [timeLeft, setTimeLeft] = useState(initialSeconds);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Auto-submit modal & submission state
  const [isAutoSubmitting, setIsAutoSubmitting] = useState(false);
  const [wasAutoSubmitted, setWasAutoSubmitted] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  // Audio alert trigger guards so sounds only play once per threshold
  const hasTriggered15Warning = useRef(false);
  const hasTriggered5Warning = useRef(false);
  const hasTriggered1Warning = useRef(false);

  // Current question index & interaction states
  const [currentIdx, setCurrentIdx] = useState(0);
  const [showCalculator, setShowCalculator] = useState(false);
  const [isPracticeMode, setIsPracticeMode] = useState(initialPracticeMode);
  const [showHint, setShowHint] = useState(false);
  const [showPracticeSolution, setShowPracticeSolution] = useState(false);
  const [selectedSectionFilter, setSelectedSectionFilter] = useState<string>('All');

  // Post-exam analytics tab
  const [analysisActiveTab, setAnalysisActiveTab] = useState<'summary' | 'analytics' | 'solutions'>('summary');
  const [solutionFilter, setSolutionFilter] = useState<'all' | 'correct' | 'incorrect' | 'unattempted'>('all');

  // Per-question time tracking (seconds)
  const [questionTimeMap, setQuestionTimeMap] = useState<Record<string, number>>({});

  // Code editor state for OPPE questions
  const [codeAnswers, setCodeAnswers] = useState<Record<string, string>>(() => {
    const initialCode: Record<string, string> = {};
    questions.forEach(q => {
      if (q.starterCode) {
        initialCode[q.id] = q.starterCode;
      }
    });
    return initialCode;
  });

  // OPPE test case run status
  const [testCaseRunState, setTestCaseRunState] = useState<Record<string, {
    isRunning: boolean;
    results: Array<{ id: string; input: string; expected: string; actual: string; passed: boolean }>;
  }>>({});

  // Responses state for every question
  const [responses, setResponses] = useState<Record<string, QuestionResponse>>(() => {
    const initial: Record<string, QuestionResponse> = {};
    questions.forEach(q => {
      initial[q.id] = {
        questionId: q.id,
        selectedOptionIndex: undefined,
        selectedOptionIndices: [],
        numericAnswer: '',
        codeAnswer: q.starterCode || '',
        isMarkedForReview: false,
        isAnswered: false,
      };
    });
    return initial;
  });

  // Track visited questions
  const [visitedQuestions, setVisitedQuestions] = useState<Set<string>>(() => new Set([questions[0]?.id]));

  // Current question
  const currentQuestion: Question | undefined = questions[currentIdx];

  // Record visited question whenever index changes
  useEffect(() => {
    if (currentQuestion) {
      setVisitedQuestions(prev => new Set(prev).add(currentQuestion.id));
      setShowHint(false);
      setShowPracticeSolution(false);
    }
  }, [currentIdx, currentQuestion]);

  // Track time spent per individual question
  useEffect(() => {
    if (isSubmitted || isPaused || isAutoSubmitting || !currentQuestion) return;
    const interval = setInterval(() => {
      setQuestionTimeMap(prev => ({
        ...prev,
        [currentQuestion.id]: (prev[currentQuestion.id] || 0) + 1
      }));
      setElapsedSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [currentIdx, currentQuestion, isSubmitted, isPaused, isAutoSubmitting]);

  // Live Timer Countdown & Audio-Visual Warning Machine
  useEffect(() => {
    if (isSubmitted || isPaused || isAutoSubmitting || isUntimed) return;

    if (timeLeft <= 0) {
      triggerAutoSubmit();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        const nextVal = prev - 1;

        // 15-minute alert check (900 seconds)
        if (nextVal <= 900 && nextVal > 895 && !hasTriggered15Warning.current) {
          hasTriggered15Warning.current = true;
          if (soundEnabled) playExamAlertSound('warning15');
        }

        // 5-minute critical alert check (300 seconds)
        if (nextVal <= 300 && nextVal > 295 && !hasTriggered5Warning.current) {
          hasTriggered5Warning.current = true;
          if (soundEnabled) playExamAlertSound('critical5');
        }

        // 1-minute alert check (60 seconds)
        if (nextVal <= 60 && nextVal > 55 && !hasTriggered1Warning.current) {
          hasTriggered1Warning.current = true;
          if (soundEnabled) playExamAlertSound('critical5');
        }

        // 00:00:00 Auto-submit check
        if (nextVal <= 0) {
          clearInterval(timer);
          triggerAutoSubmit();
          return 0;
        }

        return nextVal;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isSubmitted, isPaused, isAutoSubmitting, isUntimed, soundEnabled]);

  // Trigger graceful IIT Madras CBT Auto-Submit
  const triggerAutoSubmit = () => {
    if (soundEnabled) playExamAlertSound('timesUp');
    setIsAutoSubmitting(true);
    setWasAutoSubmitted(true);

    // Auto-freeze interactions and transition to results after brief countdown effect
    setTimeout(() => {
      setIsAutoSubmitting(false);
      setIsSubmitted(true);
    }, 1200);
  };

  // Time format helper: HH:MM:SS
  const formatTime = (seconds: number) => {
    if (seconds < 0) seconds = 0;
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Distinct academic sections for section navigation
  const availableSections = useMemo(() => {
    const subjects = new Set<string>();
    questions.forEach(q => {
      if (q.subject) subjects.add(q.subject);
      else if (q.courseTitle) subjects.add(q.courseTitle);
    });
    return Array.from(subjects);
  }, [questions]);

  // Response handlers
  const handleSelectMCQ = (optionIdx: number) => {
    if (!currentQuestion || isSubmitted) return;
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        selectedOptionIndex: optionIdx,
        isAnswered: true
      }
    }));
  };

  const handleToggleMSQ = (optionIdx: number) => {
    if (!currentQuestion || isSubmitted) return;
    setResponses(prev => {
      const currentList = prev[currentQuestion.id]?.selectedOptionIndices || [];
      const updatedList = currentList.includes(optionIdx)
        ? currentList.filter(i => i !== optionIdx)
        : [...currentList, optionIdx].sort((a, b) => a - b);
      return {
        ...prev,
        [currentQuestion.id]: {
          ...prev[currentQuestion.id],
          selectedOptionIndices: updatedList,
          isAnswered: updatedList.length > 0
        }
      };
    });
  };

  const handleNumericInput = (val: string) => {
    if (!currentQuestion || isSubmitted) return;
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        numericAnswer: val,
        isAnswered: val.trim() !== ''
      }
    }));
  };

  const handleCodeInput = (code: string) => {
    if (!currentQuestion || isSubmitted) return;
    setCodeAnswers(prev => ({ ...prev, [currentQuestion.id]: code }));
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        codeAnswer: code,
        isAnswered: code.trim().length > 20
      }
    }));
  };

  const handleRunTestCases = (q: Question) => {
    if (!q.testCases || q.testCases.length === 0) return;
    
    setTestCaseRunState(prev => ({
      ...prev,
      [q.id]: { isRunning: true, results: [] }
    }));

    setTimeout(() => {
      const userCode = codeAnswers[q.id] || q.starterCode || '';
      // Evaluate simulated test runs
      const results = q.testCases!.map((tc, idx) => {
        // High-confidence heuristic simulation for demo runner
        const isSolutionCode = userCode.length > 40 && !userCode.includes('pass') && !userCode.includes('raise NotImplementedError');
        return {
          id: tc.id,
          input: tc.input,
          expected: tc.expectedOutput,
          actual: isSolutionCode ? tc.expectedOutput : 'None / Incomplete Execution',
          passed: isSolutionCode
        };
      });

      const passedCount = results.filter(r => r.passed).length;

      setTestCaseRunState(prev => ({
        ...prev,
        [q.id]: { isRunning: false, results }
      }));

      setResponses(prev => ({
        ...prev,
        [q.id]: {
          ...prev[q.id],
          isAnswered: true,
          testCasesPassed: passedCount,
          totalTestCases: q.testCases!.length,
          selectedOptionIndex: passedCount === q.testCases!.length ? (q.correctOptionIndex ?? 0) : undefined
        }
      }));
    }, 600);
  };

  const handleClearResponse = () => {
    if (!currentQuestion || isSubmitted) return;
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        selectedOptionIndex: undefined,
        selectedOptionIndices: [],
        numericAnswer: '',
        codeAnswer: currentQuestion.starterCode || '',
        isAnswered: false
      }
    }));
    if (currentQuestion.starterCode) {
      setCodeAnswers(prev => ({ ...prev, [currentQuestion.id]: currentQuestion.starterCode || '' }));
    }
  };

  const handleToggleMarkForReview = () => {
    if (!currentQuestion || isSubmitted) return;
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        isMarkedForReview: !prev[currentQuestion.id]?.isMarkedForReview
      }
    }));
  };

  const handleSaveAndNext = () => {
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
    }
  };

  const handleMarkAndNext = () => {
    handleToggleMarkForReview();
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
    }
  };

  // Palette Status calculations
  const paletteStats = useMemo(() => {
    let answered = 0;
    let markedForReview = 0;
    let answeredAndMarked = 0;
    let notAnswered = 0;
    let notVisited = 0;

    questions.forEach(q => {
      const res = responses[q.id];
      const isVisited = visitedQuestions.has(q.id);
      const isAns = res?.isAnswered;
      const isMarked = res?.isMarkedForReview;

      if (isAns && isMarked) {
        answeredAndMarked++;
      } else if (isMarked) {
        markedForReview++;
      } else if (isAns) {
        answered++;
      } else if (isVisited) {
        notAnswered++;
      } else {
        notVisited++;
      }
    });

    return {
      answered,
      markedForReview,
      answeredAndMarked,
      notAnswered,
      notVisited,
      total: questions.length
    };
  }, [questions, responses, visitedQuestions]);

  const getQuestionStatus = (qId: string) => {
    const res = responses[qId];
    const isVisited = visitedQuestions.has(qId);
    const isAns = res?.isAnswered;
    const isMarked = res?.isMarkedForReview;

    if (isAns && isMarked) return 'answered-marked';
    if (isMarked) return 'marked';
    if (isAns) return 'answered';
    if (isVisited) return 'not-answered';
    return 'not-visited';
  };

  // Evaluation on submission
  const testResults = useMemo(() => {
    if (!isSubmitted) return null;
    let totalScore = 0;
    let totalPossibleMarks = 0;
    let correctAnswers = 0;
    let incorrectAnswers = 0;
    let unattempted = 0;

    const evaluatedResponses: Record<string, QuestionResponse> = {};
    const topicStats: Record<string, { total: number; correct: number; score: number; possible: number }> = {};
    const typeStats: Record<string, { total: number; correct: number }> = {
      MCQ: { total: 0, correct: 0 },
      MSQ: { total: 0, correct: 0 },
      NAT: { total: 0, correct: 0 },
      CODE_OUTPUT: { total: 0, correct: 0 },
      OPPE_CODE: { total: 0, correct: 0 },
    };

    questions.forEach(q => {
      const res = responses[q.id] || {
        questionId: q.id,
        isAnswered: false,
        isMarkedForReview: false
      };
      const qMarks = q.marks || 2;
      const qNegMarks = q.negativeMarks || 0;
      totalPossibleMarks += qMarks;

      const qType = q.type || 'MCQ';
      if (!typeStats[qType]) {
        typeStats[qType] = { total: 0, correct: 0 };
      }
      typeStats[qType].total++;

      const topicKey = q.subject || q.courseTitle || 'Core Domain';
      if (!topicStats[topicKey]) {
        topicStats[topicKey] = { total: 0, correct: 0, score: 0, possible: 0 };
      }
      topicStats[topicKey].total++;
      topicStats[topicKey].possible += qMarks;

      let isCorrect = false;

      if (!res.isAnswered) {
        unattempted++;
        evaluatedResponses[q.id] = { ...res, isCorrect: false, marksAwarded: 0, timeSpentSeconds: questionTimeMap[q.id] || 0 };
        return;
      }

      if (q.type === 'MSQ' && q.correctOptionIndices) {
        const selected = (res.selectedOptionIndices || []).slice().sort();
        const correct = q.correctOptionIndices.slice().sort();
        if (selected.length === correct.length && selected.every((v, i) => v === correct[i])) {
          isCorrect = true;
        }
      } else if (q.type === 'NAT' && q.correctNumericAnswer !== undefined) {
        const userNum = parseFloat(res.numericAnswer || '');
        if (q.toleranceRange) {
          if (!isNaN(userNum) && userNum >= q.toleranceRange[0] && userNum <= q.toleranceRange[1]) {
            isCorrect = true;
          }
        } else {
          const tol = q.numericTolerance !== undefined ? q.numericTolerance : 0.01;
          if (!isNaN(userNum) && Math.abs(userNum - q.correctNumericAnswer) <= tol) {
            isCorrect = true;
          }
        }
      } else if (q.type === 'OPPE_CODE') {
        const passedCases = res.testCasesPassed || 0;
        const totalCases = q.testCases?.length || 1;
        if (passedCases === totalCases || res.selectedOptionIndex === (q.correctOptionIndex ?? 0)) {
          isCorrect = true;
        }
      } else {
        // MCQ or CODE_OUTPUT with correctOptionIndex
        const expected = q.correctOptionIndex !== undefined ? q.correctOptionIndex : 0;
        if (res.selectedOptionIndex === expected) {
          isCorrect = true;
        }
      }

      if (isCorrect) {
        correctAnswers++;
        totalScore += qMarks;
        typeStats[qType].correct++;
        topicStats[topicKey].correct++;
        topicStats[topicKey].score += qMarks;
        evaluatedResponses[q.id] = { ...res, isCorrect: true, marksAwarded: qMarks, timeSpentSeconds: questionTimeMap[q.id] || 0 };
      } else {
        incorrectAnswers++;
        totalScore = Math.max(0, totalScore - qNegMarks);
        topicStats[topicKey].score = Math.max(0, topicStats[topicKey].score - qNegMarks);
        evaluatedResponses[q.id] = { ...res, isCorrect: false, marksAwarded: -qNegMarks, timeSpentSeconds: questionTimeMap[q.id] || 0 };
      }
    });

    const percentage = totalPossibleMarks > 0 ? Math.round((totalScore / totalPossibleMarks) * 100) : 0;
    const attemptedCount = correctAnswers + incorrectAnswers;
    const accuracy = attemptedCount > 0 ? Math.round((correctAnswers / attemptedCount) * 100) : 0;
    const timeSpentSeconds = isUntimed ? elapsedSeconds : Math.min(initialSeconds, initialSeconds - timeLeft);

    // Percentile calculation estimation based on score percentage curve
    let estimatedPercentile = 50;
    if (percentage >= 90) estimatedPercentile = 99.4;
    else if (percentage >= 80) estimatedPercentile = 96.2;
    else if (percentage >= 70) estimatedPercentile = 89.5;
    else if (percentage >= 60) estimatedPercentile = 78.0;
    else if (percentage >= 50) estimatedPercentile = 65.5;
    else if (percentage >= 40) estimatedPercentile = 52.0;
    else estimatedPercentile = Math.max(10, Math.round(percentage * 1.1));

    // Question Pacing metrics
    const questionPacingList = questions.map((q, idx) => {
      const timeSpent = questionTimeMap[q.id] || 0;
      const resp = evaluatedResponses[q.id];
      let paceStatus: 'fast' | 'ideal' | 'slow' = 'ideal';
      if (timeSpent < 60) paceStatus = 'fast';
      else if (timeSpent > 240) paceStatus = 'slow';
      return {
        questionId: q.id,
        index: idx + 1,
        subject: q.subject || q.courseTitle || 'Subject',
        type: q.type || 'MCQ',
        timeSpent,
        isCorrect: resp?.isCorrect || false,
        isAnswered: resp?.isAnswered || false,
        paceStatus
      };
    });

    const nonZeroPacing = questionPacingList.filter(p => p.timeSpent > 0);
    const avgTimePerQ = nonZeroPacing.length > 0 
      ? Math.round(nonZeroPacing.reduce((acc, curr) => acc + curr.timeSpent, 0) / nonZeroPacing.length)
      : Math.round(timeSpentSeconds / Math.max(1, questions.length));

    const fastestQ = nonZeroPacing.length > 0 
      ? nonZeroPacing.slice().sort((a, b) => a.timeSpent - b.timeSpent)[0] 
      : null;

    const slowestQ = nonZeroPacing.length > 0 
      ? nonZeroPacing.slice().sort((a, b) => b.timeSpent - a.timeSpent)[0] 
      : null;

    return {
      score: totalScore,
      totalMarks: totalPossibleMarks,
      percentage,
      accuracy,
      timeSpentSeconds,
      correctAnswers,
      incorrectAnswers,
      unattempted,
      estimatedPercentile,
      isPassed: percentage >= (test.passingMarks ? (test.passingMarks / test.totalMarks) * 100 : 40),
      topicStats,
      typeStats,
      responses: evaluatedResponses,
      questionPacingList,
      avgTimePerQ,
      fastestQ,
      slowestQ,
      wasAutoSubmitted
    };
  }, [isSubmitted, questions, responses, initialSeconds, timeLeft, isUntimed, elapsedSeconds, test, questionTimeMap, wasAutoSubmitted]);

  const handleFinalSubmit = () => {
    setShowSubmitConfirm(false);
    setIsSubmitted(true);
  };

  const handleFinishAndSave = () => {
    if (testResults) {
      onComplete({
        score: testResults.score,
        totalMarks: testResults.totalMarks,
        percentage: testResults.percentage,
        accuracy: testResults.accuracy,
        timeSpentSeconds: testResults.timeSpentSeconds,
        correctAnswers: testResults.correctAnswers,
        incorrectAnswers: testResults.incorrectAnswers,
        unattempted: testResults.unattempted,
        responses: testResults.responses,
        isAutoSubmitted: testResults.wasAutoSubmitted
      });
    }
  };

  // If test is submitted, render the comprehensive Post-Exam Solution & Performance Analytics Report
  if (isSubmitted && testResults) {
    const filteredQuestionsForSolution = questions.filter(q => {
      const resp = testResults.responses[q.id];
      if (solutionFilter === 'correct') return resp?.isCorrect;
      if (solutionFilter === 'incorrect') return resp?.isAnswered && !resp?.isCorrect;
      if (solutionFilter === 'unattempted') return !resp?.isAnswered;
      return true;
    });

    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
          
          {/* Header */}
          <div className="p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50 dark:bg-slate-950/60">
            <div>
              <div className="flex items-center gap-2">
                <Badge variant={test.level === 'Foundation' ? 'info' : test.level === 'Diploma' ? 'warning' : 'danger'} size="sm">
                  {test.level || 'Foundation'} Level
                </Badge>
                {test.termYear && (
                  <Badge variant="outline" size="sm">
                    {test.termYear}
                  </Badge>
                )}
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Official Exam CBT Report</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-1">
                {test.title}
              </h2>
            </div>
            
            <div className="flex flex-wrap items-center gap-2">
              <Button
                id="btn-pdf-download-solutions"
                variant="outline"
                size="sm"
                onClick={() => downloadSolutionsPdf(test, questions, testResults, userName)}
                icon={<Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />}
              >
                Download Solutions (PDF)
              </Button>
              <Button
                id="btn-print-results"
                variant="outline"
                size="sm"
                onClick={() => downloadSolutionsPdf(test, questions, testResults, userName)}
                icon={<Printer className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
              >
                Print Results
              </Button>
              <Button
                id="btn-close-cbt-analysis"
                variant="primary"
                size="sm"
                onClick={handleFinishAndSave}
                icon={<CheckCircle2 className="w-4 h-4" />}
              >
                Save & Exit
              </Button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 bg-white dark:bg-slate-900">
            <button
              id="cbt-tab-summary"
              onClick={() => setAnalysisActiveTab('summary')}
              className={`py-3 px-4 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
                analysisActiveTab === 'summary'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              <Award className="w-4 h-4" />
              Score Summary
            </button>
            <button
              id="cbt-tab-analytics"
              onClick={() => setAnalysisActiveTab('analytics')}
              className={`py-3 px-4 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
                analysisActiveTab === 'analytics'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              Performance & Topic Analytics
            </button>
            <button
              id="cbt-tab-solutions"
              onClick={() => setAnalysisActiveTab('solutions')}
              className={`py-3 px-4 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
                analysisActiveTab === 'solutions'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              Step-by-Step Solutions ({questions.length})
            </button>
          </div>

          {/* Tab Content */}
          <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
            
            {/* 1. SCORE SUMMARY TAB */}
            {analysisActiveTab === 'summary' && (
              <>
                {/* Auto-Submit Notice Banner */}
                {testResults.wasAutoSubmitted && (
                  <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
                    <div className="text-xs">
                      <span className="font-bold">Auto-Submitted on Time Limit Expiration (00:00:00): </span>
                      Your test reached the official duration limit. All submitted answers were safely recorded and evaluated under IIT Madras CBT grading rules.
                    </div>
                  </div>
                )}

                {/* Score Banner */}
                <div className={`p-6 rounded-2xl border ${
                  testResults.isPassed 
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/80 text-emerald-950 dark:text-emerald-100'
                    : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/80 text-amber-950 dark:text-amber-100'
                } flex flex-col sm:flex-row items-center justify-between gap-6`}>
                  <div className="flex items-center gap-4">
                    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                      testResults.isPassed ? 'bg-emerald-500 text-white' : 'bg-amber-500 text-white'
                    } shadow-lg`}>
                      <Award className="w-8 h-8" />
                    </div>
                    <div>
                      <div className="text-xs uppercase font-bold tracking-wider opacity-80 flex items-center gap-2">
                        <span>{testResults.isPassed ? 'Qualifier Benchmark Cleared' : 'Needs Reinforcement'}</span>
                        <span>•</span>
                        <span className="text-indigo-600 dark:text-indigo-400 font-bold">~{testResults.estimatedPercentile}th Percentile</span>
                      </div>
                      <div className="text-3xl font-extrabold mt-0.5">
                        Score: {testResults.score} / {testResults.totalMarks}
                      </div>
                      <div className="text-xs mt-1 opacity-75">
                        Percentage: {testResults.percentage}% | Time Taken: {formatTime(testResults.timeSpentSeconds)} {isUntimed ? '(Untimed)' : `/ ${durationMins}m`}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Button
                      id="btn-view-analytics-cta"
                      variant="outline"
                      size="md"
                      onClick={() => setAnalysisActiveTab('analytics')}
                      icon={<TrendingUp className="w-4 h-4" />}
                    >
                      View Breakdown
                    </Button>
                    <Button
                      id="btn-view-detailed-solutions-cta"
                      variant="primary"
                      size="md"
                      onClick={() => setAnalysisActiveTab('solutions')}
                      icon={<Sparkles className="w-4 h-4" />}
                    >
                      Review Solutions
                    </Button>
                  </div>
                </div>

                {/* Metrics Breakdown Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Accuracy</div>
                    <div className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{testResults.accuracy}%</div>
                    <div className="text-xs text-slate-500 mt-1">{testResults.correctAnswers} of {testResults.correctAnswers + testResults.incorrectAnswers} attempted</div>
                  </div>
                  <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/50 dark:bg-emerald-950/20">
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">Correct Answers</div>
                    <div className="text-2xl font-bold text-emerald-700 dark:text-emerald-300 mt-1">{testResults.correctAnswers}</div>
                    <div className="text-xs text-emerald-600/80 mt-1">Full marks secured</div>
                  </div>
                  <div className="p-4 rounded-xl border border-rose-200 dark:border-rose-900/40 bg-rose-50/50 dark:bg-rose-950/20">
                    <div className="text-xs text-rose-600 dark:text-rose-400 font-medium">Incorrect Answers</div>
                    <div className="text-2xl font-bold text-rose-700 dark:text-rose-300 mt-1">{testResults.incorrectAnswers}</div>
                    <div className="text-xs text-rose-600/80 mt-1">Review derivations</div>
                  </div>
                  <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Unattempted</div>
                    <div className="text-2xl font-bold text-slate-700 dark:text-slate-300 mt-1">{testResults.unattempted}</div>
                    <div className="text-xs text-slate-500 mt-1">Zero score impact</div>
                  </div>
                </div>
              </>
            )}

            {/* 2. PERFORMANCE & TOPIC ANALYTICS TAB */}
            {analysisActiveTab === 'analytics' && (
              <div className="space-y-6">
                
                {/* Topic Wise Accuracy Breakdown */}
                <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                      <Target className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      Topic & Subject Mastery Breakdown
                    </h3>
                    <span className="text-xs text-slate-500">Based on evaluated test score</span>
                  </div>

                  <div className="space-y-3">
                    {Object.entries(testResults.topicStats).map(([topic, rawData]) => {
                      const data = rawData as { total: number; correct: number; score: number; possible: number };
                      const topicPercentage = data.possible > 0 ? Math.round((data.score / data.possible) * 100) : 0;
                      return (
                        <div key={topic} className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                          <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
                            <span className="text-slate-900 dark:text-slate-100">{topic}</span>
                            <span className="text-indigo-600 dark:text-indigo-400">
                              {data.score} / {data.possible} Marks ({topicPercentage}%)
                            </span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                            <div 
                              className={`h-full rounded-full transition-all ${
                                topicPercentage >= 75 ? 'bg-emerald-500' : topicPercentage >= 40 ? 'bg-indigo-500' : 'bg-amber-500'
                              }`}
                              style={{ width: `${Math.max(4, topicPercentage)}%` }}
                            />
                          </div>
                          <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                            <span>{data.correct} of {data.total} questions answered correctly</span>
                            <span>{topicPercentage >= 60 ? 'Strong Foundation' : 'Needs Practice'}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Question Type Performance & Time Allocation */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Question Type Breakdown */}
                  <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-purple-600" />
                      Question Format Mastery
                    </h3>
                    <div className="space-y-2.5">
                      {Object.entries(testResults.typeStats).filter(([_, d]) => (d as { total: number }).total > 0).map(([type, rawData]) => {
                        const data = rawData as { total: number; correct: number };
                        const typePct = Math.round((data.correct / data.total) * 100);
                        return (
                          <div key={type} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 text-xs">
                            <div className="font-semibold text-slate-800 dark:text-slate-200">{type} Format</div>
                            <div className="flex items-center gap-3">
                              <span className="text-slate-500">{data.correct} / {data.total} solved</span>
                              <Badge variant={typePct >= 60 ? 'success' : 'warning'} size="sm">
                                {typePct}% Accuracy
                              </Badge>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Time Management Analysis */}
                  <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <Clock className="w-4 h-4 text-emerald-600" />
                      Pacing & Speed Metrics
                    </h3>
                    <div className="space-y-3 text-xs">
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 flex items-center justify-between">
                        <span className="text-slate-500">Average Time per Question:</span>
                        <span className="font-bold text-slate-900 dark:text-white">
                          {Math.floor(testResults.avgTimePerQ / 60)}m {testResults.avgTimePerQ % 60}s
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 flex items-center justify-between">
                        <span className="text-slate-500">Total Time Consumed:</span>
                        <span className="font-bold text-slate-900 dark:text-white">
                          {formatTime(testResults.timeSpentSeconds)} {isUntimed ? '(Untimed)' : `(${Math.min(100, Math.round((testResults.timeSpentSeconds / initialSeconds) * 100))}% of limit)`}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 flex items-center justify-between">
                        <span className="text-slate-500">Speed Rating:</span>
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          {isUntimed 
                            ? 'Self-Paced Practice' 
                            : testResults.timeSpentSeconds < initialSeconds * 0.7 
                            ? '⚡ Fast & Decisive' 
                            : '🎯 Optimal CBT Pacing'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Question-by-Question Pacing Table */}
                <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      Detailed Question Pacing & Time Allocation Breakdown
                    </h3>
                    <span className="text-xs text-slate-500">Benchmark: 1-3 mins per question</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold">
                          <th className="py-2.5 px-3">Q#</th>
                          <th className="py-2.5 px-3">Subject / Topic</th>
                          <th className="py-2.5 px-3">Type</th>
                          <th className="py-2.5 px-3">Result</th>
                          <th className="py-2.5 px-3">Time Spent</th>
                          <th className="py-2.5 px-3">Pacing Evaluation</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                        {testResults.questionPacingList.map((item) => (
                          <tr key={item.questionId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                            <td className="py-2 px-3 font-bold text-slate-900 dark:text-white">Q{item.index}</td>
                            <td className="py-2 px-3 text-slate-700 dark:text-slate-300 line-clamp-1">{item.subject}</td>
                            <td className="py-2 px-3"><Badge variant="outline" size="sm">{item.type}</Badge></td>
                            <td className="py-2 px-3">
                              {item.isCorrect ? (
                                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">✓ Correct</span>
                              ) : item.isAnswered ? (
                                <span className="text-rose-600 dark:text-rose-400 font-semibold">✗ Incorrect</span>
                              ) : (
                                <span className="text-slate-400">Unattempted</span>
                              )}
                            </td>
                            <td className="py-2 px-3 font-mono font-bold text-slate-800 dark:text-slate-200">
                              {Math.floor(item.timeSpent / 60)}m {item.timeSpent % 60}s
                            </td>
                            <td className="py-2 px-3">
                              {item.timeSpent === 0 ? (
                                <span className="text-slate-400">—</span>
                              ) : item.paceStatus === 'fast' ? (
                                <span className="text-emerald-600 dark:text-emerald-400 font-medium">⚡ Fast (&lt; 1m)</span>
                              ) : item.paceStatus === 'slow' ? (
                                <span className="text-amber-600 dark:text-amber-400 font-medium">⚠️ Extended (&gt; 4m)</span>
                              ) : (
                                <span className="text-indigo-600 dark:text-indigo-400 font-medium">🎯 Ideal Pace (1-4m)</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* 3. STEP-BY-STEP SOLUTIONS TAB */}
            {analysisActiveTab === 'solutions' && (
              <div className="space-y-6">
                
                {/* Filter Toolbar */}
                <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <button
                      id="btn-filter-sol-all"
                      onClick={() => setSolutionFilter('all')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                        solutionFilter === 'all' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      All ({questions.length})
                    </button>
                    <button
                      id="btn-filter-sol-correct"
                      onClick={() => setSolutionFilter('correct')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                        solutionFilter === 'correct' ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      Correct ({testResults.correctAnswers})
                    </button>
                    <button
                      id="btn-filter-sol-incorrect"
                      onClick={() => setSolutionFilter('incorrect')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                        solutionFilter === 'incorrect' ? 'bg-rose-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      Incorrect ({testResults.incorrectAnswers})
                    </button>
                    <button
                      id="btn-filter-sol-unattempted"
                      onClick={() => setSolutionFilter('unattempted')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                        solutionFilter === 'unattempted' ? 'bg-slate-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      Unattempted ({testResults.unattempted})
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      id="btn-pdf-sol-tab-download"
                      variant="outline"
                      size="sm"
                      onClick={() => downloadSolutionsPdf(test, questions, testResults, userName)}
                      icon={<Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />}
                    >
                      Export Solutions PDF
                    </Button>
                    <Button
                      id="btn-pdf-sol-tab-paper"
                      variant="ghost"
                      size="sm"
                      onClick={() => downloadQuestionPaperPdf(test, questions, userName)}
                      icon={<FileDown className="w-3.5 h-3.5 text-slate-500" />}
                    >
                      Blank Paper (PDF)
                    </Button>
                  </div>
                </div>

                {/* Questions Solution List */}
                <div className="space-y-6">
                  {filteredQuestionsForSolution.map((q) => {
                    const res = testResults.responses[q.id];
                    const qRealIdx = questions.findIndex(orig => orig.id === q.id) + 1;
                    const qTime = res?.timeSpentSeconds || 0;

                    return (
                      <div 
                        key={q.id} 
                        className={`p-5 rounded-2xl border transition-all ${
                          res?.isCorrect
                            ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/20 dark:bg-emerald-950/10'
                            : res?.isAnswered
                            ? 'border-rose-200 dark:border-rose-900/60 bg-rose-50/20 dark:bg-rose-950/10'
                            : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20'
                        }`}
                      >
                        {/* Question Header */}
                        <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-200/80 dark:border-slate-800/80 flex-wrap">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-bold text-slate-900 dark:text-white">Question {qRealIdx}</span>
                            <Badge variant="outline" size="sm">{q.type || 'MCQ'}</Badge>
                            {q.pyqYear && <Badge variant="info" size="sm">{q.pyqYear}</Badge>}
                            <span className="text-xs text-slate-500 font-medium">{q.subject || q.courseTitle}</span>
                            <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                              ⏱️ {Math.floor(qTime / 60)}m {qTime % 60}s
                            </span>
                          </div>
                          <div>
                            {res?.isCorrect ? (
                              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                                <CheckCircle2 className="w-4 h-4" /> Correct (+{res.marksAwarded}M)
                              </span>
                            ) : res?.isAnswered ? (
                              <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400">
                                <XCircle className="w-4 h-4" /> Incorrect ({res.marksAwarded}M)
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-500">
                                <AlertCircle className="w-4 h-4" /> Unattempted (0M)
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Question Body with LaTeX */}
                        <div className="mt-4 text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                          <RichMathText text={q.questionText} />
                        </div>

                        {/* Code snippet if present */}
                        {q.codeSnippet && (
                          <div className="mt-3 p-3 rounded-xl bg-slate-900 text-slate-100 font-mono text-xs overflow-x-auto border border-slate-800">
                            <pre>{q.codeSnippet}</pre>
                          </div>
                        )}

                        {/* Options Display for MCQ/MSQ */}
                        {q.options && q.options.length > 0 && (
                          <div className="mt-4 space-y-2">
                            {q.options.map((opt, oIdx) => {
                              const isUserPick = q.type === 'MSQ'
                                ? (res?.selectedOptionIndices || []).includes(oIdx)
                                : res?.selectedOptionIndex === oIdx;

                              const isCorrectOpt = q.type === 'MSQ'
                                ? (q.correctOptionIndices || []).includes(oIdx)
                                : q.correctOptionIndex === oIdx;

                              return (
                                <div
                                  key={oIdx}
                                  className={`p-3 rounded-xl border text-xs flex items-center justify-between ${
                                    isCorrectOpt
                                      ? 'bg-emerald-100/70 dark:bg-emerald-950/60 border-emerald-500 text-emerald-950 dark:text-emerald-200 font-semibold'
                                      : isUserPick && !isCorrectOpt
                                      ? 'bg-rose-100/70 dark:bg-rose-950/60 border-rose-500 text-rose-950 dark:text-rose-200 line-through'
                                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                                  }`}
                                >
                                  <div className="flex items-center gap-2">
                                    <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border border-current shrink-0">
                                      {String.fromCharCode(65 + oIdx)}
                                    </span>
                                    <div>
                                      <RichMathText text={opt} />
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-2 text-[11px] font-bold shrink-0">
                                    {isCorrectOpt && <span className="text-emerald-700 dark:text-emerald-300">✓ Official Key</span>}
                                    {isUserPick && !isCorrectOpt && <span className="text-rose-700 dark:text-rose-300">Your Response</span>}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* NAT Answer Display */}
                        {q.type === 'NAT' && (
                          <div className="mt-3 p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs flex items-center gap-6">
                            <div>
                              <span className="text-slate-500">Your Input: </span>
                              <span className="font-bold text-slate-900 dark:text-white font-mono">
                                {res?.numericAnswer ? res.numericAnswer : 'None'}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-500">Correct Answer: </span>
                              <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono">
                                {q.correctNumericAnswer} {q.toleranceRange ? `[${q.toleranceRange[0]} to ${q.toleranceRange[1]}]` : q.numericTolerance ? `(± ${q.numericTolerance})` : ''}
                              </span>
                            </div>
                          </div>
                        )}

                        {/* Step-by-step Solution */}
                        <div className="mt-4 p-4 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 text-xs text-indigo-950 dark:text-indigo-200">
                          <div className="font-bold uppercase tracking-wider text-[11px] text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5 mb-2">
                            <Sparkles className="w-3.5 h-3.5" />
                            Official Step-by-Step Derivation & KaTeX Proof
                          </div>
                          <div className="leading-relaxed">
                            <RichMathText text={q.explanation} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Active Live CBT Exam Interface
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/95 flex flex-col text-slate-900 dark:text-white font-sans select-none">
      
      {/* Virtual Scientific Calculator Modal Overlay */}
      <ScientificCalculator
        isOpen={showCalculator}
        onClose={() => setShowCalculator(false)}
      />

      {/* Top Exam Header */}
      <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-3 sm:px-6 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">
            CBT
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-white line-clamp-1">
                {test.title}
              </span>
              <Badge variant={test.level === 'Foundation' ? 'info' : test.level === 'Diploma' ? 'warning' : 'danger'} size="sm">
                {test.level || 'Foundation'} Level
              </Badge>
              {test.termYear && (
                <Badge variant="outline" size="sm" className="hidden sm:inline-flex">
                  {test.termYear}
                </Badge>
              )}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <span>Candidate: {userName}</span>
              <span>•</span>
              <span>Total Marks: {test.totalMarks}</span>
              <span>•</span>
              <span>Duration: {isUntimed ? 'Untimed' : `${durationMins} Mins`}</span>
            </div>
          </div>
        </div>

        {/* Action Tools & Live Timer */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          
          {/* Sound Alert Toggle */}
          <button
            id="btn-toggle-sound-alerts"
            onClick={() => setSoundEnabled(prev => !prev)}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center transition-all border ${
              soundEnabled
                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400'
                : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400 hover:text-slate-600'
            }`}
            title={soundEnabled ? 'Chime Alerts Enabled (15m & 5m warnings)' : 'Chime Alerts Muted'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Pause / Resume Controller (Exclusive to Practice Mode) */}
          {isPracticeMode ? (
            <button
              id="btn-toggle-exam-pause"
              onClick={() => setIsPaused(prev => !prev)}
              className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                isPaused
                  ? 'bg-amber-500 text-white border-amber-600 shadow-md animate-pulse'
                  : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
              title={isPaused ? 'Resume Practice Test' : 'Pause Practice Test (Practice Mode Only)'}
            >
              {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{isPaused ? 'Resume' : 'Pause'}</span>
            </button>
          ) : (
            <div 
              className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-[11px] font-medium text-slate-500"
              title="Strict IIT Madras CBT examination rules strictly prohibit pausing during active mock tests."
            >
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Strict CBT</span>
            </div>
          )}

          {/* Practice Mode Toggle */}
          <button
            id="btn-toggle-practice-mode"
            onClick={() => {
              setIsPracticeMode(prev => {
                if (prev && isPaused) setIsPaused(false);
                return !prev;
              });
            }}
            className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
              isPracticeMode
                ? 'bg-amber-100 dark:bg-amber-950/60 border-amber-400 text-amber-900 dark:text-amber-200'
                : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Toggle Practice Mode with hints, derivations, and pause features"
          >
            <Lightbulb className={`w-3.5 h-3.5 ${isPracticeMode ? 'text-amber-600 dark:text-amber-400 fill-amber-500' : ''}`} />
            <span className="hidden sm:inline">Practice:</span>
            <span>{isPracticeMode ? 'ON' : 'OFF'}</span>
          </button>

          {/* Scientific Virtual Calculator Button */}
          <Button
            id="btn-cbt-open-calc"
            variant="outline"
            size="sm"
            onClick={() => setShowCalculator(prev => !prev)}
            icon={<Calculator className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
            className="hidden sm:inline-flex"
          >
            Calculator
          </Button>

          {/* Paper PDF Export */}
          <Button
            id="btn-cbt-download-paper-live"
            variant="ghost"
            size="sm"
            onClick={() => downloadQuestionPaperPdf(test, questions, userName)}
            icon={<FileDown className="w-3.5 h-3.5" />}
            className="hidden md:inline-flex"
          >
            Paper (PDF)
          </Button>

          {/* Live Dynamic IIT Madras Countdown Timer */}
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-mono font-bold text-xs sm:text-sm border transition-all ${
            isUntimed 
              ? 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'
              : timeLeft <= 300 
              ? 'bg-rose-50 dark:bg-rose-950/80 border-rose-500 dark:border-rose-600 text-rose-600 dark:text-rose-300 animate-pulse ring-2 ring-rose-500/20'
              : timeLeft <= 900
              ? 'bg-amber-50 dark:bg-amber-950/70 border-amber-400 dark:border-amber-600 text-amber-800 dark:text-amber-300 animate-pulse'
              : 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300'
          }`}>
            <Clock className={`w-4 h-4 shrink-0 ${
              isUntimed ? 'text-slate-500' : timeLeft <= 300 ? 'text-rose-600' : timeLeft <= 900 ? 'text-amber-600' : 'text-emerald-600'
            }`} />
            <span className="tabular-nums">
              {isUntimed ? formatTime(elapsedSeconds) : formatTime(timeLeft)}
            </span>
          </div>

          {/* Submit Button */}
          <Button
            id="btn-submit-cbt-exam"
            variant="danger"
            size="sm"
            onClick={() => setShowSubmitConfirm(true)}
            icon={<Send className="w-3.5 h-3.5" />}
          >
            Submit Test
          </Button>
        </div>
      </header>

      {/* Persistent Critical Timing Alert Banners */}
      {!isUntimed && !isSubmitted && timeLeft <= 300 && (
        <div className="bg-rose-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-between shadow-inner animate-pulse">
          <div className="flex items-center gap-2 mx-auto">
            <AlertTriangle className="w-4 h-4 animate-bounce shrink-0" />
            <span>🚨 CRITICAL WARNING: Under 5 Minutes Remaining ({formatTime(timeLeft)})! The CBT exam will automatically freeze and submit when time expires (00:00:00).</span>
          </div>
        </div>
      )}

      {!isUntimed && !isSubmitted && timeLeft > 300 && timeLeft <= 900 && (
        <div className="bg-amber-500 text-slate-950 px-4 py-1.5 text-xs font-bold flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2 mx-auto">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>⚠️ 15-Minute Warning: Time is running low. Please verify all marked questions and finalize your submissions.</span>
          </div>
        </div>
      )}

      {/* Auto-Submit Modal Overlay */}
      {isAutoSubmitting && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 max-w-md w-full shadow-2xl text-center space-y-4 animate-scaleUp">
            <div className="w-16 h-16 rounded-3xl bg-rose-100 dark:bg-rose-950 text-rose-600 mx-auto flex items-center justify-center animate-bounce shadow-lg">
              <Hourglass className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                Exam Time Expired (00:00:00)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                In strict accordance with official IIT Madras CBT examination rules, your test has automatically concluded. All responses are now being evaluated...
              </p>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-indigo-600 h-full w-full animate-pulse" />
            </div>
          </div>
        </div>
      )}

      {/* Section Navigation Strip */}
      {availableSections.length > 1 && (
        <div className="bg-slate-100 dark:bg-slate-950/90 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-2 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px] shrink-0">
            Sections:
          </span>
          <button
            onClick={() => setSelectedSectionFilter('All')}
            className={`px-3 py-1 rounded-lg font-semibold transition-colors shrink-0 ${
              selectedSectionFilter === 'All'
                ? 'bg-indigo-600 text-white'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            All Sections ({questions.length})
          </button>
          {availableSections.map(sec => {
            const count = questions.filter(q => (q.subject || q.courseTitle) === sec).length;
            return (
              <button
                key={sec}
                onClick={() => {
                  setSelectedSectionFilter(sec);
                  const firstIdx = questions.findIndex(q => (q.subject || q.courseTitle) === sec);
                  if (firstIdx >= 0) setCurrentIdx(firstIdx);
                }}
                className={`px-3 py-1 rounded-lg font-semibold transition-colors shrink-0 ${
                  selectedSectionFilter === sec
                    ? 'bg-indigo-600 text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {sec} ({count})
              </button>
            );
          })}
        </div>
      )}

      {/* Main CBT Workspace (Two Columns) */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden bg-slate-100 dark:bg-slate-950">
        
        {/* Left Column: Question Area */}
        <main className="flex-1 flex flex-col bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 overflow-hidden">
          
          {/* Question Meta Bar */}
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/40">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">
                Question {currentIdx + 1} of {questions.length}
              </span>
              <span className="text-slate-300 dark:text-slate-700">|</span>
              <Badge variant="outline" size="sm">
                {currentQuestion?.type || 'MCQ'}
              </Badge>
              {currentQuestion?.pyqYear && (
                <Badge variant="info" size="sm">
                  {currentQuestion.pyqYear}
                </Badge>
              )}
              <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                {currentQuestion?.subject || currentQuestion?.courseTitle}
              </span>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Practice Mode Hint Button */}
              {isPracticeMode && currentQuestion?.hints && currentQuestion.hints.length > 0 && (
                <button
                  id="btn-cbt-toggle-hint"
                  onClick={() => setShowHint(prev => !prev)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  {showHint ? 'Hide Hint' : 'Show Hint'}
                </button>
              )}

              {/* Practice Mode Solution Reveal */}
              {isPracticeMode && (
                <button
                  id="btn-cbt-toggle-solution"
                  onClick={() => setShowPracticeSolution(prev => !prev)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  {showPracticeSolution ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  {showPracticeSolution ? 'Hide Solution' : 'Check Solution'}
                </button>
              )}

              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Marks: <span className="text-emerald-600 dark:text-emerald-400 font-bold">+{currentQuestion?.marks || 2}</span>
                {currentQuestion?.negativeMarks ? (
                  <span className="text-rose-600 dark:text-rose-400 ml-1">(-{currentQuestion.negativeMarks})</span>
                ) : (
                  <span className="text-slate-400 ml-1">(No Neg.)</span>
                )}
              </div>
            </div>
          </div>

          {/* Question Content Area */}
          <div className="flex-1 p-5 sm:p-8 overflow-y-auto space-y-6 relative">
            {isPaused && (
              <div className="absolute inset-0 z-30 bg-slate-900/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
                <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-500 flex items-center justify-center mb-4 border border-amber-500/30">
                  <Pause className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Practice Exam Paused</h3>
                <p className="text-sm text-slate-300 max-w-md mb-6 leading-relaxed">
                  The timer and per-question pacing tracker have been temporarily frozen. Take your time to review concepts and resume whenever you're ready.
                </p>
                <Button
                  id="btn-resume-from-pause-screen"
                  variant="primary"
                  size="lg"
                  onClick={() => setIsPaused(false)}
                  icon={<Play className="w-4 h-4 fill-current" />}
                >
                  Resume Exam
                </Button>
              </div>
            )}

            {currentQuestion ? (
              <>
                {/* Practice Mode Hint Box */}
                {isPracticeMode && showHint && currentQuestion.hints && (
                  <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-950 dark:text-amber-200 space-y-1.5 animate-fadeIn">
                    <div className="font-bold flex items-center gap-1.5 text-amber-700 dark:text-amber-400 uppercase tracking-wider text-[11px]">
                      <Lightbulb className="w-4 h-4" /> Exam Strategy & Hint
                    </div>
                    {currentQuestion.hints.map((h, hIdx) => (
                      <div key={hIdx} className="leading-relaxed">
                        • <RichMathText text={h} />
                      </div>
                    ))}
                    {currentQuestion.formulaRef && (
                      <div className="pt-2 border-t border-amber-200/60 dark:border-amber-800/60 font-mono text-[11px]">
                        Formula Ref: <InlineMath math={currentQuestion.formulaRef} />
                      </div>
                    )}
                  </div>
                )}

                {/* Question Text with KaTeX Rendering */}
                <div className="text-base sm:text-lg font-medium text-slate-900 dark:text-white leading-relaxed">
                  <RichMathText text={currentQuestion.questionText} />
                </div>

                {/* Code Snippet Box for Pseudocode / Source Traces */}
                {currentQuestion.codeSnippet && (
                  <div className="p-4 rounded-xl bg-slate-900 text-slate-100 font-mono text-xs sm:text-sm overflow-x-auto border border-slate-800 shadow-inner">
                    <div className="text-[10px] text-slate-400 uppercase tracking-widest pb-1 border-b border-slate-800 mb-2 font-semibold">
                      Source / Pseudocode Execution Trace
                    </div>
                    <pre className="leading-relaxed">{currentQuestion.codeSnippet}</pre>
                  </div>
                )}

                {/* OPPE Interactive Coding Runner for OPPE_CODE */}
                {currentQuestion.type === 'OPPE_CODE' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                        <FileCode className="w-4 h-4" />
                        OPPE Python Code Implementation
                      </span>
                      <Button
                        id="btn-run-oppe-code"
                        variant="outline"
                        size="sm"
                        onClick={() => handleRunTestCases(currentQuestion)}
                        icon={<Play className="w-3.5 h-3.5 text-emerald-600" />}
                      >
                        {testCaseRunState[currentQuestion.id]?.isRunning ? 'Running Test Cases...' : 'Run Test Cases'}
                      </Button>
                    </div>

                    <div className="rounded-xl overflow-hidden border border-slate-700 bg-slate-950 font-mono">
                      <textarea
                        id="oppe-code-editor"
                        rows={10}
                        value={codeAnswers[currentQuestion.id] || currentQuestion.starterCode || ''}
                        onChange={(e) => handleCodeInput(e.target.value)}
                        className="w-full p-4 bg-slate-950 text-emerald-400 font-mono text-xs sm:text-sm focus:outline-none resize-y leading-relaxed"
                        placeholder="# Write your Python solution here..."
                      />
                    </div>

                    {/* Test Cases Run Result Panel */}
                    {testCaseRunState[currentQuestion.id]?.results && (
                      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 space-y-3">
                        <div className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center justify-between">
                          <span>OPPE Test Case Validation</span>
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                            {testCaseRunState[currentQuestion.id].results.filter(r => r.passed).length} / {testCaseRunState[currentQuestion.id].results.length} Passed
                          </span>
                        </div>
                        <div className="space-y-2">
                          {testCaseRunState[currentQuestion.id].results.map((tc, idx) => (
                            <div key={tc.id} className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs flex items-center justify-between">
                              <div>
                                <div className="font-semibold text-slate-800 dark:text-slate-200">Test Case {idx + 1}</div>
                                <div className="text-slate-500 font-mono text-[11px] mt-0.5">Input: {tc.input}</div>
                                <div className="text-slate-500 font-mono text-[11px]">Expected: {tc.expected}</div>
                              </div>
                              <div>
                                {tc.passed ? (
                                  <Badge variant="success" size="sm">✓ Passed</Badge>
                                ) : (
                                  <Badge variant="danger" size="sm">✗ Failed</Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Options / Input Field based on type */}
                <div className="pt-2">
                  {currentQuestion.type === 'MSQ' ? (
                    // Multiple Select (MSQ)
                    <div className="space-y-3">
                      <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                        <CheckSquare className="w-4 h-4" />
                        Multiple Choice Question (Select one or more correct options)
                      </div>
                      {currentQuestion.options?.map((opt, optIdx) => {
                        const isChecked = (responses[currentQuestion.id]?.selectedOptionIndices || []).includes(optIdx);
                        return (
                          <button
                            key={optIdx}
                            id={`opt-msq-${optIdx}`}
                            onClick={() => handleToggleMSQ(optIdx)}
                            className={`w-full p-4 rounded-xl text-left border transition-all flex items-start gap-3 ${
                              isChecked
                                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-950 dark:text-indigo-200 font-semibold shadow-sm'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                            }`}
                          >
                            <div className="mt-0.5">
                              {isChecked ? (
                                <CheckSquare className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                              ) : (
                                <Square className="w-4 h-4 text-slate-400" />
                              )}
                            </div>
                            <div className="flex-1 text-sm">
                              <span className="font-bold mr-2">{String.fromCharCode(65 + optIdx)}.</span>
                              <RichMathText text={opt} />
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  ) : currentQuestion.type === 'NAT' ? (
                    // Numerical Answer Type (NAT)
                    <div className="space-y-4 max-w-md">
                      <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Hash className="w-4 h-4" />
                        Numerical Answer Type (Enter precise decimal or integer value)
                      </div>
                      <div className="relative">
                        <input
                          id="input-nat-answer"
                          type="number"
                          step="any"
                          placeholder="Enter your numerical answer here..."
                          value={responses[currentQuestion.id]?.numericAnswer || ''}
                          onChange={(e) => handleNumericInput(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono text-base focus:ring-2 focus:ring-indigo-500 outline-none"
                        />
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        * Virtual Keypad & decimal answers accepted (e.g. 2, 0.727, 1216).
                      </p>
                    </div>
                  ) : currentQuestion.type !== 'OPPE_CODE' ? (
                    // Standard Single Choice MCQ or CODE_OUTPUT
                    <div className="space-y-3">
                      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Choose the single correct option:
                      </div>
                      {currentQuestion.options?.map((opt, optIdx) => {
                        const isSelected = responses[currentQuestion.id]?.selectedOptionIndex === optIdx;
                        return (
                          <button
                            key={optIdx}
                            id={`opt-mcq-${optIdx}`}
                            onClick={() => handleSelectMCQ(optIdx)}
                            className={`w-full p-4 rounded-xl text-left border transition-all flex items-start gap-3 ${
                              isSelected
                                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-950 dark:text-indigo-200 font-semibold shadow-sm'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                            }`}
                          >
                            <div className={`w-5 h-5 rounded-full mt-0.5 flex items-center justify-center text-xs font-bold border shrink-0 ${
                              isSelected
                                ? 'border-indigo-600 bg-indigo-600 text-white'
                                : 'border-slate-300 dark:border-slate-700 text-slate-500'
                            }`}>
                              {String.fromCharCode(65 + optIdx)}
                            </div>
                            <div className="flex-1 text-sm">
                              <RichMathText text={opt} />
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  ) : null}
                </div>

                {/* Practice Mode Solution Reveal Box */}
                {isPracticeMode && showPracticeSolution && (
                  <div className="mt-6 p-4 rounded-xl bg-indigo-50/80 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800/80 text-xs text-indigo-950 dark:text-indigo-200 space-y-2 animate-fadeIn">
                    <div className="font-bold uppercase tracking-wider text-[11px] text-indigo-700 dark:text-indigo-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      Immediate Solution & Derivation (Practice Mode)
                    </div>
                    <div className="leading-relaxed">
                      <RichMathText text={currentQuestion.explanation} />
                    </div>
                  </div>
                )}
              </>
            ) : null}
          </div>

          {/* Bottom Action Controls */}
          <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Button
                id="btn-mark-review-next"
                variant="outline"
                size="sm"
                onClick={handleMarkAndNext}
                icon={<Bookmark className="w-3.5 h-3.5 text-purple-600" />}
              >
                {responses[currentQuestion?.id || '']?.isMarkedForReview ? 'Unmark & Next' : 'Mark for Review & Next'}
              </Button>
              <Button
                id="btn-clear-response"
                variant="ghost"
                size="sm"
                onClick={handleClearResponse}
                icon={<RotateCcw className="w-3.5 h-3.5" />}
              >
                Clear Response
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <Button
                id="btn-prev-question"
                variant="outline"
                size="sm"
                disabled={currentIdx === 0}
                onClick={() => setCurrentIdx(prev => Math.max(0, prev - 1))}
                icon={<ChevronLeft className="w-4 h-4" />}
              >
                Previous
              </Button>
              <Button
                id="btn-save-next-question"
                variant="primary"
                size="sm"
                onClick={handleSaveAndNext}
                icon={<ChevronRight className="w-4 h-4" />}
              >
                {currentIdx === questions.length - 1 ? 'Save & Review' : 'Save & Next'}
              </Button>
            </div>
          </div>
        </main>

        {/* Right Column: Question Palette & Overview */}
        <aside className="w-full lg:w-80 bg-slate-50 dark:bg-slate-950 p-4 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 flex flex-col gap-4 overflow-y-auto">
          
          {/* Quick Calculator Trigger (Mobile & Desktop) */}
          <div className="block sm:hidden">
            <Button
              id="btn-cbt-open-calc-aside"
              variant="outline"
              size="sm"
              className="w-full justify-center"
              onClick={() => setShowCalculator(true)}
              icon={<Calculator className="w-4 h-4 text-indigo-600" />}
            >
              Open Virtual Calculator
            </Button>
          </div>

          {/* Palette Legend */}
          <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Question Palette Status
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-emerald-500 font-bold text-white flex items-center justify-center text-[8px]">A</span>
                <span className="text-slate-600 dark:text-slate-400">Answered ({paletteStats.answered})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-rose-500 font-bold text-white flex items-center justify-center text-[8px]">NA</span>
                <span className="text-slate-600 dark:text-slate-400">Not Answered ({paletteStats.notAnswered})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-purple-600 font-bold text-white flex items-center justify-center text-[8px]">MR</span>
                <span className="text-slate-600 dark:text-slate-400">Marked ({paletteStats.markedForReview})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-purple-700 ring-2 ring-emerald-400 font-bold text-white flex items-center justify-center text-[8px]">AM</span>
                <span className="text-slate-600 dark:text-slate-400">Ans & Marked ({paletteStats.answeredAndMarked})</span>
              </div>
              <div className="flex items-center gap-1.5 col-span-2">
                <span className="w-3.5 h-3.5 rounded bg-slate-300 dark:bg-slate-700 font-bold text-slate-800 dark:text-slate-200 flex items-center justify-center text-[8px]">NV</span>
                <span className="text-slate-600 dark:text-slate-400">Not Visited ({paletteStats.notVisited})</span>
              </div>
            </div>
          </div>

          {/* Interactive Question Grid */}
          <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex-1 flex flex-col">
            <div className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              Questions (Jump to any)
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 overflow-y-auto max-h-60 lg:max-h-none">
              {questions.map((q, idx) => {
                const status = getQuestionStatus(q.id);
                const isCurrent = currentIdx === idx;

                let colorClasses = 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300';
                if (status === 'answered') {
                  colorClasses = 'bg-emerald-500 text-white font-bold';
                } else if (status === 'not-answered') {
                  colorClasses = 'bg-rose-500 text-white font-bold';
                } else if (status === 'marked') {
                  colorClasses = 'bg-purple-600 text-white font-bold';
                } else if (status === 'answered-marked') {
                  colorClasses = 'bg-purple-700 text-white font-bold ring-2 ring-emerald-400';
                }

                return (
                  <button
                    key={q.id}
                    id={`palette-btn-q-${idx + 1}`}
                    onClick={() => setCurrentIdx(idx)}
                    className={`h-9 rounded-lg text-xs flex items-center justify-center transition-all ${colorClasses} ${
                      isCurrent ? 'ring-2 ring-indigo-500 scale-105 shadow-md' : ''
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-2">
            <Button
              id="btn-submit-cbt-aside"
              variant="primary"
              size="md"
              className="w-full justify-center"
              onClick={() => setShowSubmitConfirm(true)}
              icon={<Send className="w-4 h-4" />}
            >
              Submit Final Assessment
            </Button>
          </div>
        </aside>
      </div>

      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950 text-indigo-600 flex items-center justify-center">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Confirm CBT Submission
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Are you sure you want to end your test attempt? You will immediately receive your score, accuracy analysis, and step-by-step solutions.
              </p>
            </div>

            {/* Quick Palette Status Snapshot */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 text-center text-xs">
              <div>
                <div className="font-bold text-emerald-600">{paletteStats.answered + paletteStats.answeredAndMarked}</div>
                <div className="text-[10px] text-slate-500">Answered</div>
              </div>
              <div>
                <div className="font-bold text-purple-600">{paletteStats.markedForReview}</div>
                <div className="text-[10px] text-slate-500">Marked</div>
              </div>
              <div>
                <div className="font-bold text-rose-600">{paletteStats.notAnswered + paletteStats.notVisited}</div>
                <div className="text-[10px] text-slate-500">Unanswered</div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <Button
                id="btn-cancel-submit"
                variant="outline"
                size="sm"
                onClick={() => setShowSubmitConfirm(false)}
              >
                Resume Test
              </Button>
              <Button
                id="btn-confirm-final-submit"
                variant="danger"
                size="sm"
                onClick={handleFinalSubmit}
                icon={<CheckCircle2 className="w-4 h-4" />}
              >
                Confirm & Submit
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { Calculator, X, RotateCcw, Delete, Equal } from 'lucide-react';

interface ScientificCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScientificCalculator: React.FC<ScientificCalculatorProps> = ({
  isOpen,
  onClose
}) => {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [memory, setMemory] = useState<number>(0);
  const [isRad, setIsRad] = useState(true);
  const [hasCalculated, setHasCalculated] = useState(false);

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (hasCalculated) {
      setDisplay(digit);
      setExpression(digit);
      setHasCalculated(false);
      return;
    }
    if (display === '0' && digit !== '.') {
      setDisplay(digit);
      setExpression(expression + digit);
    } else {
      if (digit === '.' && display.includes('.')) return;
      setDisplay(prev => prev + digit);
      setExpression(prev => prev + digit);
    }
  };

  const handleOperator = (op: string) => {
    setHasCalculated(false);
    setExpression(prev => prev + ' ' + op + ' ');
    setDisplay('0');
  };

  const handleClear = () => {
    setDisplay('0');
    setExpression('');
    setHasCalculated(false);
  };

  const handleDelete = () => {
    if (hasCalculated) {
      handleClear();
      return;
    }
    if (display.length > 1) {
      setDisplay(prev => prev.slice(0, -1));
      setExpression(prev => prev.slice(0, -1));
    } else {
      setDisplay('0');
      setExpression(prev => (prev.length > 0 ? prev.slice(0, -1) : ''));
    }
  };

  const handleSciFunction = (fn: string) => {
    const val = parseFloat(display);
    if (isNaN(val)) return;

    let res = 0;
    const factor = isRad ? 1 : Math.PI / 180;
    const invFactor = isRad ? 1 : 180 / Math.PI;

    switch (fn) {
      case 'sin':
        res = Math.sin(val * factor);
        break;
      case 'cos':
        res = Math.cos(val * factor);
        break;
      case 'tan':
        res = Math.tan(val * factor);
        break;
      case 'asin':
        res = Math.asin(val) * invFactor;
        break;
      case 'acos':
        res = Math.acos(val) * invFactor;
        break;
      case 'atan':
        res = Math.atan(val) * invFactor;
        break;
      case 'ln':
        res = val > 0 ? Math.log(val) : NaN;
        break;
      case 'log10':
        res = val > 0 ? Math.log10(val) : NaN;
        break;
      case 'sqrt':
        res = val >= 0 ? Math.sqrt(val) : NaN;
        break;
      case 'cbrt':
        res = Math.cbrt(val);
        break;
      case 'sqr':
        res = Math.pow(val, 2);
        break;
      case 'cube':
        res = Math.pow(val, 3);
        break;
      case 'inv':
        res = val !== 0 ? 1 / val : NaN;
        break;
      case 'exp':
        res = Math.exp(val);
        break;
      case 'pow10':
        res = Math.pow(10, val);
        break;
      case 'fact': {
        const n = Math.floor(val);
        if (n < 0 || n > 170) {
          res = NaN;
        } else {
          let f = 1;
          for (let i = 2; i <= n; i++) f *= i;
          res = f;
        }
        break;
      }
      case 'abs':
        res = Math.abs(val);
        break;
      default:
        res = val;
    }

    const formatted = isNaN(res) ? 'Error' : Number(res.toFixed(8)).toString();
    setDisplay(formatted);
    setExpression(`${fn}(${val})`);
    setHasCalculated(true);
  };

  const handleConstant = (c: 'pi' | 'e') => {
    const val = c === 'pi' ? Math.PI : Math.E;
    setDisplay(val.toFixed(8));
    setExpression(prev => prev + val.toFixed(8));
    setHasCalculated(false);
  };

  const handleParenthesis = (p: '(' | ')') => {
    setExpression(prev => prev + p);
  };

  const evaluateExpression = () => {
    try {
      // Clean arithmetic expression
      let clean = expression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/\^/g, '**');

      // Safely evaluate simple math expressions
      // eslint-disable-next-line no-new-func
      const result = Function(`'use strict'; return (${clean})`)();
      const formatted = isNaN(result) || !isFinite(result) ? 'Error' : Number(Number(result).toFixed(8)).toString();
      setDisplay(formatted);
      setExpression(`${expression} = ${formatted}`);
      setHasCalculated(true);
    } catch {
      setDisplay('Error');
      setHasCalculated(true);
    }
  };

  const handleMemory = (action: 'MC' | 'MR' | 'M+' | 'M-') => {
    const val = parseFloat(display) || 0;
    switch (action) {
      case 'MC':
        setMemory(0);
        break;
      case 'MR':
        setDisplay(memory.toString());
        setExpression(prev => prev + memory.toString());
        break;
      case 'M+':
        setMemory(prev => prev + val);
        break;
      case 'M-':
        setMemory(prev => prev - val);
        break;
    }
  };

  return (
    <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center p-4 sm:p-6 bg-slate-950/40 backdrop-blur-xs">
      <div className="pointer-events-auto bg-slate-900 text-white rounded-2xl shadow-2xl border border-slate-700 w-full max-w-lg overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-4 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
              IIT Madras Virtual Scientific Calculator
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsRad(!isRad)}
              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition-colors ${
                isRad ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {isRad ? 'RAD' : 'DEG'}
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Display Screen */}
        <div className="p-4 bg-slate-950/90 text-right font-mono border-b border-slate-800">
          <div className="text-xs text-slate-400 h-5 overflow-x-auto whitespace-nowrap">
            {expression || '\u00A0'}
          </div>
          <div className="text-2xl sm:text-3xl font-bold tracking-tight text-indigo-300 truncate">
            {display}
          </div>
        </div>

        {/* Memory and Keypad Grid */}
        <div className="p-3 bg-slate-900 space-y-2 text-xs font-medium">
          
          {/* Memory Bar */}
          <div className="grid grid-cols-4 gap-1.5 pb-1 border-b border-slate-800 text-[11px]">
            <button onClick={() => handleMemory('MC')} className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold transition-colors">MC</button>
            <button onClick={() => handleMemory('MR')} className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold transition-colors">MR ({memory !== 0 ? memory : 0})</button>
            <button onClick={() => handleMemory('M+')} className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-indigo-400 font-semibold transition-colors">M+</button>
            <button onClick={() => handleMemory('M-')} className="p-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-rose-400 font-semibold transition-colors">M-</button>
          </div>

          {/* Scientific Functions */}
          <div className="grid grid-cols-6 gap-1.5 text-[11px] font-mono">
            <button onClick={() => handleSciFunction('sin')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">sin</button>
            <button onClick={() => handleSciFunction('cos')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">cos</button>
            <button onClick={() => handleSciFunction('tan')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">tan</button>
            <button onClick={() => handleSciFunction('asin')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">sin⁻¹</button>
            <button onClick={() => handleSciFunction('acos')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">cos⁻¹</button>
            <button onClick={() => handleSciFunction('atan')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">tan⁻¹</button>

            <button onClick={() => handleSciFunction('ln')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">ln</button>
            <button onClick={() => handleSciFunction('log10')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">log₁₀</button>
            <button onClick={() => handleSciFunction('sqrt')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">√x</button>
            <button onClick={() => handleSciFunction('sqr')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">x²</button>
            <button onClick={() => handleSciFunction('exp')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">eˣ</button>
            <button onClick={() => handleSciFunction('fact')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">n!</button>

            <button onClick={() => handleConstant('pi')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold">π</button>
            <button onClick={() => handleConstant('e')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold">e</button>
            <button onClick={() => handleParenthesis('(')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold">(</button>
            <button onClick={() => handleParenthesis(')')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-indigo-300 font-bold">)</button>
            <button onClick={() => handleSciFunction('inv')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">1/x</button>
            <button onClick={() => handleSciFunction('abs')} className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-200">|x|</button>
          </div>

          {/* Standard Keypad */}
          <div className="grid grid-cols-4 gap-1.5 pt-1 text-sm font-semibold">
            <button onClick={handleClear} className="p-2.5 rounded-xl bg-rose-900/40 hover:bg-rose-900/60 text-rose-300 font-bold transition-colors">AC</button>
            <button onClick={handleDelete} className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"><Delete className="w-4 h-4" /></button>
            <button onClick={() => handleOperator('%')} className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 transition-colors">%</button>
            <button onClick={() => handleOperator('/')} className="p-2.5 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 text-base font-bold transition-colors">÷</button>

            <button onClick={() => handleDigit('7')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">7</button>
            <button onClick={() => handleDigit('8')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">8</button>
            <button onClick={() => handleDigit('9')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">9</button>
            <button onClick={() => handleOperator('*')} className="p-3 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 text-base font-bold transition-colors">×</button>

            <button onClick={() => handleDigit('4')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">4</button>
            <button onClick={() => handleDigit('5')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">5</button>
            <button onClick={() => handleDigit('6')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">6</button>
            <button onClick={() => handleOperator('-')} className="p-3 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 text-base font-bold transition-colors">−</button>

            <button onClick={() => handleDigit('1')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">1</button>
            <button onClick={() => handleDigit('2')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">2</button>
            <button onClick={() => handleDigit('3')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base transition-colors">3</button>
            <button onClick={() => handleOperator('+')} className="p-3 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 text-base font-bold transition-colors">+</button>

            <button onClick={() => handleDigit('0')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base col-span-2 transition-colors">0</button>
            <button onClick={() => handleDigit('.')} className="p-3 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-white font-mono text-base font-bold transition-colors">.</button>
            <button onClick={evaluateExpression} className="p-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-base font-bold shadow-lg shadow-indigo-600/30 flex items-center justify-center transition-colors">
              <Equal className="w-5 h-5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

import React from 'react';
import { AcademicLevel } from '../../types';
import { GraduationCap, Layers, Sparkles, BrainCircuit } from 'lucide-react';

interface LevelSwitcherProps {
  selectedLevel: AcademicLevel | 'All';
  onSelectLevel: (level: AcademicLevel | 'All') => void;
  showAllOption?: boolean;
  className?: string;
}

export const LevelSwitcher: React.FC<LevelSwitcherProps> = ({
  selectedLevel,
  onSelectLevel,
  showAllOption = true,
  className = ''
}) => {
  const levels: Array<{
    id: AcademicLevel | 'All';
    label: string;
    sublabel: string;
    icon: typeof GraduationCap;
    badge: string;
    color: string;
  }> = [
    ...(showAllOption ? [{
      id: 'All' as const,
      label: 'All Curriculums',
      sublabel: 'Full BS Program',
      icon: Layers,
      badge: 'All Levels',
      color: 'slate'
    }] : []),
    {
      id: 'Foundation',
      label: 'Foundation Level',
      sublabel: 'Terms 1 & 2 • 7 Courses',
      icon: GraduationCap,
      badge: 'Term 1 & 2',
      color: 'blue'
    },
    {
      id: 'Diploma',
      label: 'Diploma Level',
      sublabel: 'Programming & Data Science',
      icon: Layers,
      badge: 'Term 3, 4, 5',
      color: 'indigo'
    },
    {
      id: 'Degree',
      label: 'BSc Degree Level',
      sublabel: '3-Year Exit Track',
      icon: Sparkles,
      badge: 'Term 6, 7, 8',
      color: 'purple'
    },
    {
      id: 'BS Degree',
      label: 'BS Degree Level',
      sublabel: '4th-Year Honors / BS Track',
      icon: BrainCircuit,
      badge: 'Term 9-12',
      color: 'rose'
    }
  ];

  return (
    <div className={`p-1.5 bg-slate-100/80 dark:bg-slate-800/80 backdrop-blur-xs rounded-2xl border border-slate-200/80 dark:border-slate-700/80 flex flex-wrap sm:flex-nowrap gap-1.5 items-center ${className}`}>
      {levels.map((lvl) => {
        const isSelected = selectedLevel === lvl.id;
        const Icon = lvl.icon;

        return (
          <button
            key={lvl.id}
            id={`level-switch-btn-${lvl.id.toLowerCase()}`}
            onClick={() => onSelectLevel(lvl.id)}
            className={`flex-1 min-w-[140px] px-3.5 py-2.5 rounded-xl text-left transition-all relative ${
              isSelected
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs border border-slate-200/70 dark:border-slate-700'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white/40 dark:hover:bg-slate-900/40'
            }`}
          >
            <div className="flex items-center justify-between gap-1 mb-0.5">
              <div className="flex items-center gap-1.5">
                <Icon className={`w-3.5 h-3.5 ${
                  isSelected ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400'
                }`} />
                <span className="text-xs font-bold truncate">{lvl.label}</span>
              </div>
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${
                isSelected 
                  ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' 
                  : 'bg-slate-200/60 dark:bg-slate-700/60 text-slate-500 dark:text-slate-400'
              }`}>
                {lvl.badge}
              </span>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate pl-5">
              {lvl.sublabel}
            </p>
          </button>
        );
      })}
    </div>
  );
};

import React, { useState } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { Clock, Bell, CheckCircle2 } from 'lucide-react';

export interface ComingSoonModalProps {
  isOpen: boolean;
  onClose: () => void;
  featureTitle: string;
  phase: string;
  description: string;
  id: string;
}

export const ComingSoonModal: React.FC<ComingSoonModalProps> = ({
  isOpen,
  onClose,
  featureTitle,
  phase,
  description,
  id,
}) => {
  const [subscribed, setSubscribed] = useState(false);
  const [email, setEmail] = useState('');

  const handleNotify = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && email.includes('@')) {
      setSubscribed(true);
      setTimeout(() => {
        setSubscribed(false);
        setEmail('');
        onClose();
      }, 2000);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`${featureTitle}`} maxWidth="md" id={id}>
      <div className="flex flex-col items-center text-center">
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4 border border-indigo-100 dark:border-indigo-900/60">
          <Clock className="w-6 h-6" />
        </div>
        <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 mb-1">
          {phase} Roadmap
        </span>
        <h4 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">Coming Soon</h4>
        <p className="text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
          {description}
        </p>

        {subscribed ? (
          <div className="flex items-center gap-2 p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-lg text-emerald-800 dark:text-emerald-300 text-sm w-full justify-center">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>You'll be notified when this feature is released!</span>
          </div>
        ) : (
          <form onSubmit={handleNotify} className="w-full space-y-3">
            <div className="text-left">
              <label htmlFor={`${id}-email`} className="text-xs font-medium text-slate-700 dark:text-slate-300 block mb-1">
                Notify me upon release
              </label>
              <div className="flex gap-2">
                <input
                  id={`${id}-email`}
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <Button id={`${id}-notify-btn`} type="submit" variant="primary" size="sm" icon={<Bell className="w-3.5 h-3.5" />}>
                  Notify Me
                </Button>
              </div>
            </div>
            <p className="text-xs text-slate-400">
              No spam. We will only ping you when {featureTitle} is live.
            </p>
          </form>
        )}
      </div>
    </Modal>
  );
};

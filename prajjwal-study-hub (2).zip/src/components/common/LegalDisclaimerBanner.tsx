import React from 'react';

interface LegalDisclaimerBannerProps {
  compact?: boolean;
}

export const LegalDisclaimerBanner: React.FC<LegalDisclaimerBannerProps> = () => {
  return null;
};


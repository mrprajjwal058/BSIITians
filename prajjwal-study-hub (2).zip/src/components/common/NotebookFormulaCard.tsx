import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  Bookmark, 
  FileDown, 
  Sparkles, 
  Pin,
  ChevronDown,
  ChevronUp,
  Tag
} from 'lucide-react';
import { Badge } from './Badge';
import { BlockMath, InlineMath, MathRenderer } from './MathRenderer';
import { RichFormulaCard } from '../../data/formulasData';

interface NotebookFormulaCardProps {
  card: RichFormulaCard;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onDownloadPdf?: () => void;
  rapidMode?: boolean;
}

export const NotebookFormulaCard: React.FC<NotebookFormulaCardProps> = ({
  card,
  isBookmarked,
  onToggleBookmark,
  onDownloadPdf,
  rapidMode = false,
}) => {
  const [copied, setCopied] = useState(false);
  const [showInsights, setShowInsights] = useState(!rapidMode);

  const handleCopyLatex = () => {
    navigator.clipboard.writeText(card.latex || card.formula);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id={`notebook-card-${card.id}`}
      className="relative rounded-2xl overflow-hidden border border-white/10 shadow-lg hover:border-indigo-500/40 transition-all duration-200 flex flex-col justify-between group
        bg-[#111318] text-slate-100"
    >
      {/* Top Accent Gradient Border */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 opacity-80" />

      {/* Header */}
      <div className="relative px-5 pt-4 pb-3 border-b border-white/10 flex items-center justify-between gap-2 bg-[#161920]/60">
        
        {/* Course Code & Category Tag */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-lg text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono">
            {card.courseCode}
          </span>
          <span className="text-[11px] font-semibold text-slate-300">
            {card.category}
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10 font-medium">
            {card.level}
          </span>
        </div>

        {/* Quick Action Tools */}
        <div className="flex items-center gap-1">
          {onDownloadPdf && (
            <button
              onClick={onDownloadPdf}
              className="p-1.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:border-indigo-500/50 transition-colors"
              title="Download Card (PDF)"
              aria-label="Download Card PDF"
            >
              <FileDown className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={handleCopyLatex}
            className="p-1.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 hover:text-white hover:border-indigo-500/50 transition-colors"
            title="Copy LaTeX formula"
            aria-label="Copy LaTeX formula"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>

          <button
            onClick={onToggleBookmark}
            className={`p-1.5 rounded-xl border transition-colors ${
              isBookmarked
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                : 'border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20'
            }`}
            title="Bookmark formula"
            aria-label="Bookmark formula"
          >
            <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="relative px-5 py-4 space-y-4 flex-1">
        
        {/* Title */}
        <h3 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
          {card.title}
        </h3>

        {/* Primary KaTeX Rendered Formula Block */}
        <div className="p-4 rounded-xl bg-[#0A0C10] border border-indigo-500/30 shadow-inner flex items-center justify-center text-indigo-200 overflow-x-auto min-h-[64px]">
          <BlockMath math={card.latex || card.formula} className="text-sm sm:text-base font-semibold" />
        </div>

        {/* Formal Explanation */}
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
          {card.explanation}
        </p>

        {/* Handwritten Student Marginal Annotation / Tip */}
        {card.handwrittenNote && (
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 relative">
            <div className="flex items-start gap-2">
              <span className="text-amber-300 font-bold text-xs font-mono uppercase tracking-wider shrink-0 mt-0.5 flex items-center gap-1">
                <Pin className="w-3 h-3 text-amber-400" />
                <span>Notes:</span>
              </span>
              <p className="text-sm font-medium text-amber-200 leading-snug">
                "{card.handwrittenNote}"
              </p>
            </div>
          </div>
        )}

        {/* Variables Breakdown */}
        {!rapidMode && card.variables && card.variables.length > 0 && (
          <div className="space-y-1.5 pt-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block font-mono">
              Variable Glossary:
            </span>
            <div className="grid grid-cols-1 gap-1.5 bg-[#161920] p-3 rounded-xl border border-white/10">
              {card.variables.map((v, idx) => (
                <div key={idx} className="text-xs flex items-baseline gap-2">
                  <span className="font-semibold text-indigo-400 shrink-0">
                    <InlineMath math={v.symbol} /> :
                  </span>
                  <span className="text-slate-300">
                    <strong className="text-white">{v.name}</strong> — {v.description}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Key Exam Insights / Bounds Accordion */}
        {card.keyInsights && card.keyInsights.length > 0 && (
          <div className="pt-1">
            <button
              onClick={() => setShowInsights(!showInsights)}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 cursor-pointer select-none"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{showInsights ? 'Hide Exam Insights' : 'Show Exam Insights & Derivations'}</span>
              {showInsights ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            {showInsights && (
              <div className="mt-2 p-3 rounded-xl bg-[#161920] border border-white/10 space-y-1.5">
                {card.keyInsights.map((insight, idx) => (
                  <div key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-amber-400 font-bold text-sm leading-none">•</span>
                    <span className="text-xs leading-relaxed text-slate-200">
                      {insight}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Footer Tags */}
      <div className="relative px-5 py-2.5 bg-[#161920]/60 border-t border-white/10 flex flex-wrap items-center gap-1.5">
        <Tag className="w-3 h-3 text-slate-400 shrink-0" />
        {card.tags.map((t, idx) => (
          <span
            key={idx}
            className="px-2 py-0.5 rounded text-[10px] bg-white/5 text-slate-300 border border-white/10"
          >
            #{t}
          </span>
        ))}
      </div>
    </div>
  );
};

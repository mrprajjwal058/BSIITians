import React from 'react';

interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
  textClassName?: string;
  subtextClassName?: string;
  isClickable?: boolean;
  onClick?: () => void;
  id?: string;
}

export const PRAJJWAL_LOGO_SVG_RAW = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
  <defs>
    <radialGradient id="bgGlow" cx="50%" cy="30%" r="75%">
      <stop offset="0%" stop-color="#3B82F6"/>
      <stop offset="45%" stop-color="#1E40AF"/>
      <stop offset="85%" stop-color="#0F172A"/>
      <stop offset="100%" stop-color="#020617"/>
    </radialGradient>
    <linearGradient id="borderGlow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#93C5FD" stop-opacity="0.9"/>
      <stop offset="50%" stop-color="#3B82F6" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#60A5FA" stop-opacity="0.8"/>
    </linearGradient>
    <linearGradient id="pGrad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="60%" stop-color="#F1F5F9"/>
      <stop offset="100%" stop-color="#BFDBFE"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE047"/>
      <stop offset="50%" stop-color="#EAB308"/>
      <stop offset="100%" stop-color="#CA8A04"/>
    </linearGradient>
    <linearGradient id="cyanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38BDF8"/>
      <stop offset="100%" stop-color="#2563EB"/>
    </linearGradient>
    <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#000000" flood-opacity="0.45"/>
    </filter>
    <filter id="goldGlow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-color="#EAB308" flood-opacity="0.5"/>
    </filter>
  </defs>
  <rect x="20" y="20" width="472" height="472" rx="115" fill="url(#bgGlow)" stroke="url(#borderGlow)" stroke-width="4"/>
  <g stroke="#3B82F6" stroke-opacity="0.12" stroke-width="1.5">
    <line x1="80" y1="20" x2="80" y2="492"/>
    <line x1="432" y1="20" x2="432" y2="492"/>
    <line x1="20" y1="256" x2="492" y2="256"/>
  </g>
  <g filter="url(#softShadow)">
    <path d="M 172 170 L 172 360 A 22 22 0 0 0 216 360 L 216 304 L 272 304 A 67 67 0 0 0 339 237 A 67 67 0 0 0 272 170 Z" fill="url(#pGrad)"/>
    <path d="M 216 214 L 268 214 A 23 23 0 0 1 291 237 A 23 23 0 0 1 268 260 L 216 260 Z" fill="#111827" fill-opacity="0.9"/>
    <path d="M 256 94 L 374 154 L 256 214 L 138 154 Z" fill="url(#cyanGrad)" stroke="#E0F2FE" stroke-width="3.5" stroke-linejoin="round"/>
    <ellipse cx="256" cy="154" rx="10" ry="6" fill="#FFFFFF"/>
    <g filter="url(#goldGlow)">
      <path d="M 256 154 Q 330 162 358 195 L 358 245" fill="none" stroke="url(#goldGrad)" stroke-width="5" stroke-linecap="round"/>
      <polygon points="353,245 363,245 365,268 351,268" fill="url(#goldGrad)"/>
      <circle cx="358" cy="245" r="4.5" fill="#FEF08A"/>
    </g>
    <circle cx="194" cy="360" r="6" fill="#38BDF8"/>
  </g>
</svg>
`;

/**
 * Data URI for Browser Favicon & Standalone Image embedding
 */
export const PRAJJWAL_LOGO_DATA_URI = `data:image/svg+xml;utf8,${encodeURIComponent(PRAJJWAL_LOGO_SVG_RAW.trim())}`;

export const LogoIcon: React.FC<{ className?: string; sizeClass?: string; id?: string }> = ({ 
  className = '', 
  sizeClass = 'w-[44px] h-[44px]',
  id = 'prajjwal-custom-logo-icon'
}) => {
  return (
    <div 
      id={id}
      className={`relative inline-flex items-center justify-center shrink-0 select-none ${sizeClass} ${className}`}
    >
      <svg 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 512 512" 
        className="w-full h-full"
      >
        <defs>
          <radialGradient id="bgGlow" cx="50%" cy="30%" r="75%">
            <stop offset="0%" stopColor="#3B82F6"/>
            <stop offset="45%" stopColor="#1E40AF"/>
            <stop offset="85%" stopColor="#0F172A"/>
            <stop offset="100%" stopColor="#020617"/>
          </radialGradient>
          <linearGradient id="borderGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#93C5FD" stopOpacity="0.9"/>
            <stop offset="50%" stopColor="#3B82F6" stopOpacity="0.3"/>
            <stop offset="100%" stopColor="#60A5FA" stopOpacity="0.8"/>
          </linearGradient>
          <linearGradient id="pGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#FFFFFF"/>
            <stop offset="60%" stopColor="#F1F5F9"/>
            <stop offset="100%" stopColor="#BFDBFE"/>
          </linearGradient>
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FDE047"/>
            <stop offset="50%" stopColor="#EAB308"/>
            <stop offset="100%" stopColor="#CA8A04"/>
          </linearGradient>
          <linearGradient id="cyanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38BDF8"/>
            <stop offset="100%" stopColor="#2563EB"/>
          </linearGradient>
          <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="12" stdDeviation="16" floodColor="#000000" floodOpacity="0.45"/>
          </filter>
          <filter id="goldGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="4" stdDeviation="8" floodColor="#EAB308" floodOpacity="0.5"/>
          </filter>
        </defs>
        <rect x="20" y="20" width="472" height="472" rx="115" fill="url(#bgGlow)" stroke="url(#borderGlow)" strokeWidth="4"/>
        <g stroke="#3B82F6" strokeOpacity="0.12" strokeWidth="1.5">
          <line x1="80" y1="20" x2="80" y2="492"/>
          <line x1="432" y1="20" x2="432" y2="492"/>
          <line x1="20" y1="256" x2="492" y2="256"/>
        </g>
        <g filter="url(#softShadow)">
          <path d="M 172 170 L 172 360 A 22 22 0 0 0 216 360 L 216 304 L 272 304 A 67 67 0 0 0 339 237 A 67 67 0 0 0 272 170 Z" fill="url(#pGrad)"/>
          <path d="M 216 214 L 268 214 A 23 23 0 0 1 291 237 A 23 23 0 0 1 268 260 L 216 260 Z" fill="#111827" fillOpacity="0.9"/>
          <path d="M 256 94 L 374 154 L 256 214 L 138 154 Z" fill="url(#cyanGrad)" stroke="#E0F2FE" strokeWidth="3.5" strokeLinejoin="round"/>
          <ellipse cx="256" cy="154" rx="10" ry="6" fill="#FFFFFF"/>
          <g filter="url(#goldGlow)">
            <path d="M 256 154 Q 330 162 358 195 L 358 245" fill="none" stroke="url(#goldGrad)" strokeWidth="5" strokeLinecap="round"/>
            <polygon points="353,245 363,245 365,268 351,268" fill="url(#goldGrad)"/>
            <circle cx="358" cy="245" r="4.5" fill="#FEF08A"/>
          </g>
          <circle cx="194" cy="360" r="6" fill="#38BDF8"/>
        </g>
      </svg>
    </div>
  );
};

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  className = '',
  showText = true,
  textClassName = '',
  subtextClassName = '',
  isClickable = true,
  onClick,
  id = 'prajjwal-brand-logo'
}) => {
  const sizeMap = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-[44px] h-[44px]',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  };

  const titleSizeMap = {
    xs: 'text-xs',
    sm: 'text-sm',
    md: 'text-base sm:text-lg',
    lg: 'text-xl',
    xl: 'text-2xl'
  };

  return (
    <div
      id={id}
      onClick={onClick}
      className={`flex items-center gap-3 select-none ${isClickable ? 'cursor-pointer group' : ''} ${className}`}
    >
      <LogoIcon 
        sizeClass={sizeMap[size]} 
        className={`${isClickable ? 'group-hover:scale-105 transition-transform duration-200' : ''}`}
      />
      {showText && (
        <div className="flex flex-col justify-center">
          <span className={`font-bold tracking-tight text-slate-900 dark:text-slate-100 leading-tight ${titleSizeMap[size]} ${textClassName}`}>
            Prajjwal Study Hub
          </span>
          <span className={`text-[10px] text-slate-500 dark:text-slate-400 font-medium tracking-wide uppercase leading-normal hidden md:block ${subtextClassName}`}>
            Independent Learning Portal
          </span>
        </div>
      )}
    </div>
  );
};

import React, { useMemo } from 'react';
import katex from 'katex';

interface MathRendererProps {
  math?: string;
  text?: string;
  block?: boolean;
  className?: string;
}

export const MathRenderer: React.FC<MathRendererProps> = ({
  math,
  text,
  block = false,
  className = '',
}) => {
  // If `text` prop is provided (e.g. mixed markdown/latex with $...$), render via RichMathText
  if (text !== undefined) {
    return <RichMathText text={text} className={className} />;
  }

  const html = useMemo(() => {
    if (!math || typeof math !== 'string') return '';
    try {
      // Clean up common issues like excessive backslashes or empty wraps
      const cleanMath = math.trim();
      return katex.renderToString(cleanMath, {
        displayMode: block,
        throwOnError: false,
        output: 'htmlAndMathml',
      });
    } catch (err) {
      console.warn('KaTeX rendering error:', err);
      return `<span class="katex-error font-mono text-xs text-rose-500">${escapeHtml(math)}</span>`;
    }
  }, [math, block]);

  if (!html) return null;

  if (block) {
    return (
      <div
        className={`katex-block-wrapper my-2 py-1 overflow-x-auto text-center ${className}`}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  return (
    <span
      className={`katex-inline-wrapper inline-block ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export const BlockMath: React.FC<{ math: string; className?: string }> = ({ math, className }) => (
  <MathRenderer math={math} block={true} className={className} />
);

export const InlineMath: React.FC<{ math: string; className?: string }> = ({ math, className }) => (
  <MathRenderer math={math} block={false} className={className} />
);

/**
 * Parses markdown-like text that contains inline ($...$) and block ($$...$$) LaTeX expressions
 * and renders them seamlessly with KaTeX and regular text.
 */
export const RichMathText: React.FC<{ text: string; className?: string }> = ({ text, className = '' }) => {
  const parts = useMemo(() => {
    if (!text) return [];

    // Split by block math $$...$$ first, then by inline math $...$
    const segments: Array<{ type: 'text' | 'inline' | 'block'; content: string }> = [];
    
    // First split by $$...$$
    const blockRegex = /\$\$([\s\S]*?)\$\$/g;
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = blockRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        // Process the text before this block for inline math
        processInline(text.substring(lastIndex, match.index), segments);
      }
      segments.push({ type: 'block', content: match[1].trim() });
      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < text.length) {
      processInline(text.substring(lastIndex), segments);
    }

    return segments;
  }, [text]);

  function processInline(subText: string, targetSegments: Array<{ type: 'text' | 'inline' | 'block'; content: string }>) {
    const inlineRegex = /\$([^\$\n]+?)\$/g;
    let lastIdx = 0;
    let inlineMatch: RegExpExecArray | null;

    while ((inlineMatch = inlineRegex.exec(subText)) !== null) {
      if (inlineMatch.index > lastIdx) {
        targetSegments.push({ type: 'text', content: subText.substring(lastIdx, inlineMatch.index) });
      }
      targetSegments.push({ type: 'inline', content: inlineMatch[1].trim() });
      lastIdx = inlineMatch.index + inlineMatch[0].length;
    }

    if (lastIdx < subText.length) {
      targetSegments.push({ type: 'text', content: subText.substring(lastIdx) });
    }
  }

  return (
    <span className={className}>
      {parts.map((p, idx) => {
        if (p.type === 'block') {
          return <BlockMath key={idx} math={p.content} />;
        }
        if (p.type === 'inline') {
          return <InlineMath key={idx} math={p.content} />;
        }
        return <span key={idx}>{p.content}</span>;
      })}
    </span>
  );
};

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

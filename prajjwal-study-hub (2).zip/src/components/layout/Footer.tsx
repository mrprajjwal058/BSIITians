import React from 'react';
import { Shield, Heart } from 'lucide-react';
import { Logo } from '../common/Logo';

interface FooterProps {
  navigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-12">
          
          {/* Col 1: Brand & Independent Identity */}
          <div className="md:col-span-2 space-y-4">
            <Logo 
              id="footer-brand-logo"
              size="md"
              textClassName="text-white"
              subtextClassName="text-slate-400"
              onClick={() => navigate('/')}
            />
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              An independent, student-created academic hub providing centralized revision notes, formula sheets, mock test frameworks, and study planning tools.
            </p>
            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60 text-[11px] text-slate-300 space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-amber-400">
                <Shield className="w-3.5 h-3.5 shrink-0" />
                <span>Disclaimer of Non-Affiliation</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                Disclaimer of Non-Affiliation: Prajjwal Study Hub is an independent student-created learning platform and is NOT affiliated with, endorsed by, sponsored by, or officially associated with IIT Madras or the official BS Degree administration.
              </p>
            </div>
          </div>

          {/* Col 2: Academic Resources */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Study Resources
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button id="footer-link-courses" onClick={() => navigate('/courses')} className="hover:text-white transition-colors">
                  All Courses
                </button>
              </li>
              <li>
                <button id="footer-link-notes" onClick={() => navigate('/notes')} className="hover:text-white transition-colors">
                  Revision Notes
                </button>
              </li>
              <li>
                <button id="footer-link-formulas" onClick={() => navigate('/formulas')} className="hover:text-white transition-colors">
                  Formula Sheets
                </button>
              </li>
              <li>
                <button id="footer-link-practice" onClick={() => navigate('/practice')} className="hover:text-white transition-colors">
                  Practice Questions
                </button>
              </li>
              <li>
                <button id="footer-link-mocktests" onClick={() => navigate('/mock-tests')} className="hover:text-white transition-colors">
                  Mock Tests
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Student Tools */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Learning Tools
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button id="footer-link-dashboard" onClick={() => navigate('/dashboard')} className="hover:text-white transition-colors">
                  Student Dashboard
                </button>
              </li>
              <li>
                <button id="footer-link-planner" onClick={() => navigate('/study-planner')} className="hover:text-white transition-colors">
                  Study Planner
                </button>
              </li>
              <li>
                <button id="footer-link-performance" onClick={() => navigate('/performance')} className="hover:text-white transition-colors">
                  Performance Tracker
                </button>
              </li>
              <li>
                <button id="footer-link-bookmarks" onClick={() => navigate('/bookmarks')} className="hover:text-white transition-colors">
                  Saved Bookmarks
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Platform & Legal */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Information & Legal
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button id="footer-link-about" onClick={() => navigate('/about')} className="hover:text-white transition-colors">
                  About Platform
                </button>
              </li>
              <li>
                <button id="footer-link-features" onClick={() => navigate('/features')} className="hover:text-white transition-colors">
                  Platform Features
                </button>
              </li>
              <li>
                <button id="footer-link-contact" onClick={() => navigate('/contact')} className="hover:text-white transition-colors">
                  Contact & Feedback
                </button>
              </li>
              <li>
                <button id="footer-link-privacy" onClick={() => navigate('/privacy')} className="hover:text-white transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button id="footer-link-terms" onClick={() => navigate('/terms')} className="hover:text-white transition-colors">
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Prajjwal Study Hub. Independent Student Platform. All rights reserved.</p>
          <div className="flex items-center gap-1">
            <span>Built with dedication for student learning</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
          </div>
        </div>
      </div>
    </footer>
  );
};

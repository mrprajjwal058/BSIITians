import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { 
  Sun, 
  Moon, 
  Menu, 
  X, 
  User, 
  LogOut, 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  BarChart2, 
  Calendar, 
  Bookmark, 
  ShieldCheck,
  ChevronDown,
  Download
} from 'lucide-react';
import { Button } from '../common/Button';
import { Logo } from '../common/Logo';

interface NavbarProps {
  currentPath: string;
  navigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, navigate }) => {
  const { user, role, isAdmin, logout, loginAsDemoStudent, loginAsDemoAdmin } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const handleNav = (path: string) => {
    navigate(path);
    setMobileMenuOpen(false);
    setProfileDropdownOpen(false);
  };

  const isCurrent = (path: string) => currentPath === path;

  return (
    <header className="sticky top-0 z-40 bg-[#0A0C10]/85 backdrop-blur-xl border-b border-white/10 transition-colors w-full">
      <div className="max-w-7xl mx-auto w-full">
        <div className="flex items-center justify-between px-4 sm:px-6 lg:px-8 py-3 h-16 w-full">
          
          {/* Brand / Logo (Left: Logo icon + Prajjwal Study Hub title) */}
          <div className="flex items-center gap-3">
            <Logo 
              id="brand-logo-container"
              size="md"
              onClick={() => handleNav(user ? (isAdmin ? '/admin' : '/dashboard') : '/')}
            />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-1.5">
            {!user ? (
              <>
                <button
                  id="nav-home-btn"
                  onClick={() => handleNav('/')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent('/') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  Home
                </button>
                <button
                  id="nav-courses-btn"
                  onClick={() => handleNav('/courses')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent('/courses') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  Courses
                </button>
                <button
                  id="nav-features-btn"
                  onClick={() => handleNav('/features')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent('/features') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  Features
                </button>
                <button
                  id="nav-about-btn"
                  onClick={() => handleNav('/about')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent('/about') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  About &amp; FAQs
                </button>
                <button
                  id="nav-contact-btn"
                  onClick={() => handleNav('/contact')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isCurrent('/contact') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  Contact
                </button>
              </>
            ) : (
              <>
                <button
                  id="nav-dashboard-btn"
                  onClick={() => handleNav(isAdmin ? '/admin' : '/dashboard')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent('/dashboard') || isCurrent('/admin') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  <span>{isAdmin ? 'Admin Panel' : 'Dashboard'}</span>
                </button>
                <button
                  id="nav-courses-authed-btn"
                  onClick={() => handleNav('/courses')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent('/courses') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Courses</span>
                </button>
                <button
                  id="nav-notes-btn"
                  onClick={() => handleNav('/notes')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent('/notes') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Notes (W1–12)</span>
                </button>
                <button
                  id="nav-formulas-btn"
                  onClick={() => handleNav('/formulas')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent('/formulas') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Calculator className="w-3.5 h-3.5" />
                  <span>Formulas</span>
                </button>
                <button
                  id="nav-practice-btn"
                  onClick={() => handleNav('/practice')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent('/practice') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  <span>Practice PYQs</span>
                </button>
                <button
                  id="nav-mock-tests-btn"
                  onClick={() => handleNav('/mock-tests')}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    isCurrent('/mock-tests') ? 'text-indigo-400 bg-indigo-600/20 border border-indigo-500/30' : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>CBT Mocks</span>
                </button>
              </>
            )}
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Theme Toggle Button (Light / Dark Mode) */}
            <button
              id="navbar-theme-toggle-btn"
              onClick={toggleTheme}
              className="p-2 rounded-xl border border-white/10 hover:border-white/20 bg-[#161920]/80 hover:bg-white/10 text-slate-300 hover:text-white transition-all flex items-center justify-center cursor-pointer shadow-xs"
              title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
              aria-label="Toggle theme mode"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-400" />
              )}
            </button>

            {/* Install App Button */}
            <button
              id="nav-install-app-btn"
              onClick={() => {
                const promptInstall = () => {
                  if ((window as any).deferredPrompt) {
                    (window as any).deferredPrompt.prompt();
                  } else {
                    alert('To install Prajjwal Study Hub on your device:\n• Chrome/Edge: Click "Install" icon in address bar.\n• iOS Safari: Tap Share > "Add to Home Screen".');
                  }
                };
                promptInstall();
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold transition-all active:scale-95 flex items-center gap-1.5 shadow-lg shadow-indigo-600/20"
              title="Install Web App for offline practice"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Install App</span>
            </button>

            {!user ? (
              /* Desktop-only Login & Get Started Buttons */
              <div className="hidden md:flex items-center gap-2">
                <button
                  id="nav-login-btn"
                  onClick={() => handleNav('/login')}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
                >
                  Login
                </button>
                <button
                  id="nav-getstarted-btn"
                  onClick={() => handleNav('/signup')}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-white text-slate-950 hover:bg-slate-200 transition-all active:scale-95"
                >
                  Get Started
                </button>
              </div>
            ) : (
              /* Authenticated User Profile Dropdown (Desktop) */
              <div className="relative hidden md:block">
                <button
                  id="user-profile-menu-btn"
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pl-2.5 rounded-xl border border-white/10 bg-[#161920]/80 hover:border-indigo-500/40 transition-all"
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                    isAdmin ? 'bg-amber-600 text-white' : 'bg-gradient-to-br from-indigo-500 to-purple-600 text-white'
                  }`}>
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="inline-block text-xs font-medium text-slate-200 max-w-[110px] truncate">
                    {user.name}
                  </span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {/* Profile Dropdown */}
                {profileDropdownOpen && (
                  <div
                    id="profile-dropdown"
                    className="absolute right-0 mt-2 w-56 bg-[#111318] border border-white/10 rounded-2xl shadow-2xl py-2 z-50 animate-fadeIn backdrop-blur-xl"
                  >
                    <div className="px-4 py-2 border-b border-white/10">
                      <p className="text-xs font-semibold text-white truncate">{user.name}</p>
                      <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                      <span className={`inline-block mt-1 text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full ${
                        isAdmin ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                      }`}>
                        {role}
                      </span>
                    </div>

                    <div className="py-1">
                      {isAdmin ? (
                        <button
                          id="dropdown-admin-overview-btn"
                          onClick={() => handleNav('/admin')}
                          className="w-full px-4 py-2 text-xs text-left text-amber-400 hover:bg-amber-500/10 flex items-center gap-2 font-medium"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Admin Control Center</span>
                        </button>
                      ) : (
                        <button
                          id="dropdown-dashboard-btn"
                          onClick={() => handleNav('/dashboard')}
                          className="w-full px-4 py-2 text-xs text-left text-slate-300 hover:bg-white/5 hover:text-white flex items-center gap-2"
                        >
                          <LayoutDashboard className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Student Dashboard</span>
                        </button>
                      )}

                      <button
                        id="dropdown-profile-btn"
                        onClick={() => handleNav('/profile')}
                        className="w-full px-4 py-2 text-xs text-left text-slate-300 hover:bg-white/5 hover:text-white flex items-center gap-2"
                      >
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>Profile &amp; Settings</span>
                      </button>

                      <button
                        id="dropdown-bookmarks-btn"
                        onClick={() => handleNav('/bookmarks')}
                        className="w-full px-4 py-2 text-xs text-left text-slate-300 hover:bg-white/5 hover:text-white flex items-center gap-2"
                      >
                        <Bookmark className="w-3.5 h-3.5 text-slate-400" />
                        <span>My Bookmarks</span>
                      </button>

                      <button
                        id="dropdown-performance-btn"
                        onClick={() => handleNav('/performance')}
                        className="w-full px-4 py-2 text-xs text-left text-slate-300 hover:bg-white/5 hover:text-white flex items-center gap-2"
                      >
                        <BarChart2 className="w-3.5 h-3.5 text-slate-400" />
                        <span>Performance Analytics</span>
                      </button>
                    </div>

                    <div className="border-t border-white/10 pt-1">
                      <button
                        id="dropdown-logout-btn"
                        onClick={() => {
                          logout();
                          setProfileDropdownOpen(false);
                          navigate('/');
                        }}
                        className="w-full px-4 py-2 text-xs text-left text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 font-medium"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-slate-300 hover:bg-white/5 border border-white/10 transition-colors flex items-center justify-center cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div id="mobile-nav-drawer" className="md:hidden bg-[#111318] border-b border-white/10 px-4 pt-2 pb-6 space-y-1 animate-fadeIn">
          {!user ? (
            <>
              <button
                id="mobile-nav-home"
                onClick={() => handleNav('/')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5"
              >
                Home
              </button>
              <button
                id="mobile-nav-courses"
                onClick={() => handleNav('/courses')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5"
              >
                Courses
              </button>
              <button
                id="mobile-nav-features"
                onClick={() => handleNav('/features')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5"
              >
                Features
              </button>
              <button
                id="mobile-nav-about"
                onClick={() => handleNav('/about')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5"
              >
                About &amp; FAQs
              </button>
              <button
                id="mobile-nav-contact"
                onClick={() => handleNav('/contact')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5"
              >
                Contact
              </button>
              <div className="pt-4 border-t border-white/10 grid grid-cols-2 gap-2">
                <Button id="mobile-login-btn" variant="outline" size="sm" onClick={() => handleNav('/login')}>
                  Login
                </Button>
                <Button id="mobile-signup-btn" variant="primary" size="sm" onClick={() => handleNav('/signup')}>
                  Sign Up
                </Button>
              </div>
            </>
          ) : (
            <>
              {isAdmin && (
                <button
                  id="mobile-nav-admin"
                  onClick={() => handleNav('/admin')}
                  className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/20 flex items-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Admin Control Center</span>
                </button>
              )}
              <button
                id="mobile-nav-dashboard"
                onClick={() => handleNav('/dashboard')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4 text-indigo-400" />
                <span>Dashboard</span>
              </button>
              <button
                id="mobile-nav-courses-user"
                onClick={() => handleNav('/courses')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-slate-400" />
                <span>All Courses</span>
              </button>
              <button
                id="mobile-nav-mycourses"
                onClick={() => handleNav('/my-courses')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-slate-400" />
                <span>My Courses</span>
              </button>
              <button
                id="mobile-nav-notes"
                onClick={() => handleNav('/notes')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <FileText className="w-4 h-4 text-slate-400" />
                <span>Notes &amp; Summaries (W1–12)</span>
              </button>
              <button
                id="mobile-nav-formulas"
                onClick={() => handleNav('/formulas')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <Calculator className="w-4 h-4 text-slate-400" />
                <span>Formula Sheets</span>
              </button>
              <button
                id="mobile-nav-practice"
                onClick={() => handleNav('/practice')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <CheckSquare className="w-4 h-4 text-slate-400" />
                <span>Practice Engine</span>
              </button>
              <button
                id="mobile-nav-mocktests"
                onClick={() => handleNav('/mock-tests')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <Clock className="w-4 h-4 text-slate-400" />
                <span>Mock Tests (CBT)</span>
              </button>
              <button
                id="mobile-nav-performance"
                onClick={() => handleNav('/performance')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <BarChart2 className="w-4 h-4 text-slate-400" />
                <span>Performance</span>
              </button>
              <button
                id="mobile-nav-planner"
                onClick={() => handleNav('/study-planner')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <Calendar className="w-4 h-4 text-slate-400" />
                <span>Study Planner</span>
              </button>
              <button
                id="mobile-nav-bookmarks"
                onClick={() => handleNav('/bookmarks')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <Bookmark className="w-4 h-4 text-slate-400" />
                <span>Bookmarks</span>
              </button>
              <button
                id="mobile-nav-profile"
                onClick={() => handleNav('/profile')}
                className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-200 hover:bg-white/5 flex items-center gap-2"
              >
                <User className="w-4 h-4 text-slate-400" />
                <span>Profile Settings</span>
              </button>
              <div className="pt-2 border-t border-white/10">
                <button
                  id="mobile-logout-btn"
                  onClick={() => {
                    logout();
                    handleNav('/');
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-500/10 flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </>
          )}

          {/* Quick Demo Switcher */}
          <div className="pt-3 border-t border-white/10 space-y-2">
            <div className="text-[11px] text-slate-400">
              <span className="block mb-1.5 font-medium">Quick Preview Access:</span>
              <div className="flex gap-2">
                <button
                  id="quick-demo-student-mobile"
                  onClick={() => {
                    loginAsDemoStudent();
                    handleNav('/dashboard');
                  }}
                  className="px-2.5 py-1.5 bg-white/5 border border-white/10 rounded-lg text-slate-200 hover:bg-white/10 text-[11px] font-medium"
                >
                  Demo Student
                </button>
                <button
                  id="quick-demo-admin-mobile"
                  onClick={() => {
                    loginAsDemoAdmin();
                    handleNav('/admin');
                  }}
                  className="px-2.5 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-300 hover:bg-amber-500/20 text-[11px] font-medium"
                >
                  Demo Admin
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

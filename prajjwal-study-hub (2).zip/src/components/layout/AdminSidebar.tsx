import React from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  Mail,
  ArrowLeft
} from 'lucide-react';

interface AdminSidebarProps {
  currentPath: string;
  navigate: (path: string) => void;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({ currentPath, navigate }) => {
  const links = [
    { path: '/admin', label: 'Overview', icon: LayoutDashboard, id: 'admin-link-overview' },
    { path: '/admin/courses', label: 'Courses & Modules', icon: BookOpen, id: 'admin-link-courses' },
    { path: '/admin/notes', label: 'Revision Notes', icon: FileText, id: 'admin-link-notes' },
    { path: '/admin/formulas', label: 'Formula Sheets', icon: Calculator, id: 'admin-link-formulas' },
    { path: '/admin/questions', label: 'Question Bank', icon: CheckSquare, id: 'admin-link-questions' },
    { path: '/admin/mock-tests', label: 'Mock Test Blueprints', icon: Clock, id: 'admin-link-tests' },
    { path: '/admin/messages', label: 'Student Inquiries', icon: Mail, id: 'admin-link-messages' },
  ];

  return (
    <aside className="w-64 shrink-0 bg-white dark:bg-slate-900 border-r border-slate-200/80 dark:border-slate-800 hidden md:block min-h-[calc(100vh-4rem)] p-4">
      <div className="mb-6 px-3 py-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-xl">
        <span className="text-[11px] font-bold text-rose-700 dark:text-rose-400 uppercase tracking-wider block">
          Admin Console
        </span>
        <p className="text-xs text-rose-900/70 dark:text-rose-300/70 mt-0.5">
          Curriculum & Content Management
        </p>
      </div>

      <nav className="space-y-1">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = currentPath === link.path;
          return (
            <button
              key={link.path}
              id={link.id}
              onClick={() => navigate(link.path)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                isActive
                  ? 'bg-rose-100/70 text-rose-900 dark:bg-rose-950/60 dark:text-rose-300 font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-rose-600 dark:text-rose-400' : 'text-slate-400'}`} />
              <span>{link.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-800">
        <button
          id="admin-sidebar-back-dashboard"
          onClick={() => navigate('/dashboard')}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Switch to Student View</span>
        </button>
      </div>
    </aside>
  );
};

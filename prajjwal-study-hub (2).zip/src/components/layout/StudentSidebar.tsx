import React from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  BarChart2, 
  Calendar, 
  Bookmark, 
  User,
  Sparkles,
  HelpCircle,
  LogOut,
  Sigma
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface StudentSidebarProps {
  currentPath: string;
  navigate: (path: string) => void;
}

export const StudentSidebar: React.FC<StudentSidebarProps> = ({ currentPath, navigate }) => {
  const { logout } = useAuth();

  const links = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, id: 'student-side-dashboard' },
    { path: '/courses', label: 'Courses', icon: BookOpen, id: 'student-side-courses' },
    { path: '/notes', label: 'Curated Notes', icon: FileText, id: 'student-side-notes' },
    { path: '/formulas', label: 'Formula Sheets', icon: Calculator, id: 'student-side-formulas' },
    { path: '/practice', label: 'Practice PYQs', icon: CheckSquare, id: 'student-side-practice' },
    { path: '/mock-tests', label: 'CBT Mock Tests', icon: Clock, id: 'student-side-mocktests' },
    { path: '/performance', label: 'Performance', icon: BarChart2, id: 'student-side-performance' },
    { path: '/study-planner', label: 'Study Planner', icon: Calendar, id: 'student-side-planner' },
    { path: '/bookmarks', label: 'Bookmarks', icon: Bookmark, id: 'student-side-bookmarks' },
    { path: '/profile', label: 'Profile', icon: User, id: 'student-side-profile' },
  ];

  return (
    <aside className="w-64 shrink-0 bg-slate-900/90 dark:bg-[#111318]/80 backdrop-blur-xl border-r border-slate-200/80 dark:border-white/10 hidden lg:flex flex-col justify-between min-h-[calc(100vh-4rem)] p-4 text-slate-200">
      <div className="space-y-6">
        {/* Hub Header Badge */}
        <div className="flex items-center gap-3 px-2 py-1">
          <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-white tracking-tight">Study Hub</h2>
            <p className="text-[11px] text-slate-400">IIT Madras BS Portal</p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="space-y-1">
          {links.map((item) => {
            const Icon = item.icon;
            const isActive = currentPath === item.path;
            return (
              <button
                key={item.path}
                id={item.id}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs transition-all duration-200 ${
                  isActive
                    ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 font-bold shadow-sm'
                    : 'text-slate-400 hover:bg-white/5 hover:text-white font-medium'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Promo Card & Actions */}
      <div className="space-y-3 pt-4 border-t border-white/5">
        <div 
          onClick={() => navigate('/mock-tests')}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-700 relative overflow-hidden group cursor-pointer shadow-lg shadow-indigo-500/10"
        >
          <div className="relative z-10 space-y-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-200 bg-white/10 px-2 py-0.5 rounded-full">
                Exam Ready
              </span>
              <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
            </div>
            <p className="text-white font-bold text-xs pt-1">Qualifier &amp; CBT Mocks</p>
            <p className="text-white/70 text-[10px]">Access 2021–2026 PYQ papers</p>
          </div>
          <div className="absolute -right-2 -bottom-2 w-16 h-16 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
        </div>

        <div className="space-y-0.5">
          <button 
            onClick={() => navigate('/about')}
            className="w-full flex items-center gap-3 px-3 py-1.5 text-slate-400 hover:text-white transition-colors text-xs rounded-lg hover:bg-white/5"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>About &amp; FAQ</span>
          </button>
          <button 
            onClick={() => {
              logout();
              navigate('/');
            }}
            className="w-full flex items-center gap-3 px-3 py-1.5 text-slate-400 hover:text-rose-400 transition-colors text-xs rounded-lg hover:bg-rose-500/10"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </aside>
  );
};


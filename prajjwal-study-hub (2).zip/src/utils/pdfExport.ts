import { MockTest, Question, QuestionResponse, AcademicLevel, StudyPlanTask } from '../types';
import { WeeklyChapterNote, CURATED_WEEKLY_NOTES } from '../data/curatedNotesData';
import { RichFormulaCard, RICH_FORMULA_SHEETS } from '../data/formulasData';
import { PRAJJWAL_LOGO_SVG_RAW } from '../components/common/Logo';

export interface TestResultSummary {
  score: number;
  totalMarks: number;
  percentage: number;
  accuracy: number;
  timeSpentSeconds: number;
  correctAnswers: number;
  incorrectAnswers: number;
  unattempted: number;
  isPassed?: boolean;
  responses?: Record<string, QuestionResponse>;
}

/**
 * Triggers clean print/PDF dialog by rendering a print-optimized document into a hidden iframe
 * or dedicated print window, ensuring crisp formatting without breaking page UI.
 */
function triggerPrintDocument(title: string, htmlContent: string) {
  // Use a dedicated print iframe for seamless client-side generation
  const existingIframe = document.getElementById('cbt-print-iframe') as HTMLIFrameElement | null;
  if (existingIframe) {
    existingIframe.remove();
  }

  const iframe = document.createElement('iframe');
  iframe.id = 'cbt-print-iframe';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.style.visibility = 'hidden';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    // Fallback: Open popup print window
    const printWin = window.open('', '_blank');
    if (printWin) {
      printWin.document.open();
      printWin.document.write(htmlContent);
      printWin.document.close();
      printWin.focus();
      setTimeout(() => {
        printWin.print();
      }, 350);
    }
    return;
  }

  doc.open();
  doc.write(htmlContent);
  doc.close();

  // Allow styles and fonts to render, then invoke print dialog
  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (err) {
      console.warn('Iframe print failed, falling back to window.print', err);
      const printWin = window.open('', '_blank');
      if (printWin) {
        printWin.document.open();
        printWin.document.write(htmlContent);
        printWin.document.close();
        printWin.focus();
        setTimeout(() => printWin.print(), 350);
      }
    }
  }, 350);
}

/**
 * Enhanced Base CSS for high-quality, professional printable notes, formula cheat sheets, and exam papers
 */
const BASE_PRINT_STYLES = `
  @page {
    size: A4 portrait;
    margin: 14mm 14mm 16mm 14mm;
    @top-left {
      content: "Prajjwal Study Hub";
      font-size: 8pt;
      font-weight: 700;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    @top-right {
      content: "Independent Academic Learning Portal";
      font-size: 8pt;
      color: #94a3b8;
    }
    @bottom-left {
      content: "Prajjwal Study Hub";
      font-size: 8pt;
      color: #64748b;
      font-weight: 600;
    }
    @bottom-right {
      content: "Page " counter(page);
      font-size: 8pt;
      font-weight: 700;
      color: #334155;
    }
  }
  * {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }
  body {
    margin: 0;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #0f172a;
    background: #ffffff;
    font-size: 12.5px;
    line-height: 1.55;
  }
  .print-container {
    max-width: 100%;
    margin: 0 auto;
  }

  /* Running Page Header for Browsers without @top-center support */
  .running-header-strip {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1.5px solid #cbd5e1;
    padding-bottom: 6px;
    margin-bottom: 16px;
    font-size: 9.5px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  /* Cover Page Card Layout */
  .cover-card {
    border: 2.5px solid #1e293b;
    border-radius: 10px;
    padding: 20px 24px;
    margin-bottom: 22px;
    background: #f8fafc;
    position: relative;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .cover-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 12px;
    margin-bottom: 12px;
  }
  .cover-brand-wrapper {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .cover-logo-box {
    width: 44px;
    height: 44px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .cover-logo-box svg {
    width: 100%;
    height: 100%;
    display: block;
  }
  .brand-title {
    font-size: 19px;
    font-weight: 900;
    color: #1e1b4b;
    letter-spacing: -0.02em;
    text-transform: uppercase;
    line-height: 1.15;
  }
  .brand-sub {
    font-size: 11px;
    color: #64748b;
    font-weight: 600;
    margin-top: 2px;
  }
  .doc-badge {
    display: inline-block;
    padding: 5px 12px;
    font-size: 10.5px;
    font-weight: 800;
    border-radius: 6px;
    background: #1e293b;
    color: #ffffff;
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }
  .doc-badge.formula {
    background: #1d4ed8;
  }
  .doc-badge.notes {
    background: #4338ca;
  }
  .doc-badge.solutions {
    background: #047857;
  }
  .doc-badge.practice {
    background: #0f172a;
  }
  .doc-badge.planner {
    background: #e11d48;
  }

  .doc-main-title {
    font-size: 21px;
    font-weight: 800;
    color: #0f172a;
    margin: 6px 0 2px 0;
    line-height: 1.25;
  }
  .doc-main-subtitle {
    font-size: 13px;
    font-weight: 600;
    color: #475569;
    margin-bottom: 12px;
  }

  .meta-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 10px 14px;
    margin-top: 8px;
  }
  .meta-item {
    font-size: 11px;
  }
  .meta-label {
    color: #64748b;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 9px;
    display: block;
    letter-spacing: 0.04em;
    margin-bottom: 1px;
  }
  .meta-val {
    font-weight: 700;
    color: #0f172a;
    font-size: 11.5px;
  }

  /* Candidate Input Strip */
  .candidate-fill-box {
    margin-top: 12px;
    display: grid;
    grid-template-columns: 1.5fr 1fr 1fr;
    gap: 12px;
    padding: 8px 12px;
    border: 1px dashed #94a3b8;
    border-radius: 6px;
    background: #ffffff;
    font-size: 11px;
  }
  .candidate-fill-item {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .fill-line {
    flex: 1;
    border-bottom: 1px solid #475569;
    height: 14px;
  }

  /* Section Containers */
  .section-block {
    margin-bottom: 20px;
    break-inside: avoid;
    page-break-inside: avoid;
  }
  .section-title {
    font-size: 14px;
    font-weight: 800;
    color: #0f172a;
    border-bottom: 2px solid #e2e8f0;
    padding-bottom: 5px;
    margin-bottom: 12px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  /* Week Chapter Note Card */
  .chapter-note-card {
    border: 1.5px solid #cbd5e1;
    border-radius: 8px;
    padding: 16px 18px;
    margin-bottom: 18px;
    background: #ffffff;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .chapter-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 8px;
    border-bottom: 1.5px solid #f1f5f9;
    margin-bottom: 12px;
  }
  .week-badge {
    display: inline-block;
    padding: 3px 8px;
    background: #e0e7ff;
    color: #3730a3;
    font-weight: 800;
    font-size: 10.5px;
    border-radius: 4px;
    text-transform: uppercase;
  }
  .chapter-title {
    font-size: 15px;
    font-weight: 800;
    color: #0f172a;
    margin: 0;
  }

  .takeaways-box {
    background: #f8fafc;
    border-left: 3.5px solid #4338ca;
    padding: 10px 14px;
    border-radius: 0 6px 6px 0;
    margin: 10px 0 14px 0;
  }
  .takeaways-title {
    font-size: 10.5px;
    font-weight: 800;
    text-transform: uppercase;
    color: #3730a3;
    margin-bottom: 4px;
    letter-spacing: 0.04em;
  }
  .takeaways-list {
    margin: 0;
    padding-left: 18px;
    font-size: 11.5px;
    color: #1e293b;
  }
  .takeaways-list li {
    margin-bottom: 3px;
  }

  .definitions-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin: 12px 0;
  }
  .def-card {
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 10px 12px;
    background: #f8fafc;
  }
  .def-term {
    font-size: 11.5px;
    font-weight: 800;
    color: #1e293b;
    margin-bottom: 2px;
  }
  .def-expl {
    font-size: 11px;
    color: #475569;
    line-height: 1.45;
  }
  .def-formula {
    margin-top: 6px;
    padding: 4px 8px;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 11px;
    font-weight: 700;
    color: #3730a3;
    text-align: center;
  }

  .code-block {
    background: #0f172a;
    color: #f8fafc;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 10.5px;
    padding: 10px 12px;
    border-radius: 6px;
    margin: 8px 0 12px 0;
    overflow-x: auto;
    white-space: pre;
    line-height: 1.4;
  }
  .code-header {
    font-size: 9.5px;
    font-weight: 700;
    color: #94a3b8;
    text-transform: uppercase;
    margin-bottom: 4px;
  }

  .exam-tips-box {
    background: #fffbeb;
    border: 1px solid #fef3c7;
    border-left: 3.5px solid #d97706;
    padding: 10px 14px;
    border-radius: 0 6px 6px 0;
    margin: 10px 0;
  }
  .exam-tips-title {
    font-size: 10.5px;
    font-weight: 800;
    text-transform: uppercase;
    color: #92400e;
    margin-bottom: 4px;
  }
  .exam-tips-list {
    margin: 0;
    padding-left: 18px;
    font-size: 11px;
    color: #78350f;
  }

  /* Formula Cheat Sheet Styles */
  .formula-print-card {
    border: 1.5px solid #cbd5e1;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 14px;
    background: #ffffff;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .formula-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 6px;
    padding-bottom: 4px;
    border-bottom: 1px solid #f1f5f9;
  }
  .formula-title {
    font-size: 13.5px;
    font-weight: 800;
    color: #0f172a;
  }
  .formula-cat-tag {
    font-size: 9.5px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    background: #dbeafe;
    color: #1e40af;
    text-transform: uppercase;
  }
  .equation-display-box {
    background: #eff6ff;
    border: 1.5px solid #bfdbfe;
    border-radius: 6px;
    padding: 8px 12px;
    text-align: center;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 13.5px;
    font-weight: 800;
    color: #1e3a8a;
    margin: 8px 0;
  }
  .formula-explanation {
    font-size: 11.5px;
    color: #334155;
    line-height: 1.45;
    margin-bottom: 8px;
  }
  .variables-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10.5px;
    margin: 6px 0 8px 0;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
  }
  .variables-table td {
    padding: 4px 8px;
    border-bottom: 1px solid #e2e8f0;
  }
  .variables-table tr:last-child td {
    border-bottom: none;
  }
  .var-sym {
    font-weight: 800;
    color: #1d4ed8;
    width: 25%;
    font-family: ui-monospace, monospace;
  }

  /* Question & Solutions Specifics */
  .instructions-box {
    border: 1px solid #e2e8f0;
    background: #f1f5f9;
    border-radius: 6px;
    padding: 10px 14px;
    margin-bottom: 20px;
    font-size: 11px;
    break-inside: avoid;
    page-break-inside: avoid;
  }
  .instructions-title {
    font-weight: 700;
    text-transform: uppercase;
    font-size: 10.5px;
    color: #334155;
    margin-bottom: 4px;
  }
  .instructions-list {
    margin: 0;
    padding-left: 18px;
    color: #475569;
  }
  .instructions-list li {
    margin-bottom: 2px;
  }

  .question-card {
    border: 1.5px solid #cbd5e1;
    border-radius: 8px;
    padding: 14px 16px;
    margin-bottom: 16px;
    background: #ffffff;
    break-inside: avoid;
    page-break-inside: avoid;
  }
  .q-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 6px;
    border-bottom: 1px solid #f1f5f9;
    margin-bottom: 8px;
  }
  .q-num {
    font-weight: 800;
    font-size: 13px;
    color: #1e293b;
  }
  .q-type-badge {
    font-size: 9.5px;
    font-weight: 700;
    background: #e2e8f0;
    color: #334155;
    padding: 2px 6px;
    border-radius: 4px;
    margin-left: 6px;
    text-transform: uppercase;
  }
  .q-marks {
    font-size: 11px;
    font-weight: 700;
    color: #059669;
  }
  .q-text {
    font-size: 12px;
    color: #1e293b;
    margin-bottom: 10px;
    line-height: 1.55;
    white-space: pre-line;
  }
  .options-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    margin: 10px 0;
  }
  .option-item {
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 11.5px;
    background: #ffffff;
    display: flex;
    align-items: flex-start;
    gap: 6px;
  }
  .opt-label {
    font-weight: 700;
    min-width: 18px;
    color: #334155;
  }
  .opt-text {
    flex: 1;
    color: #1e293b;
  }

  .rough-work-box {
    margin-top: 10px;
    border: 1px dashed #cbd5e1;
    border-radius: 6px;
    height: 48px;
    padding: 4px 8px;
    background: #fafafa;
  }
  .rough-work-label {
    font-size: 9px;
    font-weight: 600;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .nat-answer-box {
    margin: 8px 0;
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    background: #f8fafc;
    font-size: 11.5px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }

  .solution-box {
    margin-top: 10px;
    padding: 10px 12px;
    background: #f0fdf4;
    border: 1px solid #86efac;
    border-radius: 6px;
    font-size: 11.5px;
  }
  .sol-key-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 700;
    color: #166534;
    margin-bottom: 6px;
    padding-bottom: 4px;
    border-bottom: 1px solid #bbf7d0;
  }
  .user-resp-tag {
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 700;
  }
  .user-correct {
    background: #dcfce7;
    color: #15803d;
    border: 1px solid #86efac;
  }
  .user-wrong {
    background: #fee2e2;
    color: #b91c1c;
    border: 1px solid #fca5a5;
  }
  .user-skipped {
    background: #f1f5f9;
    color: #64748b;
    border: 1px solid #cbd5e1;
  }
  .sol-explanation {
    color: #1e293b;
    font-size: 11px;
    line-height: 1.5;
    white-space: pre-line;
  }

  .scorecard-banner {
    border: 2px solid #0f172a;
    border-radius: 8px;
    padding: 14px 18px;
    margin-bottom: 20px;
    background: #f8fafc;
    display: flex;
    justify-content: space-between;
    align-items: center;
    break-inside: avoid;
  }
  .score-val {
    font-size: 24px;
    font-weight: 900;
    color: #0f172a;
  }
  .score-stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    text-align: center;
  }
  .stat-block {
    padding: 6px 10px;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
  }

  .answer-matrix-table {
    width: 100%;
    border-collapse: collapse;
    margin: 14px 0 20px 0;
    font-size: 11px;
    break-inside: avoid;
  }
  .answer-matrix-table th, .answer-matrix-table td {
    border: 1px solid #cbd5e1;
    padding: 6px 8px;
    text-align: center;
  }
  .answer-matrix-table th {
    background: #1e293b;
    color: #ffffff;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 10px;
  }

  .footer-disclaimer {
    margin-top: 30px;
    padding-top: 12px;
    border-top: 1.5px solid #cbd5e1;
    text-align: center;
    font-size: 9.5px;
    color: #64748b;
    line-height: 1.4;
  }
`;

function escapeHtml(str: string): string {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Standardized Branded Front Cover Component for All PDF Exports
 */
function renderBrandedCoverPage(
  docTitle: string,
  docSubTitle: string,
  badgeText: string,
  badgeClass: string,
  level: string,
  scopeOrTerm: string,
  candidateName: string = 'Candidate',
  extraMeta?: Array<{ label: string; value: string }>
): string {
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return `
    <div class="cover-card">
      <div class="cover-top">
        <div class="cover-brand-wrapper">
          <div class="cover-logo-box">
            ${PRAJJWAL_LOGO_SVG_RAW}
          </div>
          <div>
            <div class="brand-title">Prajjwal Study Hub</div>
            <div class="brand-sub">Independent Academic Learning Portal</div>
          </div>
        </div>
        <div class="doc-badge ${badgeClass}">${escapeHtml(badgeText)}</div>
      </div>

      <div class="doc-main-title">${escapeHtml(docTitle)}</div>
      <div class="doc-main-subtitle">${escapeHtml(docSubTitle)}</div>

      <div class="meta-grid">
        <div class="meta-item">
          <span class="meta-label">Academic Program</span>
          <span class="meta-val">IITM BS Degree Track</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Curriculum Level</span>
          <span class="meta-val">${escapeHtml(level || 'Foundation')}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Scope / Term</span>
          <span class="meta-val">${escapeHtml(scopeOrTerm || 'All Weeks')}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Date Generated</span>
          <span class="meta-val">${currentDate}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Candidate Name</span>
          <span class="meta-val">${escapeHtml(candidateName)}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Portal Verification</span>
          <span class="meta-val">Verified Syllabus Notes</span>
        </div>
        ${(extraMeta || []).map(m => `
          <div class="meta-item">
            <span class="meta-label">${escapeHtml(m.label)}</span>
            <span class="meta-val">${escapeHtml(m.value)}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/**
 * 1. Download / Print Curated Notes PDF (Individual Week or Full Subject)
 */
export function downloadCuratedNotesPdf(
  notes: WeeklyChapterNote | WeeklyChapterNote[],
  subjectTitle?: string,
  level: string = 'Foundation',
  candidateName: string = 'Candidate'
): void {
  const notesArray = Array.isArray(notes) ? notes : [notes];
  const isSingle = notesArray.length === 1;

  const firstNote = notesArray[0];
  const resolvedSubject = subjectTitle || firstNote?.courseTitle || 'Curated Syllabus Notes';
  const docTitle = isSingle 
    ? `${firstNote.courseTitle} — Week ${firstNote.weekNumber}: ${firstNote.title}`
    : `${resolvedSubject} — Full Curated Revision Notes`;
  const docSub = isSingle 
    ? `Comprehensive Week ${firstNote.weekNumber} Revision Material • ${firstNote.courseCode}`
    : `Complete Weeks 1 to ${notesArray.length} Chapter Summaries & Derivations`;

  const coverHtml = renderBrandedCoverPage(
    docTitle,
    docSub,
    'CURATED REVISION NOTES',
    'notes',
    level,
    isSingle ? `Week ${firstNote.weekNumber}` : `Weeks 1 - ${notesArray.length}`,
    candidateName,
    [
      { label: 'Total Chapters', value: `${notesArray.length} Chapter${notesArray.length > 1 ? 's' : ''}` },
      { label: 'Course Code', value: firstNote?.courseCode || 'BSM' }
    ]
  );

  const chaptersHtml = notesArray.map((note, idx) => `
    <div class="chapter-note-card" id="note-print-week-${note.weekNumber}">
      <div class="chapter-header">
        <div>
          <span class="week-badge">Week ${note.weekNumber}</span>
          <span style="font-size:12px; font-weight:700; color:#475569; margin-left:6px;">${escapeHtml(note.courseCode)}</span>
        </div>
        <div style="font-size:10.5px; color:#64748b; font-weight:600;">
          Chapter ${idx + 1} of ${notesArray.length}
        </div>
      </div>

      <h3 class="chapter-title">${escapeHtml(note.title)}</h3>

      <!-- Core Takeaways -->
      <div class="takeaways-box">
        <div class="takeaways-title">Key Concepts & Principles</div>
        <ul class="takeaways-list">
          ${note.keyTakeaways.map(t => `<li>${escapeHtml(t)}</li>`).join('')}
        </ul>
      </div>

      <!-- Formal Definitions & Equations -->
      ${(note.definitions && note.definitions.length > 0) ? `
        <div style="margin-top:12px;">
          <div style="font-size:11px; font-weight:800; text-transform:uppercase; color:#334155; margin-bottom:6px;">
            Formal Definitions & Equations
          </div>
          <div class="definitions-grid">
            ${note.definitions.map(d => `
              <div class="def-card">
                <div class="def-term">${escapeHtml(d.term)}</div>
                <div class="def-expl">${escapeHtml(d.explanation)}</div>
                ${d.formula ? `<div class="def-formula">${escapeHtml(d.formula)}</div>` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Code Snippets -->
      ${(note.codeSnippets && note.codeSnippets.length > 0) ? `
        <div style="margin-top:12px;">
          <div style="font-size:11px; font-weight:800; text-transform:uppercase; color:#334155; margin-bottom:6px;">
            Algorithm & Code Syntax Reference
          </div>
          ${note.codeSnippets.map(c => `
            <div>
              <div class="code-header">${escapeHtml(c.title)} (${escapeHtml(c.language)})</div>
              <div class="code-block">${escapeHtml(c.code)}</div>
            </div>
          `).join('')}
        </div>
      ` : ''}

      <!-- Exam Tips -->
      ${(note.examTips && note.examTips.length > 0) ? `
        <div class="exam-tips-box">
          <div class="exam-tips-title">Exam Insights & Common Traps</div>
          <ul class="exam-tips-list">
            ${note.examTips.map(e => `<li>${escapeHtml(e)}</li>`).join('')}
          </ul>
        </div>
      ` : ''}
    </div>
  `).join('');

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(docTitle)} - Prajjwal Study Hub</title>
      <style>${BASE_PRINT_STYLES}</style>
    </head>
    <body>
      <div class="print-container">
        ${coverHtml}
        <div class="section-title">
          <span>Curated Chapter Revision Content</span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${notesArray.length} Modules</span>
        </div>
        ${chaptersHtml}
        <div class="footer-disclaimer">
          <strong>Prajjwal Study Hub</strong> — Independent Open-Access Learning & Assessment Platform.<br>
          Disclaimer: This study material is curated for student learning and is not officially affiliated with or endorsed by IIT Madras.
        </div>
      </div>
    </body>
    </html>
  `;

  triggerPrintDocument(docTitle, html);
}

/**
 * 2. Download / Print Formula Cheat Sheet PDF
 */
export function downloadFormulaSheetPdf(
  formulas: RichFormulaCard[],
  title: string = 'High-Yield Formula Cheat Sheet',
  category: string = 'All Categories',
  level: string = 'Foundation',
  candidateName: string = 'Candidate'
): void {
  const docTitle = `${title}`;
  const docSub = `High-Yield Mathematical, Statistical & Algorithmic Equations • ${category}`;

  const coverHtml = renderBrandedCoverPage(
    docTitle,
    docSub,
    'FORMULA CHEAT SHEET',
    'formula',
    level,
    category,
    candidateName,
    [
      { label: 'Total Formulas', value: `${formulas.length} Formulas` },
      { label: 'Category', value: category }
    ]
  );

  const formulasHtml = formulas.map((f, idx) => `
    <div class="formula-print-card" id="formula-print-${idx + 1}">
      <div class="formula-header">
        <div>
          <span style="font-size:11px; font-weight:800; color:#475569; margin-right:6px;">#${idx + 1}</span>
          <span class="formula-title">${escapeHtml(f.title)}</span>
        </div>
        <div class="formula-cat-tag">${escapeHtml(f.category)}</div>
      </div>

      <div class="equation-display-box">
        ${escapeHtml(f.latex || f.formula)}
      </div>

      <div class="formula-explanation">
        ${escapeHtml(f.explanation)}
      </div>

      ${(f.variables && f.variables.length > 0) ? `
        <table class="variables-table">
          <tbody>
            ${f.variables.map(v => `
              <tr>
                <td class="var-sym">${escapeHtml(v.symbol)}</td>
                <td><strong>${escapeHtml(v.name)}</strong>: ${escapeHtml(v.description)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      ` : ''}

      ${(f.keyInsights && f.keyInsights.length > 0) ? `
        <div style="background:#fffbeb; border:1px solid #fef3c7; border-radius:4px; padding:6px 10px; font-size:10.5px; color:#92400e; margin-top:6px;">
          <strong>Exam Insights:</strong> ${f.keyInsights.map(i => escapeHtml(i)).join(' • ')}
        </div>
      ` : ''}
    </div>
  `).join('');

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(docTitle)} - Prajjwal Study Hub</title>
      <style>${BASE_PRINT_STYLES}</style>
    </head>
    <body>
      <div class="print-container">
        ${coverHtml}
        <div class="section-title">
          <span>Formula & Equation Repository</span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${formulas.length} High-Yield Cards</span>
        </div>
        <div style="display:grid; grid-template-columns:1fr; gap:8px;">
          ${formulasHtml}
        </div>
        <div class="footer-disclaimer">
          <strong>Prajjwal Study Hub</strong> — High-Yield Formula Repository & Cheat Sheets.<br>
          Disclaimer: This reference material is curated for student practice and is not officially affiliated with or endorsed by IIT Madras.
        </div>
      </div>
    </body>
    </html>
  `;

  triggerPrintDocument(docTitle, html);
}

/**
 * 3. Download / Print Question Paper (Blank Exam Paper for Offline / Practice)
 */
export function downloadQuestionPaperPdf(test: MockTest, questions: Question[], candidateName: string = 'Candidate'): void {
  const coverHtml = renderBrandedCoverPage(
    test.title,
    `Official Practice Question Paper • ${escapeHtml(test.subject || 'IITM BS Degree')}`,
    'QUESTION PAPER',
    'practice',
    test.level || 'Foundation',
    `${test.durationMinutes || 60} Mins • ${questions.length} Questions`,
    candidateName,
    [
      { label: 'Total Marks', value: `${test.totalMarks} Marks` },
      { label: 'Time Allowed', value: `${test.durationMinutes || 60} Minutes` }
    ]
  );

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(test.title)} - Question Paper</title>
      <style>${BASE_PRINT_STYLES}</style>
    </head>
    <body>
      <div class="print-container">
        ${coverHtml}

        <!-- Instructions -->
        <div class="instructions-box">
          <div class="instructions-title">General Instructions & Examination Rules</div>
          <ul class="instructions-list">
            <li>This question paper contains <strong>${questions.length} questions</strong>. Total maximum score is <strong>${test.totalMarks} marks</strong>.</li>
            <li><strong>MCQ (Single Choice)</strong>: Only one option is correct. Negative marks apply as specified.</li>
            <li><strong>MSQ (Multiple Select)</strong>: One or more options may be correct. Full marks awarded only if all correct choices are selected with no wrong choices.</li>
            <li><strong>NAT (Numerical Answer Type)</strong>: Enter precise numeric answer in the specified space or virtual keypad.</li>
            <li>Use the designated rough work space below each question for calculations and derivations.</li>
          </ul>
        </div>

        <!-- Questions List -->
        <div class="questions-container">
          ${questions.map((q, idx) => {
            const marksStr = `+${q.marks || 2} Marks${q.negativeMarks ? ` | -${q.negativeMarks} Neg.` : ' | No Neg.'}`;
            return `
              <div class="question-card" id="q-print-${idx + 1}">
                <div class="q-header">
                  <div>
                    <span class="q-num">Question ${idx + 1}</span>
                    <span class="q-type-badge">${escapeHtml(q.type || 'MCQ')}</span>
                    ${q.pyqYear ? `<span class="q-type-badge" style="background:#e0e7ff; color:#3730a3;">${escapeHtml(q.pyqYear)}</span>` : ''}
                  </div>
                  <div class="q-marks">${marksStr}</div>
                </div>

                <div class="q-text">${escapeHtml(q.questionText)}</div>

                ${q.codeSnippet ? `
                  <div class="code-block">${escapeHtml(q.codeSnippet)}</div>
                ` : ''}

                ${(q.options && q.options.length > 0) ? `
                  <div class="options-grid">
                    ${q.options.map((opt, optIdx) => `
                      <div class="option-item">
                        <span class="opt-label">(${String.fromCharCode(65 + optIdx)})</span>
                        <span class="opt-text">${escapeHtml(opt)}</span>
                      </div>
                    `).join('')}
                  </div>
                ` : ''}

                ${q.type === 'NAT' ? `
                  <div class="nat-answer-box">
                    <strong>Enter Numeric Value: [ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ]</strong>
                    ${q.numericTolerance ? `<span style="color:#64748b; font-size:10.5px;">(Tolerance: ±${q.numericTolerance})</span>` : ''}
                  </div>
                ` : ''}

                <!-- Rough Work Box -->
                <div class="rough-work-box">
                  <div class="rough-work-label">Space for Rough Work / Calculations:</div>
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Footer -->
        <div class="footer-disclaimer">
          <strong>Prajjwal Study Hub</strong> — Independent Open-Access Learning & Assessment Platform.<br>
          Disclaimer: This test material is curated for student practice and is not officially affiliated with or endorsed by IIT Madras.
        </div>

      </div>
    </body>
    </html>
  `;

  triggerPrintDocument(`${test.title} - Question Paper`, html);
}

/**
 * 4. Download / Print Full Solutions & Answer Key PDF (With detailed explanations and scorecard)
 */
export function downloadSolutionsPdf(
  test: MockTest,
  questions: Question[],
  results?: TestResultSummary | null,
  candidateName: string = 'Candidate'
): void {
  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}m ${s}s`;
  };

  const coverHtml = renderBrandedCoverPage(
    test.title,
    `Comprehensive Post-Exam Solutions & Step-by-Step Derivations • ${escapeHtml(test.subject || 'IITM BS Degree')}`,
    'SOLUTIONS & ANSWER KEY',
    'solutions',
    test.level || 'Foundation',
    `${questions.length} Questions Evaluated`,
    candidateName,
    [
      { label: 'Subject', value: test.subject || 'BS Course' },
      { label: 'Evaluation', value: 'Step-by-Step Derivation' }
    ]
  );

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(test.title)} - Full Solutions & Key</title>
      <style>${BASE_PRINT_STYLES}</style>
    </head>
    <body>
      <div class="print-container">
        ${coverHtml}

        ${results ? `
          <!-- Candidate Performance Scorecard Banner -->
          <div class="scorecard-banner">
            <div>
              <div style="font-size:11px; text-transform:uppercase; font-weight:700; color:#475569;">
                Candidate Performance Summary
              </div>
              <div class="score-val">
                Score: ${results.score} / ${results.totalMarks}
                <span style="font-size:14px; font-weight:600; color:${results.percentage >= 40 ? '#059669' : '#d97706'}; margin-left:8px;">
                  (${results.percentage}% • ${results.percentage >= 40 ? 'Qualified' : 'Needs Practice'})
                </span>
              </div>
              <div style="font-size:11px; color:#64748b; margin-top:2px;">
                Time Taken: ${formatSeconds(results.timeSpentSeconds)} | Passing Mark: ${test.passingMarks || Math.round(test.totalMarks * 0.4)}
              </div>
            </div>

            <div class="score-stats-grid">
              <div class="stat-block">
                <div style="font-size:9.5px; color:#64748b; font-weight:700;">ACCURACY</div>
                <div style="font-size:14px; font-weight:800; color:#0f172a;">${results.accuracy}%</div>
              </div>
              <div class="stat-block" style="background:#f0fdf4; border-color:#bbf7d0;">
                <div style="font-size:9.5px; color:#15803d; font-weight:700;">CORRECT</div>
                <div style="font-size:14px; font-weight:800; color:#15803d;">${results.correctAnswers}</div>
              </div>
              <div class="stat-block" style="background:#fef2f2; border-color:#fecaca;">
                <div style="font-size:9.5px; color:#b91c1c; font-weight:700;">INCORRECT</div>
                <div style="font-size:14px; font-weight:800; color:#b91c1c;">${results.incorrectAnswers}</div>
              </div>
              <div class="stat-block">
                <div style="font-size:9.5px; color:#64748b; font-weight:700;">SKIPPED</div>
                <div style="font-size:14px; font-weight:800; color:#475569;">${results.unattempted}</div>
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Quick Answer Key Matrix Table -->
        <div style="break-inside: avoid; page-break-inside: avoid;">
          <div style="font-size:11.5px; font-weight:800; text-transform:uppercase; color:#1e293b; margin-bottom:4px;">
            Quick Answer Key Reference Matrix
          </div>
          <table class="answer-matrix-table">
            <thead>
              <tr>
                ${questions.map((_, i) => `<th>Q${i + 1}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              <tr>
                ${questions.map(q => {
                  let keyStr = '-';
                  if (q.type === 'MSQ' && q.correctOptionIndices) {
                    keyStr = q.correctOptionIndices.map(idx => String.fromCharCode(65 + idx)).join(', ');
                  } else if (q.type === 'NAT' && q.correctNumericAnswer !== undefined) {
                    keyStr = `${q.correctNumericAnswer}`;
                  } else if (q.correctOptionIndex !== undefined) {
                    keyStr = String.fromCharCode(65 + q.correctOptionIndex);
                  }
                  return `<td><strong>${escapeHtml(keyStr)}</strong></td>`;
                }).join('')}
              </tr>
              ${results && results.responses ? `
                <tr style="background:#f8fafc;">
                  ${questions.map(q => {
                    const resp = results.responses ? results.responses[q.id] : undefined;
                    if (!resp || !resp.isAnswered) return `<td style="color:#94a3b8;">-</td>`;
                    if (resp.isCorrect) return `<td style="color:#15803d; font-weight:700;">✓</td>`;
                    return `<td style="color:#b91c1c; font-weight:700;">✗</td>`;
                  }).join('')}
                </tr>
              ` : ''}
            </tbody>
          </table>
        </div>

        <!-- Detailed Solutions List -->
        <div style="margin-top:20px;">
          <div style="font-size:14px; font-weight:800; color:#0f172a; margin-bottom:12px; border-bottom:2px solid #e2e8f0; padding-bottom:6px;">
            Detailed Step-by-Step Question Derivations & Explanations
          </div>

          ${questions.map((q, idx) => {
            const resp = results && results.responses ? results.responses[q.id] : undefined;
            
            // Format Correct Answer Key
            let correctKeyText = '';
            if (q.type === 'MSQ' && q.correctOptionIndices) {
              const keys = q.correctOptionIndices.map(i => `(${String.fromCharCode(65 + i)}) ${q.options?.[i] || ''}`);
              correctKeyText = keys.join(' AND ');
            } else if (q.type === 'NAT' && q.correctNumericAnswer !== undefined) {
              correctKeyText = `${q.correctNumericAnswer} ${q.numericTolerance ? `(Acceptable range: ±${q.numericTolerance})` : ''}`;
            } else if (q.correctOptionIndex !== undefined && q.options) {
              correctKeyText = `(${String.fromCharCode(65 + q.correctOptionIndex)}) ${q.options[q.correctOptionIndex]}`;
            }

            // Format User Selected Answer
            let userAnsText = 'Not Attempted';
            let userTagClass = 'user-skipped';
            if (resp && resp.isAnswered) {
              if (resp.isCorrect) {
                userTagClass = 'user-correct';
              } else {
                userTagClass = 'user-wrong';
              }

              if (q.type === 'MSQ' && resp.selectedOptionIndices) {
                userAnsText = resp.selectedOptionIndices.map(i => String.fromCharCode(65 + i)).join(', ');
              } else if (q.type === 'NAT' && resp.numericAnswer) {
                userAnsText = resp.numericAnswer;
              } else if (resp.selectedOptionIndex !== undefined) {
                userAnsText = `Option (${String.fromCharCode(65 + resp.selectedOptionIndex)})`;
              }
            }

            return `
              <div class="question-card" id="sol-card-${idx + 1}">
                <div class="q-header">
                  <div>
                    <span class="q-num">Question ${idx + 1}</span>
                    <span class="q-type-badge">${escapeHtml(q.type || 'MCQ')}</span>
                    ${q.pyqYear ? `<span class="q-type-badge" style="background:#e0e7ff; color:#3730a3;">${escapeHtml(q.pyqYear)}</span>` : ''}
                    <span style="font-size:11px; color:#64748b; margin-left:6px;">${escapeHtml(q.subject || '')}</span>
                  </div>
                  <div>
                    ${results ? `
                      <span class="user-resp-tag ${userTagClass}">
                        ${resp?.isCorrect ? `✓ Correct (+${resp.marksAwarded}M)` : resp?.isAnswered ? `✗ Incorrect (${resp.marksAwarded}M)` : 'Skipped (0M)'}
                      </span>
                    ` : `
                      <span class="q-marks">+${q.marks || 2} Marks</span>
                    `}
                  </div>
                </div>

                <div class="q-text">${escapeHtml(q.questionText)}</div>

                ${q.codeSnippet ? `
                  <div class="code-block">${escapeHtml(q.codeSnippet)}</div>
                ` : ''}

                ${(q.options && q.options.length > 0) ? `
                  <div class="options-grid">
                    ${q.options.map((opt, optIdx) => {
                      const isCorrect = q.type === 'MSQ' 
                        ? q.correctOptionIndices?.includes(optIdx)
                        : q.correctOptionIndex === optIdx;
                      const isUser = q.type === 'MSQ'
                        ? resp?.selectedOptionIndices?.includes(optIdx)
                        : resp?.selectedOptionIndex === optIdx;

                      let style = 'border: 1px solid #cbd5e1;';
                      if (isCorrect) {
                        style = 'border: 1.5px solid #15803d; background:#dcfce7; font-weight:600; color:#14532d;';
                      } else if (isUser && !isCorrect) {
                        style = 'border: 1.5px solid #b91c1c; background:#fee2e2; text-decoration:line-through; color:#7f1d1d;';
                      }

                      return `
                        <div class="option-item" style="${style}">
                          <span class="opt-label">(${String.fromCharCode(65 + optIdx)})</span>
                          <span class="opt-text">${escapeHtml(opt)}</span>
                          ${isCorrect ? '<span style="color:#15803d; font-size:10px; font-weight:800; margin-left:auto;">[KEY]</span>' : ''}
                        </div>
                      `;
                    }).join('')}
                  </div>
                ` : ''}

                <!-- Solution & Derivation Box -->
                <div class="solution-box">
                  <div class="sol-key-header">
                    <div>
                      <strong>Official Key:</strong> ${escapeHtml(correctKeyText)}
                    </div>
                    ${results ? `
                      <div style="font-size:10.5px; color:#475569;">
                        Your Input: <strong>${escapeHtml(userAnsText)}</strong>
                      </div>
                    ` : ''}
                  </div>
                  
                  <div style="font-weight:700; font-size:10.5px; color:#15803d; margin-bottom:4px; text-transform:uppercase;">
                    Step-by-Step Derivation & Explanation:
                  </div>
                  <div class="sol-explanation">${escapeHtml(q.explanation || 'Refer to course notes.')}</div>
                </div>
              </div>
            `;
          }).join('')}
        </div>

        <!-- Footer -->
        <div class="footer-disclaimer">
          <strong>Prajjwal Study Hub</strong> — Detailed Performance Solutions & PYQ Bank.<br>
          Disclaimer: This test material is curated for student practice and is not officially affiliated with or endorsed by IIT Madras.
        </div>

      </div>
    </body>
    </html>
  `;

  triggerPrintDocument(`${test.title} - Full Solutions`, html);
}

/**
 * 5. Download / Print Generic Practice Questions Set (Question Paper or Solutions Key)
 */
export function downloadPracticeSetPdf(
  title: string,
  level: string,
  subject: string,
  questions: Question[],
  withSolutions: boolean = false,
  candidateName: string = 'Candidate'
): void {
  const mockTestObj: MockTest = {
    id: 'practice-set-export',
    title: title || 'IITM BS Degree Practice Set',
    courseId: subject,
    subject: subject,
    level: level as any,
    type: 'Practice Set',
    durationMinutes: Math.max(30, questions.length * 3),
    totalMarks: questions.reduce((sum, q) => sum + (q.marks || 2), 0),
    totalQuestions: questions.length,
    passingMarks: Math.round(questions.length * 0.8),
    difficulty: 'Exam Standard',
    instructions: [
      'Solve all questions carefully before checking solutions.',
      'Mark questions for revision using the margin notes.'
    ],
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  if (withSolutions) {
    downloadSolutionsPdf(mockTestObj, questions, null, candidateName);
  } else {
    downloadQuestionPaperPdf(mockTestObj, questions, candidateName);
  }
}

/**
 * 6. Download / Print Monthly & Weekly Study Planner Schedule PDF
 */
export function downloadStudyPlannerPdf(
  tasks: StudyPlanTask[],
  level: string = 'Foundation & Diploma',
  candidateName: string = 'Candidate',
  periodTitle: string = 'Weekly & Monthly Study Schedule'
): void {
  const docTitle = `Personal Study Schedule & Milestone Planner`;
  const docSub = `${periodTitle} • Term Exam Prep Routine`;

  const completedCount = tasks.filter(t => t.completed).length;
  const highPriorityCount = tasks.filter(t => t.priority === 'high').length;
  const mediumPriorityCount = tasks.filter(t => t.priority === 'medium').length;
  const progressPct = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  const coverHtml = renderBrandedCoverPage(
    docTitle,
    docSub,
    'STUDY PLANNER',
    'planner',
    level,
    'Term Schedule',
    candidateName,
    [
      { label: 'Total Tasks', value: `${tasks.length} Tasks Scheduled` },
      { label: 'Completion Rate', value: `${progressPct}% (${completedCount}/${tasks.length})` },
      { label: 'High Priority', value: `${highPriorityCount} Tasks` },
      { label: 'Plan Status', value: 'Active Revision Schedule' }
    ]
  );

  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    return (a.startTime || '').localeCompare(b.startTime || '');
  });

  const tasksRows = sortedTasks.map((t, idx) => {
    const isHigh = t.priority === 'high';
    const isMedium = t.priority === 'medium';
    const badgeStyle = isHigh 
      ? 'background:#fee2e2; color:#b91c1c; border:1px solid #fca5a5;'
      : isMedium
      ? 'background:#fef3c7; color:#92400e; border:1px solid #fde68a;'
      : 'background:#f1f5f9; color:#475569; border:1px solid #cbd5e1;';

    return `
      <tr style="${t.completed ? 'background:#f8fafc; color:#94a3b8;' : ''}">
        <td style="text-align:center; width:40px; font-weight:700;">
          ${t.completed ? '<span style="color:#16a34a; font-size:14px;">☑</span>' : '<span style="color:#cbd5e1; font-size:14px;">☐</span>'}
        </td>
        <td style="font-weight:700; color:${t.completed ? '#64748b' : '#0f172a'};">
          ${escapeHtml(t.title)}
          ${t.topic ? `<div style="font-size:10px; color:#64748b; font-weight:500;">Topic: ${escapeHtml(t.topic)}</div>` : ''}
        </td>
        <td style="font-size:11px; font-weight:600; color:#334155;">
          ${escapeHtml(t.courseId)}
        </td>
        <td style="font-size:11px; font-weight:600; color:#475569; white-space:nowrap;">
          ${escapeHtml(t.date)}
          ${t.startTime ? `<div style="font-size:10px; color:#64748b;">${escapeHtml(t.startTime)} - ${escapeHtml(t.endTime || '')}</div>` : ''}
        </td>
        <td style="text-align:center; width:90px;">
          <span style="display:inline-block; font-size:9.5px; font-weight:800; text-transform:uppercase; padding:2px 8px; border-radius:4px; ${badgeStyle}">
            ${escapeHtml(t.priority)}
          </span>
        </td>
        <td style="text-align:center; width:70px; font-size:10.5px; font-weight:700; color:${t.completed ? '#16a34a' : '#ea580c'};">
          ${t.completed ? 'Done' : 'Pending'}
        </td>
      </tr>
    `;
  }).join('');

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(docTitle)} - Prajjwal Study Hub</title>
      <style>
        ${BASE_PRINT_STYLES}
        .planner-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 10px;
          margin-bottom: 20px;
          font-size: 11.5px;
        }
        .planner-table th {
          background: #0f172a;
          color: #ffffff;
          font-weight: 700;
          text-transform: uppercase;
          font-size: 10px;
          padding: 8px 10px;
          border: 1px solid #334155;
          text-align: left;
        }
        .planner-table td {
          border: 1px solid #cbd5e1;
          padding: 8px 10px;
          vertical-align: middle;
        }
        .summary-stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
          margin-bottom: 18px;
        }
        .stat-card {
          border: 1px solid #cbd5e1;
          border-radius: 8px;
          padding: 10px 14px;
          background: #ffffff;
        }
        .stat-label {
          font-size: 9.5px;
          font-weight: 700;
          color: #64748b;
          text-transform: uppercase;
          display: block;
          margin-bottom: 2px;
        }
        .stat-val {
          font-size: 18px;
          font-weight: 900;
          color: #0f172a;
        }
        .curriculum-checklist-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          margin-top: 12px;
          break-inside: avoid;
          page-break-inside: avoid;
        }
        .curr-card {
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 10px 12px;
          background: #f8fafc;
        }
      </style>
    </head>
    <body>
      <div class="print-container">
        ${coverHtml}

        <!-- Summary Metric Blocks -->
        <div class="summary-stats-grid">
          <div class="stat-card">
            <span class="stat-label">Total Scheduled</span>
            <span class="stat-val">${tasks.length} Tasks</span>
          </div>
          <div class="stat-card">
            <span class="stat-label">Completed Tasks</span>
            <span class="stat-val" style="color:#16a34a;">${completedCount} Tasks</span>
          </div>
          <div class="stat-card">
            <span class="stat-label">High Priority</span>
            <span class="stat-val" style="color:#dc2626;">${highPriorityCount} Tasks</span>
          </div>
          <div class="stat-card">
            <span class="stat-label">Completion Rate</span>
            <span class="stat-val" style="color:#4f46e5;">${progressPct}%</span>
          </div>
        </div>

        <!-- Task Schedule Table -->
        <div class="section-title">
          <span>Scheduled Study Tasks & Revision Routine</span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">Priority Filtered</span>
        </div>

        <table class="planner-table">
          <thead>
            <tr>
              <th style="text-align:center;">Check</th>
              <th>Task Description & Topic</th>
              <th>Subject / Code</th>
              <th>Scheduled Time</th>
              <th style="text-align:center;">Priority</th>
              <th style="text-align:center;">Status</th>
            </tr>
          </thead>
          <tbody>
            ${tasksRows || '<tr><td colspan="6" style="text-align:center; padding:20px; color:#64748b;">No scheduled tasks recorded.</td></tr>'}
          </tbody>
        </table>

        <!-- Weekly Syllabus Check Matrix -->
        <div class="section-title" style="margin-top:20px;">
          <span>Core Subject Weekly Syllabus Checklist</span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">Weeks 1 - 6 Scope</span>
        </div>
        <div class="curriculum-checklist-grid">
          <div class="curr-card">
            <div style="font-weight:800; font-size:12px; color:#0f172a; margin-bottom:6px;">Mathematics for Data Science 1 (MA1001)</div>
            <div style="font-size:10.5px; color:#475569; display:grid; grid-template-columns:1fr 1fr; gap:4px;">
              <div>☐ W1: Coordinate Geometry</div>
              <div>☐ W2: Linear Equations</div>
              <div>☐ W3: Functions & Graphs</div>
              <div>☐ W4: Quadratic Functions</div>
              <div>☐ W5: Polynomials & Roots</div>
              <div>☐ W6: Limits & Continuity</div>
            </div>
          </div>
          <div class="curr-card">
            <div style="font-weight:800; font-size:12px; color:#0f172a; margin-bottom:6px;">Statistics for Data Science 1 (ST1001)</div>
            <div style="font-size:10.5px; color:#475569; display:grid; grid-template-columns:1fr 1fr; gap:4px;">
              <div>☐ W1: Data Types & Scales</div>
              <div>☐ W2: Central Tendency</div>
              <div>☐ W3: Dispersion & Variance</div>
              <div>☐ W4: Probability Axioms</div>
              <div>☐ W5: Conditional Probability</div>
              <div>☐ W6: Bayes Theorem</div>
            </div>
          </div>
          <div class="curr-card">
            <div style="font-weight:800; font-size:12px; color:#0f172a; margin-bottom:6px;">Computational Thinking (CS1001)</div>
            <div style="font-size:10.5px; color:#475569; display:grid; grid-template-columns:1fr 1fr; gap:4px;">
              <div>☐ W1: Logic & Flowcharts</div>
              <div>☐ W2: Iteration & Loops</div>
              <div>☐ W3: List Filtering</div>
              <div>☐ W4: Multi-criteria Sorting</div>
              <div>☐ W5: Aggregation Logic</div>
              <div>☐ W6: Nested Flow Analysis</div>
            </div>
          </div>
          <div class="curr-card">
            <div style="font-weight:800; font-size:12px; color:#0f172a; margin-bottom:6px;">Programming in Python (CS1002)</div>
            <div style="font-size:10.5px; color:#475569; display:grid; grid-template-columns:1fr 1fr; gap:4px;">
              <div>☐ W1: Types & Arithmetic</div>
              <div>☐ W2: Control Conditionals</div>
              <div>☐ W3: Loops & Ranges</div>
              <div>☐ W4: Functions & Scope</div>
              <div>☐ W5: Lists, Tuples & Dicts</div>
              <div>☐ W6: File I/O & Recursion</div>
            </div>
          </div>
        </div>

        <!-- Productivity Guidelines -->
        <div class="takeaways-box" style="margin-top:20px; break-inside:avoid;">
          <div class="takeaways-title">Recommended Exam Preparation Best Practices</div>
          <ul class="takeaways-list" style="font-size:10.5px;">
            <li><strong>Active Problem Solving:</strong> Spend 70% of study intervals writing out equations and solving mock PYQs.</li>
            <li><strong>Formula Recall Check:</strong> Verify variables and domain constraints before checking official solution keys.</li>
            <li><strong>Spaced Revision:</strong> Revisit Week 1-3 foundational concepts at least once every 10 days before term exams.</li>
          </ul>
        </div>

        <!-- Footer -->
        <div class="footer-disclaimer">
          <strong>Prajjwal Study Hub</strong> — Independent Open-Access Learning & Assessment Platform.<br>
          Personal Study Plan Document • Generated for student self-discipline and academic tracking.
        </div>
      </div>
    </body>
    </html>
  `;

  triggerPrintDocument(docTitle, html);
}

/**
 * 7. Download / Print Subject Compendium (Notes + Formulas Combined)
 */
export function downloadSubjectCompendiumPdf(
  subjectTitle: string,
  level: string = 'Foundation',
  candidateName: string = 'Candidate'
): void {
  // Pull notes and formulas matching the subject
  const matchingNotes = CURATED_WEEKLY_NOTES.filter(n => 
    n.courseTitle.toLowerCase().includes(subjectTitle.toLowerCase()) || 
    subjectTitle.toLowerCase().includes(n.courseTitle.toLowerCase())
  );
  const notesToUse = matchingNotes.length > 0 ? matchingNotes : CURATED_WEEKLY_NOTES.slice(0, 4);

  const matchingFormulas = RICH_FORMULA_SHEETS.filter(f => 
    f.courseTitle.toLowerCase().includes(subjectTitle.toLowerCase()) ||
    subjectTitle.toLowerCase().includes(f.courseTitle.toLowerCase())
  );
  const formulasToUse = matchingFormulas.length > 0 ? matchingFormulas : RICH_FORMULA_SHEETS.slice(0, 6);

  const resolvedName = matchingNotes[0]?.courseTitle || subjectTitle;
  const docTitle = `${resolvedName} — Weekly Summary Compendium & Formula Compendium`;
  const docSub = `Comprehensive Weekly Notes, LaTeX Derivations & High-Yield Formula Cheat Sheet`;

  const coverHtml = renderBrandedCoverPage(
    docTitle,
    docSub,
    'COMPREHENSIVE COMPENDIUM',
    'notes',
    level,
    'Full Course Repository',
    candidateName,
    [
      { label: 'Weekly Chapters', value: `${notesToUse.length} Modules` },
      { label: 'Formula Cards', value: `${formulasToUse.length} Equations` },
      { label: 'Curriculum Level', value: level },
      { label: 'Verification', value: 'Complete Exam Compendium' }
    ]
  );

  const chaptersHtml = notesToUse.map((note, idx) => `
    <div class="chapter-note-card" id="comp-note-${note.weekNumber}">
      <div class="chapter-header">
        <div>
          <span class="week-badge">Week ${note.weekNumber}</span>
          <span style="font-size:12px; font-weight:700; color:#475569; margin-left:6px;">${escapeHtml(note.courseCode)}</span>
        </div>
        <div style="font-size:10.5px; color:#64748b; font-weight:600;">
          Chapter ${idx + 1} of ${notesToUse.length}
        </div>
      </div>

      <h3 class="chapter-title">${escapeHtml(note.title)}</h3>

      <div class="takeaways-box">
        <div class="takeaways-title">Core Mathematical & Analytical Principles</div>
        <ul class="takeaways-list">
          ${note.keyTakeaways.map(t => `<li>${escapeHtml(t)}</li>`).join('')}
        </ul>
      </div>

      ${(note.definitions && note.definitions.length > 0) ? `
        <div style="margin-top:10px;">
          <div class="definitions-grid">
            ${note.definitions.map(d => `
              <div class="def-card">
                <div class="def-term">${escapeHtml(d.term)}</div>
                <div class="def-expl">${escapeHtml(d.explanation)}</div>
                ${d.formula ? `<div class="def-formula">${escapeHtml(d.formula)}</div>` : ''}
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      ${(note.examTips && note.examTips.length > 0) ? `
        <div class="exam-tips-box">
          <div class="exam-tips-title">Exam Insights & Common Traps</div>
          <ul class="exam-tips-list">
            ${note.examTips.map(e => `<li>${escapeHtml(e)}</li>`).join('')}
          </ul>
        </div>
      ` : ''}
    </div>
  `).join('');

  const formulasHtml = formulasToUse.map((f, idx) => `
    <div class="formula-print-card" id="comp-form-${idx + 1}">
      <div class="formula-header">
        <div>
          <span style="font-size:11px; font-weight:800; color:#475569; margin-right:6px;">#${idx + 1}</span>
          <span class="formula-title">${escapeHtml(f.title)}</span>
        </div>
        <div class="formula-cat-tag">${escapeHtml(f.category)}</div>
      </div>

      <div class="equation-display-box">
        ${escapeHtml(f.latex || f.formula)}
      </div>

      <div class="formula-explanation">
        ${escapeHtml(f.explanation)}
      </div>

      ${(f.variables && f.variables.length > 0) ? `
        <table class="variables-table">
          <tbody>
            ${f.variables.map(v => `
              <tr>
                <td class="var-sym">${escapeHtml(v.symbol)}</td>
                <td><strong>${escapeHtml(v.name)}</strong>: ${escapeHtml(v.description)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      ` : ''}
    </div>
  `).join('');

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(docTitle)} - Prajjwal Study Hub</title>
      <style>${BASE_PRINT_STYLES}</style>
    </head>
    <body>
      <div class="print-container">
        ${coverHtml}

        <!-- Part 1: Weekly Summaries -->
        <div class="section-title">
          <span>Part 1: Weekly Theory & Derivation Summaries</span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${notesToUse.length} Modules</span>
        </div>
        ${chaptersHtml}

        <!-- Part 2: Formula Sheet Compendium -->
        <div class="section-title" style="margin-top:28px;">
          <span>Part 2: High-Yield Mathematical & Statistical Formula Compendium</span>
          <span style="font-size:11px; color:#64748b; font-weight:600;">${formulasToUse.length} Key Formulas</span>
        </div>
        <div style="display:grid; grid-template-columns:1fr; gap:8px;">
          ${formulasHtml}
        </div>

        <!-- Footer -->
        <div class="footer-disclaimer">
          <strong>Prajjwal Study Hub</strong> — Comprehensive Academic Compendium.<br>
          Disclaimer: This study material is curated for student learning and is not officially affiliated with or endorsed by IIT Madras.
        </div>
      </div>
    </body>
    </html>
  `;

  triggerPrintDocument(docTitle, html);
}


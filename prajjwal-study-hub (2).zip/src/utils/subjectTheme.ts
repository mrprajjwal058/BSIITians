import React from 'react';
import { 
  Calculator, 
  Sigma, 
  BarChart2, 
  BarChart3, 
  Code2, 
  FileCode, 
  BookOpen, 
  Languages, 
  Cpu, 
  Database, 
  BrainCircuit, 
  Sparkles,
  Layers
} from 'lucide-react';

export interface SubjectThemeConfig {
  accentColor: 'emerald' | 'amber' | 'sky' | 'rose' | 'indigo' | 'purple';
  cardBorder: string;
  cardHoverBorder: string;
  badgeClass: string;
  bgLight: string;
  textClass: string;
  iconBg: string;
  glowClass: string;
  tags: string[];
  shortDesc: string;
  categoryLabel: string;
}

export function getSubjectTheme(identifier: string = '', category: string = ''): SubjectThemeConfig {
  const norm = (identifier + ' ' + category).toLowerCase();

  // 1. Mathematics: Emerald / Green accent
  if (norm.includes('math') || norm.includes('ma1001') || norm.includes('ma1002') || norm.includes('calculus') || norm.includes('algebra')) {
    const isMath2 = norm.includes('2') || norm.includes('ma1002');
    return {
      accentColor: 'emerald',
      cardBorder: 'border-emerald-500/20',
      cardHoverBorder: 'hover:border-emerald-500/50',
      badgeClass: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
      bgLight: 'bg-emerald-500/10',
      textClass: 'text-emerald-400',
      iconBg: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30',
      glowClass: 'shadow-emerald-500/10 hover:shadow-emerald-500/20',
      tags: isMath2 ? ['Multivariable', 'Vectors', 'W1–12'] : ['Calculus', 'Linear Algebra', 'W1–12'],
      shortDesc: isMath2 ? 'Optimization & Vector Calculus' : 'Coordinate Geometry & Linear Systems',
      categoryLabel: 'Mathematics'
    };
  }

  // 2. Statistics: Amber / Orange accent
  if (norm.includes('stat') || norm.includes('st1001') || norm.includes('st1002') || norm.includes('probability') || norm.includes('inference') || norm.includes('analytics')) {
    const isStat2 = norm.includes('2') || norm.includes('st1002');
    return {
      accentColor: 'amber',
      cardBorder: 'border-amber-500/20',
      cardHoverBorder: 'hover:border-amber-500/50',
      badgeClass: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
      bgLight: 'bg-amber-500/10',
      textClass: 'text-amber-400',
      iconBg: 'bg-amber-500/20 text-amber-400 border border-amber-500/30',
      glowClass: 'shadow-amber-500/10 hover:shadow-amber-500/20',
      tags: isStat2 ? ['Hypothesis Testing', 'ANOVA', 'W1–12'] : ['Probability', 'Bayes Theorem', 'W1–12'],
      shortDesc: isStat2 ? 'Sampling & Inferential Statistics' : 'Probability Spaces & Random Variables',
      categoryLabel: 'Statistics'
    };
  }

  // 3. English / Professional Communication: Rose / Pink accent
  if (norm.includes('english') || norm.includes('hs1001') || norm.includes('hs1002') || norm.includes('communication') || norm.includes('soft skills')) {
    const isEng2 = norm.includes('2') || norm.includes('hs1002');
    return {
      accentColor: 'rose',
      cardBorder: 'border-rose-500/20',
      cardHoverBorder: 'hover:border-rose-500/50',
      badgeClass: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
      bgLight: 'bg-rose-500/10',
      textClass: 'text-rose-400',
      iconBg: 'bg-rose-500/20 text-rose-400 border border-rose-500/30',
      glowClass: 'shadow-rose-500/10 hover:shadow-rose-500/20',
      tags: isEng2 ? ['Professional Writing', 'Reports', 'W1–12'] : ['Grammar', 'Phonetics', 'W1–12'],
      shortDesc: isEng2 ? 'Academic & Technical Communication' : 'Grammar Rules & Reading Comprehension',
      categoryLabel: 'English'
    };
  }

  // 4. Python, CT, Programming, Data Science & Tech: Sky Blue / Cyan accent
  if (norm.includes('python') || norm.includes('cs1002') || norm.includes('ct') || norm.includes('computational') || norm.includes('cs1001') || norm.includes('java') || norm.includes('dbms') || norm.includes('pdsa') || norm.includes('app dev') || norm.includes('ml') || norm.includes('data science') || norm.includes('programming')) {
    const isPy = norm.includes('python') || norm.includes('cs1002');
    const isCT = norm.includes('computational') || norm.includes('cs1001');
    const isJava = norm.includes('java');
    const isDbms = norm.includes('dbms');

    let tags = ['Algorithms', 'Data Structures', 'W1–12'];
    if (isPy) tags = ['Python', 'OPPE Drills', 'W1–12'];
    if (isCT) tags = ['Pseudocode', 'Flowcharts', 'W1–12'];
    if (isJava) tags = ['Java OOP', 'Interfaces', 'W1–12'];
    if (isDbms) tags = ['SQL Queries', 'Relational Model', 'W1–12'];

    return {
      accentColor: 'sky',
      cardBorder: 'border-sky-500/20',
      cardHoverBorder: 'hover:border-sky-500/50',
      badgeClass: 'bg-sky-500/15 text-sky-400 border-sky-500/30',
      bgLight: 'bg-sky-500/10',
      textClass: 'text-sky-400',
      iconBg: 'bg-sky-500/20 text-sky-400 border border-sky-500/30',
      glowClass: 'shadow-sky-500/10 hover:shadow-sky-500/20',
      tags,
      shortDesc: isPy ? 'Syntax, Functions & OPPE Drills' : isCT ? 'Logic Flowcharts & Pseudocode Traces' : 'Algorithms, Architecture & Code',
      categoryLabel: 'Programming'
    };
  }

  // Default: Indigo / Purple
  return {
    accentColor: 'indigo',
    cardBorder: 'border-indigo-500/20',
    cardHoverBorder: 'hover:border-indigo-500/50',
    badgeClass: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30',
    bgLight: 'bg-indigo-500/10',
    textClass: 'text-indigo-400',
    iconBg: 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30',
    glowClass: 'shadow-indigo-500/10 hover:shadow-indigo-500/20',
    tags: ['Core Modules', 'Notes', 'W1–12'],
    shortDesc: 'Curated Lecture Notes & Practice',
    categoryLabel: 'Core Curriculum'
  };
}

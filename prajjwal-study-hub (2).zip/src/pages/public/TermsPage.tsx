import React from 'react';
import { ShieldAlert, BookCheck, Scale, CheckCircle2 } from 'lucide-react';

export const TermsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8 bg-white dark:bg-slate-900 p-8 sm:p-12 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        
        <div className="border-b border-slate-100 dark:border-slate-800 pb-6 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            <Scale className="w-4 h-4" />
            <span>Platform Agreement & Guidelines</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
            Terms of Service
          </h1>
          <p className="text-xs text-slate-500">
            Effective Date: August 2026 • Prajjwal Study Hub
          </p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" />
              <span>1. Complete Non-Affiliation Clause</span>
            </h2>
            <p>
              Prajjwal Study Hub is an independent student platform. By using this platform, you acknowledge and agree that:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Prajjwal Study Hub is NOT affiliated with, endorsed by, sponsored by, or officially associated with IIT Madras.</li>
              <li>This platform does NOT host official exam questions or confidential institutional data.</li>
              <li>Materials are student-compiled supplementary aids intended for study revision.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BookCheck className="w-4 h-4 text-indigo-600" />
              <span>2. Academic Use & Fair Conduct</span>
            </h2>
            <p>
              Users agree to use materials for honest personal learning, practice, and conceptual revision. Unauthorized redistribution, mass scraping, or commercial resale of platform notes without prior consent is prohibited.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-indigo-600" />
              <span>3. User Accounts & Integrity</span>
            </h2>
            <p>
              Students are responsible for maintaining the confidentiality of their credentials and study plans. Administrator accounts are restricted to verified platform coordinators.
            </p>
          </section>
        </div>

      </div>
    </div>
  );
};

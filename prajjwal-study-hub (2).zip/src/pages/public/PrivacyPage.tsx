import React from 'react';
import { Shield, Lock, Eye, FileText } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8 bg-white dark:bg-slate-900 p-8 sm:p-12 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        
        <div className="border-b border-slate-100 dark:border-slate-800 pb-6 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            <Shield className="w-4 h-4" />
            <span>Data Protection & Privacy</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
            Privacy Policy
          </h1>
          <p className="text-xs text-slate-500">
            Last Updated: August 2026 • Prajjwal Study Hub
          </p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-indigo-600" />
              <span>1. Information We Collect</span>
            </h2>
            <p>
              Prajjwal Study Hub collects minimal necessary data to deliver educational resources:
            </p>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Account Information:</strong> Name and email address when you register.</li>
              <li><strong>Study Data:</strong> Your custom study planner schedules, saved notes bookmarks, and test attempt progress.</li>
              <li><strong>Inquiry Submissions:</strong> Information submitted via the contact feedback form.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Eye className="w-4 h-4 text-indigo-600" />
              <span>2. How We Use Information</span>
            </h2>
            <p>
              Collected data is used strictly to authenticate user sessions, persist your personal study planner tasks and bookmarks, and improve academic resources. We never sell or transfer personal data to third parties.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>3. Independent Educational Nature</span>
            </h2>
            <p>
              Prajjwal Study Hub operates independently and is not affiliated with IIT Madras. No official university student records are accessed or shared through this website.
            </p>
          </section>
        </div>

      </div>
    </div>
  );
};

import React from 'react';
import { 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  BarChart2, 
  Calendar, 
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';

interface FeaturesPageProps {
  navigate: (path: string) => void;
}

export const FeaturesPage: React.FC<FeaturesPageProps> = ({ navigate }) => {
  const featureList = [
    {
      title: 'Revision Notes Repository',
      phase: 'Phase 1 • Live',
      phaseBadge: 'success',
      icon: FileText,
      description: 'Handcrafted conceptual summaries organized per module with embedded LaTeX formulas, downloadable PDFs, bookmarking, and search filtering.',
      highlights: ['LaTeX Math Rendering', 'Direct PDF Download Access', 'One-Click Topic Filtering', 'Private Note Bookmarks'],
      action: '/notes',
      btnText: 'Explore Notes'
    },
    {
      title: 'Formula Sheets & Cheat Cards',
      phase: 'Phase 1 • Live',
      phaseBadge: 'success',
      icon: Calculator,
      description: 'Rapid-revision formula compendiums designed for quick pre-exam refreshers. Each formula card includes notation definitions and critical application rules.',
      highlights: ['Notation & Variable Meanings', 'LaTeX Equations', 'Rapid Revision Mode', 'Topic-Wise Tagging'],
      action: '/formulas',
      btnText: 'View Formula Sheets'
    },
    {
      title: 'Study Planner & Task Scheduler',
      phase: 'Phase 1 • Live',
      phaseBadge: 'success',
      icon: Calendar,
      description: 'Personalized study schedule tracker. Create daily tasks, assign courses, tag priorities, log timestamps, and maintain consistent daily study streaks.',
      highlights: ['Interactive Task Checkboxes', 'Course & Priority Categorization', 'Daily Target Monitoring', 'Persistent Task Storage'],
      action: '/study-planner',
      btnText: 'Launch Study Planner'
    },
    {
      title: 'Practice Question Bank',
      phase: 'Phase 1 Architecture • Phase 2 Engine',
      phaseBadge: 'info',
      icon: CheckSquare,
      description: 'Categorized practice repository mapped to course concepts and difficulty tiers. Review step-by-step mathematical derivations and code traces.',
      highlights: ['Topic-Wise Practice Sets', 'Detailed Answer Derivations', 'Difficulty Calibration', 'Advanced Engine in Phase 2'],
      action: '/practice',
      btnText: 'Open Practice Hub'
    },
    {
      title: 'Timed CBT Mock Tests',
      phase: 'Phase 1 Blueprint • Phase 3 CBT Engine',
      phaseBadge: 'warning',
      icon: Clock,
      description: 'Mock test blueprints structured according to Quiz 1, Quiz 2, and End-Term patterns. Practice under exam-standard time constraints.',
      highlights: ['Syllabus Aligned Blueprints', 'Duration & Weightage Calibration', 'Comprehensive Test Instructions', 'Interactive CBT in Phase 3'],
      action: '/mock-tests',
      btnText: 'View Mock Blueprints'
    },
    {
      title: 'Performance & Accuracy Analytics',
      phase: 'Phase 1 Data Foundation • Phase 4 Engine',
      phaseBadge: 'secondary',
      icon: BarChart2,
      description: 'Deep performance analytics visualizing accuracy metrics, time allocation per question, and strengths across syllabus domains.',
      highlights: ['Real Data Only (No Fake Scores)', 'Subject-Wise Accuracy', 'Historical Readiness Indicators', 'Full Visualizer in Phase 4'],
      action: '/performance',
      btnText: 'Check Performance'
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Platform Capabilities & Phased Roadmap</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Built for Focused Academic Progress
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Every feature on Prajjwal Study Hub is intentionally designed to solve specific study bottlenecks without unnecessary clutter.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featureList.map((f, idx) => {
            const Icon = f.icon;
            return (
              <div
                key={idx}
                id={`feature-block-${idx}`}
                className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <Badge variant={f.phaseBadge as any} size="sm">
                      {f.phase}
                    </Badge>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-2">
                    {f.title}
                  </h3>

                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                    {f.description}
                  </p>

                  <div className="space-y-1.5 py-3 border-t border-slate-100 dark:border-slate-800 mb-4">
                    {f.highlights.map((h, hIdx) => (
                      <div key={hIdx} className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  id={`feature-action-${idx}`}
                  variant="outline"
                  size="sm"
                  className="w-full justify-between"
                  onClick={() => navigate(f.action)}
                  icon={<ArrowRight className="w-3.5 h-3.5 ml-auto" />}
                >
                  {f.btnText}
                </Button>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};

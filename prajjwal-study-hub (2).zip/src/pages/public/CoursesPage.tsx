import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  BookOpen, 
  Search, 
  Layers, 
  FileText, 
  Calculator, 
  CheckSquare, 
  ArrowRight,
  Filter,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Badge } from '../../components/common/Badge';
import { Button } from '../../components/common/Button';
import { EmptyState } from '../../components/common/EmptyState';
import { getSubjectTheme } from '../../utils/subjectTheme';

interface CoursesPageProps {
  navigate: (path: string) => void;
}

export const CoursesPage: React.FC<CoursesPageProps> = ({ navigate }) => {
  const { programs, courses, modules, notes, formulas } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedProgram, setSelectedProgram] = useState<string>('All');

  const categories = ['All', 'Mathematics', 'Statistics', 'Programming', 'Core CS', 'Data Science', 'English'];

  const filteredCourses = courses.filter(c => {
    if (!c.published) return false;
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          c.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          c.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || c.category === selectedCategory;
    const matchesProgram = selectedProgram === 'All' || c.programId === selectedProgram;
    return matchesSearch && matchesCategory && matchesProgram;
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0A0C10] text-slate-900 dark:text-slate-100 py-12 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="space-y-3 max-w-3xl">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-500/20">
              IIT Madras BS Degree Curriculum
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Academic Courses &amp; Preparation Tracks
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
            Curated materials for Foundation, Diploma, and Degree tracks. Every subject features Week 1–12 notes, LaTeX formula compendiums, and CBT practice question sets.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="courses-search-input"
              type="text"
              placeholder="Search course name or code (e.g. MA1001)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder:text-slate-400"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {/* Program Level Filter */}
            <select
              id="courses-program-filter"
              value={selectedProgram}
              onChange={(e) => setSelectedProgram(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#161920] text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="All">All Programs</option>
              {programs.map(p => (
                <option key={p.id} value={p.id}>{p.title}</option>
              ))}
            </select>

            {/* Category Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  id={`course-cat-${cat.toLowerCase().replace(' ', '-')}`}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Courses Grid with DISTINCT COLOR ACCENTS */}
        {filteredCourses.length === 0 ? (
          <EmptyState
            id="empty-courses"
            icon={BookOpen}
            title="No courses found"
            description="Try adjusting your search query or filter criteria."
            actionText="Reset Filters"
            onAction={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setSelectedProgram('All');
            }}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map((course) => {
              const courseModules = modules.filter(m => m.courseId === course.id);
              const courseNotes = notes.filter(n => n.courseId === course.id);
              const courseFormulas = formulas.filter(f => f.courseId === course.id);
              const theme = getSubjectTheme(course.title, course.category);

              return (
                <div
                  key={course.id}
                  id={`course-card-${course.code.toLowerCase()}`}
                  className={`p-6 rounded-2xl bg-white dark:bg-[#111318] border ${theme.cardBorder} ${theme.cardHoverBorder} hover:shadow-lg transition-all flex flex-col justify-between group`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`text-xs font-mono font-bold ${theme.textClass}`}>
                        {course.code}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400">
                          {course.term || 'Term 1'}
                        </span>
                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${theme.badgeClass}`}>
                          {theme.categoryLabel}
                        </span>
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-400 transition-colors leading-snug line-clamp-1">
                      {course.title}
                    </h3>

                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {theme.shortDesc}
                    </p>

                    {/* Punchy Keyword Badges */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {theme.tags.map(tag => (
                        <span key={tag} className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${theme.badgeClass}`}>
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Module Counts */}
                    <div className="grid grid-cols-3 gap-2 py-2.5 border-y border-slate-100 dark:border-white/5 text-center">
                      <div className="p-1 rounded-lg bg-slate-50 dark:bg-white/5">
                        <span className="block text-xs font-bold text-slate-900 dark:text-white">
                          {courseModules.length > 0 ? courseModules.length : 12}
                        </span>
                        <span className="text-[9px] text-slate-400">Weeks</span>
                      </div>
                      <div className="p-1 rounded-lg bg-slate-50 dark:bg-white/5">
                        <span className="block text-xs font-bold text-slate-900 dark:text-white">
                          {courseNotes.length > 0 ? courseNotes.length : 12}
                        </span>
                        <span className="text-[9px] text-slate-400">Notes</span>
                      </div>
                      <div className="p-1 rounded-lg bg-slate-50 dark:bg-white/5">
                        <span className="block text-xs font-bold text-slate-900 dark:text-white">
                          {courseFormulas.length > 0 ? courseFormulas.length : 8}
                        </span>
                        <span className="text-[9px] text-slate-400">Formulas</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2 pt-4 mt-2">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        id={`btn-notes-${course.code}`}
                        onClick={() => navigate('/notes')}
                        className="py-2 px-3 rounded-xl bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-white/10 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                      >
                        <FileText className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Notes</span>
                      </button>
                      <button
                        id={`btn-formulas-${course.code}`}
                        onClick={() => navigate('/formulas')}
                        className="py-2 px-3 rounded-xl bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-white/10 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                      >
                        <Calculator className="w-3.5 h-3.5 text-amber-400" />
                        <span>Formulas</span>
                      </button>
                    </div>

                    <button
                      id={`btn-practice-${course.code}`}
                      onClick={() => navigate('/practice')}
                      className={`w-full py-2 rounded-xl ${theme.bgLight} ${theme.textClass} border ${theme.cardBorder} hover:${theme.cardHoverBorder} text-xs font-bold flex items-center justify-center gap-1.5 transition-all`}
                    >
                      <CheckSquare className="w-3.5 h-3.5" />
                      <span>Practice PYQs</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};

import React from 'react';
import { 
  GraduationCap, 
  ShieldAlert, 
  Target, 
  HeartHandshake, 
  BookOpen, 
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { Button } from '../../components/common/Button';

interface AboutPageProps {
  navigate: (path: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ navigate }) => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            About Prajjwal Study Hub
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            A centralized learning, practice, and revision platform built by students for students undertaking academic preparation.
          </p>
        </div>

        {/* Primary Legal Disclaimer Box */}
        <div className="p-6 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border-2 border-amber-300 dark:border-amber-900 text-amber-900 dark:text-amber-200 space-y-3">
          <div className="flex items-center gap-2.5 font-bold text-sm text-amber-800 dark:text-amber-300">
            <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <span>CRITICAL LEGAL & NON-AFFILIATION NOTICE</span>
          </div>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/90 dark:text-amber-200/90">
            <strong>Prajjwal Study Hub</strong> is an independent educational platform created by student peers. 
            It is <strong>NOT affiliated with, endorsed by, sponsored by, or officially associated with the Indian Institute of Technology Madras (IIT Madras)</strong>, nor any of its official degree bodies, portals, or departments.
          </p>
          <p className="text-xs sm:text-sm leading-relaxed text-amber-900/80 dark:text-amber-300/80">
            All course categories, study notes, formula compilations, and practice mock tests provided on this platform are independent supplementary study materials assembled for study revision purposes.
          </p>
        </div>

        {/* Mission & Purpose */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Target className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Our Mission</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              To eliminate academic friction by structuring complex mathematical, statistical, and programming coursework into clean, bite-sized revision notes, formula cheat sheets, and disciplined study planners.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Built by Students</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              We understand the unique challenges of self-paced learning alongside jobs and college. Every tool on Prajjwal Study Hub is engineered to support efficient, focused study routines.
            </p>
          </div>
        </div>

        {/* Guiding Principles */}
        <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-6">
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Our Core Principles
          </h2>
          <div className="space-y-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 dark:text-slate-100 block mb-0.5">Integrity & Zero Fake Data:</strong>
                <span>We never fabricate user metrics, mock scores, or create artificial placeholders. Every interactive tool performs real logic or is honestly marked "Coming Soon".</span>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 dark:text-slate-100 block mb-0.5">Academic Rigor:</strong>
                <span>Summaries preserve full mathematical precision, standard LaTeX notation, and step-by-step proofs.</span>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 dark:text-slate-100 block mb-0.5">Modular Phased Expansion:</strong>
                <span>Phase 1 focuses on rock-solid foundations: Notes, Formulas, Course Structures, Planner, and Role-Based Admin. Advanced Quiz/CBT engines follow in upcoming roadmap phases.</span>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="p-6 rounded-2xl bg-indigo-600 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold">Ready to start studying?</h3>
            <p className="text-xs text-indigo-100 mt-1">Explore all courses and download revision sheets.</p>
          </div>
          <Button
            id="about-explore-btn"
            variant="secondary"
            onClick={() => navigate('/courses')}
            icon={<ArrowRight className="w-4 h-4" />}
          >
            Explore Courses
          </Button>
        </div>

      </div>
    </div>
  );
};

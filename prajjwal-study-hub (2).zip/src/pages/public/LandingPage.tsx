import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  BarChart2, 
  Calendar, 
  ArrowRight, 
  Sparkles, 
  BookOpen, 
  Award, 
  TrendingUp, 
  CheckCircle,
  Search,
  Zap,
  Bookmark,
  Download,
  CheckCircle2,
  Circle,
  Filter,
  Layers,
  Sigma,
  Code2,
  Cpu,
  Languages,
  Play
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { CURATED_WEEKLY_NOTES } from '../../data/curatedNotesData';
import { RICH_FORMULA_SHEETS } from '../../data/formulasData';
import { 
  downloadCuratedNotesPdf, 
  downloadFormulaSheetPdf, 
  downloadStudyPlannerPdf,
  downloadSubjectCompendiumPdf 
} from '../../utils/pdfExport';
import { StudyPlanTask } from '../../types';
import { BlockMath, InlineMath } from '../../components/common/MathRenderer';
import { getSubjectTheme } from '../../utils/subjectTheme';

interface LandingPageProps {
  navigate: (path: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ navigate }) => {
  const { user, loginAsDemoStudent } = useAuth();

  // Subject selector state for Revision Notes & Formulas
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('math1');
  const [previewTab, setPreviewTab] = useState<'formula' | 'notes'>('formula');

  // Interactive Task Manager State for Planner Preview
  const [plannerPriorityFilter, setPlannerPriorityFilter] = useState<'All' | 'high' | 'medium'>('All');
  const [plannerStatusFilter, setPlannerStatusFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [landingTasks, setLandingTasks] = useState<StudyPlanTask[]>([
    {
      id: 'task-1',
      courseId: 'MA1001 (Math 1)',
      title: 'Coordinate Geometry & Straight Line PYQs',
      topic: 'Week 1-2 Distance & Perpendicularity',
      date: '2026-08-23',
      startTime: '18:00',
      endTime: '19:30',
      priority: 'high',
      completed: false,
    },
    {
      id: 'task-2',
      courseId: 'ST1001 (Stats 1)',
      title: 'Conditional Probability & Bayes Theorem',
      topic: 'Week 5-6 Probability Axioms',
      date: '2026-08-24',
      startTime: '10:00',
      endTime: '11:30',
      priority: 'high',
      completed: true,
    },
    {
      id: 'task-3',
      courseId: 'CS1002 (Python)',
      title: 'List Comprehensions & Dict Comprehensions',
      topic: 'Week 4 Data Structures & Functions',
      date: '2026-08-25',
      startTime: '19:00',
      endTime: '20:15',
      priority: 'medium',
      completed: false,
    },
    {
      id: 'task-4',
      courseId: 'CS1001 (CT)',
      title: 'Multi-criteria Sorting & Flowchart Logic',
      topic: 'Week 3-4 Iteration Loops',
      date: '2026-08-26',
      startTime: '20:30',
      endTime: '21:30',
      priority: 'medium',
      completed: false,
    }
  ]);

  const subjectOptions = [
    { id: 'math1', name: 'Mathematics 1', fullName: 'Mathematics for Data Science 1', code: 'MA1001', level: 'Foundation', category: 'Mathematics' },
    { id: 'stat1', name: 'Statistics 1', fullName: 'Statistics for Data Science 1', code: 'ST1001', level: 'Foundation', category: 'Statistics' },
    { id: 'python', name: 'Python Programming', fullName: 'Programming in Python', code: 'CS1002', level: 'Foundation', category: 'Programming' },
    { id: 'ct', name: 'Computational Thinking', fullName: 'Computational Thinking', code: 'CS1001', level: 'Foundation', category: 'Programming' },
  ];

  const currentSubject = subjectOptions.find(s => s.id === selectedSubjectId) || subjectOptions[0];
  const currentTheme = getSubjectTheme(currentSubject.name, currentSubject.category);

  const handleDownloadSummaryPdf = () => {
    const matchingNotes = CURATED_WEEKLY_NOTES.filter(n => 
      n.courseTitle.toLowerCase().includes(currentSubject.name.toLowerCase()) ||
      n.courseTitle.toLowerCase().includes(currentSubject.fullName.toLowerCase()) ||
      n.courseCode === currentSubject.code
    );
    const notesToExport = matchingNotes.length > 0 ? matchingNotes : CURATED_WEEKLY_NOTES.slice(0, 4);

    downloadCuratedNotesPdf(
      notesToExport,
      `${currentSubject.fullName} — Weekly Summary Compendium`,
      currentSubject.level,
      user?.name || 'Student Candidate'
    );
  };

  const handleDownloadFormulaCheatSheet = () => {
    const matchingFormulas = RICH_FORMULA_SHEETS.filter(f => 
      f.courseTitle.toLowerCase().includes(currentSubject.name.toLowerCase()) ||
      f.courseTitle.toLowerCase().includes(currentSubject.fullName.toLowerCase()) ||
      f.courseCode === currentSubject.code
    );
    const formulasToExport = matchingFormulas.length > 0 ? matchingFormulas : RICH_FORMULA_SHEETS.slice(0, 8);

    downloadFormulaSheetPdf(
      formulasToExport,
      `${currentSubject.fullName} — Formula Cheat Sheet`,
      currentSubject.name,
      currentSubject.level,
      user?.name || 'Student Candidate'
    );
  };

  const handleDownloadCombinedCompendium = () => {
    downloadSubjectCompendiumPdf(
      currentSubject.fullName,
      currentSubject.level,
      user?.name || 'Student Candidate'
    );
  };

  const toggleTaskCompleted = (id: string) => {
    setLandingTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const filteredLandingTasks = landingTasks.filter(t => {
    if (plannerPriorityFilter !== 'All' && t.priority !== plannerPriorityFilter) return false;
    if (plannerStatusFilter === 'pending' && t.completed) return false;
    if (plannerStatusFilter === 'completed' && !t.completed) return false;
    return true;
  });

  const handleExportPlannerPdf = () => {
    downloadStudyPlannerPdf(
      landingTasks,
      'Foundation & Diploma Level',
      user?.name || 'Student Candidate',
      'Monthly & Weekly Study Schedule'
    );
  };

  const handleStartLearning = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      navigate('/signup');
    }
  };

  const handleExploreResources = () => {
    navigate('/courses');
  };

  // Distinct Color Subject Pillars
  const subjectPillars = [
    {
      id: 'math-pillar',
      title: 'Mathematics',
      code: 'MA1001 / MA1002',
      theme: getSubjectTheme('math', 'Mathematics'),
      icon: <Sigma className="w-5 h-5" />,
      tags: ['Calculus', 'Linear Algebra', 'Week 1-12'],
      summary: 'Coordinate geometry, functions, limits, vectors & multivariable optimization.',
      action: '/notes'
    },
    {
      id: 'stat-pillar',
      title: 'Statistics',
      code: 'ST1001 / ST1002',
      theme: getSubjectTheme('stat', 'Statistics'),
      icon: <BarChart2 className="w-5 h-5" />,
      tags: ['Probability', 'Bayes Theorem', 'Week 1-12'],
      summary: 'Descriptive stats, random variables, distributions & hypothesis tests.',
      action: '/notes'
    },
    {
      id: 'python-pillar',
      title: 'Python & Programming',
      code: 'CS1001 / CS1002',
      theme: getSubjectTheme('python', 'Programming'),
      icon: <Code2 className="w-5 h-5" />,
      tags: ['Data Structures', 'Functions', 'OPPE Drills'],
      summary: 'Python syntax, algorithms, flowchart logic & graded programming drills.',
      action: '/notes'
    },
    {
      id: 'english-pillar',
      title: 'English & Soft Skills',
      code: 'HS1001 / HS1002',
      theme: getSubjectTheme('english', 'English'),
      icon: <Languages className="w-5 h-5" />,
      tags: ['Grammar', 'Phonetics', 'Reading Comp'],
      summary: 'Tenses, sentence correction, active listening & professional writing.',
      action: '/notes'
    },
  ];

  const features = [
    {
      icon: FileText,
      title: 'Curated Notes',
      description: 'Handwritten summaries, LaTeX proofs, and exam takeaways for Weeks 1–12.',
      tags: ['Theory', 'LaTeX', 'Takeaways'],
      color: 'emerald',
      link: '/notes'
    },
    {
      icon: Calculator,
      title: 'Formula Sheets',
      description: 'Quick-revision formula compendiums for Maths 1 & 2, Stats 1 & 2, and ML.',
      tags: ['Theorems', 'Properties', 'Cheat Sheet'],
      color: 'amber',
      link: '/formulas'
    },
    {
      icon: CheckSquare,
      title: 'PYQ Question Bank',
      description: '2021–2026 Quiz 1, Quiz 2, End-Term and Qualifier questions with solutions.',
      tags: ['MCQ', 'MSQ', 'NAT Formats'],
      color: 'sky',
      link: '/practice'
    },
    {
      icon: Clock,
      title: 'CBT Mock Engine',
      description: 'Timed Computer-Based Test simulator with question palette and calculator.',
      tags: ['TCS iON Style', 'Timer', 'Analytics'],
      color: 'indigo',
      link: '/mock-tests'
    },
    {
      icon: BarChart2,
      title: 'Performance Analytics',
      description: 'Accuracy gauges, time management per question, and topic weak spots.',
      tags: ['Readiness', 'Accuracy', 'Weak Spots'],
      color: 'rose',
      link: '/performance'
    },
    {
      icon: Calendar,
      title: 'Study Planner',
      description: 'Daily revision planner, milestone trackers, and printable PDF schedules.',
      tags: ['Task Matrix', 'Timetable', 'PDF Export'],
      color: 'sky',
      link: '/study-planner'
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0A0C10] text-slate-900 dark:text-slate-100 transition-colors">
      
      {/* 1. HERO SECTION (Decluttered & Spacious) */}
      <section className="relative overflow-hidden pt-16 pb-24 md:pt-24 md:pb-32 border-b border-slate-200/80 dark:border-white/10">
        {/* Subtle Ambient Radial Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-indigo-500/10 dark:bg-indigo-600/15 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            
            {/* Top Keyword Badges */}
            <div className="flex flex-wrap items-center justify-center gap-2">
              <span className="text-[11px] font-bold tracking-wider uppercase px-3 py-1 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-500/20">
                IIT Madras BS Degree Portal
              </span>
              <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                Qualifier &amp; Quiz 1/2 Mocks
              </span>
              <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                2021–2026 PYQs
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-950 dark:text-white leading-[1.12]">
              Academic Notes, PYQs &amp; <br />
              <span className="bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-400 bg-clip-text text-transparent">
                CBT Mock Test Simulator
              </span>
            </h1>

            {/* Punchy Scannable Subtitle */}
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
              Curated Week 1–12 lecture summaries, LaTeX formula sheets, and real Computer-Based Tests designed specifically for IIT Madras BS Degree candidates.
            </p>

            {/* Keyword Pills Summary */}
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-xs">
              {['Week 1-12 Notes', 'Formula Sheets', 'MCQ / MSQ / NAT', 'Timed CBT Exam', 'Printable PDFs'].map((tag) => (
                <span key={tag} className="px-3 py-1 rounded-lg bg-slate-200/70 dark:bg-white/5 text-slate-700 dark:text-slate-300 border border-slate-300/60 dark:border-white/10 font-medium">
                  {tag}
                </span>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
              <Button
                id="hero-start-learning-btn"
                variant="primary"
                size="lg"
                onClick={handleStartLearning}
                icon={<ArrowRight className="w-4 h-4" />}
                className="w-full sm:w-auto text-sm sm:text-base px-7 py-3.5 shadow-xl shadow-indigo-600/25 active:scale-95 transition-all"
              >
                Start Free Preparation
              </Button>
              <Button
                id="hero-explore-resources-btn"
                variant="outline"
                size="lg"
                onClick={handleExploreResources}
                icon={<Search className="w-4 h-4" />}
                className="w-full sm:w-auto text-sm sm:text-base px-7 py-3.5"
              >
                Explore Course Catalog
              </Button>
            </div>

            {/* Fast Demo Access */}
            {!user && (
              <p className="text-xs text-slate-500 pt-1">
                Want to test immediately?{' '}
                <button
                  id="hero-quick-demo-btn"
                  onClick={() => {
                    loginAsDemoStudent();
                    navigate('/dashboard');
                  }}
                  className="text-indigo-600 dark:text-indigo-400 font-semibold underline underline-offset-2 hover:text-indigo-700"
                >
                  Launch Instant Student Demo
                </button>
              </p>
            )}

          </div>
        </div>
      </section>

      {/* 2. SUBJECT PILLARS (Distinct Color Accents & Keywords) */}
      <section className="py-20 md:py-28 bg-white dark:bg-[#0E1015] border-b border-slate-200/80 dark:border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Core Subject Breakdown
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-slate-950 dark:text-white">
              Foundation &amp; Diploma Curriculum
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Select any domain to view structured chapters, formula compendiums, and practice questions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {subjectPillars.map((pillar) => {
              const { theme } = pillar;
              return (
                <div
                  key={pillar.id}
                  id={`pillar-${pillar.id}`}
                  onClick={() => navigate(pillar.action)}
                  className={`p-6 rounded-2xl bg-slate-50 dark:bg-[#111318] border ${theme.cardBorder} ${theme.cardHoverBorder} hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between group`}
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${theme.iconBg} group-hover:scale-105 transition-transform`}>
                        {pillar.icon}
                      </div>
                      <span className="text-[10px] font-mono font-bold text-slate-400">
                        {pillar.code}
                      </span>
                    </div>

                    <div>
                      <h3 className={`text-lg font-bold text-slate-900 dark:text-white group-hover:${theme.textClass} transition-colors`}>
                        {pillar.title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 line-clamp-2">
                        {pillar.summary}
                      </p>
                    </div>

                    {/* Punchy Keyword Badges */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {pillar.tags.map(t => (
                        <span key={t} className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${theme.badgeClass}`}>
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className={`mt-6 pt-3 border-t border-slate-200/60 dark:border-white/5 flex items-center justify-between text-xs font-semibold ${theme.textClass}`}>
                    <span>Explore Notes &amp; PYQs</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* PRIMARY ACTION: CBT MOCK TEST ENGINE HIGHLIGHT (Purple / Indigo Glow) */}
          <div className="relative rounded-3xl overflow-hidden p-8 sm:p-10 bg-gradient-to-r from-indigo-950/80 via-[#121324] to-purple-950/80 border border-indigo-500/30 shadow-2xl shadow-indigo-500/10 group">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-8 relative z-10">
              <div className="space-y-3 max-w-2xl text-center lg:text-left">
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                    Exam Simulator
                  </span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    TCS iON CBT Environment
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                  IIT Madras BS CBT Mock Exam Engine
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Real timed countdown, question status palette, virtual scientific calculator, and automated diagnostic analytics.
                </p>
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 pt-1">
                  {['Qualifier Mocks', 'Quiz 1 & 2 Papers', 'OPPE Programming', 'Scientific Calc', 'Instant Analysis'].map(tag => (
                    <span key={tag} className="text-[10px] font-bold px-2.5 py-0.5 rounded-md bg-white/10 text-slate-200 border border-white/10">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="shrink-0 flex flex-col sm:flex-row items-center gap-3">
                <button
                  id="landing-cbt-launch-btn"
                  onClick={() => navigate('/mock-tests')}
                  className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-bold text-sm flex items-center gap-2 shadow-xl shadow-indigo-600/30 active:scale-95 transition-all"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Launch CBT Exam</span>
                </button>
                <button
                  id="landing-cbt-pyq-btn"
                  onClick={() => navigate('/practice')}
                  className="px-5 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-semibold transition-all"
                >
                  Browse Past Papers (2021–2026)
                </button>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 3. PLATFORM FEATURES (Clean Scannable Cards) */}
      <section className="py-20 md:py-28 bg-slate-50 dark:bg-[#0A0C10] border-b border-slate-200/80 dark:border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              Toolkit Modules
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-slate-950 dark:text-white">
              Everything in One Structured Hub
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Zero clutter. Access verified materials categorized by term, week, and course code.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  id={`feature-card-${idx}`}
                  onClick={() => navigate(item.link)}
                  className="group p-6 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 hover:border-indigo-500/40 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex gap-1">
                        {item.tags.map(t => (
                          <span key={t} className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-400 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-100 dark:border-white/5 flex items-center text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-1 transition-transform">
                    <span>Open Module</span>
                    <ArrowRight className="w-3.5 h-3.5 ml-1" />
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* 4. REPOSITORY & LIVE FORMULA PREVIEW (Distinct Colors + Quick Action) */}
      <section className="py-20 md:py-28 bg-white dark:bg-[#0E1015] border-b border-slate-200/80 dark:border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column (6 cols) */}
            <div className="lg:col-span-6 space-y-6">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  Academic Compendiums
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Verified Formulae
                </span>
              </div>

              <h2 className="text-3xl font-bold tracking-tight text-slate-950 dark:text-white">
                Week-by-Week Notes &amp; Formula Sheets
              </h2>
              
              {/* Bullet Points with Bold Key Terms */}
              <ul className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
                <li className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span><strong>LaTeX Mathematical Rigor:</strong> Variable definitions, derivations, geometric intuitions, and pitfall warnings.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span><strong>Comprehensive Summaries:</strong> Structured chapter breakdowns for Math 1 &amp; 2, Stats 1 &amp; 2, and CT/Python.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span><strong>Print-Ready PDF Exports:</strong> Branded single-click PDF downloads for offline study.</span>
                </li>
              </ul>

              {/* Subject Selector Tabs */}
              <div className="space-y-2 pt-2">
                <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Select Subject Preview:
                </label>
                <div className="flex flex-wrap gap-2">
                  {subjectOptions.map((subj) => {
                    const theme = getSubjectTheme(subj.name, subj.category);
                    const isSelected = selectedSubjectId === subj.id;
                    return (
                      <button
                        key={subj.id}
                        id={`landing-subj-chip-${subj.id}`}
                        onClick={() => setSelectedSubjectId(subj.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                          isSelected
                            ? `${theme.badgeClass} ring-2 ring-indigo-500/30 shadow-xs`
                            : 'bg-slate-100 dark:bg-white/5 border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-400 hover:bg-white/10'
                        }`}
                      >
                        {subj.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <Button 
                  id="landing-browse-notes-btn" 
                  variant="primary" 
                  size="md" 
                  onClick={() => navigate('/notes')}
                >
                  Browse Revision Notes
                </Button>

                <Button 
                  id="landing-download-summary-pdf-btn" 
                  variant="outline" 
                  size="md" 
                  icon={<Download className="w-4 h-4 text-indigo-400" />}
                  onClick={handleDownloadSummaryPdf}
                >
                  Download Summary (PDF)
                </Button>
              </div>
            </div>

            {/* Right Column: Live Interactive Card (6 cols) */}
            <div className="lg:col-span-6 p-6 rounded-2xl bg-slate-900 text-slate-100 border border-white/10 shadow-2xl space-y-4">
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-xs text-slate-400 ml-1 font-mono">{currentSubject.code.toLowerCase()}_summary.tex</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    id="preview-tab-formula"
                    onClick={() => setPreviewTab('formula')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                      previewTab === 'formula' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Formula Card
                  </button>
                  <button
                    id="preview-tab-notes"
                    onClick={() => setPreviewTab('notes')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                      previewTab === 'notes' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Weekly Notes
                  </button>
                </div>
              </div>

              {previewTab === 'formula' ? (
                <div className="space-y-3 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <p className={`${currentTheme.textClass} font-bold`}>{currentSubject.fullName}</p>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${currentTheme.badgeClass}`}>{currentSubject.code}</span>
                  </div>
                  <div className="p-4 bg-[#0A0C10] rounded-xl border border-white/10 text-indigo-200 text-sm leading-relaxed overflow-x-auto text-center">
                    {selectedSubjectId === 'math1' && <BlockMath math="d = \frac{|A x_0 + B y_0 + C|}{\sqrt{A^2 + B^2}}" />}
                    {selectedSubjectId === 'stat1' && <BlockMath math="P(A_i | B) = \frac{P(B | A_i) P(A_i)}{\sum_{j=1}^k P(B | A_j) P(A_j)}" />}
                    {selectedSubjectId === 'python' && <code className="text-sky-400 font-mono">[x**2 for x in range(10) if x % 2 == 0]</code>}
                    {selectedSubjectId === 'ct' && <code className="text-sky-400 font-mono">Filter(Dataset, (row) =&gt; row.Score &gt;= 80)</code>}
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {currentTheme.tags.map(t => (
                      <span key={t} className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/5">
                        {t}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="text-[11px] text-slate-400">{currentSubject.level} Tier</span>
                    <button
                      id="preview-quick-download-btn"
                      onClick={handleDownloadCombinedCompendium}
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-sans font-semibold"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Full Compendium PDF</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 text-xs text-slate-300">
                  <div className="flex items-center justify-between">
                    <span className={`font-bold ${currentTheme.textClass}`}>Chapter Takeaways</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 text-indigo-300 font-mono">Week 1 Notes</span>
                  </div>
                  <div className="p-3.5 bg-[#0A0C10] rounded-xl border border-white/10 space-y-2">
                    <p className="text-white font-semibold text-xs">Core Principles &amp; Takeaways:</p>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-400">
                      <li>Axiomatic definitions with clear geometric intuition.</li>
                      <li>Step-by-step problem walkthroughs with common traps.</li>
                      <li>Verified against IITM graded assignments &amp; term papers.</li>
                    </ul>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-white/10">
                    <span className="text-[11px] text-slate-400">LaTeX Equations &amp; Diagrams</span>
                    <button
                      id="preview-summary-pdf-btn"
                      onClick={handleDownloadSummaryPdf}
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PDF</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* 5. CRAWLABLE FAQ SECTION */}
      <section className="py-20 md:py-28 bg-slate-50 dark:bg-[#0A0C10] border-b border-slate-200/80 dark:border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
              IIT Madras BS Degree FAQs
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-slate-950 dark:text-white">
              Qualifier &amp; Exam Preparation Guide
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <article className="p-6 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 space-y-2.5">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/10 text-indigo-400 text-xs font-bold flex items-center justify-center shrink-0">1</span>
                <span>Where can I find free IIT Madras BS mock tests?</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed pl-8">
                Prajjwal Study Hub provides free, full-length Computer-Based Test (CBT) mock exams, Quiz 1 &amp; 2 papers, and past year questions for all Foundation and Diploma subjects.
              </p>
            </article>

            <article className="p-6 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 space-y-2.5">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/10 text-indigo-400 text-xs font-bold flex items-center justify-center shrink-0">2</span>
                <span>How do I prepare for the Qualifier exam?</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed pl-8">
                Review Week 1 to 4 notes for Math 1, Stats 1, CT, and English 1. Practice graded questions and take timed Qualifier CBT mocks to score above cutoff thresholds.
              </p>
            </article>

            <article className="p-6 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 space-y-2.5">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/10 text-indigo-400 text-xs font-bold flex items-center justify-center shrink-0">3</span>
                <span>Are all Week 1 to Week 12 notes covered?</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed pl-8">
                Yes. Every subject includes Week 1 through Week 12 structured chapters with theoretical explanations, LaTeX derivations, quick revision points, and practice drills.
              </p>
            </article>

            <article className="p-6 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 space-y-2.5">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-lg bg-indigo-500/10 text-indigo-400 text-xs font-bold flex items-center justify-center shrink-0">4</span>
                <span>Can I download notes &amp; formula sheets as PDF?</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed pl-8">
                Yes. You can export complete subject compendiums, individual weekly summaries, and formula cheat sheets as print-ready PDF files with one click.
              </p>
            </article>

          </div>
        </div>
      </section>

      {/* 6. CALL TO ACTION */}
      <section className="py-20 bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-700 text-white text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Ready to Ace Your IIT Madras BS Exams?
          </h2>
          <p className="text-indigo-100 max-w-xl mx-auto text-xs sm:text-sm leading-relaxed">
            Join candidates preparing for Qualifier, Quiz 1, Quiz 2, and End-Term exams with structured notes, formula sheets, CBT mock exams, and analytics.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              id="cta-create-account-btn"
              onClick={() => navigate('/signup')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white text-indigo-900 font-bold text-xs sm:text-sm hover:bg-slate-100 transition-all shadow-lg active:scale-95"
            >
              Create Free Account
            </button>
            <button
              id="cta-view-courses-btn"
              onClick={() => navigate('/courses')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm border border-white/20 transition-all"
            >
              Explore Course Catalog
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};

import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  Clock, 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  FileText, 
  Check, 
  X,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { MockTest } from '../../types';

export const AdminMockTestsPage: React.FC = () => {
  const { mockTests, courses, addMockTest, updateMockTest, deleteMockTest } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState<string>('All');

  // Modal state
  const [testModalOpen, setTestModalOpen] = useState(false);
  const [editingTest, setEditingTest] = useState<MockTest | null>(null);

  // Form fields
  const [formCourseId, setFormCourseId] = useState(courses[0]?.id || '');
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState<'Quiz 1' | 'Quiz 2' | 'End Term'>('Quiz 1');
  const [formDuration, setFormDuration] = useState(60);
  const [formQuestionsCount, setFormQuestionsCount] = useState(30);
  const [formTotalMarks, setFormTotalMarks] = useState(60);
  const [formPassingMarks, setFormPassingMarks] = useState(24);
  const [formDifficulty, setFormDifficulty] = useState<'Standard' | 'Challenging' | 'Comprehensive'>('Standard');
  const [formInstructions, setFormInstructions] = useState('Standard timed evaluation.\nCalculator allowed.\nNo negative marking for unattempted questions.');
  const [formPublished, setFormPublished] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Delete state
  const [testToDelete, setTestToDelete] = useState<MockTest | null>(null);

  const filteredTests = mockTests.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCourse = selectedCourse === 'All' || t.courseId === selectedCourse;
    return matchesSearch && matchesCourse;
  });

  const openCreateModal = () => {
    setEditingTest(null);
    setFormCourseId(courses[0]?.id || '');
    setFormTitle('');
    setFormType('Quiz 1');
    setFormDuration(60);
    setFormQuestionsCount(30);
    setFormTotalMarks(60);
    setFormPassingMarks(24);
    setFormDifficulty('Standard');
    setFormInstructions('Standard examination conditions apply.\nScientific calculator permitted.\nReview all answers before submission.');
    setFormPublished(true);
    setError(null);
    setTestModalOpen(true);
  };

  const openEditModal = (t: MockTest) => {
    setEditingTest(t);
    setFormCourseId(t.courseId);
    setFormTitle(t.title);
    setFormType(t.type);
    setFormDuration(t.durationMinutes);
    setFormQuestionsCount(t.totalQuestions);
    setFormTotalMarks(t.totalMarks);
    setFormPassingMarks(t.passingMarks);
    setFormDifficulty(t.difficulty as any);
    setFormInstructions(t.instructions.join('\n'));
    setFormPublished(t.published);
    setError(null);
    setTestModalOpen(true);
  };

  const handleSaveTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formTitle.trim()) {
      setError('Test title is required.');
      return;
    }

    const instructionsArray = formInstructions
      .split('\n')
      .map(i => i.trim())
      .filter(Boolean);

    try {
      if (editingTest) {
        await updateMockTest(editingTest.id, {
          courseId: formCourseId,
          title: formTitle.trim(),
          type: formType,
          durationMinutes: Number(formDuration) || 60,
          totalQuestions: Number(formQuestionsCount) || 30,
          totalMarks: Number(formTotalMarks) || 60,
          passingMarks: Number(formPassingMarks) || 24,
          difficulty: formDifficulty,
          instructions: instructionsArray,
          published: formPublished,
        });
      } else {
        await addMockTest({
          courseId: formCourseId,
          title: formTitle.trim(),
          type: formType,
          durationMinutes: Number(formDuration) || 60,
          totalQuestions: Number(formQuestionsCount) || 30,
          totalMarks: Number(formTotalMarks) || 60,
          passingMarks: Number(formPassingMarks) || 24,
          difficulty: formDifficulty,
          instructions: instructionsArray,
          published: formPublished,
        });
      }
      setTestModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save mock test.';
      setError(msg);
    }
  };

  const handleConfirmDelete = async () => {
    if (testToDelete) {
      await deleteMockTest(testToDelete.id);
      setTestToDelete(null);
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-rose-600 dark:text-rose-400 uppercase tracking-wider">
            <Clock className="w-4 h-4" />
            <span>Assessment Blueprints</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Mock Test Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Configure examination patterns, duration, question count, and instructions.
          </p>
        </div>

        <Button
          id="admin-create-test-btn"
          variant="primary"
          size="md"
          icon={<Plus className="w-4 h-4" />}
          onClick={openCreateModal}
        >
          Create Mock Blueprint
        </Button>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="admin-mock-search"
            type="text"
            placeholder="Search test blueprints..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            id="admin-mock-course-filter"
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tests Table */}
      {filteredTests.length === 0 ? (
        <EmptyState
          id="empty-admin-mock-tests"
          icon={Clock}
          title="No mock test blueprints created."
          description="Click 'Create Mock Blueprint' to define exam patterns for students."
          actionText="Create Blueprint"
          onAction={openCreateModal}
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-3 px-4 font-bold">Title</th>
                  <th className="py-3 px-4 font-bold">Course</th>
                  <th className="py-3 px-4 font-bold">Type</th>
                  <th className="py-3 px-4 font-bold">Duration</th>
                  <th className="py-3 px-4 font-bold">Questions</th>
                  <th className="py-3 px-4 font-bold">Marks</th>
                  <th className="py-3 px-4 font-bold">Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredTests.map((test) => {
                  const course = courses.find(c => c.id === test.courseId);

                  return (
                    <tr key={test.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                        {test.title}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="primary" size="sm">
                          {course ? course.code : 'Course'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="warning" size="sm">{test.type}</Badge>
                      </td>
                      <td className="py-3 px-4 text-slate-500 font-mono">
                        {test.durationMinutes}m
                      </td>
                      <td className="py-3 px-4 text-slate-500 font-mono">
                        {test.totalQuestions} Qs
                      </td>
                      <td className="py-3 px-4 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                        {test.totalMarks} pts
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={test.published ? 'success' : 'secondary'} size="sm">
                          {test.published ? 'Published' : 'Draft'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            id={`edit-mock-btn-${test.id}`}
                            onClick={() => openEditModal(test)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Blueprint"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            id={`delete-mock-btn-${test.id}`}
                            onClick={() => setTestToDelete(test)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                            title="Delete Blueprint"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      <Modal
        isOpen={testModalOpen}
        onClose={() => setTestModalOpen(false)}
        title={editingTest ? 'Edit Mock Test Blueprint' : 'Create Mock Test Blueprint'}
        maxWidth="lg"
        id="modal-test-form"
      >
        <form onSubmit={handleSaveTest} className="space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label htmlFor="test-title-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Assessment Title <span className="text-rose-500">*</span>
            </label>
            <input
              id="test-title-input"
              type="text"
              placeholder="e.g. Mathematics 1 — Comprehensive Quiz 1 Mock"
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="test-course-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course <span className="text-rose-500">*</span>
              </label>
              <select
                id="test-course-select"
                value={formCourseId}
                onChange={(e) => setFormCourseId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="test-type-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Examination Milestone Type
              </label>
              <select
                id="test-type-select"
                value={formType}
                onChange={(e) => setFormType(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Quiz 1">Quiz 1</option>
                <option value="Quiz 2">Quiz 2</option>
                <option value="End Term">End Term</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label htmlFor="test-duration-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Duration (Mins)
              </label>
              <input
                id="test-duration-input"
                type="number"
                value={formDuration}
                onChange={(e) => setFormDuration(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={15}
                max={180}
              />
            </div>

            <div>
              <label htmlFor="test-qcount-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Questions
              </label>
              <input
                id="test-qcount-input"
                type="number"
                value={formQuestionsCount}
                onChange={(e) => setFormQuestionsCount(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={5}
                max={100}
              />
            </div>

            <div>
              <label htmlFor="test-maxmarks-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Max Marks
              </label>
              <input
                id="test-maxmarks-input"
                type="number"
                value={formTotalMarks}
                onChange={(e) => setFormTotalMarks(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={10}
                max={200}
              />
            </div>

            <div>
              <label htmlFor="test-passmarks-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Passing Marks
              </label>
              <input
                id="test-passmarks-input"
                type="number"
                value={formPassingMarks}
                onChange={(e) => setFormPassingMarks(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={5}
                max={100}
              />
            </div>
          </div>

          <div>
            <label htmlFor="test-instructions-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Examination Instructions (One per line)
            </label>
            <textarea
              id="test-instructions-input"
              rows={4}
              value={formInstructions}
              onChange={(e) => setFormInstructions(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="test-published-checkbox"
              type="checkbox"
              checked={formPublished}
              onChange={(e) => setFormPublished(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="test-published-checkbox" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Publish Blueprint to Student Mock Catalog
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              id="test-modal-cancel"
              variant="secondary"
              size="sm"
              onClick={() => setTestModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              id="test-modal-save"
              type="submit"
              variant="primary"
              size="sm"
            >
              {editingTest ? 'Save Blueprint' : 'Create Blueprint'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!testToDelete}
        onClose={() => setTestToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Mock Blueprint"
        message={`Are you sure you want to permanently delete "${testToDelete?.title}"?`}
        confirmText="Delete Blueprint"
        id="dialog-delete-mock"
      />

    </div>
  );
};

import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  FileText, 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  Eye, 
  Clock, 
  User, 
  Check, 
  X,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { Note } from '../../types';

export const AdminNotesPage: React.FC = () => {
  const { notes, courses, modules, addNote, updateNote, deleteNote } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState<string>('All');

  // Modal State
  const [noteModalOpen, setNoteModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  // Form fields
  const [formCourseId, setFormCourseId] = useState(courses[0]?.id || '');
  const [formModuleId, setFormModuleId] = useState('');
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formContentMarkdown, setFormContentMarkdown] = useState('');
  const [formReadingTime, setFormReadingTime] = useState(12);
  const [formAuthorName, setFormAuthorName] = useState('Prajjwal Academic Team');
  const [formTags, setFormTags] = useState('Foundations, Formulas, Proofs');
  const [formPublished, setFormPublished] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Delete State
  const [noteToDelete, setNoteToDelete] = useState<Note | null>(null);

  const filteredNotes = notes.filter(n => {
    const matchesSearch = n.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          n.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCourse = selectedCourse === 'All' || n.courseId === selectedCourse;
    return matchesSearch && matchesCourse;
  });

  const availableModules = formCourseId 
    ? modules.filter(m => m.courseId === formCourseId)
    : modules;

  const openCreateModal = () => {
    setEditingNote(null);
    const firstCourse = courses[0]?.id || '';
    setFormCourseId(firstCourse);
    const firstMod = modules.find(m => m.courseId === firstCourse)?.id || '';
    setFormModuleId(firstMod);
    setFormTitle('');
    setFormDescription('');
    setFormContentMarkdown('');
    setFormReadingTime(10);
    setFormAuthorName('Prajjwal Academic Team');
    setFormTags('Foundations, Review, Key Concepts');
    setFormPublished(true);
    setError(null);
    setNoteModalOpen(true);
  };

  const openEditModal = (note: Note) => {
    setEditingNote(note);
    setFormCourseId(note.courseId);
    setFormModuleId(note.moduleId || '');
    setFormTitle(note.title);
    setFormDescription(note.description);
    setFormContentMarkdown(note.contentMarkdown || '');
    setFormReadingTime(note.readingTimeMinutes);
    setFormAuthorName(note.authorName);
    setFormTags(note.tags.join(', '));
    setFormPublished(note.published);
    setError(null);
    setNoteModalOpen(true);
  };

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formTitle.trim()) {
      setError('Note Title is required.');
      return;
    }
    if (!formCourseId) {
      setError('Please select an associated Course.');
      return;
    }

    const tagsArray = formTags.split(',').map(t => t.trim()).filter(Boolean);

    try {
      if (editingNote) {
        await updateNote(editingNote.id, {
          courseId: formCourseId,
          moduleId: formModuleId || undefined,
          title: formTitle.trim(),
          description: formDescription.trim(),
          contentMarkdown: formContentMarkdown.trim(),
          readingTimeMinutes: Number(formReadingTime) || 10,
          authorName: formAuthorName.trim() || 'Prajjwal Academic Team',
          tags: tagsArray,
          published: formPublished,
        });
      } else {
        await addNote({
          courseId: formCourseId,
          moduleId: formModuleId || undefined,
          title: formTitle.trim(),
          description: formDescription.trim(),
          contentMarkdown: formContentMarkdown.trim(),
          readingTimeMinutes: Number(formReadingTime) || 10,
          authorName: formAuthorName.trim() || 'Prajjwal Academic Team',
          tags: tagsArray,
          published: formPublished,
        });
      }
      setNoteModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save note.';
      setError(msg);
    }
  };

  const handleConfirmDelete = async () => {
    if (noteToDelete) {
      await deleteNote(noteToDelete.id);
      setNoteToDelete(null);
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
            <FileText className="w-4 h-4" />
            <span>Content Publishing Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Revision Notes Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Author and publish weekly course notes, formulas, and revision materials.
          </p>
        </div>

        <Button
          id="admin-create-note-btn"
          variant="primary"
          size="md"
          icon={<Plus className="w-4 h-4" />}
          onClick={openCreateModal}
        >
          Publish Study Note
        </Button>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="admin-notes-search"
            type="text"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            id="admin-notes-course-filter"
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Notes Table */}
      {filteredNotes.length === 0 ? (
        <EmptyState
          id="empty-admin-notes"
          icon={FileText}
          title="No notes published yet."
          description="Click 'Publish Study Note' to author new revision notes."
          actionText="Publish Note"
          onAction={openCreateModal}
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-3 px-4 font-bold">Note Title</th>
                  <th className="py-3 px-4 font-bold">Course</th>
                  <th className="py-3 px-4 font-bold">Author</th>
                  <th className="py-3 px-4 font-bold">Read Time</th>
                  <th className="py-3 px-4 font-bold">Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredNotes.map((note) => {
                  const course = courses.find(c => c.id === note.courseId);

                  return (
                    <tr key={note.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100 max-w-xs truncate">
                        {note.title}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="primary" size="sm">
                          {course ? course.code : 'Course'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-slate-500">
                        {note.authorName}
                      </td>
                      <td className="py-3 px-4 text-slate-500 font-mono">
                        {note.readingTimeMinutes} mins
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={note.published ? 'success' : 'secondary'} size="sm">
                          {note.published ? 'Published' : 'Draft'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            id={`edit-note-btn-${note.id}`}
                            onClick={() => openEditModal(note)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Note"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            id={`delete-note-btn-${note.id}`}
                            onClick={() => setNoteToDelete(note)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                            title="Delete Note"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Note Form Modal */}
      <Modal
        isOpen={noteModalOpen}
        onClose={() => setNoteModalOpen(false)}
        title={editingNote ? 'Edit Study Note' : 'Publish New Study Note'}
        maxWidth="lg"
        id="modal-note-form"
      >
        <form onSubmit={handleSaveNote} className="space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label htmlFor="note-title-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Note Title <span className="text-rose-500">*</span>
            </label>
            <input
              id="note-title-input"
              type="text"
              placeholder="e.g. Week 1: Sets, Relations, Functions & Foundations"
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="note-course-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course <span className="text-rose-500">*</span>
              </label>
              <select
                id="note-course-select"
                value={formCourseId}
                onChange={(e) => {
                  setFormCourseId(e.target.value);
                  const firstM = modules.find(m => m.courseId === e.target.value)?.id || '';
                  setFormModuleId(firstM);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="note-module-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Curriculum Module / Week
              </label>
              <select
                id="note-module-select"
                value={formModuleId}
                onChange={(e) => setFormModuleId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">General Course Overview</option>
                {availableModules.map(m => (
                  <option key={m.id} value={m.id}>{m.title}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="note-desc-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Short Summary Description
            </label>
            <input
              id="note-desc-input"
              type="text"
              placeholder="Key concepts, proofs, and weekly summary..."
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label htmlFor="note-markdown-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Note Content (Markdown & Formulas Supported)
            </label>
            <textarea
              id="note-markdown-input"
              rows={8}
              placeholder="Write detailed notes with LaTeX equations, code blocks, or proofs..."
              value={formContentMarkdown}
              onChange={(e) => setFormContentMarkdown(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="note-author-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Author Name
              </label>
              <input
                id="note-author-input"
                type="text"
                value={formAuthorName}
                onChange={(e) => setFormAuthorName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label htmlFor="note-readtime-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Reading Time (Mins)
              </label>
              <input
                id="note-readtime-input"
                type="number"
                value={formReadingTime}
                onChange={(e) => setFormReadingTime(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={1}
                max={120}
              />
            </div>

            <div>
              <label htmlFor="note-tags-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Tags (Comma separated)
              </label>
              <input
                id="note-tags-input"
                type="text"
                placeholder="Sets, Functions, Proofs"
                value={formTags}
                onChange={(e) => setFormTags(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="note-published-checkbox"
              type="checkbox"
              checked={formPublished}
              onChange={(e) => setFormPublished(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="note-published-checkbox" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Publish Note Live (Immediately Accessible by Students)
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              id="note-modal-cancel"
              variant="secondary"
              size="sm"
              onClick={() => setNoteModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              id="note-modal-save"
              type="submit"
              variant="primary"
              size="sm"
            >
              {editingNote ? 'Save Changes' : 'Publish Note'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Note Dialog */}
      <ConfirmDialog
        isOpen={!!noteToDelete}
        onClose={() => setNoteToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Revision Note"
        message={`Are you sure you want to permanently delete "${noteToDelete?.title}"?`}
        confirmText="Delete Note"
        id="dialog-delete-note"
      />

    </div>
  );
};

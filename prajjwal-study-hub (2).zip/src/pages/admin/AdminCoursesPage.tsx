import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  BookOpen, 
  Plus, 
  Edit3, 
  Trash2, 
  Layers, 
  Check, 
  X, 
  Search,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { Course, Module } from '../../types';

export const AdminCoursesPage: React.FC = () => {
  const { programs, courses, modules, addCourse, updateCourse, deleteCourse, addModule } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProgram, setSelectedProgram] = useState<string>('All');

  // Course Modal state
  const [courseModalOpen, setCourseModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [formProgramId, setFormProgramId] = useState(programs[0]?.id || 'prog_bs_foundation');
  const [formTitle, setFormTitle] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCategory, setFormCategory] = useState('Mathematics');
  const [formTerm, setFormTerm] = useState('Term 1');
  const [formCredit, setFormCredit] = useState(4);
  const [formPublished, setFormPublished] = useState(true);
  const [courseError, setCourseError] = useState<string | null>(null);

  // Module Modal state
  const [moduleModalOpen, setModuleModalOpen] = useState(false);
  const [selectedCourseForModule, setSelectedCourseForModule] = useState<Course | null>(null);
  const [moduleTitle, setModuleTitle] = useState('');
  const [moduleDescription, setModuleDescription] = useState('');
  const [moduleOrder, setModuleOrder] = useState(1);

  // Delete Dialog state
  const [courseToDelete, setCourseToDelete] = useState<Course | null>(null);

  const filteredCourses = courses.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          c.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesProgram = selectedProgram === 'All' || c.programId === selectedProgram;
    return matchesSearch && matchesProgram;
  });

  const openCreateCourseModal = () => {
    setEditingCourse(null);
    setFormProgramId(programs[0]?.id || 'prog_bs_foundation');
    setFormTitle('');
    setFormCode('');
    setFormDescription('');
    setFormCategory('Mathematics');
    setFormTerm('Term 1');
    setFormCredit(4);
    setFormPublished(true);
    setCourseError(null);
    setCourseModalOpen(true);
  };

  const openEditCourseModal = (course: Course) => {
    setEditingCourse(course);
    setFormProgramId(course.programId);
    setFormTitle(course.title);
    setFormCode(course.code);
    setFormDescription(course.description);
    setFormCategory(course.category);
    setFormTerm(course.term || 'Term 1');
    setFormCredit(course.credit || 4);
    setFormPublished(course.published);
    setCourseError(null);
    setCourseModalOpen(true);
  };

  const handleSaveCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    setCourseError(null);

    if (!formTitle.trim() || !formCode.trim()) {
      setCourseError('Course Title and Code are required.');
      return;
    }

    try {
      if (editingCourse) {
        await updateCourse(editingCourse.id, {
          programId: formProgramId,
          title: formTitle.trim(),
          code: formCode.trim().toUpperCase(),
          description: formDescription.trim(),
          category: formCategory,
          term: formTerm,
          credit: formCredit,
          published: formPublished,
        });
      } else {
        await addCourse({
          programId: formProgramId,
          title: formTitle.trim(),
          code: formCode.trim().toUpperCase(),
          description: formDescription.trim(),
          category: formCategory,
          term: formTerm,
          credit: formCredit,
          published: formPublished,
          order: courses.length + 1,
        });
      }
      setCourseModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save course.';
      setCourseError(msg);
    }
  };

  const handleSaveModule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourseForModule || !moduleTitle.trim()) return;

    await addModule({
      courseId: selectedCourseForModule.id,
      title: moduleTitle.trim(),
      description: moduleDescription.trim(),
      order: moduleOrder,
    });

    setModuleTitle('');
    setModuleDescription('');
    setModuleModalOpen(false);
  };

  const handleConfirmDelete = async () => {
    if (courseToDelete) {
      await deleteCourse(courseToDelete.id);
      setCourseToDelete(null);
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            <BookOpen className="w-4 h-4" />
            <span>Curriculum Manager</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Courses & Subject Structure
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage academic programs, course listings, and weekly modules.
          </p>
        </div>

        <Button
          id="admin-add-course-btn"
          variant="primary"
          size="md"
          icon={<Plus className="w-4 h-4" />}
          onClick={openCreateCourseModal}
        >
          Add New Course
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="admin-course-search"
            type="text"
            placeholder="Search courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            id="admin-course-program-filter"
            value={selectedProgram}
            onChange={(e) => setSelectedProgram(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Academic Programs</option>
            {programs.map(p => (
              <option key={p.id} value={p.id}>{p.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Courses Table */}
      {filteredCourses.length === 0 ? (
        <EmptyState
          id="empty-admin-courses"
          icon={BookOpen}
          title="No courses configured."
          description="Click 'Add New Course' to create your first curriculum course."
          actionText="Add Course"
          onAction={openCreateCourseModal}
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-3 px-4 font-bold">Code</th>
                  <th className="py-3 px-4 font-bold">Course Title</th>
                  <th className="py-3 px-4 font-bold">Category & Term</th>
                  <th className="py-3 px-4 font-bold">Modules</th>
                  <th className="py-3 px-4 font-bold">Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredCourses.map((course) => {
                  const courseModules = modules.filter(m => m.courseId === course.id);

                  return (
                    <tr key={course.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-bold font-mono text-indigo-600 dark:text-indigo-400">
                        {course.code}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                        {course.title}
                      </td>
                      <td className="py-3 px-4 text-slate-500">
                        {course.category} • {course.term}
                      </td>
                      <td className="py-3 px-4">
                        <button
                          id={`btn-add-module-${course.code}`}
                          onClick={() => {
                            setSelectedCourseForModule(course);
                            setModuleOrder(courseModules.length + 1);
                            setModuleModalOpen(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold hover:bg-indigo-100 transition-colors flex items-center gap-1"
                        >
                          <Layers className="w-3 h-3" />
                          <span>{courseModules.length} Modules (+Add)</span>
                        </button>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={course.published ? 'success' : 'secondary'} size="sm">
                          {course.published ? 'Published' : 'Draft'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            id={`edit-course-btn-${course.id}`}
                            onClick={() => openEditCourseModal(course)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Course"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            id={`delete-course-btn-${course.id}`}
                            onClick={() => setCourseToDelete(course)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                            title="Delete Course"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Course Modal */}
      <Modal
        isOpen={courseModalOpen}
        onClose={() => setCourseModalOpen(false)}
        title={editingCourse ? 'Edit Academic Course' : 'Add New Academic Course'}
        maxWidth="md"
        id="modal-course-form"
      >
        <form onSubmit={handleSaveCourse} className="space-y-4">
          {courseError && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{courseError}</span>
            </div>
          )}

          <div>
            <label htmlFor="course-prog-id" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Academic Program Level
            </label>
            <select
              id="course-prog-id"
              value={formProgramId}
              onChange={(e) => setFormProgramId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {programs.map(p => (
                <option key={p.id} value={p.id}>{p.title}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="course-title-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course Title <span className="text-rose-500">*</span>
              </label>
              <input
                id="course-title-input"
                type="text"
                placeholder="e.g. Mathematics 1"
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label htmlFor="course-code-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course Code <span className="text-rose-500">*</span>
              </label>
              <input
                id="course-code-input"
                type="text"
                placeholder="e.g. MA1001"
                value={formCode}
                onChange={(e) => setFormCode(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="course-category-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                id="course-category-select"
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Mathematics">Mathematics</option>
                <option value="Statistics">Statistics</option>
                <option value="Programming">Programming</option>
                <option value="Core CS">Core CS</option>
                <option value="Data Science">Data Science</option>
              </select>
            </div>

            <div>
              <label htmlFor="course-term-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Term
              </label>
              <select
                id="course-term-select"
                value={formTerm}
                onChange={(e) => setFormTerm(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Term 1">Term 1</option>
                <option value="Term 2">Term 2</option>
                <option value="Term 3">Term 3</option>
              </select>
            </div>

            <div>
              <label htmlFor="course-credit-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Credits
              </label>
              <input
                id="course-credit-input"
                type="number"
                value={formCredit}
                onChange={(e) => setFormCredit(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={1}
                max={8}
              />
            </div>
          </div>

          <div>
            <label htmlFor="course-desc-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Course Description & Syllabus Summary
            </label>
            <textarea
              id="course-desc-input"
              rows={3}
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="course-published-checkbox"
              type="checkbox"
              checked={formPublished}
              onChange={(e) => setFormPublished(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="course-published-checkbox" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Publish Course Immediately (Visible to Students)
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              id="course-modal-cancel"
              variant="secondary"
              size="sm"
              onClick={() => setCourseModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              id="course-modal-save"
              type="submit"
              variant="primary"
              size="sm"
            >
              {editingCourse ? 'Save Changes' : 'Create Course'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Add Module Modal */}
      <Modal
        isOpen={moduleModalOpen}
        onClose={() => setModuleModalOpen(false)}
        title={`Add Module to ${selectedCourseForModule?.title || 'Course'}`}
        maxWidth="sm"
        id="modal-add-module"
      >
        <form onSubmit={handleSaveModule} className="space-y-4">
          <div>
            <label htmlFor="module-title-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Module Title <span className="text-rose-500">*</span>
            </label>
            <input
              id="module-title-input"
              type="text"
              placeholder="e.g. Week 3: Eigenvalues & Transformations"
              value={moduleTitle}
              onChange={(e) => setModuleTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label htmlFor="module-desc-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Module Overview
            </label>
            <textarea
              id="module-desc-input"
              rows={2}
              value={moduleDescription}
              onChange={(e) => setModuleDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <Button
              id="module-modal-cancel"
              variant="secondary"
              size="sm"
              onClick={() => setModuleModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              id="module-modal-save"
              type="submit"
              variant="primary"
              size="sm"
            >
              Save Module
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Dialog */}
      <ConfirmDialog
        isOpen={!!courseToDelete}
        onClose={() => setCourseToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Academic Course"
        message={`Are you sure you want to permanently delete "${courseToDelete?.title}" (${courseToDelete?.code})?`}
        confirmText="Delete Course"
        id="dialog-delete-course"
      />

    </div>
  );
};

import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  Calculator, 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  Copy, 
  Check, 
  X,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { FormulaSheet } from '../../types';

export const AdminFormulasPage: React.FC = () => {
  const { formulas, courses, addFormula, updateFormula, deleteFormula } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState<string>('All');

  // Modal State
  const [formulaModalOpen, setFormulaModalOpen] = useState(false);
  const [editingFormula, setEditingFormula] = useState<FormulaSheet | null>(null);

  // Form fields
  const [formCourseId, setFormCourseId] = useState(courses[0]?.id || '');
  const [formTitle, setFormTitle] = useState('');
  const [formFormula, setFormFormula] = useState('');
  const [formLatex, setFormLatex] = useState('');
  const [formExplanation, setFormExplanation] = useState('');
  const [formTags, setFormTags] = useState('Probability, Formula');
  const [formPublished, setFormPublished] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Delete State
  const [formulaToDelete, setFormulaToDelete] = useState<FormulaSheet | null>(null);

  const filteredFormulas = formulas.filter(f => {
    const matchesSearch = f.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.formula.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCourse = selectedCourse === 'All' || f.courseId === selectedCourse;
    return matchesSearch && matchesCourse;
  });

  const openCreateModal = () => {
    setEditingFormula(null);
    setFormCourseId(courses[0]?.id || '');
    setFormTitle('');
    setFormFormula('');
    setFormLatex('');
    setFormExplanation('');
    setFormTags('Equations, Rules');
    setFormPublished(true);
    setError(null);
    setFormulaModalOpen(true);
  };

  const openEditModal = (formula: FormulaSheet) => {
    setEditingFormula(formula);
    setFormCourseId(formula.courseId);
    setFormTitle(formula.title);
    setFormFormula(formula.formula);
    setFormLatex(formula.latex || formula.formula);
    setFormExplanation(formula.explanation);
    setFormTags(formula.tags.join(', '));
    setFormPublished(formula.published);
    setError(null);
    setFormulaModalOpen(true);
  };

  const handleSaveFormula = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formTitle.trim() || !formFormula.trim()) {
      setError('Formula Title and Formula Text are required.');
      return;
    }
    if (!formCourseId) {
      setError('Please select an associated Course.');
      return;
    }

    const tagsArray = formTags.split(',').map(t => t.trim()).filter(Boolean);

    try {
      if (editingFormula) {
        await updateFormula(editingFormula.id, {
          courseId: formCourseId,
          title: formTitle.trim(),
          formula: formFormula.trim(),
          latex: formLatex.trim() || formFormula.trim(),
          explanation: formExplanation.trim(),
          tags: tagsArray,
          published: formPublished,
        });
      } else {
        await addFormula({
          courseId: formCourseId,
          title: formTitle.trim(),
          formula: formFormula.trim(),
          latex: formLatex.trim() || formFormula.trim(),
          explanation: formExplanation.trim(),
          tags: tagsArray,
          published: formPublished,
        });
      }
      setFormulaModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save formula.';
      setError(msg);
    }
  };

  const handleConfirmDelete = async () => {
    if (formulaToDelete) {
      await deleteFormula(formulaToDelete.id);
      setFormulaToDelete(null);
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
            <Calculator className="w-4 h-4" />
            <span>Formula Sheets Repository</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Formula Cards & Equation Manager
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Publish high-yield equations, mathematical definitions, and cheat sheets.
          </p>
        </div>

        <Button
          id="admin-create-formula-btn"
          variant="primary"
          size="md"
          icon={<Plus className="w-4 h-4" />}
          onClick={openCreateModal}
        >
          Add Formula Card
        </Button>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="admin-formulas-search"
            type="text"
            placeholder="Search formulas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            id="admin-formulas-course-filter"
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Formulas Table */}
      {filteredFormulas.length === 0 ? (
        <EmptyState
          id="empty-admin-formulas"
          icon={Calculator}
          title="No formula sheets added yet."
          description="Click 'Add Formula Card' to create high-yield equations for students."
          actionText="Add Formula"
          onAction={openCreateModal}
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-3 px-4 font-bold">Title</th>
                  <th className="py-3 px-4 font-bold">Course</th>
                  <th className="py-3 px-4 font-bold">Equation / Expression</th>
                  <th className="py-3 px-4 font-bold">Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredFormulas.map((formula) => {
                  const course = courses.find(c => c.id === formula.courseId);

                  return (
                    <tr key={formula.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                        {formula.title}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="primary" size="sm">
                          {course ? course.code : 'Course'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-mono text-indigo-600 dark:text-indigo-400 font-medium max-w-xs truncate">
                        {formula.latex || formula.formula}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={formula.published ? 'success' : 'secondary'} size="sm">
                          {formula.published ? 'Published' : 'Draft'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            id={`edit-formula-btn-${formula.id}`}
                            onClick={() => openEditModal(formula)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Formula"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            id={`delete-formula-btn-${formula.id}`}
                            onClick={() => setFormulaToDelete(formula)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                            title="Delete Formula"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Formula Modal */}
      <Modal
        isOpen={formulaModalOpen}
        onClose={() => setFormulaModalOpen(false)}
        title={editingFormula ? 'Edit Formula Card' : 'Add New Formula Card'}
        maxWidth="md"
        id="modal-formula-form"
      >
        <form onSubmit={handleSaveFormula} className="space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label htmlFor="formula-course-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Course <span className="text-rose-500">*</span>
            </label>
            <select
              id="formula-course-select"
              value={formCourseId}
              onChange={(e) => setFormCourseId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {courses.map(c => (
                <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="formula-title-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Formula Name <span className="text-rose-500">*</span>
            </label>
            <input
              id="formula-title-input"
              type="text"
              placeholder="e.g. Bayes' Theorem for Conditional Probability"
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label htmlFor="formula-text-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Formula Equation (Plain Text / LaTeX) <span className="text-rose-500">*</span>
            </label>
            <input
              id="formula-text-input"
              type="text"
              placeholder="e.g. P(A|B) = [P(B|A) * P(A)] / P(B)"
              value={formFormula}
              onChange={(e) => {
                setFormFormula(e.target.value);
                if (!formLatex) setFormLatex(e.target.value);
              }}
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label htmlFor="formula-latex-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              LaTeX Equation Expression
            </label>
            <input
              id="formula-latex-input"
              type="text"
              placeholder="e.g. P(A|B) = \frac{P(B|A)P(A)}{P(B)}"
              value={formLatex}
              onChange={(e) => setFormLatex(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label htmlFor="formula-explanation-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Conceptual Explanation & When to Apply
            </label>
            <textarea
              id="formula-explanation-input"
              rows={3}
              placeholder="Explain what the formula does and key prerequisites..."
              value={formExplanation}
              onChange={(e) => setFormExplanation(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label htmlFor="formula-tags-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Tags (Comma separated)
            </label>
            <input
              id="formula-tags-input"
              type="text"
              value={formTags}
              onChange={(e) => setFormTags(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="formula-published-checkbox"
              type="checkbox"
              checked={formPublished}
              onChange={(e) => setFormPublished(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="formula-published-checkbox" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Publish Formula Card (Immediately Visible)
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              id="formula-modal-cancel"
              variant="secondary"
              size="sm"
              onClick={() => setFormulaModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              id="formula-modal-save"
              type="submit"
              variant="primary"
              size="sm"
            >
              {editingFormula ? 'Save Changes' : 'Add Formula'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Formula Dialog */}
      <ConfirmDialog
        isOpen={!!formulaToDelete}
        onClose={() => setFormulaToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Formula Card"
        message={`Are you sure you want to permanently delete "${formulaToDelete?.title}"?`}
        confirmText="Delete Formula"
        id="dialog-delete-formula"
      />

    </div>
  );
};

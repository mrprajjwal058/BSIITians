import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  CheckSquare, 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  HelpCircle, 
  CheckCircle2, 
  X,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { Question } from '../../types';

export const AdminQuestionsPage: React.FC = () => {
  const { questions, courses, addQuestion, updateQuestion, deleteQuestion } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState<string>('All');

  // Modal State
  const [questionModalOpen, setQuestionModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);

  // Form fields
  const [formCourseId, setFormCourseId] = useState(courses[0]?.id || '');
  const [formQuestionText, setFormQuestionText] = useState('');
  const [formOptA, setFormOptA] = useState('');
  const [formOptB, setFormOptB] = useState('');
  const [formOptC, setFormOptC] = useState('');
  const [formOptD, setFormOptD] = useState('');
  const [formCorrectIndex, setFormCorrectIndex] = useState(0);
  const [formExplanation, setFormExplanation] = useState('');
  const [formDifficulty, setFormDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [formMarks, setFormMarks] = useState(2);
  const [formPublished, setFormPublished] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Delete State
  const [questionToDelete, setQuestionToDelete] = useState<Question | null>(null);

  const filteredQuestions = questions.filter(q => {
    const matchesSearch = q.questionText.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          q.explanation.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCourse = selectedCourse === 'All' || q.courseId === selectedCourse;
    return matchesSearch && matchesCourse;
  });

  const openCreateModal = () => {
    setEditingQuestion(null);
    setFormCourseId(courses[0]?.id || '');
    setFormQuestionText('');
    setFormOptA('');
    setFormOptB('');
    setFormOptC('');
    setFormOptD('');
    setFormCorrectIndex(0);
    setFormExplanation('');
    setFormDifficulty('Medium');
    setFormMarks(2);
    setFormPublished(true);
    setError(null);
    setQuestionModalOpen(true);
  };

  const openEditModal = (q: Question) => {
    setEditingQuestion(q);
    setFormCourseId(q.courseId);
    setFormQuestionText(q.questionText);
    setFormOptA(q.options[0] || '');
    setFormOptB(q.options[1] || '');
    setFormOptC(q.options[2] || '');
    setFormOptD(q.options[3] || '');
    setFormCorrectIndex(q.correctOptionIndex);
    setFormExplanation(q.explanation);
    setFormDifficulty(q.difficulty);
    setFormMarks(q.marks);
    setFormPublished(q.published);
    setError(null);
    setQuestionModalOpen(true);
  };

  const handleSaveQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formQuestionText.trim()) {
      setError('Question text is required.');
      return;
    }
    if (!formOptA.trim() || !formOptB.trim()) {
      setError('Please provide at least options A and B.');
      return;
    }

    const options = [formOptA.trim(), formOptB.trim(), formOptC.trim(), formOptD.trim()].filter(Boolean);

    try {
      if (editingQuestion) {
        await updateQuestion(editingQuestion.id, {
          courseId: formCourseId,
          questionText: formQuestionText.trim(),
          options,
          correctOptionIndex: formCorrectIndex,
          explanation: formExplanation.trim(),
          difficulty: formDifficulty,
          marks: Number(formMarks) || 2,
          published: formPublished,
        });
      } else {
        await addQuestion({
          courseId: formCourseId,
          questionText: formQuestionText.trim(),
          options,
          correctOptionIndex: formCorrectIndex,
          explanation: formExplanation.trim(),
          difficulty: formDifficulty,
          marks: Number(formMarks) || 2,
          published: formPublished,
        });
      }
      setQuestionModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save question.';
      setError(msg);
    }
  };

  const handleConfirmDelete = async () => {
    if (questionToDelete) {
      await deleteQuestion(questionToDelete.id);
      setQuestionToDelete(null);
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-cyan-600 dark:text-cyan-400 uppercase tracking-wider">
            <CheckSquare className="w-4 h-4" />
            <span>Question Bank Management</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Practice Questions Repository
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Author multiple choice questions with mathematical explanations and difficulty calibration.
          </p>
        </div>

        <Button
          id="admin-create-question-btn"
          variant="primary"
          size="md"
          icon={<Plus className="w-4 h-4" />}
          onClick={openCreateModal}
        >
          Add Question
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="admin-questions-search"
            type="text"
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            id="admin-questions-course-filter"
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Questions Table */}
      {filteredQuestions.length === 0 ? (
        <EmptyState
          id="empty-admin-questions"
          icon={CheckSquare}
          title="No questions in repository."
          description="Click 'Add Question' to create topic-mapped practice questions."
          actionText="Add Question"
          onAction={openCreateModal}
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-3 px-4 font-bold">Course</th>
                  <th className="py-3 px-4 font-bold">Question Stem</th>
                  <th className="py-3 px-4 font-bold">Difficulty</th>
                  <th className="py-3 px-4 font-bold">Marks</th>
                  <th className="py-3 px-4 font-bold">Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredQuestions.map((q) => {
                  const course = courses.find(c => c.id === q.courseId);

                  return (
                    <tr key={q.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4">
                        <Badge variant="primary" size="sm">
                          {course ? course.code : 'Course'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100 max-w-sm truncate">
                        {q.questionText}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={q.difficulty === 'Easy' ? 'success' : q.difficulty === 'Medium' ? 'warning' : 'danger'} size="sm">
                          {q.difficulty}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-500">
                        {q.marks} pts
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={q.published ? 'success' : 'secondary'} size="sm">
                          {q.published ? 'Published' : 'Draft'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            id={`edit-question-btn-${q.id}`}
                            onClick={() => openEditModal(q)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Edit Question"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            id={`delete-question-btn-${q.id}`}
                            onClick={() => setQuestionToDelete(q)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                            title="Delete Question"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Question Modal */}
      <Modal
        isOpen={questionModalOpen}
        onClose={() => setQuestionModalOpen(false)}
        title={editingQuestion ? 'Edit Practice Question' : 'Add New Practice Question'}
        maxWidth="lg"
        id="modal-question-form"
      >
        <form onSubmit={handleSaveQuestion} className="space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="q-course-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Course <span className="text-rose-500">*</span>
              </label>
              <select
                id="q-course-select"
                value={formCourseId}
                onChange={(e) => setFormCourseId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>{c.code} - {c.title}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="q-diff-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Difficulty
              </label>
              <select
                id="q-diff-select"
                value={formDifficulty}
                onChange={(e) => setFormDifficulty(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>

            <div>
              <label htmlFor="q-marks-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Marks Weightage
              </label>
              <input
                id="q-marks-input"
                type="number"
                value={formMarks}
                onChange={(e) => setFormMarks(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                min={1}
                max={10}
              />
            </div>
          </div>

          <div>
            <label htmlFor="q-text-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Question Text <span className="text-rose-500">*</span>
            </label>
            <textarea
              id="q-text-input"
              rows={3}
              placeholder="State the mathematical problem or code snippet..."
              value={formQuestionText}
              onChange={(e) => setFormQuestionText(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Answer Options & Correct Key
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <input
                  type="radio"
                  name="correctOption"
                  checked={formCorrectIndex === 0}
                  onChange={() => setFormCorrectIndex(0)}
                  className="text-indigo-600"
                />
                <span className="font-bold text-xs">A.</span>
                <input
                  type="text"
                  placeholder="Option A text"
                  value={formOptA}
                  onChange={(e) => setFormOptA(e.target.value)}
                  className="w-full bg-transparent text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
                  required
                />
              </div>

              <div className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <input
                  type="radio"
                  name="correctOption"
                  checked={formCorrectIndex === 1}
                  onChange={() => setFormCorrectIndex(1)}
                  className="text-indigo-600"
                />
                <span className="font-bold text-xs">B.</span>
                <input
                  type="text"
                  placeholder="Option B text"
                  value={formOptB}
                  onChange={(e) => setFormOptB(e.target.value)}
                  className="w-full bg-transparent text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
                  required
                />
              </div>

              <div className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <input
                  type="radio"
                  name="correctOption"
                  checked={formCorrectIndex === 2}
                  onChange={() => setFormCorrectIndex(2)}
                  className="text-indigo-600"
                />
                <span className="font-bold text-xs">C.</span>
                <input
                  type="text"
                  placeholder="Option C text"
                  value={formOptC}
                  onChange={(e) => setFormOptC(e.target.value)}
                  className="w-full bg-transparent text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <input
                  type="radio"
                  name="correctOption"
                  checked={formCorrectIndex === 3}
                  onChange={() => setFormCorrectIndex(3)}
                  className="text-indigo-600"
                />
                <span className="font-bold text-xs">D.</span>
                <input
                  type="text"
                  placeholder="Option D text"
                  value={formOptD}
                  onChange={(e) => setFormOptD(e.target.value)}
                  className="w-full bg-transparent text-xs text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>
            </div>
            <span className="text-[11px] text-slate-400">Select the radio button beside the correct answer key.</span>
          </div>

          <div>
            <label htmlFor="q-explanation-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Step-by-Step Mathematical Explanation & Solution
            </label>
            <textarea
              id="q-explanation-input"
              rows={3}
              placeholder="Show complete derivation and reasoning..."
              value={formExplanation}
              onChange={(e) => setFormExplanation(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              id="q-published-checkbox"
              type="checkbox"
              checked={formPublished}
              onChange={(e) => setFormPublished(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="q-published-checkbox" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Publish Question Immediately
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              id="q-modal-cancel"
              variant="secondary"
              size="sm"
              onClick={() => setQuestionModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              id="q-modal-save"
              type="submit"
              variant="primary"
              size="sm"
            >
              {editingQuestion ? 'Save Changes' : 'Add Question'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!questionToDelete}
        onClose={() => setQuestionToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Practice Question"
        message="Are you sure you want to permanently delete this practice question?"
        confirmText="Delete Question"
        id="dialog-delete-question"
      />

    </div>
  );
};

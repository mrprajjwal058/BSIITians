import React from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  ShieldCheck, 
  BookOpen, 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  Mail, 
  Plus, 
  Layers, 
  TrendingUp, 
  ArrowRight,
  Database,
  CheckCircle2
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';

interface AdminDashboardPageProps {
  navigate: (path: string) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ navigate }) => {
  const { user } = useAuth();
  const { programs, courses, modules, notes, formulas, questions, mockTests, contactMessages } = useData();

  const stats = [
    { label: 'Academic Programs', count: programs.length, icon: Layers, color: 'text-indigo-600', link: '/admin/courses' },
    { label: 'Courses / Subjects', count: courses.length, icon: BookOpen, color: 'text-blue-600', link: '/admin/courses' },
    { label: 'Curriculum Modules', count: modules.length, icon: Layers, color: 'text-violet-600', link: '/admin/courses' },
    { label: 'Revision Notes', count: notes.length, icon: FileText, color: 'text-emerald-600', link: '/admin/notes' },
    { label: 'Formula Sheets', count: formulas.length, icon: Calculator, color: 'text-amber-600', link: '/admin/formulas' },
    { label: 'Practice Questions', count: questions.length, icon: CheckSquare, color: 'text-cyan-600', link: '/admin/questions' },
    { label: 'Mock Test Blueprints', count: mockTests.length, icon: Clock, color: 'text-rose-600', link: '/admin/mock-tests' },
    { label: 'Feedback Inquiries', count: contactMessages.length, icon: Mail, color: 'text-purple-600', link: '/admin/messages' },
  ];

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-rose-600 dark:text-rose-400 uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            <span>Curriculum Content Management Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Admin Overview & Platform Health
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage course taxonomies, publish revision notes, maintain formula repositories, and review student feedback.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="danger" size="md">
            Admin Privileges Active
          </Badge>
          <Button
            id="admin-view-student-view"
            variant="outline"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            Switch to Student View
          </Button>
        </div>
      </div>

      {/* Database State Pill */}
      <div className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/60 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">Firestore & Local Database State Synced</h4>
            <p className="text-[11px] text-slate-500">All academic content changes immediately persist across browser and database sessions.</p>
          </div>
        </div>
        <Badge variant="success" size="sm">Online & Synced</Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <button
              key={idx}
              id={`admin-stat-${idx}`}
              onClick={() => navigate(stat.link)}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-400 dark:hover:border-indigo-700 transition-all text-left group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">{stat.label}</span>
                <Icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-slate-100">
                {stat.count}
              </div>
              <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium mt-1 flex items-center gap-1 group-hover:underline">
                <span>Manage</span>
                <ArrowRight className="w-3 h-3" />
              </div>
            </button>
          );
        })}
      </div>

      {/* Quick Publishing Actions & Recent Messages */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Quick Publishing Actions */}
        <div className="lg:col-span-6 space-y-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Plus className="w-4 h-4 text-indigo-600" />
            <span>Quick Resource Creation</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Button
              id="admin-qa-add-course"
              variant="outline"
              size="sm"
              className="w-full justify-start"
              icon={<BookOpen className="w-4 h-4 text-blue-600" />}
              onClick={() => navigate('/admin/courses')}
            >
              New Course / Subject
            </Button>

            <Button
              id="admin-qa-add-note"
              variant="outline"
              size="sm"
              className="w-full justify-start"
              icon={<FileText className="w-4 h-4 text-emerald-600" />}
              onClick={() => navigate('/admin/notes')}
            >
              Publish Study Note
            </Button>

            <Button
              id="admin-qa-add-formula"
              variant="outline"
              size="sm"
              className="w-full justify-start"
              icon={<Calculator className="w-4 h-4 text-amber-600" />}
              onClick={() => navigate('/admin/formulas')}
            >
              Add Formula Card
            </Button>

            <Button
              id="admin-qa-add-question"
              variant="outline"
              size="sm"
              className="w-full justify-start"
              icon={<CheckSquare className="w-4 h-4 text-cyan-600" />}
              onClick={() => navigate('/admin/questions')}
            >
              Add Practice Question
            </Button>

            <Button
              id="admin-qa-add-mock"
              variant="outline"
              size="sm"
              className="w-full justify-start sm:col-span-2"
              icon={<Clock className="w-4 h-4 text-rose-600" />}
              onClick={() => navigate('/admin/mock-tests')}
            >
              Create Mock Test Blueprint
            </Button>
          </div>
        </div>

        {/* Recent Feedback Submissions */}
        <div className="lg:col-span-6 space-y-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Mail className="w-4 h-4 text-purple-600" />
              <span>Recent Feedback Inquiries</span>
            </h3>
            <button
              id="admin-view-all-inquiries-btn"
              onClick={() => navigate('/admin/messages')}
              className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
            >
              View All ({contactMessages.length})
            </button>
          </div>

          {contactMessages.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-xs">
              No feedback submissions received yet.
            </div>
          ) : (
            <div className="space-y-3">
              {contactMessages.slice(0, 3).map((msg) => (
                <div
                  key={msg.id}
                  className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-slate-100">{msg.name}</span>
                      <Badge variant="secondary" size="sm">{msg.category}</Badge>
                    </div>
                    <p className="text-slate-500 truncate max-w-xs">{msg.subject}</p>
                  </div>
                  <Badge variant={msg.status === 'pending' ? 'warning' : 'success'} size="sm">
                    {msg.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};

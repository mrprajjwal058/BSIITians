import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  Mail, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Search, 
  MessageSquare, 
  Eye, 
  Filter,
  User,
  Check
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { ContactMessage } from '../../types';

export const AdminMessagesPage: React.FC = () => {
  const { contactMessages, updateMessageStatus, deleteContactMessage } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // View modal
  const [activeMessage, setActiveMessage] = useState<ContactMessage | null>(null);
  // Delete confirm
  const [messageToDelete, setMessageToDelete] = useState<ContactMessage | null>(null);

  const filteredMessages = contactMessages.filter(m => {
    const matchesSearch = m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          m.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          m.message.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || m.category === selectedCategory;
    const matchesStatus = selectedStatus === 'All' || m.status === selectedStatus;
    return matchesSearch && matchesCat && matchesStatus;
  });

  const handleStatusChange = async (msgId: string, status: 'pending' | 'reviewed' | 'replied') => {
    await updateMessageStatus(msgId, status);
    if (activeMessage && activeMessage.id === msgId) {
      setActiveMessage({ ...activeMessage, status });
    }
  };

  const handleConfirmDelete = async () => {
    if (messageToDelete) {
      await deleteContactMessage(messageToDelete.id);
      setMessageToDelete(null);
    }
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-purple-600 dark:text-purple-400 uppercase tracking-wider">
            <Mail className="w-4 h-4" />
            <span>Community Submissions</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Student Feedback & Inquiries
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Review correction reports, new resource requests, and general questions from learners.
          </p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="admin-messages-search"
            type="text"
            placeholder="Search inquiries..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            id="admin-messages-category-filter"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Categories</option>
            <option value="general">General</option>
            <option value="feedback">Feedback</option>
            <option value="resource_request">Resource Request</option>
            <option value="correction">Correction Report</option>
          </select>

          <select
            id="admin-messages-status-filter"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="reviewed">Reviewed</option>
            <option value="replied">Replied</option>
          </select>
        </div>
      </div>

      {/* Messages List */}
      {filteredMessages.length === 0 ? (
        <EmptyState
          id="empty-admin-messages"
          icon={Mail}
          title="No feedback submissions found."
          description="Inquiries submitted via the Contact page will appear here."
        />
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-3 px-4 font-bold">Date</th>
                  <th className="py-3 px-4 font-bold">Sender</th>
                  <th className="py-3 px-4 font-bold">Category</th>
                  <th className="py-3 px-4 font-bold">Subject</th>
                  <th className="py-3 px-4 font-bold">Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredMessages.map((msg) => (
                  <tr key={msg.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px] whitespace-nowrap">
                      {new Date(msg.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">{msg.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{msg.email}</div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="secondary" size="sm">
                        {msg.category}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800 dark:text-slate-200 max-w-xs truncate">
                      {msg.subject}
                    </td>
                    <td className="py-3 px-4">
                      <select
                        id={`status-select-${msg.id}`}
                        value={msg.status}
                        onChange={(e) => handleStatusChange(msg.id, e.target.value as any)}
                        className={`px-2 py-1 rounded-lg text-[11px] font-semibold border ${
                          msg.status === 'pending'
                            ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                            : msg.status === 'reviewed'
                            ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                            : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                        }`}
                      >
                        <option value="pending">Pending</option>
                        <option value="reviewed">Reviewed</option>
                        <option value="replied">Replied</option>
                      </select>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          id={`view-msg-btn-${msg.id}`}
                          onClick={() => setActiveMessage(msg)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          title="View Message"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          id={`delete-msg-btn-${msg.id}`}
                          onClick={() => setMessageToDelete(msg)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                          title="Delete Message"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View Message Modal */}
      {activeMessage && (
        <Modal
          isOpen={!!activeMessage}
          onClose={() => setActiveMessage(null)}
          title={`Inquiry from ${activeMessage.name}`}
          maxWidth="md"
          id={`modal-msg-detail-${activeMessage.id}`}
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Sender Email:</span>
                <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{activeMessage.email}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Category:</span>
                <Badge variant="secondary" size="sm">{activeMessage.category}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Submitted At:</span>
                <span className="text-slate-700 dark:text-slate-300">{new Date(activeMessage.createdAt).toLocaleString()}</span>
              </div>
            </div>

            <div>
              <span className="block font-bold text-slate-900 dark:text-slate-100 mb-1">Subject:</span>
              <p className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-semibold">
                {activeMessage.subject}
              </p>
            </div>

            <div>
              <span className="block font-bold text-slate-900 dark:text-slate-100 mb-1">Message Body:</span>
              <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                {activeMessage.message}
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-slate-500">Status:</span>
                <select
                  value={activeMessage.status}
                  onChange={(e) => handleStatusChange(activeMessage.id, e.target.value as any)}
                  className="px-2 py-1 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  <option value="pending">Pending</option>
                  <option value="reviewed">Reviewed</option>
                  <option value="replied">Replied</option>
                </select>
              </div>

              <Button
                id="modal-msg-close-btn"
                variant="primary"
                size="sm"
                onClick={() => setActiveMessage(null)}
              >
                Done
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Message Confirmation */}
      <ConfirmDialog
        isOpen={!!messageToDelete}
        onClose={() => setMessageToDelete(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Inquiry Message"
        message="Are you sure you want to permanently delete this student inquiry?"
        confirmText="Delete Message"
        id="dialog-delete-msg"
      />

    </div>
  );
};

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { 
  FileText, 
  Calculator, 
  CheckSquare, 
  Clock, 
  Calendar, 
  Award, 
  TrendingUp, 
  ArrowRight, 
  BookOpen, 
  CheckCircle2, 
  BarChart2,
  Plus,
  Sparkles,
  Layers,
  ChevronRight,
  Play,
  FileQuestion,
  Sigma,
  Zap,
  Download,
  GraduationCap
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { LevelSwitcher } from '../../components/common/LevelSwitcher';
import { AcademicLevel } from '../../types';
import { CURATED_WEEKLY_NOTES } from '../../data/curatedNotesData';
import { RICH_FORMULA_SHEETS } from '../../data/formulasData';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';
import { getSubjectTheme } from '../../utils/subjectTheme';

interface DashboardPageProps {
  navigate: (path: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ navigate }) => {
  const { user } = useAuth();
  const { courses, notes, formulas, tasks, mockTests, attempts, questions } = useData();

  const [selectedLevel, setSelectedLevel] = useState<AcademicLevel | 'All'>('Foundation');

  // Filtered metrics by level
  const filteredNotesCount = CURATED_WEEKLY_NOTES.filter(n => selectedLevel === 'All' || n.level === selectedLevel).length + notes.length;
  const filteredFormulasCount = RICH_FORMULA_SHEETS.filter(f => selectedLevel === 'All' || f.level === selectedLevel).length + formulas.length;
  const filteredQuestionsCount = questions.filter(q => selectedLevel === 'All' || q.level === selectedLevel).length;
  const filteredMockTests = mockTests.filter(t => selectedLevel === 'All' || !t.level || t.level === selectedLevel);
  const filteredAttempts = attempts.filter(a => selectedLevel === 'All' || !a.level || a.level === selectedLevel);
  const availableSubjects = selectedLevel === 'All' ? ACADEMIC_SUBJECTS : ACADEMIC_SUBJECTS.filter(s => s.level === selectedLevel);

  const totalAttempts = filteredAttempts.length;
  const avgScore = totalAttempts > 0 
    ? Math.round(filteredAttempts.reduce((acc, a) => acc + a.percentage, 0) / totalAttempts) 
    : 0;
  const avgAccuracy = totalAttempts > 0
    ? Math.round(filteredAttempts.reduce((acc, a) => acc + a.accuracy, 0) / totalAttempts)
    : 0;

  // Dynamic calculated readiness % based on activity
  const readinessPercent = totalAttempts > 0 
    ? Math.min(98, Math.max(45, Math.round((avgScore * 0.5) + (avgAccuracy * 0.3) + Math.min(20, totalAttempts * 5))))
    : 85;

  const todayTasks = tasks.filter(t => {
    const taskDate = new Date(t.date).toDateString();
    const today = new Date().toDateString();
    return taskDate === today;
  });

  // Resolve a clean, valid candidate greeting name
  const validGreetingName = (() => {
    if (!user) return null;
    const raw = (user.name || (user as any).displayName || '').trim();
    if (!raw) return null;
    if (raw.includes('@')) return null;
    if (/\d/.test(raw)) return null;

    let clean = raw.replace(/\s*\((?:Admin|Student|Faculty|Guest)\)/gi, '').trim();
    clean = clean.replace(/\b(?:Admin|Student)\b/gi, '').trim();

    const lower = clean.toLowerCase();
    const disallowed = new Set(['student', 'admin', 'user', 'guest', 'candidate', 'anonymous', 'null', 'undefined']);
    if (disallowed.has(lower)) return null;

    const firstName = clean.split(/\s+/).filter(Boolean)[0];
    if (!firstName || disallowed.has(firstName.toLowerCase())) return null;
    if (!/^[\p{L}'-]+$/u.test(firstName)) return null;

    return firstName;
  })();

  const welcomeHeading = validGreetingName ? `Welcome back, ${validGreetingName}` : 'Welcome back';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0A0C10] text-slate-900 dark:text-slate-100 font-sans p-4 sm:p-6 lg:p-8 space-y-8 transition-colors">
      
      {/* 1. TOP STATUS BAR & HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-white/10">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold tracking-wider uppercase px-2.5 py-0.5 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-500/20 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
              IIT Madras BS Degree Portal
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {welcomeHeading}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {user?.programEnrolled || 'Data Science & Applications'} • {user?.currentTerm || 'Term 1 Active'}
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            id="dash-open-planner-btn"
            onClick={() => navigate('/study-planner')}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-white/10 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs"
          >
            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
            <span>Study Planner</span>
          </button>
          <button
            id="dash-browse-notes-btn"
            onClick={() => navigate('/notes')}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-lg shadow-indigo-600/25 transition-all active:scale-95"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Curated Notes (W1–12)</span>
          </button>
        </div>
      </div>

      {/* 2. HERO BANNER (Decluttered & Primary Action Highlight) */}
      <section className="relative rounded-3xl overflow-hidden p-6 sm:p-10 bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 shadow-lg">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-indigo-500/10 via-purple-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-500/20">
              Exam Preparation Hub
            </span>
            <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400">
              Term 1 to Term 8 Tracks
            </span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-950 dark:text-white">
            IIT Madras BS Degree <br />
            <span className="bg-gradient-to-r from-indigo-500 to-purple-500 bg-clip-text text-transparent">
              Academic Resource Hub
            </span>
          </h2>

          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-lg">
            Access verified Week 1–12 theory chapters, formula compendiums, timed CBT mock simulations, and 2021–2026 past papers.
          </p>

          <div className="pt-2 flex items-center gap-3 flex-wrap">
            <button
              id="hero-mock-tests-btn"
              onClick={() => navigate('/mock-tests')}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 ring-1 ring-purple-500/30 active:scale-95 transition-all"
            >
              <Clock className="w-4 h-4" />
              <span>Launch Timed CBT Mock</span>
            </button>
            <button
              id="hero-continue-learning-btn"
              onClick={() => navigate('/notes')}
              className="bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-800 dark:text-white border border-slate-200 dark:border-white/10 px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Continue Notes</span>
            </button>
          </div>
        </div>
      </section>

      {/* 3. GLOBAL LEVEL SWITCHER */}
      <div className="bg-white dark:bg-[#111318]/65 backdrop-blur-xl border border-slate-200 dark:border-white/10 p-2.5 rounded-2xl shadow-xs">
        <LevelSwitcher
          selectedLevel={selectedLevel}
          onSelectLevel={setSelectedLevel}
        />
      </div>

      {/* 4. MAIN TWO-COLUMN DASHBOARD GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Current Subjects Grid (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />
              <span>Current Subjects ({selectedLevel === 'All' ? 'All Levels' : `${selectedLevel}`})</span>
            </h3>
            <button
              id="dash-browse-all-courses-btn"
              onClick={() => navigate('/courses')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold flex items-center gap-1 transition-colors"
            >
              <span>View Full Directory</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Subjects Grid with DISTINCT COLOR ACCENTS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {availableSubjects.map((sub) => {
              const theme = getSubjectTheme(sub.name, sub.category);
              return (
                <div 
                  key={sub.id}
                  id={`subject-card-${sub.code}`}
                  className={`bg-white dark:bg-[#111318] border ${theme.cardBorder} ${theme.cardHoverBorder} p-5 rounded-2xl shadow-xs hover:shadow-md transition-all flex flex-col justify-between group`}
                >
                  <div className="space-y-3">
                    {/* Top Row: Code + Tags */}
                    <div className="flex justify-between items-start">
                      <span className={`text-xs font-mono font-bold ${theme.textClass}`}>
                        {sub.code}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400">
                          {sub.level}
                        </span>
                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${theme.badgeClass}`}>
                          {theme.categoryLabel}
                        </span>
                      </div>
                    </div>

                    {/* Title */}
                    <div>
                      <h4 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-500 dark:group-hover:text-indigo-300 transition-colors line-clamp-1">
                        {sub.name}
                      </h4>
                      <p className="text-slate-500 dark:text-slate-400 text-xs mt-1 line-clamp-1">
                        {theme.shortDesc}
                      </p>
                    </div>

                    {/* Punchy Keyword Badges */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {theme.tags.map(tag => (
                        <span key={tag} className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${theme.badgeClass}`}>
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-2 pt-4 mt-3 border-t border-slate-100 dark:border-white/5">
                    <button
                      id={`start-lesson-${sub.code}`}
                      onClick={() => navigate('/notes')}
                      className={`w-full py-2 rounded-xl bg-slate-50 dark:bg-white/5 hover:${theme.bgLight} ${theme.textClass} border border-slate-200 dark:border-white/10 flex items-center justify-center gap-1.5 text-xs font-bold transition-all`}
                    >
                      <span>Study Week 1–12 Notes</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center justify-between text-[11px] px-1 text-slate-500 dark:text-slate-400">
                      <button
                        onClick={() => navigate('/formulas')}
                        className="hover:text-indigo-500 dark:hover:text-indigo-300 transition-colors flex items-center gap-1"
                      >
                        <Calculator className="w-3 h-3 text-indigo-400" />
                        <span>Formulas</span>
                      </button>
                      <span>•</span>
                      <button
                        onClick={() => navigate('/practice')}
                        className="hover:text-emerald-500 dark:hover:text-emerald-300 transition-colors flex items-center gap-1"
                      >
                        <CheckSquare className="w-3 h-3 text-emerald-400" />
                        <span>PYQs</span>
                      </button>
                      <span>•</span>
                      <button
                        onClick={() => navigate('/mock-tests')}
                        className="hover:text-amber-500 dark:hover:text-amber-300 transition-colors flex items-center gap-1"
                      >
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>Mocks</span>
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>

          {/* Quick Curriculum Modules Grid */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-500" />
              <span>Curriculum Modules</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div 
                onClick={() => navigate('/notes')}
                className="p-4 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 hover:border-emerald-500/40 cursor-pointer transition-all group shadow-xs"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                    <FileText className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{filteredNotesCount} Files</span>
                </div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-emerald-400">Chapter Notes</h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Week 1–12 theory &amp; proofs</p>
              </div>

              <div 
                onClick={() => navigate('/formulas')}
                className="p-4 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 hover:border-amber-500/40 cursor-pointer transition-all group shadow-xs"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
                    <Calculator className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{filteredFormulasCount} Sheets</span>
                </div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-amber-400">Formula Cards</h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Theorems, limits &amp; rules</p>
              </div>

              <div 
                onClick={() => navigate('/practice')}
                className="p-4 rounded-2xl bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 hover:border-sky-500/40 cursor-pointer transition-all group shadow-xs"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-500 flex items-center justify-center">
                    <CheckSquare className="w-4 h-4" />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono font-bold">{filteredQuestionsCount} PYQs</span>
                </div>
                <h5 className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-sky-400">Practice Bank</h5>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">MCQ, MSQ &amp; NAT drills</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Sidebar Widgets (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Practice Zone Radial Progress Widget (Purple/Indigo Glow) */}
          <div className="bg-white dark:bg-[#111318] border border-indigo-500/30 p-6 rounded-3xl relative overflow-hidden shadow-xl shadow-indigo-500/5">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
            
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Practice Readiness</h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Qualifier &amp; Quiz 1 Target</p>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-300 border border-indigo-500/20">
                Active
              </span>
            </div>

            {/* Radial SVG Gauge */}
            <div className="flex flex-col items-center justify-center py-1">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full transform -rotate-90">
                  <circle 
                    cx="64" 
                    cy="64" 
                    r="52" 
                    stroke="currentColor" 
                    strokeWidth="8" 
                    fill="transparent" 
                    className="text-slate-100 dark:text-white/10" 
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="52"
                    stroke="currentColor"
                    strokeWidth="8"
                    fill="transparent"
                    className="text-indigo-500 drop-shadow-[0_0_8px_rgba(99,102,241,0.5)] transition-all duration-1000"
                    strokeDasharray="326"
                    strokeDashoffset={Math.round(326 - (326 * readinessPercent) / 100)}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-extrabold text-slate-900 dark:text-white">{readinessPercent}%</span>
                  <span className="text-[8px] uppercase text-slate-400 font-bold tracking-widest">Prepared</span>
                </div>
              </div>
            </div>

            {/* Quick Diagnostic Metrics */}
            <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-white/5 text-center">
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-white/5">
                <span className="text-[10px] text-slate-400 block">Tests</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">{totalAttempts}</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-white/5">
                <span className="text-[10px] text-slate-400 block">Accuracy</span>
                <span className="text-xs font-bold text-emerald-500">{avgAccuracy > 0 ? `${avgAccuracy}%` : '88%'}</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-white/5">
                <span className="text-[10px] text-slate-400 block">Streak</span>
                <span className="text-xs font-bold text-amber-500">{tasks.some(t => t.completed) ? '1d' : '0d'}</span>
              </div>
            </div>

            {/* Action Buttons (Glowing Primary CTA) */}
            <div className="grid grid-cols-2 gap-2.5 mt-4">
              <button 
                id="widget-btn-quizzes"
                onClick={() => navigate('/practice')}
                className="bg-slate-50 dark:bg-white/5 hover:bg-indigo-500/10 border border-slate-200 dark:border-white/10 p-3 rounded-xl flex flex-col items-center gap-1 transition-all text-slate-700 dark:text-slate-200"
              >
                <FileQuestion className="w-4 h-4 text-indigo-500" />
                <span className="text-[10px] font-bold uppercase tracking-tight">PYQ Drills</span>
              </button>
              <button 
                id="widget-btn-mocks"
                onClick={() => navigate('/mock-tests')}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white p-3 rounded-xl flex flex-col items-center gap-1 transition-all shadow-md shadow-indigo-600/20"
              >
                <Clock className="w-4 h-4 text-white" />
                <span className="text-[10px] font-bold uppercase tracking-tight">CBT Mocks</span>
              </button>
            </div>
          </div>

          {/* Formula Sheets Quick Access */}
          <div className="bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 p-5 rounded-3xl space-y-3 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sigma className="w-4 h-4 text-indigo-500" />
                <span>Formula Cheat Sheets</span>
              </h3>
              <button 
                onClick={() => navigate('/formulas')}
                className="text-[11px] text-indigo-500 hover:underline font-semibold"
              >
                View All
              </button>
            </div>

            <div className="space-y-1.5">
              {[
                { title: 'Mathematics', subtitle: 'Calculus & Linear Algebra', color: 'text-emerald-500' },
                { title: 'Statistics', subtitle: 'Bayes Theorem & Random Variables', color: 'text-amber-500' },
                { title: 'Python Syntax', subtitle: 'Data Structures & List Comprehensions', color: 'text-sky-500' },
                { title: 'Machine Learning', subtitle: 'Gradients & Loss Functions', color: 'text-purple-500' },
              ].map((item) => (
                <button
                  key={item.title}
                  onClick={() => navigate('/formulas')}
                  className="w-full flex justify-between items-center p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-white/5 text-xs text-slate-600 dark:text-slate-300 transition-all text-left"
                >
                  <div>
                    <span className={`font-bold block ${item.color}`}>{item.title}</span>
                    <span className="text-[10px] text-slate-400 block">{item.subtitle}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Today's Agenda Widget */}
          <div className="bg-white dark:bg-[#111318] border border-slate-200 dark:border-white/10 p-5 rounded-3xl space-y-3 shadow-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-white/5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-500" />
                <span>Today's Study Agenda</span>
              </h3>
              <button
                id="dash-add-task-btn"
                onClick={() => navigate('/study-planner')}
                className="text-[11px] text-indigo-500 hover:underline font-semibold flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Task</span>
              </button>
            </div>

            {todayTasks.length === 0 ? (
              <div className="text-center py-3 space-y-1">
                <p className="text-xs text-slate-400">No tasks logged for today.</p>
                <button
                  onClick={() => navigate('/study-planner')}
                  className="text-xs text-indigo-500 hover:underline font-semibold"
                >
                  Schedule revision in Planner →
                </button>
              </div>
            ) : (
              <div className="space-y-1.5">
                {todayTasks.map((t) => (
                  <div
                    key={t.id}
                    className="p-2 rounded-xl bg-slate-50 dark:bg-white/5 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${t.completed ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                      <span className={`truncate ${t.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200 font-medium'}`}>
                        {t.title}
                      </span>
                    </div>
                    <span className="text-[9px] uppercase font-bold text-slate-400 shrink-0 px-1.5 py-0.5 rounded bg-white dark:bg-white/10">
                      {t.priority}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* 5. FOOTER DISCLAIMER */}
      <footer className="pt-6 border-t border-slate-200 dark:border-white/10 text-center">
        <p className="text-[11px] text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Disclaimer: Prajjwal Study Hub is an independent student-driven learning portal and is not officially affiliated with or endorsed by IIT Madras.
        </p>
      </footer>

    </div>
  );
};

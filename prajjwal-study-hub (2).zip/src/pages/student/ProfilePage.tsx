import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { 
  User, 
  Mail, 
  ShieldCheck, 
  BookOpen, 
  Moon, 
  Sun, 
  LogOut, 
  CheckCircle2, 
  Sparkles,
  Calendar,
  Save,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';

interface ProfilePageProps {
  navigate: (path: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ navigate }) => {
  const { user, logout, updateUserProfile } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [name, setName] = useState(user?.name || '');
  const [programEnrolled, setProgramEnrolled] = useState(user?.programEnrolled || 'IIT Madras BS Degree — Foundation Level');
  const [currentTerm, setCurrentTerm] = useState(user?.currentTerm || 'Term 1');
  const [targetExam, setTargetExam] = useState(user?.targetExam || 'Upcoming Quiz 1 & End-Term');
  const [studyGoal, setStudyGoal] = useState(user?.studyGoal || 'Achieve S Grade in Mathematics & Statistics 1');
  
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    updateUserProfile({
      name,
      programEnrolled,
      currentTerm,
      targetExam,
      studyGoal,
    });
    setLoading(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
            <User className="w-4 h-4" />
            <span>Student Profile & Preferences</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Account & Learning Profile
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage your academic track, exam goals, and platform theme.
          </p>
        </div>

        <Button
          id="profile-logout-btn"
          variant="danger"
          size="sm"
          icon={<LogOut className="w-3.5 h-3.5" />}
          onClick={handleLogout}
        >
          Sign Out
        </Button>
      </div>

      {/* Profile Info Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
        
        {/* User Identity Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-xl font-black shadow-sm">
              {user?.name?.charAt(0).toUpperCase() || 'S'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">{user?.name}</h3>
                <Badge variant={user?.role === 'admin' ? 'danger' : 'primary'} size="sm">
                  {user?.role === 'admin' ? 'Platform Admin' : 'Verified Student'}
                </Badge>
              </div>
              <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span>{user?.email}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              id="profile-theme-toggle-btn"
              variant="outline"
              size="sm"
              icon={theme === 'light' ? <Sun className="w-3.5 h-3.5 text-amber-500" /> : <Moon className="w-3.5 h-3.5 text-indigo-400" />}
              onClick={toggleTheme}
            >
              {theme === 'light' ? 'Light Mode Active' : 'Dark Mode Active'}
            </Button>
          </div>
        </div>

        {/* Edit Form */}
        <form onSubmit={handleSave} className="space-y-4 pt-2">
          {savedSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Profile preferences successfully updated!</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="profile-name" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Display Name
              </label>
              <input
                id="profile-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label htmlFor="profile-email-readonly" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Email Address (Primary Identity)
              </label>
              <input
                id="profile-email-readonly"
                type="email"
                value={user?.email || ''}
                disabled
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/40 text-slate-500 cursor-not-allowed"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="profile-program" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Program Enrolled
              </label>
              <input
                id="profile-program"
                type="text"
                value={programEnrolled}
                onChange={(e) => setProgramEnrolled(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label htmlFor="profile-term" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Current Term
              </label>
              <select
                id="profile-term"
                value={currentTerm}
                onChange={(e) => setCurrentTerm(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Term 1">Term 1 (Foundation)</option>
                <option value="Term 2">Term 2 (Foundation)</option>
                <option value="Term 3">Term 3 (Foundation)</option>
                <option value="Diploma Term 1">Diploma Term 1</option>
                <option value="Diploma Term 2">Diploma Term 2</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="profile-target-exam" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Target Examination Target
              </label>
              <input
                id="profile-target-exam"
                type="text"
                placeholder="e.g. End-Term Exams September"
                value={targetExam}
                onChange={(e) => setTargetExam(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label htmlFor="profile-goal" className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Study Goal / Academic Milestone
              </label>
              <input
                id="profile-goal"
                type="text"
                placeholder="e.g. Master week 1-4 probability proofs"
                value={studyGoal}
                onChange={(e) => setStudyGoal(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <Button
              id="profile-save-btn"
              type="submit"
              variant="primary"
              size="md"
              loading={loading}
              icon={<Save className="w-4 h-4" />}
            >
              Save Profile Preferences
            </Button>
          </div>
        </form>

      </div>

      {/* Footer Disclaimer Note */}
      <footer className="pt-8 mt-12 border-t border-slate-200/80 dark:border-slate-800 text-center">
        <p className="text-xs text-slate-400 dark:text-slate-500 max-w-3xl mx-auto leading-relaxed">
          Disclaimer of Non-Affiliation: Prajjwal Study Hub is an independent student-created learning platform and is NOT affiliated with, endorsed by, sponsored by, or officially associated with IIT Madras or the official BS Degree administration.
        </p>
      </footer>

    </div>
  );
};

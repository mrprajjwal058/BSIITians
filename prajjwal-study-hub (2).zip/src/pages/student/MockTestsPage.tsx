import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  Clock, 
  Search, 
  HelpCircle, 
  Sparkles, 
  CheckCircle2, 
  FileText, 
  Award, 
  PlayCircle, 
  RotateCcw,
  BarChart2,
  GraduationCap,
  Layers,
  Cpu,
  BookOpen,
  Filter,
  CheckSquare,
  Hash,
  Activity,
  Download,
  FileDown,
  Printer,
  ArrowLeft,
  Calendar,
  Code2,
  Tag,
  Check,
  ChevronRight,
  TrendingUp,
  BrainCircuit,
  SlidersHorizontal
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { EmptyState } from '../../components/common/EmptyState';
import { CBTExamModal } from '../../components/cbt/CBTExamModal';
import { MockTest, Question, AcademicLevel, AcademicSubLevel, ExamCategory, TestAttempt } from '../../types';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';
import { downloadQuestionPaperPdf, downloadSolutionsPdf } from '../../utils/pdfExport';
import { getSubjectTheme } from '../../utils/subjectTheme';

interface MockTestsPageProps {
  navigate: (path: string) => void;
}

export const MockTestsPage: React.FC<MockTestsPageProps> = ({ navigate }) => {
  const { mockTests, questions, courses, attempts, recordTestAttempt } = useData();
  const { user } = useAuth();

  // Multi-Tier Hierarchy Filter State
  const [selectedSubLevel, setSelectedSubLevel] = useState<AcademicSubLevel | 'All'>('All');
  const [selectedExamCategory, setSelectedExamCategory] = useState<ExamCategory | 'All'>('All');
  const [selectedTermYear, setSelectedTermYear] = useState<string>('All');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Active CBT Exam session & Blueprint modal
  const [activeCbtTest, setActiveCbtTest] = useState<MockTest | null>(null);
  const [activeBlueprint, setActiveBlueprint] = useState<MockTest | null>(null);

  // Available subjects for the active sub-level
  const availableSubjects = useMemo(() => {
    if (selectedSubLevel === 'All') return ACADEMIC_SUBJECTS;
    if (selectedSubLevel === 'Foundation') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'Foundation');
    }
    if (selectedSubLevel === 'Diploma in Programming') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'Diploma in Programming');
    }
    if (selectedSubLevel === 'Diploma in Data Science') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'Diploma in Data Science');
    }
    if (selectedSubLevel === 'BSc Degree Level') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'BSc Degree Level' || s.subLevel === 'Degree');
    }
    if (selectedSubLevel === 'BS Degree Level') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'BS Degree Level');
    }
    if (selectedSubLevel === 'Degree / BS Level' || selectedSubLevel === 'Degree') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'BSc Degree Level' || s.subLevel === 'BS Degree Level' || s.subLevel === 'Degree' || s.level === 'Degree' || s.level === 'BS Degree');
    }
    return ACADEMIC_SUBJECTS;
  }, [selectedSubLevel]);

  // Unique list of term years from existing mock tests
  const availableTermYears = useMemo(() => {
    const years = new Set<string>();
    mockTests.forEach(t => {
      if (t.termYear) years.add(t.termYear);
    });
    return Array.from(years).sort().reverse();
  }, [mockTests]);

  // Multi-Tier Filtered mock tests
  const filteredTests = useMemo(() => {
    return mockTests.filter(t => {
      if (!t.published) return false;
      
      // Sub-Level / Academic Tier filter
      if (selectedSubLevel !== 'All') {
        if (t.subLevel) {
          if (selectedSubLevel === 'BSc Degree Level') {
            if (t.subLevel !== 'BSc Degree Level' && t.subLevel !== 'Degree') return false;
          } else if (selectedSubLevel === 'BS Degree Level') {
            if (t.subLevel !== 'BS Degree Level') return false;
          } else if (selectedSubLevel === 'Degree / BS Level' || selectedSubLevel === 'Degree') {
            if (t.subLevel !== 'BSc Degree Level' && t.subLevel !== 'BS Degree Level' && t.subLevel !== 'Degree' && t.level !== 'Degree' && t.level !== 'BS Degree') return false;
          } else if (t.subLevel !== selectedSubLevel) {
            return false;
          }
        } else if (t.level) {
          if (selectedSubLevel === 'Foundation' && t.level !== 'Foundation') return false;
          if ((selectedSubLevel === 'Diploma in Programming' || selectedSubLevel === 'Diploma in Data Science') && t.level !== 'Diploma') return false;
          if (selectedSubLevel === 'BSc Degree Level' && t.level !== 'Degree') return false;
          if (selectedSubLevel === 'BS Degree Level' && t.level !== 'BS Degree') return false;
          if ((selectedSubLevel === 'Degree / BS Level' || selectedSubLevel === 'Degree') && t.level !== 'Degree' && t.level !== 'BS Degree') return false;
        }
      }

      // Exam Category / Type filter (Quiz 1, Quiz 2, End Term, OPPE, Qualifier)
      if (selectedExamCategory !== 'All') {
        const matchesExamType = t.examCategory === selectedExamCategory || t.type === selectedExamCategory;
        if (!matchesExamType) return false;
      }

      // Term / Year filter
      if (selectedTermYear !== 'All') {
        if (t.termYear !== selectedTermYear && !t.title.includes(selectedTermYear)) {
          return false;
        }
      }

      // Subject filter
      if (selectedSubject !== 'All') {
        const matchSubj = t.subject?.toLowerCase().includes(selectedSubject.toLowerCase()) ||
                          t.courseId === selectedSubject ||
                          t.title.toLowerCase().includes(selectedSubject.toLowerCase());
        if (!matchSubj) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = t.title.toLowerCase().includes(q);
        const matchSubj = t.subject?.toLowerCase().includes(q);
        const matchDesc = t.description?.toLowerCase().includes(q);
        if (!matchTitle && !matchSubj && !matchDesc) return false;
      }

      return true;
    });
  }, [mockTests, selectedSubLevel, selectedExamCategory, selectedTermYear, selectedSubject, searchQuery]);

  // Handle launching a CBT test
  const handleLaunchTest = (test: MockTest) => {
    setActiveCbtTest(test);
  };

  // Get question objects for active test
  const getQuestionsForTest = (test: MockTest): Question[] => {
    if (test.questionIds && test.questionIds.length > 0) {
      const found = questions.filter(q => test.questionIds?.includes(q.id));
      if (found.length > 0) return found;
    }
    // Fallback: match by course or level
    const levelQuestions = questions.filter(q => {
      if (test.subLevel && q.subLevel && q.subLevel !== test.subLevel) return false;
      if (test.level && q.level && q.level !== test.level) return false;
      if (test.courseId && q.courseId === test.courseId) return true;
      return true;
    });
    return levelQuestions.length > 0 ? levelQuestions.slice(0, test.totalQuestions || 6) : questions.slice(0, 6);
  };

  const handleTestComplete = (result: {
    score: number;
    totalMarks: number;
    percentage: number;
    accuracy: number;
    timeSpentSeconds: number;
    correctAnswers: number;
    incorrectAnswers: number;
    unattempted: number;
  }) => {
    if (activeCbtTest) {
      const course = courses.find(c => c.id === activeCbtTest.courseId);
      recordTestAttempt({
        testId: activeCbtTest.id,
        mockTestId: activeCbtTest.id,
        testTitle: activeCbtTest.title,
        level: activeCbtTest.level,
        subLevel: activeCbtTest.subLevel,
        examCategory: activeCbtTest.examCategory,
        courseId: activeCbtTest.courseId,
        courseTitle: course ? course.title : (activeCbtTest.subject || 'IIT Madras BS'),
        score: result.score,
        totalMarks: result.totalMarks,
        percentage: result.percentage,
        accuracy: result.accuracy,
        timeSpentSeconds: result.timeSpentSeconds,
        totalQuestions: activeCbtTest.totalQuestions,
        correctAnswers: result.correctAnswers,
        incorrectAnswers: result.incorrectAnswers,
        unattempted: result.unattempted,
      });
    }
    setActiveCbtTest(null);
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-indigo-400 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <span className="text-slate-600">•</span>
            <div className="flex items-center gap-1 text-xs font-bold text-indigo-400 uppercase tracking-wider">
              <Clock className="w-3.5 h-3.5" />
              <span>IIT Madras BS CBT Mock Exam Engine</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            IIT Madras BS Mock Tests &amp; Quiz 1/2 CBT Simulator
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real Computer-Based Tests for Qualifier, Quiz 1, Quiz 2, and End-Term exams with real-time countdown timer, question palette, virtual scientific calculator, and performance analytics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="success" size="md">
            Exam Engine Active
          </Badge>
          <Button
            id="btn-goto-practice-hub"
            variant="outline"
            size="sm"
            onClick={() => navigate('/practice')}
            icon={<BookOpen className="w-3.5 h-3.5" />}
          >
            Practice PYQ Bank
          </Button>
        </div>
      </div>

      {/* 1. ACADEMIC SUB-LEVEL HIERARCHY SELECTOR */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>1. Select Academic Tier / Degree Level</span>
          </div>
          <span className="text-xs text-slate-400">
            {selectedSubLevel === 'All' ? 'Showing all curriculum tiers' : `${selectedSubLevel} Tier Active`}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
          {/* Foundation Level */}
          <button
            id="sublevel-btn-foundation"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'Foundation' ? 'All' : 'Foundation');
              setSelectedSubject('All');
            }}
            className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'Foundation'
                ? 'bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/30 shadow-lg'
                : 'bg-[#111318] border-white/10 hover:border-white/20 hover:bg-[#161920]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center font-bold text-xs border border-indigo-500/30">
                L1
              </div>
              <Badge variant="info" size="sm">Foundation</Badge>
            </div>
            <h3 className="font-bold text-sm text-white">Foundation Level</h3>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              Math 1 &amp; 2, Stats 1 &amp; 2, Computational Thinking, Python, English.
            </p>
          </button>

          {/* Diploma in Programming */}
          <button
            id="sublevel-btn-diploma-prog"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'Diploma in Programming' ? 'All' : 'Diploma in Programming');
              setSelectedSubject('All');
            }}
            className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'Diploma in Programming'
                ? 'bg-purple-950/40 border-purple-500 ring-2 ring-purple-500/30 shadow-lg'
                : 'bg-[#111318] border-white/10 hover:border-white/20 hover:bg-[#161920]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-xs border border-purple-500/30">
                L2
              </div>
              <Badge variant="warning" size="sm">Programming</Badge>
            </div>
            <h3 className="font-bold text-sm text-white">Diploma in Programming</h3>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              Java, DBMS, PDSA, App Dev 1 &amp; 2, System Commands (OPPE).
            </p>
          </button>

          {/* Diploma in Data Science */}
          <button
            id="sublevel-btn-diploma-ds"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'Diploma in Data Science' ? 'All' : 'Diploma in Data Science');
              setSelectedSubject('All');
            }}
            className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'Diploma in Data Science'
                ? 'bg-cyan-950/40 border-cyan-500 ring-2 ring-cyan-500/30 shadow-lg'
                : 'bg-[#111318] border-white/10 hover:border-white/20 hover:bg-[#161920]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold text-xs border border-cyan-500/30">
                L2
              </div>
              <Badge variant="success" size="sm">Data Science</Badge>
            </div>
            <h3 className="font-bold text-sm text-white">Diploma in Data Science</h3>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              MLF, MLP, BDM, Tools in DS, Business Analytics, Math for ML.
            </p>
          </button>

          {/* BSc Degree Level (3-Year Exit) */}
          <button
            id="sublevel-btn-bsc-degree"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'BSc Degree Level' ? 'All' : 'BSc Degree Level');
              setSelectedSubject('All');
            }}
            className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'BSc Degree Level'
                ? 'bg-purple-950/40 border-purple-500 ring-2 ring-purple-500/30 shadow-lg'
                : 'bg-[#111318] border-white/10 hover:border-white/20 hover:bg-[#161920]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-xs border border-purple-500/30">
                L3
              </div>
              <Badge variant="default" size="sm">BSc Track</Badge>
            </div>
            <h3 className="font-bold text-sm text-white">BSc Degree Level</h3>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              Terms 6-8: DL, AI Search, Speech/NLP, Software Testing, Big Data.
            </p>
          </button>

          {/* BS Degree Level (4th-Year Track) */}
          <button
            id="sublevel-btn-bs-degree"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'BS Degree Level' ? 'All' : 'BS Degree Level');
              setSelectedSubject('All');
            }}
            className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'BS Degree Level'
                ? 'bg-rose-950/40 border-rose-500 ring-2 ring-rose-500/30 shadow-lg'
                : 'bg-[#111318] border-white/10 hover:border-white/20 hover:bg-[#161920]'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-300 flex items-center justify-center font-bold text-xs border border-rose-500/30">
                L4
              </div>
              <Badge variant="danger" size="sm">BS 4th Year</Badge>
            </div>
            <h3 className="font-bold text-sm text-white">BS Degree Level</h3>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              Terms 9-12: GenAI, RL, Cloud Arch, Robotics AI, Capstone Viva.
            </p>
          </button>
        </div>
      </div>

      {/* 2. EXAM CATEGORY & TERM YEAR FILTER BAR */}
      <div className="p-4 rounded-2xl bg-[#111318] border border-white/10 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <SlidersHorizontal className="w-4 h-4 text-indigo-400" />
            <span>2. Exam Category, Term &amp; Subject Filters</span>
          </div>
          <span className="text-xs text-slate-400">
            {filteredTests.length} Tests Available
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="cbt-search-input"
              type="text"
              placeholder="Search by test title or code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-white/10 bg-[#161920] text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Exam Category Filter */}
          <div>
            <select
              id="cbt-category-filter"
              value={selectedExamCategory}
              onChange={(e) => setSelectedExamCategory(e.target.value as any)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-[#161920] text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold"
            >
              <option value="All" className="bg-[#111318] text-white">All Exam Types (Quiz 1, 2, End Term, OPPE)</option>
              <option value="Qualifier Mock" className="bg-[#111318] text-white">Qualifier Mock Exam</option>
              <option value="Quiz 1" className="bg-[#111318] text-white">Quiz 1 (In-term 1)</option>
              <option value="Quiz 2" className="bg-[#111318] text-white">Quiz 2 (In-term 2)</option>
              <option value="End Term" className="bg-[#111318] text-white">End Term Comprehensive Exam</option>
              <option value="OPPE 1" className="bg-[#111318] text-white">OPPE 1 (Programming Exam 1)</option>
              <option value="OPPE 2" className="bg-[#111318] text-white">OPPE 2 (Programming Exam 2)</option>
            </select>
          </div>

          {/* Academic Term / Year Filter */}
          <div>
            <select
              id="cbt-term-filter"
              value={selectedTermYear}
              onChange={(e) => setSelectedTermYear(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-[#161920] text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold"
            >
              <option value="All" className="bg-[#111318] text-white">All Academic Terms (2021 - 2026)</option>
              {availableTermYears.map(yr => (
                <option key={yr} value={yr} className="bg-[#111318] text-white">{yr} Term</option>
              ))}
              <option value="Jan 2026" className="bg-[#111318] text-white">Jan 2026 Term</option>
              <option value="Sept 2025" className="bg-[#111318] text-white">Sept 2025 Term</option>
              <option value="May 2025" className="bg-[#111318] text-white">May 2025 Term</option>
              <option value="Jan 2025" className="bg-[#111318] text-white">Jan 2025 Term</option>
              <option value="Sept 2024" className="bg-[#111318] text-white">Sept 2024 Term</option>
            </select>
          </div>

          {/* Specific Subject Filter */}
          <div>
            <select
              id="cbt-subject-filter"
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-white/10 bg-[#161920] text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold"
            >
              <option value="All" className="bg-[#111318] text-white">All Subjects ({selectedSubLevel === 'All' ? 'All Tiers' : selectedSubLevel})</option>
              {availableSubjects.map(s => (
                <option key={s.id} value={s.name} className="bg-[#111318] text-white">{s.code}: {s.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 3. CBT MOCK TESTS GRID */}
      {filteredTests.length === 0 ? (
        <EmptyState
          id="empty-mock-tests"
          icon={Clock}
          title="No mock exams match your selected filters."
          description="Try selecting a different academic level, resetting the exam category, or clearing the search query."
          actionText="Reset All Filters"
          onAction={() => {
            setSelectedSubLevel('All');
            setSelectedExamCategory('All');
            setSelectedTermYear('All');
            setSelectedSubject('All');
            setSearchQuery('');
          }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTests.map((test) => {
            const course = courses.find(c => c.id === test.courseId);
            const testQuestions = getQuestionsForTest(test);
            const isOPPE = test.examCategory?.includes('OPPE') || test.type?.includes('OPPE');
            const theme = getSubjectTheme(test.subject || test.title);

            return (
              <div
                key={test.id}
                id={`test-card-${test.id}`}
                className={`p-6 rounded-2xl bg-[#111318] border ${theme.cardBorder} hover:border-indigo-500/50 shadow-lg transition-all flex flex-col justify-between group`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md border ${theme.badgeClass}`}>
                      {test.subject || 'Core'}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/10">
                      {test.examCategory || test.type}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white mb-1.5 leading-snug group-hover:text-indigo-300 transition-colors">
                    {test.title}
                  </h3>

                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
                    <span className={theme.textClass}>{test.subject}</span>
                    {test.termYear && (
                      <>
                        <span>•</span>
                        <span className="font-semibold text-purple-400 font-mono">{test.termYear}</span>
                      </>
                    )}
                  </div>

                  {/* Exam Key Metrics */}
                  <div className="grid grid-cols-3 gap-2 py-3 border-y border-white/10 text-center my-3">
                    <div className="p-2 rounded-xl bg-[#161920] border border-white/5">
                      <span className="block text-xs font-bold text-white">
                        {test.durationMinutes}m
                      </span>
                      <span className="text-[10px] text-slate-400">Duration</span>
                    </div>
                    <div className="p-2 rounded-xl bg-[#161920] border border-white/5">
                      <span className="block text-xs font-bold text-white">
                        {testQuestions.length || test.totalQuestions}
                      </span>
                      <span className="text-[10px] text-slate-400">Questions</span>
                    </div>
                    <div className="p-2 rounded-xl bg-[#161920] border border-white/5">
                      <span className="block text-xs font-bold text-white">
                        {test.totalMarks}
                      </span>
                      <span className="text-[10px] text-slate-400">Max Marks</span>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-400 mb-4">
                    <div className="flex items-center justify-between">
                      <span>Passing Benchmark:</span>
                      <span className="font-bold text-slate-200">
                        {test.passingMarks ? `${test.passingMarks} Marks (40%)` : '40% Marks'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Format:</span>
                      <span className="font-medium text-slate-200">
                        {isOPPE ? 'Python Code & Test Cases' : 'MCQ, MSQ & NAT'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 pt-3 border-t border-white/10">
                  <Button
                    id={`btn-launch-test-${test.id}`}
                    variant="primary"
                    size="md"
                    className="w-full justify-center shadow-lg shadow-indigo-600/20 active:scale-95 transition-all"
                    onClick={() => handleLaunchTest(test)}
                    icon={isOPPE ? <Code2 className="w-4 h-4" /> : <PlayCircle className="w-4 h-4" />}
                  >
                    {isOPPE ? 'Launch OPPE Runner' : 'Start CBT Mock Exam'}
                  </Button>

                  <div className="flex items-center gap-2">
                    <Button
                      id={`btn-blueprint-${test.id}`}
                      variant="outline"
                      size="sm"
                      className="flex-1 justify-center text-xs"
                      onClick={() => setActiveBlueprint(test)}
                      icon={<HelpCircle className="w-3.5 h-3.5 text-indigo-600" />}
                    >
                      Blueprint
                    </Button>
                    <Button
                      id={`btn-pdf-paper-${test.id}`}
                      variant="ghost"
                      size="sm"
                      className="flex-1 justify-center text-xs"
                      onClick={() => downloadQuestionPaperPdf(test, testQuestions, user?.name || 'Candidate')}
                      icon={<FileDown className="w-3.5 h-3.5 text-slate-500" />}
                    >
                      PDF Paper
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Blueprint & Exam Pattern Modal */}
      {activeBlueprint && (
        <Modal
          isOpen={true}
          onClose={() => setActiveBlueprint(null)}
          title={`Exam Pattern & Blueprint: ${activeBlueprint.title}`}
          size="lg"
        >
          <div className="space-y-6">
            <div className="p-4 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-xs text-indigo-950 dark:text-indigo-200">
              <div className="font-bold mb-1 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                IIT Madras BS Official Evaluation Policy
              </div>
              <p className="leading-relaxed">
                This Computer-Based Test simulates the exact grading structure and user interface of IIT Madras in-term and qualifier exams.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <div className="text-xs text-slate-400">Total Duration</div>
                <div className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">{activeBlueprint.durationMinutes} mins</div>
              </div>
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <div className="text-xs text-slate-400">Total Marks</div>
                <div className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">{activeBlueprint.totalMarks} M</div>
              </div>
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <div className="text-xs text-slate-400">Passing Score</div>
                <div className="text-lg font-bold text-emerald-600 mt-0.5">{activeBlueprint.passingMarks || 40} M</div>
              </div>
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
                <div className="text-xs text-slate-400">Term / Year</div>
                <div className="text-lg font-bold text-indigo-600 mt-0.5">{activeBlueprint.termYear || 'Current'}</div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">Question Types & Grading Schema</h4>
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-indigo-100 dark:bg-indigo-950 text-indigo-600 font-bold flex items-center justify-center text-[10px]">MCQ</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Single Choice Questions</span>
                  </div>
                  <span className="text-slate-500">+2 Marks / 0 Negative</span>
                </div>
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-purple-100 dark:bg-purple-950 text-purple-600 font-bold flex items-center justify-center text-[10px]">MSQ</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Multiple Select Questions</span>
                  </div>
                  <span className="text-slate-500">+3 Marks (Partial marking / No negative)</span>
                </div>
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-600 font-bold flex items-center justify-center text-[10px]">NAT</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Numerical Answer Type</span>
                  </div>
                  <span className="text-slate-500">+3 Marks (Tolerance range supported)</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <Button
                id="btn-close-blueprint"
                variant="outline"
                size="sm"
                onClick={() => setActiveBlueprint(null)}
              >
                Close
              </Button>
              <Button
                id="btn-launch-from-blueprint"
                variant="primary"
                size="sm"
                onClick={() => {
                  const testToLaunch = activeBlueprint;
                  setActiveBlueprint(null);
                  handleLaunchTest(testToLaunch);
                }}
                icon={<PlayCircle className="w-4 h-4" />}
              >
                Start Test Now
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* CBT Active Exam Modal */}
      {activeCbtTest && (
        <CBTExamModal
          test={activeCbtTest}
          questions={getQuestionsForTest(activeCbtTest)}
          userName={user?.name || 'Candidate'}
          onClose={() => setActiveCbtTest(null)}
          onComplete={handleTestComplete}
        />
      )}
    </div>
  );
};

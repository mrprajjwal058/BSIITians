import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  Calculator, 
  Search, 
  Bookmark, 
  Zap,
  ArrowLeft,
  FileText,
  FileDown,
  BookOpen,
  Sparkles,
  Layers,
  RotateCcw
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { EmptyState } from '../../components/common/EmptyState';
import { LevelSwitcher } from '../../components/common/LevelSwitcher';
import { NotebookFormulaCard } from '../../components/common/NotebookFormulaCard';
import { RICH_FORMULA_SHEETS, RichFormulaCard } from '../../data/formulasData';
import { AcademicLevel } from '../../types';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';
import { downloadFormulaSheetPdf } from '../../utils/pdfExport';

interface FormulasPageProps {
  navigate: (path: string) => void;
}

export const FormulasPage: React.FC<FormulasPageProps> = ({ navigate }) => {
  const { toggleBookmark, isBookmarked } = useData();
  const { user } = useAuth();

  const [selectedLevel, setSelectedLevel] = useState<AcademicLevel | 'All'>('Foundation');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCourseId, setSelectedCourseId] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [rapidRevisionMode, setRapidRevisionMode] = useState<boolean>(false);
  const [activeViewMode, setActiveViewMode] = useState<'all' | 'bookmarked'>('all');

  const categories = [
    'All',
    'Coordinate Geometry',
    'Calculus',
    'Linear Algebra',
    'Probability',
    'Statistics',
    'Algorithms',
    'Machine Learning',
    'Deep Learning',
    'Software Engineering'
  ];

  // Available subjects for the level
  const availableSubjects = selectedLevel === 'All'
    ? ACADEMIC_SUBJECTS
    : ACADEMIC_SUBJECTS.filter(s => s.level === selectedLevel);

  // Filter formula cards
  const filteredRichFormulas = RICH_FORMULA_SHEETS.filter(f => {
    if (activeViewMode === 'bookmarked' && !isBookmarked('formula', f.id)) return false;
    if (selectedLevel !== 'All' && f.level !== selectedLevel) return false;
    if (selectedCategory !== 'All' && f.category !== selectedCategory) return false;
    if (selectedCourseId !== 'All' && f.courseId !== selectedCourseId) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = f.title.toLowerCase().includes(q);
      const matchFormula = f.formula.toLowerCase().includes(q);
      const matchExplanation = f.explanation.toLowerCase().includes(q);
      const matchNote = f.handwrittenNote?.toLowerCase().includes(q) || false;
      const matchTags = f.tags.some(t => t.toLowerCase().includes(q));
      if (!matchTitle && !matchFormula && !matchExplanation && !matchNote && !matchTags) return false;
    }
    return true;
  });

  const handleDownloadFormulaSheetPdf = () => {
    if (filteredRichFormulas.length === 0) return;
    const categoryTitle = selectedCategory !== 'All' ? `${selectedCategory} Formulas` : 'Comprehensive Cheat Sheet';
    const subtitle = selectedCourseId !== 'All' 
      ? `Course: ${selectedCourseId}` 
      : `${selectedLevel} Curriculum Repository`;
      
    downloadFormulaSheetPdf(
      filteredRichFormulas,
      `${categoryTitle} • ${subtitle}`,
      selectedLevel === 'All' ? 'Foundation' : selectedLevel,
      user?.name || 'Prajjwal Student'
    );
  };

  const handleDownloadSingleCardPdf = (card: RichFormulaCard) => {
    downloadFormulaSheetPdf(
      [card],
      `${card.title} (${card.courseCode})`,
      card.level,
      user?.name || 'Prajjwal Student'
    );
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* 1. Header with Breadcrumbs & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-indigo-400 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <span className="text-slate-600">•</span>
            <div className="flex items-center gap-1 text-xs font-bold text-amber-400 uppercase tracking-wider">
              <Calculator className="w-3.5 h-3.5" />
              <span>IIT Madras BS Formula Sheets &amp; Cheatsheets</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            IIT Madras BS Formula Sheets &amp; Revision Compendium
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            High-yield LaTeX formulas, theorem derivations, variable breakdowns, and exam tips for Mathematics 1 &amp; 2, Statistics 1 &amp; 2, and Machine Learning.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Rapid Mode Toggle */}
          <button
            onClick={() => setRapidRevisionMode(!rapidRevisionMode)}
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all border ${
              rapidRevisionMode
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md font-extrabold'
                : 'bg-[#161920] text-slate-300 border-white/10 hover:bg-white/5 hover:text-white'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${rapidRevisionMode ? 'fill-current' : ''}`} />
            <span>{rapidRevisionMode ? 'Rapid Mode (Active)' : 'Rapid Mode'}</span>
          </button>

          {/* Download PDF Button */}
          <Button
            id="formula-download-pdf-top"
            variant="primary"
            size="sm"
            onClick={handleDownloadFormulaSheetPdf}
            icon={<FileDown className="w-3.5 h-3.5" />}
          >
            Download PDF
          </Button>

          {/* Link to Notes */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/notes')}
            icon={<FileText className="w-3.5 h-3.5" />}
          >
            Study Notes
          </Button>
        </div>
      </div>

      {/* 2. Global Level Switcher */}
      <LevelSwitcher
        selectedLevel={selectedLevel}
        onSelectLevel={(lvl) => {
          setSelectedLevel(lvl);
          setSelectedCourseId('All');
          setSelectedCategory('All');
        }}
      />

      {/* 3. Filter and Search Controls */}
      <div className="p-4 rounded-2xl bg-[#111318] border border-white/10 shadow-lg space-y-4">
        
        {/* Search & Subject Select */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="formula-search-input"
              type="text"
              placeholder="Search formulas, variables, theorems..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-white/10 bg-[#161920] text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {/* View Mode Toggle: All vs Bookmarked */}
            <div className="flex items-center gap-1 p-1 bg-[#161920] border border-white/10 rounded-xl">
              <button
                onClick={() => setActiveViewMode('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeViewMode === 'all'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                All Cards
              </button>
              <button
                onClick={() => setActiveViewMode('bookmarked')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                  activeViewMode === 'bookmarked'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Bookmark className="w-3 h-3" />
                <span>Saved</span>
              </button>
            </div>

            {/* Subject Select */}
            <select
              id="formula-subject-select"
              value={selectedCourseId}
              onChange={(e) => setSelectedCourseId(e.target.value)}
              className="px-3 py-2 rounded-xl border border-white/10 bg-[#161920] text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="All">All Subjects ({availableSubjects.length})</option>
              {availableSubjects.map((s) => (
                <option key={s.id} value={s.id} className="bg-[#111318] text-white">
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                  : 'bg-[#161920] border border-white/10 text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Formulas Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              {activeViewMode === 'bookmarked' ? 'Bookmarked Formulas' : `${selectedCategory === 'All' ? 'Curated Formulas' : selectedCategory} (${filteredRichFormulas.length})`}
            </h2>
          </div>

          {filteredRichFormulas.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDownloadFormulaSheetPdf}
              icon={<FileDown className="w-3.5 h-3.5" />}
            >
              Download Cheat Sheet (PDF)
            </Button>
          )}
        </div>

        {filteredRichFormulas.length === 0 ? (
          <EmptyState
            icon={<Calculator className="w-10 h-10 text-slate-400" />}
            title="No Formulas Found"
            description="Try selecting a different level, category, or clearing your search term."
            action={
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSelectedLevel('All');
                  setSelectedCategory('All');
                  setSelectedCourseId('All');
                  setSearchQuery('');
                  setActiveViewMode('all');
                }}
                icon={<RotateCcw className="w-3.5 h-3.5" />}
              >
                Reset All Filters
              </Button>
            }
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredRichFormulas.map((card) => (
              <NotebookFormulaCard
                key={card.id}
                card={card}
                isBookmarked={isBookmarked('formula', card.id)}
                onToggleBookmark={() => toggleBookmark('formula', card.id, card.title, card.courseTitle)}
                onDownloadPdf={() => handleDownloadSingleCardPdf(card)}
                rapidMode={rapidRevisionMode}
              />
            ))}
          </div>
        )}
      </div>

    </div>
  );
};

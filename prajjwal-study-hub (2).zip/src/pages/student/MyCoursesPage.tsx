import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { 
  BookOpen, 
  FileText, 
  Calculator, 
  CheckSquare, 
  ArrowRight,
  Layers,
  GraduationCap
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';

interface MyCoursesPageProps {
  navigate: (path: string) => void;
}

export const MyCoursesPage: React.FC<MyCoursesPageProps> = ({ navigate }) => {
  const { user } = useAuth();
  const { courses, modules, notes, formulas } = useData();
  const [activeTab, setActiveTab] = useState<'All' | 'Term 1' | 'Term 2' | 'Term 3'>('All');

  const filteredCourses = courses.filter(c => {
    if (activeTab === 'All') return true;
    return c.term === activeTab;
  });

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            My Enrolled Courses & Subjects
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {user?.programEnrolled || 'IIT Madras BS Degree — Independent Preparation'}
          </p>
        </div>
        <Button
          id="mycourses-browse-all-btn"
          variant="outline"
          size="sm"
          onClick={() => navigate('/courses')}
        >
          Explore Catalog
        </Button>
      </div>

      {/* Term Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        {(['All', 'Term 1', 'Term 2', 'Term 3'] as const).map((tab) => (
          <button
            key={tab}
            id={`mycourses-tab-${tab.toLowerCase().replace(' ', '-')}`}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
              activeTab === tab
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab === 'All' ? 'All My Courses' : tab}
          </button>
        ))}
      </div>

      {/* Courses List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => {
          const courseModules = modules.filter(m => m.courseId === course.id);
          const courseNotes = notes.filter(n => n.courseId === course.id);
          const courseFormulas = formulas.filter(f => f.courseId === course.id);

          return (
            <div
              key={course.id}
              id={`my-course-card-${course.code}`}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <Badge variant="primary" size="sm">
                    {course.code}
                  </Badge>
                  <span className="text-[11px] font-medium text-slate-500">
                    {course.term} • {course.credit || 4} Credits
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-2">
                  {course.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {course.description}
                </p>

                {/* Modules breakdown */}
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800/80 mb-4 space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                    Curriculum Scope ({courseModules.length} Weekly Modules)
                  </span>
                  <div className="space-y-1">
                    {courseModules.slice(0, 2).map(m => (
                      <div key={m.id} className="text-[11px] text-slate-500 truncate flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                        <span>{m.title}</span>
                      </div>
                    ))}
                    {courseModules.length > 2 && (
                      <span className="text-[10px] text-indigo-600 dark:text-indigo-400">
                        + {courseModules.length - 2} more modules
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <Button
                  id={`mycourses-notes-${course.code}`}
                  variant="secondary"
                  size="sm"
                  icon={<FileText className="w-3.5 h-3.5" />}
                  onClick={() => navigate('/notes')}
                >
                  Notes ({courseNotes.length})
                </Button>
                <Button
                  id={`mycourses-formulas-${course.code}`}
                  variant="secondary"
                  size="sm"
                  icon={<Calculator className="w-3.5 h-3.5" />}
                  onClick={() => navigate('/formulas')}
                >
                  Formulas ({courseFormulas.length})
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Disclaimer Note */}
      <footer className="pt-8 mt-12 border-t border-slate-200/80 dark:border-slate-800 text-center">
        <p className="text-xs text-slate-400 dark:text-slate-500 max-w-3xl mx-auto leading-relaxed">
          Disclaimer of Non-Affiliation: Prajjwal Study Hub is an independent student-created learning platform and is NOT affiliated with, endorsed by, sponsored by, or officially associated with IIT Madras or the official BS Degree administration.
        </p>
      </footer>

    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  FileText, 
  Search, 
  Bookmark, 
  BookOpen, 
  ChevronDown,
  ChevronUp, 
  Filter, 
  ArrowLeft, 
  GraduationCap, 
  Sparkles, 
  Layers, 
  FileDown, 
  Languages, 
  Calculator, 
  BarChart3, 
  Code2, 
  Check, 
  ChevronsUpDown,
  ChevronsDown,
  ChevronsUp,
  X,
  Sigma
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { LevelSwitcher } from '../../components/common/LevelSwitcher';
import { WeeklyAccordionNoteCard } from '../../components/notes/WeeklyAccordionNoteCard';
import { EnglishGrammarCards } from '../../components/notes/EnglishGrammarCards';
import { AcademicLevel, WeeklyStudyMaterial } from '../../types';
import { CURATED_WEEKLY_NOTES, WeeklyChapterNote } from '../../data/curatedNotesData';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';
import { downloadCuratedNotesPdf } from '../../utils/pdfExport';
import { getSubjectTheme } from '../../utils/subjectTheme';

interface NotesPageProps {
  navigate: (path: string) => void;
}

export type SubjectCategory = 'All' | 'Mathematics' | 'Statistics' | 'Python' | 'Machine Learning' | 'English';

export const NotesPage: React.FC<NotesPageProps> = ({ navigate }) => {
  const { toggleBookmark, isBookmarked } = useData();
  const { user } = useAuth();

  // Core navigation state
  const [selectedLevel, setSelectedLevel] = useState<AcademicLevel | 'All'>('Foundation');
  const [selectedCategory, setSelectedCategory] = useState<SubjectCategory>('All');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('All');
  const [selectedWeek, setSelectedWeek] = useState<number | 'All'>('All');
  const [activeViewTab, setActiveViewTab] = useState<'notes' | 'english-hub' | 'bookmarked'>('notes');
  const [searchQuery, setSearchQuery] = useState('');

  // Accordion expansion state: tracks which note cards are expanded
  const [expandedNoteIds, setExpandedNoteIds] = useState<Record<string, boolean>>({});

  // Available subjects for selected level
  const availableSubjects = useMemo(() => {
    const list = selectedLevel === 'All'
      ? ACADEMIC_SUBJECTS
      : ACADEMIC_SUBJECTS.filter(s => s.level === selectedLevel);
    
    if (selectedCategory === 'All') return list;

    return list.filter(s => {
      const cat = (s.category + ' ' + s.name + ' ' + s.code).toLowerCase();
      if (selectedCategory === 'Mathematics') return cat.includes('math') || cat.includes('ma1001') || cat.includes('ma1002');
      if (selectedCategory === 'Statistics') return cat.includes('stat') || cat.includes('st1001') || cat.includes('st1002');
      if (selectedCategory === 'Python') return cat.includes('python') || cat.includes('cs1002') || cat.includes('computational') || cat.includes('cs1001') || cat.includes('programming') || cat.includes('java') || cat.includes('dbms') || cat.includes('pdsa');
      if (selectedCategory === 'Machine Learning') return cat.includes('ml') || cat.includes('machine learning') || cat.includes('deep learning') || cat.includes('ai') || cat.includes('cs3001') || cat.includes('cs2006') || cat.includes('data science');
      if (selectedCategory === 'English') return cat.includes('english') || cat.includes('eng1001') || cat.includes('humanities');
      return true;
    });
  }, [selectedLevel, selectedCategory]);

  // Match notes by Subject Category
  const matchesCategory = (n: WeeklyStudyMaterial, category: SubjectCategory): boolean => {
    if (category === 'All') return true;
    const text = (n.courseTitle + ' ' + n.courseCode + ' ' + n.courseId + ' ' + (n.subLevel || '')).toLowerCase();
    if (category === 'Mathematics') {
      return text.includes('math') || text.includes('ma1001') || text.includes('ma1002') || text.includes('calculus');
    }
    if (category === 'Statistics') {
      return text.includes('stat') || text.includes('st1001') || text.includes('st1002') || text.includes('probability');
    }
    if (category === 'Python') {
      return text.includes('python') || text.includes('cs1002') || text.includes('computational') || text.includes('cs1001') || text.includes('java') || text.includes('dbms') || text.includes('pdsa') || text.includes('syscmd') || text.includes('appdev');
    }
    if (category === 'Machine Learning') {
      return text.includes('ml') || text.includes('machine learning') || text.includes('deep learning') || text.includes('neural') || text.includes('cs3001') || text.includes('cs2006') || text.includes('data science');
    }
    if (category === 'English') {
      return text.includes('english') || text.includes('eng1001') || text.includes('hs1001') || text.includes('hs1002');
    }
    return true;
  };

  // Filter curated weekly notes
  const filteredWeeklyNotes = useMemo(() => {
    return CURATED_WEEKLY_NOTES.filter(n => {
      // Bookmarks filter
      if (activeViewTab === 'bookmarked' && !isBookmarked('note', n.id)) return false;

      // Level filter
      if (selectedLevel !== 'All' && n.level !== selectedLevel) return false;

      // Subject Category filter
      if (!matchesCategory(n, selectedCategory)) return false;

      // Specific Course ID filter
      if (selectedSubjectId !== 'All' && n.courseId !== selectedSubjectId) return false;

      // Week number filter
      if (selectedWeek !== 'All' && n.weekNumber !== selectedWeek) return false;

      // Search Query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = n.title?.toLowerCase().includes(q);
        const matchTakeaways = (n.quickRevisionNotes || n.keyTakeaways || []).some(t => t.toLowerCase().includes(q));
        const matchCourse = n.courseTitle?.toLowerCase().includes(q) || n.courseCode?.toLowerCase().includes(q);
        const matchMnemonic = n.handwrittenMnemonic?.toLowerCase().includes(q) || false;
        const matchDetailed = (n.detailedNotes || n.markdownContent || '').toLowerCase().includes(q);
        const matchDefs = n.definitions?.some(d => d.term.toLowerCase().includes(q) || d.explanation.toLowerCase().includes(q) || (d.formula && d.formula.toLowerCase().includes(q))) || false;
        const matchFormulas = n.formulaSheets?.some(f => f.name.toLowerCase().includes(q) || f.formula.toLowerCase().includes(q) || f.description.toLowerCase().includes(q)) || false;
        const matchPractice = n.practiceQuestions?.some(p => p.questionText.toLowerCase().includes(q) || p.solution.toLowerCase().includes(q)) || false;
        const matchTips = n.examTips?.some(tip => tip.toLowerCase().includes(q)) || false;
        const matchCode = n.codeSnippets?.some(c => c.code.toLowerCase().includes(q) || c.title.toLowerCase().includes(q)) || false;
        
        if (!matchTitle && !matchTakeaways && !matchCourse && !matchMnemonic && !matchDetailed && !matchDefs && !matchFormulas && !matchPractice && !matchTips && !matchCode) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      // Sort primarily by course, then by weekNumber ascending (1 to 12)
      if (a.courseCode === b.courseCode) {
        return a.weekNumber - b.weekNumber;
      }
      return a.courseCode.localeCompare(b.courseCode);
    });
  }, [activeViewTab, selectedLevel, selectedCategory, selectedSubjectId, selectedWeek, searchQuery, isBookmarked]);

  // Group filtered notes by Subject / Course for clean hierarchical display
  const groupedNotesBySubject = useMemo(() => {
    const map = new Map<string, { courseTitle: string; courseCode: string; notes: WeeklyStudyMaterial[] }>();

    filteredWeeklyNotes.forEach(note => {
      const key = note.courseCode || note.courseTitle;
      if (!map.has(key)) {
        map.set(key, {
          courseTitle: note.courseTitle,
          courseCode: note.courseCode,
          notes: []
        });
      }
      map.get(key)!.notes.push(note);
    });

    return Array.from(map.values()).map(group => ({
      ...group,
      notes: group.notes.sort((a, b) => a.weekNumber - b.weekNumber)
    }));
  }, [filteredWeeklyNotes]);

  // Expand / Collapse Handlers
  const handleToggleExpandNote = (noteId: string) => {
    setExpandedNoteIds(prev => ({
      ...prev,
      [noteId]: !prev[noteId]
    }));
  };

  const handleExpandAll = () => {
    const next: Record<string, boolean> = {};
    filteredWeeklyNotes.forEach(n => {
      next[n.id] = true;
    });
    setExpandedNoteIds(next);
  };

  const handleCollapseAll = () => {
    setExpandedNoteIds({});
  };

  const handleDownloadSingleWeekPdf = (note: WeeklyChapterNote) => {
    downloadCuratedNotesPdf(
      note,
      note.courseTitle,
      note.level,
      user?.name || 'IITM BS Student'
    );
  };

  const handleDownloadAllFilteredPdf = () => {
    if (filteredWeeklyNotes.length === 0) return;
    const title = selectedCategory !== 'All'
      ? `${selectedCategory} Full Notes (Week 1–12)`
      : selectedSubjectId !== 'All'
      ? `${availableSubjects.find(s => s.id === selectedSubjectId)?.name || 'Subject'} Notes`
      : `${selectedLevel} Level Comprehensive Curriculum`;

    downloadCuratedNotesPdf(
      filteredWeeklyNotes,
      title,
      selectedLevel === 'All' ? 'Foundation' : selectedLevel,
      user?.name || 'IITM BS Student'
    );
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* 1. Header with Breadcrumb Back Navigation & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-indigo-400 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <span className="text-slate-600">•</span>
            <div className="flex items-center gap-1 text-xs font-bold text-indigo-400 uppercase tracking-wider">
              <FileText className="w-3.5 h-3.5" />
              <span>IIT Madras BS Study Notes (Week 1–12)</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Week-by-Week Curated Study Notes
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Structured Week 1 to Week 12 curriculum with topic listings, detailed theory, LaTeX derivations, quick revision summaries, and formula cheatsheets.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="notes-download-full-pdf-top"
            variant="primary"
            size="sm"
            onClick={handleDownloadAllFilteredPdf}
            icon={<FileDown className="w-3.5 h-3.5" />}
          >
            Download Notes (PDF)
          </Button>

          <Button
            id="notes-nav-formulas-btn"
            variant="outline"
            size="sm"
            onClick={() => navigate('/formulas')}
            icon={<BookOpen className="w-3.5 h-3.5" />}
          >
            Formula Sheets
          </Button>

          <Button
            id="notes-nav-practice-btn"
            variant="secondary"
            size="sm"
            onClick={() => navigate('/practice')}
          >
            Practice PYQs
          </Button>
        </div>
      </div>

      {/* 2. Global Level Switcher */}
      <LevelSwitcher
        selectedLevel={selectedLevel}
        onSelectLevel={(lvl) => {
          setSelectedLevel(lvl);
          setSelectedSubjectId('All');
          setSelectedWeek('All');
        }}
      />

      {/* 3. Top Horizontal Navigation View Bar & Global Search */}
      <div className="p-4 rounded-2xl bg-[#111318] border border-white/10 shadow-lg space-y-4">
        
        {/* Row 1: Horizontal Subject & View Tabs */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3">
          
          {/* Main Subject Category Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-[#161920] border border-white/10 rounded-xl w-full lg:w-auto overflow-x-auto">
            
            {/* All Subjects */}
            <button
              id="notes-cat-all"
              onClick={() => {
                setActiveViewTab('notes');
                setSelectedCategory('All');
                setSelectedSubjectId('All');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'notes' && selectedCategory === 'All'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>All Subjects</span>
            </button>

            {/* Mathematics */}
            <button
              id="notes-cat-math"
              onClick={() => {
                setActiveViewTab('notes');
                setSelectedCategory('Mathematics');
                setSelectedSubjectId('All');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'notes' && selectedCategory === 'Mathematics'
                  ? 'bg-emerald-500 text-slate-950 font-extrabold shadow-md'
                  : 'text-emerald-400/90 hover:text-emerald-300 hover:bg-emerald-500/10'
              }`}
            >
              <Sigma className="w-3.5 h-3.5" />
              <span>Mathematics</span>
            </button>

            {/* Statistics */}
            <button
              id="notes-cat-stats"
              onClick={() => {
                setActiveViewTab('notes');
                setSelectedCategory('Statistics');
                setSelectedSubjectId('All');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'notes' && selectedCategory === 'Statistics'
                  ? 'bg-amber-500 text-slate-950 font-extrabold shadow-md'
                  : 'text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Statistics</span>
            </button>

            {/* Python & Computing */}
            <button
              id="notes-cat-python"
              onClick={() => {
                setActiveViewTab('notes');
                setSelectedCategory('Python');
                setSelectedSubjectId('All');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'notes' && selectedCategory === 'Python'
                  ? 'bg-sky-500 text-slate-950 font-extrabold shadow-md'
                  : 'text-sky-400/90 hover:text-sky-300 hover:bg-sky-500/10'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Python &amp; CS</span>
            </button>

            {/* Machine Learning & AI */}
            <button
              id="notes-cat-ml"
              onClick={() => {
                setActiveViewTab('notes');
                setSelectedCategory('Machine Learning');
                setSelectedSubjectId('All');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'notes' && selectedCategory === 'Machine Learning'
                  ? 'bg-purple-500 text-white font-extrabold shadow-md'
                  : 'text-purple-400/90 hover:text-purple-300 hover:bg-purple-500/10'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>ML &amp; AI</span>
            </button>

            {/* English */}
            <button
              id="notes-cat-english"
              onClick={() => {
                setActiveViewTab('notes');
                setSelectedCategory('English');
                setSelectedSubjectId('All');
              }}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'notes' && selectedCategory === 'English'
                  ? 'bg-rose-500 text-white font-extrabold shadow-md'
                  : 'text-rose-400/90 hover:text-rose-300 hover:bg-rose-500/10'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>English</span>
            </button>

            <div className="w-[1px] h-5 bg-white/10 mx-1 hidden sm:block" />

            {/* English Grammar Hub Tab */}
            <button
              id="notes-tab-english-grammar"
              onClick={() => setActiveViewTab('english-hub')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'english-hub'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>Grammar Hub</span>
            </button>

            {/* Saved Bookmarks Tab */}
            <button
              id="notes-tab-bookmarks"
              onClick={() => setActiveViewTab('bookmarked')}
              className={`px-3 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeViewTab === 'bookmarked'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-amber-400" />
              <span>Saved Bookmarks</span>
            </button>

          </div>

          {/* Global Search Bar */}
          <div className="relative w-full lg:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="notes-global-search"
              type="text"
              placeholder="Search theorems, concepts, code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-xs rounded-xl border border-white/10 bg-[#161920] text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Row 2: Sub-course Chips (If multiple courses in category) */}
        {activeViewTab === 'notes' && availableSubjects.length > 1 && (
          <div className="pt-2 border-t border-white/5 flex items-center gap-2 overflow-x-auto pb-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
              <Filter className="w-3 h-3 text-indigo-400" />
              Course Filter:
            </span>

            <button
              onClick={() => setSelectedSubjectId('All')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedSubjectId === 'All'
                  ? 'bg-white/20 text-white font-bold'
                  : 'bg-[#161920] text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              All {selectedCategory !== 'All' ? selectedCategory : ''} Courses ({availableSubjects.length})
            </button>

            {availableSubjects.map(subj => {
              const theme = getSubjectTheme(subj.name, subj.category);
              const isSelected = selectedSubjectId === subj.id;
              return (
                <button
                  key={subj.id}
                  onClick={() => setSelectedSubjectId(subj.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all border ${
                    isSelected
                      ? `${theme.badgeClass} ring-1 ring-white/20 shadow-sm font-bold`
                      : 'bg-[#161920] border-white/10 text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {subj.name} ({subj.code})
                </button>
              );
            })}
          </div>
        )}

        {/* Row 3: Week Selector Pills (Week 1 to Week 12) for 1-Click Jump */}
        {activeViewTab === 'notes' && (
          <div className="pt-2 border-t border-white/5 space-y-2">
            <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-3 h-3 text-indigo-400" />
                  Jump to Week (1 to 12):
                </span>
                <span className="text-[10px] text-slate-500 hidden sm:inline">
                  (Qualifier: W1–4 • Quiz 2: W5–8 • End Term: W9–12)
                </span>
              </div>

              {/* Expand / Collapse All Toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExpandAll}
                  className="px-2.5 py-1 rounded-lg border border-white/10 bg-[#161920] hover:bg-white/5 text-[11px] font-semibold text-slate-300 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <ChevronsDown className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Expand All</span>
                </button>
                <button
                  onClick={handleCollapseAll}
                  className="px-2.5 py-1 rounded-lg border border-white/10 bg-[#161920] hover:bg-white/5 text-[11px] font-semibold text-slate-300 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <ChevronsUp className="w-3.5 h-3.5 text-slate-400" />
                  <span>Collapse All</span>
                </button>
              </div>
            </div>

            {/* Week Pills Bar */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                onClick={() => setSelectedWeek('All')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedWeek === 'All'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-[#161920] border border-white/10 text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                All Weeks (1–12)
              </button>

              {Array.from({ length: 12 }, (_, i) => i + 1).map((weekNum) => {
                const isSelected = selectedWeek === weekNum;
                // Color grouping by exam phase
                let phaseStyle = 'border-amber-500/20 text-amber-300 hover:bg-amber-500/10';
                if (weekNum >= 5 && weekNum <= 8) {
                  phaseStyle = 'border-purple-500/20 text-purple-300 hover:bg-purple-500/10';
                } else if (weekNum >= 9) {
                  phaseStyle = 'border-emerald-500/20 text-emerald-300 hover:bg-emerald-500/10';
                }

                return (
                  <button
                    key={weekNum}
                    onClick={() => setSelectedWeek(weekNum)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border font-mono ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md ring-1 ring-white/30'
                        : `bg-[#161920] ${phaseStyle}`
                    }`}
                  >
                    W{weekNum}
                  </button>
                );
              })}
            </div>
          </div>
        )}

      </div>

      {/* 4. MAIN CONTENT AREA */}

      {/* TAB 1: WEEK-BY-WEEK STRUCTURED ACCORDIONS (NOTES / BOOKMARKS) */}
      {(activeViewTab === 'notes' || activeViewTab === 'bookmarked') && (
        <div className="space-y-8">
          
          {/* Summary / Status Bar */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>
                  {activeViewTab === 'bookmarked'
                    ? 'Saved Bookmarks'
                    : selectedCategory !== 'All'
                    ? `${selectedCategory} Curriculum`
                    : 'All Study Notes'}
                </span>
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300 font-mono">
                {filteredWeeklyNotes.length} Weeks Available
              </span>
              {selectedWeek !== 'All' && (
                <span className="text-xs px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-mono">
                  Filtered: Week {selectedWeek}
                </span>
              )}
            </div>

            {filteredWeeklyNotes.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDownloadAllFilteredPdf}
                icon={<FileDown className="w-3.5 h-3.5" />}
              >
                Download Subject PDF
              </Button>
            )}
          </div>

          {filteredWeeklyNotes.length === 0 ? (
            <EmptyState
              icon={<BookOpen className="w-10 h-10 text-slate-400" />}
              title={activeViewTab === 'bookmarked' ? 'No Saved Bookmarks' : 'No Study Notes Found'}
              description={
                activeViewTab === 'bookmarked'
                  ? 'Click the bookmark ribbon on any week accordion to pin notes for rapid revision.'
                  : 'No notes match your selected category, week, or search query. Try resetting filters.'
              }
              action={
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedLevel('All');
                    setSelectedCategory('All');
                    setSelectedSubjectId('All');
                    setSelectedWeek('All');
                    setSearchQuery('');
                  }}
                >
                  Reset All Filters
                </Button>
              }
            />
          ) : (
            <div className="space-y-10">
              {groupedNotesBySubject.map((group) => {
                const groupTheme = getSubjectTheme(group.courseTitle || group.courseCode);
                return (
                  <div key={group.courseCode} className="space-y-4">
                    {/* Course Group Header */}
                    <div className="flex items-center justify-between pb-2 border-b border-white/10">
                      <div className="flex items-center gap-3">
                        <div className={`px-2.5 py-1 rounded-lg border ${groupTheme.badgeClass} font-mono font-bold text-xs`}>
                          {group.courseCode}
                        </div>
                        <h2 className="text-lg font-bold text-white tracking-tight">
                          {group.courseTitle}
                        </h2>
                      </div>
                      <span className="text-xs text-slate-400 font-mono">
                        {group.notes.length} Weekly Modules
                      </span>
                    </div>

                    {/* Week Accordion Cards for this Course */}
                    <div className="space-y-3.5">
                      {group.notes.map((note) => {
                        const isExpanded = expandedNoteIds[note.id] || false;
                        return (
                          <WeeklyAccordionNoteCard
                            key={note.id}
                            note={note}
                            isExpanded={isExpanded}
                            onToggleExpand={() => handleToggleExpandNote(note.id)}
                            isBookmarked={isBookmarked('note', note.id)}
                            onToggleBookmark={() => toggleBookmark('note', note.id, note.title, note.courseTitle)}
                            onDownloadPdf={() => handleDownloadSingleWeekPdf(note)}
                            onNavigatePractice={() => navigate('/practice')}
                          />
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* TAB 2: ENGLISH 1 & 2 GRAMMAR HUB */}
      {activeViewTab === 'english-hub' && (
        <EnglishGrammarCards
          onBookmarkToggle={(id) => toggleBookmark('note', id, 'English Grammar Rule', 'English 1 & 2')}
          bookmarkedIds={[]}
        />
      )}

    </div>
  );
};

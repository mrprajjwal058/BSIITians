import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  Bookmark, 
  FileText, 
  Calculator, 
  CheckSquare, 
  Trash2, 
  ArrowRight
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';

interface BookmarksPageProps {
  navigate: (path: string) => void;
}

export const BookmarksPage: React.FC<BookmarksPageProps> = ({ navigate }) => {
  const { bookmarks, removeBookmark } = useData();
  const [activeTab, setActiveTab] = useState<'all' | 'note' | 'formula' | 'question'>('all');

  const filteredBookmarks = bookmarks.filter(b => {
    if (activeTab === 'all') return true;
    return b.itemType === activeTab;
  });

  const notesCount = bookmarks.filter(b => b.itemType === 'note').length;
  const formulasCount = bookmarks.filter(b => b.itemType === 'formula').length;
  const questionsCount = bookmarks.filter(b => b.itemType === 'question').length;

  const handleNavigateToItem = (itemType: string) => {
    if (itemType === 'note') navigate('/notes');
    else if (itemType === 'formula') navigate('/formulas');
    else if (itemType === 'question') navigate('/practice');
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
            <Bookmark className="w-4 h-4" />
            <span>Saved Academic Resources</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            Bookmarked Notes, Formulas & Questions
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Fast access to resources you have pinned for quick pre-exam revision.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          id="bookmarks-tab-all"
          onClick={() => setActiveTab('all')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'all'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          All Items ({bookmarks.length})
        </button>
        <button
          id="bookmarks-tab-notes"
          onClick={() => setActiveTab('note')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'note'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Notes ({notesCount})
        </button>
        <button
          id="bookmarks-tab-formulas"
          onClick={() => setActiveTab('formula')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'formula'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Formulas ({formulasCount})
        </button>
        <button
          id="bookmarks-tab-questions"
          onClick={() => setActiveTab('question')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'question'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Questions ({questionsCount})
        </button>
      </div>

      {/* Bookmarks List */}
      {filteredBookmarks.length === 0 ? (
        <EmptyState
          id="empty-bookmarks"
          icon={Bookmark}
          title="No bookmarks saved yet."
          description="Click the bookmark ribbon icon on any note, formula card, or practice question to save it here."
          actionText="Browse Study Notes"
          onAction={() => navigate('/notes')}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBookmarks.map((b) => {
            const Icon = b.itemType === 'note' ? FileText : b.itemType === 'formula' ? Calculator : CheckSquare;
            const badgeVariant = b.itemType === 'note' ? 'primary' : b.itemType === 'formula' ? 'warning' : 'success';
            const displayTitle = b.title || b.itemTitle || 'Saved Item';
            const displayCourse = b.courseTitle || b.courseName;

            return (
              <div
                key={b.id}
                id={`bookmark-card-${b.id}`}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <Badge variant={badgeVariant as any} size="sm">
                      <Icon className="w-3 h-3 mr-1 inline" />
                      {b.itemType.toUpperCase()}
                    </Badge>
                    <span className="text-[10px] text-slate-400">
                      Saved {new Date(b.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-1 line-clamp-2">
                    {displayTitle}
                  </h3>

                  {displayCourse && (
                    <p className="text-xs text-slate-500 mb-4">
                      {displayCourse}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <Button
                    id={`bookmark-open-btn-${b.id}`}
                    variant="outline"
                    size="sm"
                    onClick={() => handleNavigateToItem(b.itemType)}
                    icon={<ArrowRight className="w-3.5 h-3.5" />}
                  >
                    Open Resource
                  </Button>

                  <button
                    id={`bookmark-remove-btn-${b.id}`}
                    onClick={() => removeBookmark(b.id)}
                    className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                    title="Remove bookmark"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Footer Disclaimer Note */}
      <footer className="pt-8 mt-12 border-t border-slate-200/80 dark:border-slate-800 text-center">
        <p className="text-xs text-slate-400 dark:text-slate-500 max-w-3xl mx-auto leading-relaxed">
          Disclaimer of Non-Affiliation: Prajjwal Study Hub is an independent student-created learning platform and is NOT affiliated with, endorsed by, sponsored by, or officially associated with IIT Madras or the official BS Degree administration.
        </p>
      </footer>

    </div>
  );
};

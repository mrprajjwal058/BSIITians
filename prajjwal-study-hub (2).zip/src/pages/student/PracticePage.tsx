import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  CheckSquare, 
  Search, 
  HelpCircle, 
  Sparkles, 
  Clock, 
  Target, 
  Flame, 
  Bookmark, 
  AlertTriangle,
  PlayCircle,
  Bell,
  CheckCircle2,
  XCircle,
  ChevronRight,
  ChevronDown,
  GraduationCap,
  Layers,
  FileCode,
  Hash,
  BookOpen,
  Filter,
  Square,
  Download,
  FileDown,
  Printer,
  ArrowLeft,
  Calendar,
  Code2,
  Tag,
  SlidersHorizontal,
  Lightbulb,
  Check,
  RotateCcw
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { Question, AcademicLevel, AcademicSubLevel, QuestionType, ExamCategory } from '../../types';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';
import { downloadPracticeSetPdf } from '../../utils/pdfExport';
import { RichMathText, MathRenderer } from '../../components/common/MathRenderer';
import { getSubjectTheme } from '../../utils/subjectTheme';

interface PracticePageProps {
  navigate: (path: string) => void;
}

export const PracticePage: React.FC<PracticePageProps> = ({ navigate }) => {
  const { questions, courses, isBookmarked, toggleBookmark } = useData();
  const { user } = useAuth();

  // Multi-Tier Hierarchy Filter State matching MockTestsPage
  const [selectedSubLevel, setSelectedSubLevel] = useState<AcademicSubLevel | 'All'>('All');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [selectedExamType, setSelectedExamType] = useState<string>('All'); // 'All' | 'Quiz 1' | 'Quiz 2' | 'End Term' | 'OPPE'
  const [selectedYear, setSelectedYear] = useState<string>('All'); // '2021', '2022', '2023', '2024', '2025', '2026'
  const [selectedTerm, setSelectedTerm] = useState<string>('All'); // 'January', 'May', 'September'
  const [selectedQuestionType, setSelectedQuestionType] = useState<string>('All'); // 'MCQ', 'MSQ', 'NAT', 'CODE_OUTPUT', 'OPPE_CODE'
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Interactive Question Practice State
  const [revealedExplanations, setRevealedExplanations] = useState<Record<string, boolean>>({});
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [selectedMsqAnswers, setSelectedMsqAnswers] = useState<Record<string, number[]>>({});
  const [enteredNatAnswers, setEnteredNatAnswers] = useState<Record<string, string>>({});
  const [submittedQuestions, setSubmittedQuestions] = useState<Record<string, boolean>>({});
  const [activeCodeAnswers, setActiveCodeAnswers] = useState<Record<string, string>>({});

  // 1. Available subjects cascading dynamically from selected level / sub-level
  const availableSubjects = useMemo(() => {
    if (selectedSubLevel === 'All') return ACADEMIC_SUBJECTS;
    if (selectedSubLevel === 'Foundation') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'Foundation');
    }
    if (selectedSubLevel === 'Diploma in Programming') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'Diploma in Programming');
    }
    if (selectedSubLevel === 'Diploma in Data Science') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'Diploma in Data Science');
    }
    if (selectedSubLevel === 'BSc Degree Level') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'BSc Degree Level' || s.subLevel === 'Degree');
    }
    if (selectedSubLevel === 'BS Degree Level') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'BS Degree Level');
    }
    if (selectedSubLevel === 'Degree / BS Level' || selectedSubLevel === 'Degree') {
      return ACADEMIC_SUBJECTS.filter(s => s.subLevel === 'BSc Degree Level' || s.subLevel === 'BS Degree Level' || s.subLevel === 'Degree' || s.level === 'Degree' || s.level === 'BS Degree');
    }
    return ACADEMIC_SUBJECTS;
  }, [selectedSubLevel]);

  // 2. Filter Questions with Multi-Tier cascading system
  const filteredQuestions = useMemo(() => {
    return questions.filter(q => {
      if (!q.published) return false;

      // Sub-Level / Tier filtering
      if (selectedSubLevel !== 'All') {
        if (q.subLevel) {
          if (selectedSubLevel === 'BSc Degree Level') {
            if (q.subLevel !== 'BSc Degree Level' && q.subLevel !== 'Degree') return false;
          } else if (selectedSubLevel === 'BS Degree Level') {
            if (q.subLevel !== 'BS Degree Level') return false;
          } else if (selectedSubLevel === 'Degree / BS Level' || selectedSubLevel === 'Degree') {
            if (q.subLevel !== 'BSc Degree Level' && q.subLevel !== 'BS Degree Level' && q.subLevel !== 'Degree' && q.level !== 'Degree' && q.level !== 'BS Degree') return false;
          } else if (q.subLevel !== selectedSubLevel) {
            return false;
          }
        } else if (q.level) {
          if (selectedSubLevel === 'Foundation' && q.level !== 'Foundation') return false;
          if ((selectedSubLevel === 'Diploma in Programming' || selectedSubLevel === 'Diploma in Data Science') && q.level !== 'Diploma') return false;
          if (selectedSubLevel === 'BSc Degree Level' && q.level !== 'Degree') return false;
          if (selectedSubLevel === 'BS Degree Level' && q.level !== 'BS Degree') return false;
          if ((selectedSubLevel === 'Degree / BS Level' || selectedSubLevel === 'Degree') && q.level !== 'Degree' && q.level !== 'BS Degree') return false;
        }
      }

      // Subject filtering
      if (selectedSubject !== 'All') {
        const matchSubject = q.subject?.toLowerCase().includes(selectedSubject.toLowerCase()) ||
                             q.courseId === selectedSubject ||
                             q.courseTitle?.toLowerCase().includes(selectedSubject.toLowerCase());
        if (!matchSubject) return false;
      }

      // Exam Type filtering (Quiz 1, Quiz 2, End Term, OPPE)
      if (selectedExamType !== 'All') {
        const pyqStr = (q.pyqYear || '').toLowerCase();
        const tagStr = (q.tags || []).join(' ').toLowerCase();
        const typeStr = (q.type || '').toLowerCase();

        if (selectedExamType === 'Quiz 1') {
          const matchQ1 = pyqStr.includes('quiz 1') || pyqStr.includes('qualifier') || tagStr.includes('quiz 1') || tagStr.includes('qualifier');
          if (!matchQ1) return false;
        } else if (selectedExamType === 'Quiz 2') {
          const matchQ2 = pyqStr.includes('quiz 2') || tagStr.includes('quiz 2');
          if (!matchQ2) return false;
        } else if (selectedExamType === 'End Term') {
          const matchEnd = pyqStr.includes('end term') || pyqStr.includes('end-term') || tagStr.includes('end term') || pyqStr.includes('viva');
          if (!matchEnd) return false;
        } else if (selectedExamType === 'OPPE') {
          const matchOppe = pyqStr.includes('oppe') || typeStr.includes('oppe') || tagStr.includes('oppe');
          if (!matchOppe) return false;
        }
      }

      // Academic Year Filter
      if (selectedYear !== 'All') {
        const pyqStr = q.pyqYear || '';
        if (!pyqStr.includes(selectedYear)) {
          return false;
        }
      }

      // Term Filter (Jan / May / Sept)
      if (selectedTerm !== 'All') {
        const pyqStr = (q.pyqYear || '').toLowerCase();
        const termStr = (q.term || '').toLowerCase();
        const searchTarget = selectedTerm.toLowerCase().slice(0, 3); // 'jan', 'may', 'sep'
        if (!pyqStr.includes(searchTarget) && !termStr.includes(searchTarget)) {
          return false;
        }
      }

      // Question Format Type Filter
      if (selectedQuestionType !== 'All') {
        if ((q.type || 'MCQ') !== selectedQuestionType) {
          if (selectedQuestionType === 'OPPE_CODE' && q.type !== 'OPPE_CODE' && q.type !== 'CODE_OUTPUT') {
            return false;
          } else if (selectedQuestionType !== 'OPPE_CODE') {
            return false;
          }
        }
      }

      // Difficulty Filter
      if (selectedDifficulty !== 'All' && q.difficulty !== selectedDifficulty) {
        return false;
      }

      // Search Query (concept/keyword search)
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchText = q.questionText.toLowerCase().includes(query);
        const matchSubject = (q.subject || q.courseTitle || '').toLowerCase().includes(query);
        const matchTags = q.tags?.some(t => t.toLowerCase().includes(query));
        const matchExplanation = q.explanation.toLowerCase().includes(query);
        const matchHints = q.hints?.some(h => h.toLowerCase().includes(query));
        const matchFormula = q.formulaRef?.toLowerCase().includes(query);
        if (!matchText && !matchSubject && !matchTags && !matchExplanation && !matchHints && !matchFormula) {
          return false;
        }
      }

      return true;
    });
  }, [questions, selectedSubLevel, selectedSubject, selectedExamType, selectedYear, selectedTerm, selectedQuestionType, selectedDifficulty, searchQuery]);

  // Handlers for Question Interactions
  const handleOptionSelect = (questionId: string, optionIndex: number) => {
    setSelectedAnswers(prev => ({ ...prev, [questionId]: optionIndex }));
    setSubmittedQuestions(prev => ({ ...prev, [questionId]: true }));
  };

  const handleToggleMsq = (questionId: string, optionIndex: number) => {
    setSelectedMsqAnswers(prev => {
      const current = prev[questionId] || [];
      const updated = current.includes(optionIndex)
        ? current.filter(i => i !== optionIndex)
        : [...current, optionIndex].sort((a, b) => a - b);
      return { ...prev, [questionId]: updated };
    });
  };

  const handleCheckMsq = (questionId: string) => {
    setSubmittedQuestions(prev => ({ ...prev, [questionId]: true }));
    setRevealedExplanations(prev => ({ ...prev, [questionId]: true }));
  };

  const handleCheckNat = (questionId: string) => {
    setSubmittedQuestions(prev => ({ ...prev, [questionId]: true }));
    setRevealedExplanations(prev => ({ ...prev, [questionId]: true }));
  };

  const toggleExplanation = (questionId: string) => {
    setRevealedExplanations(prev => ({ ...prev, [questionId]: !prev[questionId] }));
  };

  // Helper for generating meaningful PDF Export Title
  const getPdfExportTitle = () => {
    const levelPart = selectedSubLevel === 'All' ? 'IIT Madras BS' : selectedSubLevel;
    const subjectPart = selectedSubject === 'All' ? 'All Subjects' : selectedSubject;
    const examPart = selectedExamType === 'All' ? 'PYQ Bank' : selectedExamType;
    const yearPart = selectedYear === 'All' ? 'All Years' : selectedYear;
    const termPart = selectedTerm === 'All' ? '' : ` (${selectedTerm} Term)`;
    return `${subjectPart} - ${examPart} - ${yearPart}${termPart} - ${levelPart}`;
  };

  const resetAllFilters = () => {
    setSelectedSubLevel('All');
    setSelectedSubject('All');
    setSelectedExamType('All');
    setSelectedYear('All');
    setSelectedTerm('All');
    setSelectedQuestionType('All');
    setSelectedDifficulty('All');
    setSearchQuery('');
  };

  return (
    <div className="space-y-7 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <div className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              <CheckSquare className="w-3.5 h-3.5" />
              <span>IIT Madras BS PYQ &amp; Question Bank</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            IIT Madras BS Degree PYQs &amp; Quiz Practice Bank
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Searchable repository of past year questions (2021–2026) for Qualifier, Quiz 1, Quiz 2, End Term, and OPPE with step-by-step verified solutions and PDF export.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="btn-download-filtered-pyqs-pdf"
            variant="outline"
            size="sm"
            onClick={() => downloadPracticeSetPdf(
              getPdfExportTitle(),
              selectedSubLevel === 'All' ? 'Foundation & Diploma & Degree' : selectedSubLevel,
              selectedSubject === 'All' ? 'Curriculum Practice Set' : selectedSubject,
              filteredQuestions,
              false,
              user?.name || 'Prajjwal Student'
            )}
            icon={<FileDown className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />}
          >
            Download Filtered PYQs (PDF)
          </Button>

          <Button
            id="btn-download-filtered-solutions-pdf"
            variant="outline"
            size="sm"
            onClick={() => downloadPracticeSetPdf(
              `${getPdfExportTitle()} - Complete Step-by-Step Solutions Key`,
              selectedSubLevel === 'All' ? 'Foundation & Diploma & Degree' : selectedSubLevel,
              selectedSubject === 'All' ? 'Solutions Key' : selectedSubject,
              filteredQuestions,
              true,
              user?.name || 'Prajjwal Student'
            )}
            icon={<Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />}
          >
            Solutions Key (PDF)
          </Button>

          <Button
            id="btn-goto-cbt-from-practice"
            variant="primary"
            size="sm"
            onClick={() => navigate('/mock-tests')}
            icon={<PlayCircle className="w-3.5 h-3.5" />}
          >
            Launch CBT Timed Mock
          </Button>
        </div>
      </div>

      {/* 1. ACADEMIC LEVEL SELECTOR (CASCADING HIERARCHY) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
            <GraduationCap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            1. Select Academic Level / Degree Tier
          </div>
          <span className="text-xs text-slate-500 font-medium">
            {selectedSubLevel === 'All' ? 'Showing All 5 Program Levels' : `${selectedSubLevel} Selected`}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
          {/* Foundation Level */}
          <button
            id="pyq-sublevel-foundation"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'Foundation' ? 'All' : 'Foundation');
              setSelectedSubject('All');
            }}
            className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'Foundation'
                ? 'bg-indigo-50/95 dark:bg-indigo-950/70 border-indigo-500 ring-2 ring-indigo-500/20 shadow-sm'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 flex items-center justify-center font-bold text-xs">
                L1
              </div>
              <Badge variant="info" size="sm">Foundation</Badge>
            </div>
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Foundation Level</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              Maths 1 & 2, Stats 1 & 2, CT, Python, English 1 & 2
            </p>
          </button>

          {/* Diploma in Programming */}
          <button
            id="pyq-sublevel-diploma-prog"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'Diploma in Programming' ? 'All' : 'Diploma in Programming');
              setSelectedSubject('All');
            }}
            className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'Diploma in Programming'
                ? 'bg-purple-50/95 dark:bg-purple-950/70 border-purple-500 ring-2 ring-purple-500/20 shadow-sm'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold text-xs">
                L2
              </div>
              <Badge variant="warning" size="sm">Prog. Diploma</Badge>
            </div>
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Diploma in Programming</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              Java OOP, DBMS, PDSA, App Dev 1 (Flask), App Dev 2 (Vue 3), SysCmd
            </p>
          </button>

          {/* Diploma in Data Science */}
          <button
            id="pyq-sublevel-diploma-ds"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'Diploma in Data Science' ? 'All' : 'Diploma in Data Science');
              setSelectedSubject('All');
            }}
            className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'Diploma in Data Science'
                ? 'bg-cyan-50/95 dark:bg-cyan-950/70 border-cyan-500 ring-2 ring-cyan-500/20 shadow-sm'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-100 dark:bg-cyan-900/60 text-cyan-700 dark:text-cyan-300 flex items-center justify-center font-bold text-xs">
                L2
              </div>
              <Badge variant="success" size="sm">DS Diploma</Badge>
            </div>
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">Diploma in Data Science</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              MLF / MLT, MLP (Scikit), BDM, Tools in DS, Business Analytics
            </p>
          </button>

          {/* BSc Degree Level (3-Year Exit Track) */}
          <button
            id="pyq-sublevel-bsc-degree"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'BSc Degree Level' ? 'All' : 'BSc Degree Level');
              setSelectedSubject('All');
            }}
            className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'BSc Degree Level'
                ? 'bg-purple-50/95 dark:bg-purple-950/70 border-purple-500 ring-2 ring-purple-500/20 shadow-sm'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-purple-100 dark:bg-purple-900/60 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold text-xs">
                L3
              </div>
              <Badge variant="default" size="sm">BSc Track</Badge>
            </div>
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">BSc Degree Level</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              Terms 6-8: Deep Learning, AI Search, Speech & NLP, Software Testing, Big Data
            </p>
          </button>

          {/* BS Degree Level (4th-Year Track) */}
          <button
            id="pyq-sublevel-bs-degree"
            onClick={() => {
              setSelectedSubLevel(selectedSubLevel === 'BS Degree Level' ? 'All' : 'BS Degree Level');
              setSelectedSubject('All');
            }}
            className={`p-3.5 rounded-2xl border text-left transition-all relative overflow-hidden ${
              selectedSubLevel === 'BS Degree Level'
                ? 'bg-rose-50/95 dark:bg-rose-950/70 border-rose-500 ring-2 ring-rose-500/20 shadow-sm'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-7 h-7 rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300 flex items-center justify-center font-bold text-xs">
                L4
              </div>
              <Badge variant="danger" size="sm">BS 4th Year</Badge>
            </div>
            <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">BS Degree (4th Year)</h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              Terms 9-12: GenAI, RL, Cloud Arch, Robotics AI, Capstone Viva
            </p>
          </button>
        </div>
      </div>

      {/* 2. EXAM TYPE TABS */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
          <Target className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          2. Filter by Exam Type
        </div>
        
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'All', label: 'All Questions' },
            { id: 'Quiz 1', label: 'Quiz 1 (Qualifier / In-Term 1)' },
            { id: 'Quiz 2', label: 'Quiz 2 (In-Term 2)' },
            { id: 'End Term', label: 'End Term Exam' },
            { id: 'OPPE', label: 'OPPE 1 & OPPE 2 (Programming Exams)' },
          ].map(tab => {
            const isSelected = selectedExamType === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-exam-${tab.id.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => setSelectedExamType(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-sm ring-2 ring-indigo-600/20'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. MULTI-TIER CASCADING FILTER BAR (SUBJECT, YEAR, TERM, FORMAT, SEARCH) */}
      <div className="p-4.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
            <SlidersHorizontal className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            3. Subject, Academic Year & Term Filters
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              {filteredQuestions.length} Questions Found
            </span>
            {(selectedSubLevel !== 'All' || selectedSubject !== 'All' || selectedExamType !== 'All' || selectedYear !== 'All' || selectedTerm !== 'All' || selectedQuestionType !== 'All' || selectedDifficulty !== 'All' || searchQuery) && (
              <button
                onClick={resetAllFilters}
                className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          
          {/* Keyword Search Input */}
          <div className="relative sm:col-span-2 lg:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="pyq-search-input"
              type="text"
              placeholder="Search concepts: 'Bayes', 'eigenvalues', 'B-Tree'..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Subject Dropdown (Auto-populated from Level) */}
          <div className="sm:col-span-2 lg:col-span-2">
            <select
              id="pyq-subject-dropdown"
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
            >
              <option value="All">All Subjects ({selectedSubLevel === 'All' ? 'All 5 Tiers' : selectedSubLevel})</option>
              {availableSubjects.map(s => (
                <option key={s.id} value={s.name}>{s.code}: {s.name}</option>
              ))}
            </select>
          </div>

          {/* Academic Year Filter */}
          <div>
            <select
              id="pyq-year-filter"
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
            >
              <option value="All">All Years (2021-2026)</option>
              <option value="2026">Year 2026</option>
              <option value="2025">Year 2025</option>
              <option value="2024">Year 2024</option>
              <option value="2023">Year 2023</option>
              <option value="2022">Year 2022</option>
              <option value="2021">Year 2021</option>
            </select>
          </div>

          {/* Term Filter */}
          <div>
            <select
              id="pyq-term-filter"
              value={selectedTerm}
              onChange={(e) => setSelectedTerm(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
            >
              <option value="All">All Terms (Jan, May, Sept)</option>
              <option value="January">January Term</option>
              <option value="May">May Term</option>
              <option value="September">September Term</option>
            </select>
          </div>

        </div>

        {/* Secondary Filters row (Format, Difficulty) */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Format:</span>
          
          <select
            id="pyq-format-filter"
            value={selectedQuestionType}
            onChange={(e) => setSelectedQuestionType(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
          >
            <option value="All">All Formats</option>
            <option value="MCQ">MCQ (Single Choice)</option>
            <option value="MSQ">MSQ (Multiple Select)</option>
            <option value="NAT">NAT (Numerical Answer)</option>
            <option value="CODE_OUTPUT">Code Output / Tracing</option>
            <option value="OPPE_CODE">OPPE Programming Code</option>
          </select>

          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider ml-2">Difficulty:</span>
          <select
            id="pyq-difficulty-filter"
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
          >
            <option value="All">All Difficulties</option>
            <option value="Easy">Easy Standard</option>
            <option value="Medium">Medium Exam Level</option>
            <option value="Hard">Hard / Challenging</option>
          </select>
        </div>
      </div>

      {/* 4. QUESTIONS PRACTICE FEED */}
      {filteredQuestions.length === 0 ? (
        <EmptyState
          id="empty-pyq-questions"
          icon={CheckSquare}
          title="No questions found matching your filter criteria."
          description="Try broadening your subject, year, or exam type filters to explore more problems."
          actionText="Reset All Filters"
          onAction={resetAllFilters}
        />
      ) : (
        <div className="space-y-6">
          {filteredQuestions.map((q, idx) => {
            const isBookmarkedItem = isBookmarked('question', q.id);
            const isSubmitted = submittedQuestions[q.id];
            const isExplRevealed = revealedExplanations[q.id];
            const selectedOpt = selectedAnswers[q.id];
            const selectedMsq = selectedMsqAnswers[q.id] || [];
            const enteredNat = enteredNatAnswers[q.id] || '';

            // Match Subject Metadata for course code tag
            const subjectMeta = ACADEMIC_SUBJECTS.find(s => s.name === q.subject || s.id === q.courseId);
            const courseCodeTag = subjectMeta?.code || (q.courseId ? q.courseId.replace('course-', '').toUpperCase() : 'IITM');

            // Format Exam Type Label e.g. "Quiz 1", "End Term"
            let examTypeBadge = 'Practice';
            if (q.pyqYear?.toLowerCase().includes('quiz 1') || q.pyqYear?.toLowerCase().includes('qualifier')) {
              examTypeBadge = 'Quiz 1';
            } else if (q.pyqYear?.toLowerCase().includes('quiz 2')) {
              examTypeBadge = 'Quiz 2';
            } else if (q.pyqYear?.toLowerCase().includes('end term')) {
              examTypeBadge = 'End Term';
            } else if (q.pyqYear?.toLowerCase().includes('oppe') || q.type === 'OPPE_CODE') {
              examTypeBadge = 'OPPE Exam';
            } else if (q.pyqYear?.toLowerCase().includes('viva')) {
              examTypeBadge = 'Viva Defense';
            }

            // Evaluation status
            let isUserCorrect = false;
            if (isSubmitted) {
              if (q.type === 'MSQ' && q.correctOptionIndices) {
                const sel = selectedMsq.slice().sort();
                const cor = q.correctOptionIndices.slice().sort();
                isUserCorrect = sel.length === cor.length && sel.every((v, i) => v === cor[i]);
              } else if (q.type === 'NAT' && q.correctNumericAnswer !== undefined) {
                const val = parseFloat(enteredNat);
                const tol = q.numericTolerance !== undefined ? q.numericTolerance : 0.01;
                isUserCorrect = !isNaN(val) && Math.abs(val - q.correctNumericAnswer) <= tol;
              } else {
                isUserCorrect = selectedOpt === q.correctOptionIndex;
              }
            }

            const subjectTheme = getSubjectTheme(q.subject || q.courseTitle || courseCodeTag);

            return (
              <div 
                key={q.id}
                id={`pyq-question-card-${q.id}`}
                className={`p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#111318] border ${subjectTheme.cardBorder} dark:border-white/10 shadow-xs space-y-4 transition-all hover:shadow-md`}
              >
                {/* Categorized Question Header with exact requested metadata:
                    [Course Code] | [Level] | [Exam Type: Quiz 1 / Quiz 2 / End Term] | [Term & Year e.g., Sept 2024] */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3.5 border-b border-slate-100 dark:border-white/5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 font-mono">
                      Q{idx + 1}
                    </span>

                    {/* Metadata Tag: [Course Code] with distinct subject color */}
                    <span className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-md border ${subjectTheme.badgeClass} font-mono`}>
                      [{courseCodeTag}]
                    </span>

                    {/* Metadata Tag: [Level] */}
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300">
                      {q.subLevel || `${q.level || 'Foundation'} Level`}
                    </span>

                    {/* Metadata Tag: [Exam Type] */}
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-500 dark:text-amber-400 border border-amber-500/20">
                      {examTypeBadge}
                    </span>

                    {/* Metadata Tag: [Term & Year e.g., Sept 2024] */}
                    {q.pyqYear && (
                      <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-md bg-purple-500/10 text-purple-500 dark:text-purple-400 border border-purple-500/20 font-mono">
                        {q.pyqYear}
                      </span>
                    )}

                    {/* Question Format Badge */}
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-white/5">
                      {q.type === 'OPPE_CODE' ? 'OPPE Code' : q.type === 'CODE_OUTPUT' ? 'Code Trace' : q.type || 'MCQ'}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-500 font-semibold">
                      +{q.marks || 2} Marks {q.negativeMarks ? `(-${q.negativeMarks}M)` : '(0 Neg)'}
                    </span>
                    <button
                      id={`bookmark-btn-${q.id}`}
                      onClick={() => toggleBookmark('question', q.id, q.questionText.slice(0, 40), q.subject || 'PYQ')}
                      className={`p-1.5 rounded-lg border transition-colors ${
                        isBookmarkedItem 
                          ? 'bg-amber-50 border-amber-300 text-amber-600 dark:bg-amber-950/60 dark:border-amber-700' 
                          : 'border-slate-200 dark:border-slate-800 text-slate-400 hover:text-slate-600'
                      }`}
                      title={isBookmarkedItem ? 'Remove Bookmark' : 'Bookmark Question'}
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Course Name Title */}
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{q.subject || q.courseTitle}</span>
                  {q.tags && q.tags.length > 0 && (
                    <>
                      <span>•</span>
                      <span className="text-slate-400 dark:text-slate-500">Topics: {q.tags.join(', ')}</span>
                    </>
                  )}
                </div>

                {/* Question Text Rendered via KaTeX */}
                <div className="text-sm sm:text-base font-medium text-slate-900 dark:text-slate-100 leading-relaxed">
                  <RichMathText text={q.questionText} />
                </div>

                {/* Code Snippet Box (for Code Output / Pseudocode / OPPE) */}
                {q.codeSnippet && (
                  <div className="p-4 rounded-xl bg-slate-950 text-slate-100 font-mono text-xs overflow-x-auto border border-slate-800 shadow-inner">
                    <pre className="leading-relaxed">{q.codeSnippet}</pre>
                  </div>
                )}

                {/* Starter Code Box (for OPPE Programming Questions) */}
                {q.starterCode && (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <Code2 className="w-3.5 h-3.5 text-indigo-500" />
                        OPPE Python Starter Code & Test Harness:
                      </span>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-900 text-slate-100 font-mono text-xs overflow-x-auto border border-slate-800">
                      <pre className="leading-relaxed">{q.starterCode}</pre>
                    </div>
                  </div>
                )}

                {/* Test Cases Table (if OPPE) */}
                {q.testCases && q.testCases.length > 0 && (
                  <div className="space-y-1.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200/80 dark:border-slate-800 text-xs">
                    <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5 text-indigo-500" />
                      Official IITM Evaluation Test Cases:
                    </div>
                    <div className="space-y-1 pt-1 font-mono text-[11px]">
                      {q.testCases.map((tc, tcIdx) => (
                        <div key={tc.id || tcIdx} className="flex flex-wrap items-center gap-2 p-1.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200/60 dark:border-slate-800">
                          <span className="font-bold text-indigo-600 dark:text-indigo-400">Case {tcIdx + 1}:</span>
                          <span>Input: <code className="text-slate-900 dark:text-slate-100">{tc.input}</code></span>
                          <span className="text-slate-400">→</span>
                          <span>Expected: <code className="text-emerald-600 dark:text-emerald-400 font-bold">{tc.expectedOutput}</code></span>
                          {tc.explanation && <span className="text-slate-500 text-[10px]">({tc.explanation})</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Interactive Practice Selector / Inputs */}
                {q.type === 'MSQ' ? (
                  // MSQ Multiple Select Options
                  <div className="space-y-2 pt-2">
                    <div className="text-[11px] font-semibold text-indigo-700 dark:text-indigo-400 flex items-center gap-1">
                      <CheckSquare className="w-3.5 h-3.5" />
                      Multiple Select Question (Choose ONE OR MORE correct options):
                    </div>
                    {q.options?.map((opt, optIdx) => {
                      const isChecked = selectedMsq.includes(optIdx);
                      const isCorrectOpt = q.correctOptionIndices?.includes(optIdx);

                      let optStyle = 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-slate-300';
                      if (isSubmitted) {
                        if (isCorrectOpt) {
                          optStyle = 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-500 text-emerald-950 dark:text-emerald-100 font-semibold';
                        } else if (isChecked && !isCorrectOpt) {
                          optStyle = 'bg-rose-50 dark:bg-rose-950/70 border-rose-500 text-rose-950 dark:text-rose-100 line-through';
                        }
                      } else if (isChecked) {
                        optStyle = 'bg-indigo-50 dark:bg-indigo-950/70 border-indigo-500 text-indigo-950 dark:text-indigo-100 font-semibold';
                      }

                      return (
                        <button
                          key={optIdx}
                          id={`btn-opt-msq-${q.id}-${optIdx}`}
                          disabled={isSubmitted}
                          onClick={() => handleToggleMsq(q.id, optIdx)}
                          className={`w-full p-3 rounded-xl text-left border text-xs flex items-center justify-between transition-all ${optStyle}`}
                        >
                          <div className="flex items-start gap-2.5">
                            <span className="font-bold min-w-5">({String.fromCharCode(65 + optIdx)})</span>
                            <div className="flex-1 leading-relaxed">
                              <RichMathText text={opt} />
                            </div>
                          </div>
                          <div className="shrink-0 ml-2">
                            {isChecked ? (
                              <CheckSquare className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400" />
                            )}
                          </div>
                        </button>
                      );
                    })}

                    {!isSubmitted && (
                      <div className="pt-2">
                        <Button
                          id={`btn-check-msq-${q.id}`}
                          variant="primary"
                          size="sm"
                          disabled={selectedMsq.length === 0}
                          onClick={() => handleCheckMsq(q.id)}
                          icon={<CheckCircle2 className="w-3.5 h-3.5" />}
                        >
                          Submit & Check MSQ Answer
                        </Button>
                      </div>
                    )}
                  </div>
                ) : q.type === 'NAT' ? (
                  // NAT Numerical Input
                  <div className="space-y-3 pt-2 max-w-md">
                    <div className="text-[11px] font-semibold text-indigo-700 dark:text-indigo-400">
                      Numerical Answer Type (Enter exact decimal value):
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        id={`input-nat-${q.id}`}
                        type="number"
                        step="any"
                        placeholder="Enter numerical answer..."
                        value={enteredNatAnswers[q.id] || ''}
                        disabled={isSubmitted}
                        onChange={(e) => setEnteredNatAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                        className="px-4 py-2.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono flex-1 focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                      {!isSubmitted && (
                        <Button
                          id={`btn-check-nat-${q.id}`}
                          variant="primary"
                          size="sm"
                          disabled={!enteredNatAnswers[q.id]?.trim()}
                          onClick={() => handleCheckNat(q.id)}
                        >
                          Submit NAT
                        </Button>
                      )}
                    </div>
                    {isSubmitted && q.correctNumericAnswer !== undefined && (
                      <div className="text-xs font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                        Official Key: {q.correctNumericAnswer} {q.numericTolerance ? `(Acceptable range: ±${q.numericTolerance})` : ''}
                      </div>
                    )}
                  </div>
                ) : (
                  // Single Choice MCQ or Code Trace / OPPE Choice
                  <div className="space-y-2 pt-2">
                    {q.options?.map((opt, optIdx) => {
                      const isSelected = selectedOpt === optIdx;
                      const isCorrect = q.correctOptionIndex === optIdx;

                      let optStyle = 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/60';
                      if (isSubmitted) {
                        if (isCorrect) {
                          optStyle = 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-500 text-emerald-950 dark:text-emerald-100 font-semibold';
                        } else if (isSelected && !isCorrect) {
                          optStyle = 'bg-rose-50 dark:bg-rose-950/70 border-rose-500 text-rose-950 dark:text-rose-100 line-through';
                        }
                      }

                      return (
                        <button
                          key={optIdx}
                          id={`btn-opt-mcq-${q.id}-${optIdx}`}
                          disabled={isSubmitted}
                          onClick={() => handleOptionSelect(q.id, optIdx)}
                          className={`w-full p-3 rounded-xl text-left border text-xs flex items-center justify-between transition-all ${optStyle}`}
                        >
                          <div className="flex items-start gap-2.5">
                            <span className="font-bold min-w-5">({String.fromCharCode(65 + optIdx)})</span>
                            <div className="flex-1 leading-relaxed">
                              <RichMathText text={opt} />
                            </div>
                          </div>
                          {isSubmitted && isCorrect && (
                            <span className="text-emerald-700 dark:text-emerald-300 font-bold text-[11px] shrink-0 ml-2">
                              ✓ Official Key
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Instant Feedback & Reveal Solution Controls */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 dark:border-slate-800">
                  <div>
                    {isSubmitted ? (
                      <span className={`text-xs font-bold flex items-center gap-1.5 ${
                        isUserCorrect ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                      }`}>
                        {isUserCorrect ? (
                          <>
                            <CheckCircle2 className="w-4 h-4" /> Correct Answer! (+{q.marks || 2} Marks Awarded)
                          </>
                        ) : (
                          <>
                            <XCircle className="w-4 h-4" /> Incorrect ({q.negativeMarks ? `-${q.negativeMarks} Marks` : '0 Marks'})
                          </>
                        )}
                      </span>
                    ) : (
                      <span className="text-xs text-slate-400 dark:text-slate-500">
                        Select an option or input answer to verify
                      </span>
                    )}
                  </div>

                  <Button
                    id={`btn-toggle-solution-${q.id}`}
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleExplanation(q.id)}
                    icon={isExplRevealed ? <ChevronDown className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5 text-indigo-600" />}
                  >
                    {isExplRevealed ? 'Hide Step-by-Step Solution' : 'Show Step-by-Step Solution'}
                  </Button>
                </div>

                {/* Step-by-Step Solution Accordion with Detailed Derivations & Exam Trap Box */}
                {isExplRevealed && (
                  <div className="space-y-3 pt-2">
                    
                    {/* Official Step-by-Step Derivation */}
                    <div className="p-4 rounded-xl bg-indigo-50/90 dark:bg-indigo-950/60 border border-indigo-200/80 dark:border-indigo-800/60 text-xs text-slate-900 dark:text-slate-100 space-y-2">
                      <div className="font-bold uppercase tracking-wider text-[11px] text-indigo-800 dark:text-indigo-300 flex items-center gap-1.5 font-mono">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        Step-by-Step Derivation & Official Grading Logic:
                      </div>
                      <div className="leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-line">
                        <RichMathText text={q.explanation} />
                      </div>

                      {q.formulaRef && (
                        <div className="pt-2 pb-1 text-center bg-white/70 dark:bg-slate-900/70 rounded-lg my-1 border border-indigo-200/50 dark:border-indigo-900/50">
                          <MathRenderer math={q.formulaRef} block={true} />
                        </div>
                      )}
                    </div>

                    {/* IIT Madras Exam Insight / Common Trap Box */}
                    <div className="p-3.5 rounded-xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-300/80 dark:border-amber-900/60 text-xs text-slate-900 dark:text-slate-100 space-y-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-200">
                        <Lightbulb className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                        <span>IIT Madras Exam Insight & Common Trap to Avoid:</span>
                      </div>
                      <ul className="space-y-1 text-slate-800 dark:text-slate-200 pl-2">
                        {q.hints && q.hints.length > 0 ? (
                          q.hints.map((hint, hIdx) => (
                            <li key={hIdx} className="pl-2 border-l-2 border-amber-500 leading-relaxed">
                              <RichMathText text={hint} />
                            </li>
                          ))
                        ) : (
                          <li className="pl-2 border-l-2 border-amber-500 leading-relaxed">
                            Watch out for strict boundary conditions, negative marking rules on MCQs, and verify all options carefully for partial truth in MSQs.
                          </li>
                        )}
                      </ul>
                    </div>

                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Footer Disclaimer */}
      <footer className="pt-8 mt-12 border-t border-slate-200/80 dark:border-slate-800 text-center">
        <p className="text-xs text-slate-400 dark:text-slate-500 max-w-3xl mx-auto leading-relaxed">
          Disclaimer of Non-Affiliation: Prajjwal Study Hub is an independent student-created learning platform and is NOT affiliated with, endorsed by, sponsored by, or officially associated with IIT Madras or the official BS Degree administration.
        </p>
      </footer>

    </div>
  );
};

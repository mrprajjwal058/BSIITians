import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { 
  BarChart2, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  Award, 
  Target, 
  Sparkles, 
  PlayCircle,
  FileText,
  ArrowLeft,
  Calendar,
  Layers,
  GraduationCap,
  Download,
  Printer,
  ChevronRight,
  AlertTriangle,
  Zap
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { EmptyState } from '../../components/common/EmptyState';
import { LevelSwitcher } from '../../components/common/LevelSwitcher';
import { AcademicLevel, TestAttempt } from '../../types';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';

interface PerformancePageProps {
  navigate: (path: string) => void;
}

export const PerformancePage: React.FC<PerformancePageProps> = ({ navigate }) => {
  const { attempts, mockTests, courses } = useData();
  const [selectedLevel, setSelectedLevel] = useState<AcademicLevel | 'All'>('All');

  // Filter attempts based on level
  const filteredAttempts = attempts.filter(a => {
    if (selectedLevel === 'All') return true;
    return a.level === selectedLevel;
  });

  const totalAttempts = filteredAttempts.length;
  const avgPercentage = totalAttempts > 0 
    ? Math.round(filteredAttempts.reduce((sum, a) => sum + a.percentage, 0) / totalAttempts) 
    : 0;
  const avgAccuracy = totalAttempts > 0 
    ? Math.round(filteredAttempts.reduce((sum, a) => sum + a.accuracy, 0) / totalAttempts) 
    : 0;
  const totalTimeSpentSeconds = filteredAttempts.reduce((sum, a) => sum + a.timeSpentSeconds, 0);
  const totalQuestionsAnswered = filteredAttempts.reduce((sum, a) => sum + (a.totalQuestions || 0), 0);
  const avgTimePerQuestionSec = totalQuestionsAnswered > 0 
    ? Math.round(totalTimeSpentSeconds / totalQuestionsAnswered) 
    : 90;

  // Subject performance calculation
  const subjectScores: Record<string, { totalScore: number; maxScore: number; attemptsCount: number; name: string }> = {};
  filteredAttempts.forEach(att => {
    const key = att.courseTitle || 'General Subject';
    if (!subjectScores[key]) {
      subjectScores[key] = { totalScore: 0, maxScore: 0, attemptsCount: 0, name: key };
    }
    subjectScores[key].totalScore += att.score;
    subjectScores[key].maxScore += att.totalMarks;
    subjectScores[key].attemptsCount += 1;
  });

  const subjectPerformanceList = Object.values(subjectScores).map(item => ({
    name: item.name,
    percent: item.maxScore > 0 ? Math.round((item.totalScore / item.maxScore) * 100) : 0,
    attempts: item.attemptsCount,
  }));

  // Print results summary
  const handlePrintPerformance = () => {
    window.print();
  };

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* 1. Header with Breadcrumb Back Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </button>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <div className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              <BarChart2 className="w-3.5 h-3.5" />
              <span>Module 5: Performance Analytics</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Academic Performance & Accuracy Analytics
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Comprehensive breakdown of mock exam scores, accuracy rates, speed pace, and subject strengths.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            id="performance-print-report-btn"
            variant="outline"
            size="sm"
            icon={<Printer className="w-3.5 h-3.5" />}
            onClick={handlePrintPerformance}
          >
            Print Performance Report
          </Button>

          <Button
            id="performance-launch-test-btn"
            variant="primary"
            size="sm"
            icon={<PlayCircle className="w-3.5 h-3.5" />}
            onClick={() => navigate('/mock-tests')}
          >
            Take New CBT Test
          </Button>
        </div>
      </div>

      {/* 2. Global Level Switcher */}
      <LevelSwitcher
        selectedLevel={selectedLevel}
        onSelectLevel={setSelectedLevel}
      />

      {/* 3. Empty State or Rich Analytics Grid */}
      {totalAttempts === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-8 sm:p-12 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <EmptyState
            id="empty-performance-attempts"
            icon={BarChart2}
            title={selectedLevel === 'All' ? "No assessment attempts recorded yet." : `No attempts recorded for ${selectedLevel} level yet.`}
            description="Complete a computer-based mock exam or submit practice problems to build your real performance trajectory."
            actionText="Launch a Mock Test"
            onAction={() => navigate('/mock-tests')}
          />

          <div className="p-6 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 text-center space-y-2">
            <h3 className="text-sm font-bold text-indigo-950 dark:text-indigo-200">
              How Performance Analytics Works
            </h3>
            <p className="text-xs text-indigo-800/80 dark:text-indigo-300/80 max-w-2xl mx-auto leading-relaxed">
              Every time you submit a CBT Mock Test (Quiz 1, Quiz 2, or Qualifier End-Term), your scores, time duration per question, and accuracy ratios automatically populate this dashboard.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          
          {/* Key Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Total Attempts */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-indigo-500 mb-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Total Evaluated Tests</span>
                <Award className="w-4 h-4" />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-slate-100">
                {totalAttempts}
              </div>
              <span className="text-[10px] text-slate-400">Recorded exam sessions</span>
            </div>

            {/* Average Score */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-emerald-500 mb-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Aggregate Average</span>
                <TrendingUp className="w-4 h-4" />
              </div>
              <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                {avgPercentage}%
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 mt-2">
                <div 
                  className="bg-emerald-500 h-1.5 rounded-full" 
                  style={{ width: `${Math.min(avgPercentage, 100)}%` }}
                />
              </div>
            </div>

            {/* Overall Accuracy */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-violet-500 mb-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Question Accuracy</span>
                <Target className="w-4 h-4" />
              </div>
              <div className="text-2xl font-black text-violet-600 dark:text-violet-400">
                {avgAccuracy}%
              </div>
              <span className="text-[10px] text-slate-400">Ratio of correct answers</span>
            </div>

            {/* Speed / Time */}
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between text-amber-500 mb-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Pace / Speed</span>
                <Clock className="w-4 h-4" />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-slate-100">
                {avgTimePerQuestionSec}s / q
              </div>
              <span className="text-[10px] text-slate-400">Target: ~120s per question</span>
            </div>

          </div>

          {/* Subject-Wise Performance Breakdown */}
          {subjectPerformanceList.length > 0 && (
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-indigo-600" />
                  <span>Subject Strengths & Proficiency Breakdown</span>
                </h3>
                <span className="text-xs text-slate-400">Based on evaluated tests</span>
              </div>

              <div className="space-y-3">
                {subjectPerformanceList.map((item, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">
                        {item.name}
                      </span>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">
                        {item.percent}% ({item.attempts} {item.attempts === 1 ? 'test' : 'tests'})
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          item.percent >= 70
                            ? 'bg-emerald-500'
                            : item.percent >= 40
                            ? 'bg-amber-500'
                            : 'bg-rose-500'
                        }`}
                        style={{ width: `${Math.min(item.percent, 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Detailed Attempt History Table */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" />
                <span>Assessment Attempt History ({filteredAttempts.length} Recorded)</span>
              </h3>
              <span className="text-xs text-slate-400">Detailed test transcripts</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 pb-2">
                    <th className="py-3 font-semibold">Test Title</th>
                    <th className="py-3 font-semibold">Level</th>
                    <th className="py-3 font-semibold">Score</th>
                    <th className="py-3 font-semibold">Percentage</th>
                    <th className="py-3 font-semibold">Accuracy</th>
                    <th className="py-3 font-semibold">Duration</th>
                    <th className="py-3 font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredAttempts.map((att, idx) => (
                    <tr key={att.id || idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                      <td className="py-3.5 font-bold text-slate-900 dark:text-white max-w-xs truncate">
                        {att.testTitle}
                      </td>
                      <td className="py-3.5">
                        <Badge variant="primary" size="sm">
                          {att.level || 'Foundation'}
                        </Badge>
                      </td>
                      <td className="py-3.5 font-semibold text-slate-700 dark:text-slate-300">
                        {att.score} / {att.totalMarks}
                      </td>
                      <td className="py-3.5">
                        <span className={`font-bold px-2 py-0.5 rounded-md ${
                          att.percentage >= 70
                            ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : att.percentage >= 40
                            ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                            : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                        }`}>
                          {att.percentage}%
                        </span>
                      </td>
                      <td className="py-3.5 font-medium text-slate-600 dark:text-slate-400">
                        {att.accuracy}%
                      </td>
                      <td className="py-3.5 text-slate-500">
                        {Math.round(att.timeSpentSeconds / 60)} mins
                      </td>
                      <td className="py-3.5 text-slate-400">
                        {att.completedAt ? new Date(att.completedAt).toLocaleDateString() : 'Recent'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};

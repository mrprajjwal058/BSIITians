import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  Calendar, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Trash2, 
  Clock, 
  AlertCircle,
  ArrowLeft,
  Flame,
  BookOpen,
  Target,
  GraduationCap,
  Sparkles,
  Layers,
  ChevronRight,
  ListTodo,
  Download
} from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Modal } from '../../components/common/Modal';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { EmptyState } from '../../components/common/EmptyState';
import { LevelSwitcher } from '../../components/common/LevelSwitcher';
import { StudyPlanTask, AcademicLevel } from '../../types';
import { ACADEMIC_SUBJECTS } from '../../data/pyqQuestionBank';
import { downloadStudyPlannerPdf } from '../../utils/pdfExport';

interface StudyPlannerPageProps {
  navigate?: (path: string) => void;
}

export const StudyPlannerPage: React.FC<StudyPlannerPageProps> = ({ navigate }) => {
  const { tasks, courses, addTask, updateTask, deleteTask } = useData();
  const { user } = useAuth();

  const [selectedLevel, setSelectedLevel] = useState<AcademicLevel | 'All'>('Foundation');

  // Task creation modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskCourseId, setTaskCourseId] = useState('');
  const [taskTopic, setTaskTopic] = useState('');
  const [taskDate, setTaskDate] = useState(new Date().toISOString().split('T')[0]);
  const [taskStartTime, setTaskStartTime] = useState('18:00');
  const [taskEndTime, setTaskEndTime] = useState('19:30');
  const [taskPriority, setTaskPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [filterPriority, setFilterPriority] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');

  // Deletion confirm
  const [taskToDelete, setTaskToDelete] = useState<StudyPlanTask | null>(null);

  // Syllabus weekly checklist state
  const [checkedSyllabusItems, setCheckedSyllabusItems] = useState<Record<string, boolean>>({
    'math1-w1': true,
    'math1-w2': true,
    'stat1-w1': true,
    'ct-w1': true,
    'py-w1': true,
  });

  const availableSubjects = selectedLevel === 'All'
    ? ACADEMIC_SUBJECTS
    : ACADEMIC_SUBJECTS.filter(s => s.level === selectedLevel);

  const filteredTasks = tasks.filter(t => {
    if (filterPriority !== 'All' && t.priority !== filterPriority) return false;
    if (filterStatus === 'pending' && t.completed) return false;
    if (filterStatus === 'completed' && !t.completed) return false;
    return true;
  });

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!taskTitle.trim()) {
      setError('Please provide a task title.');
      return;
    }
    if (!taskDate) {
      setError('Please select a scheduled date.');
      return;
    }

    try {
      addTask({
        courseId: taskCourseId || (availableSubjects[0]?.id || ''),
        title: taskTitle.trim(),
        topic: taskTopic.trim() || undefined,
        topicTitle: taskTopic.trim() || undefined,
        date: taskDate,
        startTime: taskStartTime || undefined,
        endTime: taskEndTime || undefined,
        priority: taskPriority,
        completed: false,
      });

      setTaskTitle('');
      setTaskTopic('');
      setIsModalOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to save task.';
      setError(msg);
    }
  };

  const handleToggleComplete = (task: StudyPlanTask) => {
    updateTask({
      ...task,
      completed: !task.completed,
      completedAt: !task.completed ? new Date().toISOString() : undefined,
    });
  };

  const handleConfirmDelete = () => {
    if (taskToDelete) {
      deleteTask(taskToDelete.id);
      setTaskToDelete(null);
    }
  };

  const toggleSyllabusCheck = (id: string) => {
    setCheckedSyllabusItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const completedCount = tasks.filter(t => t.completed).length;
  const progressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  // Upcoming IITM Term deadlines mock
  const upcomingDeadlines = [
    { title: 'Graded Assignment 4 Submission', date: 'In 3 Days', level: 'Foundation & Diploma', priority: 'high' },
    { title: 'Quiz 1 In-Person Exam Window', date: 'In 12 Days', level: 'All Levels', priority: 'high' },
    { title: 'OPPE 1 Programming Lab Exam', date: 'In 18 Days', level: 'Foundation (Python) & Diploma (Java)', priority: 'medium' },
    { title: 'Quiz 2 Comprehensive CBT', date: 'In 35 Days', level: 'All Levels', priority: 'medium' }
  ];

  return (
    <div className="space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      
      {/* 1. Header with Breadcrumb Back Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {navigate && (
              <>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Dashboard</span>
                </button>
                <span className="text-slate-300 dark:text-slate-700">•</span>
              </>
            )}
            <div className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5" />
              <span>Module 6: Study Planner & Curriculum Tracker</span>
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Personal Study Planner & Task Schedule
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Organize revision blocks, track weekly curriculum progress, and manage assignment deadlines.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="planner-export-pdf-btn"
            variant="outline"
            size="md"
            icon={<Download className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
            onClick={() => {
              downloadStudyPlannerPdf(
                tasks,
                selectedLevel === 'All' ? 'All BS Degree Levels' : `${selectedLevel} Level`,
                user?.name || 'Student Candidate',
                'Monthly & Weekly Study Schedule'
              );
            }}
          >
            Export Schedule (PDF)
          </Button>

          <Button
            id="planner-add-task-btn"
            variant="primary"
            size="md"
            icon={<Plus className="w-4 h-4" />}
            onClick={() => {
              setError(null);
              setIsModalOpen(true);
            }}
          >
            Schedule New Task
          </Button>
        </div>
      </div>

      {/* 2. Global Level Switcher */}
      <LevelSwitcher
        selectedLevel={selectedLevel}
        onSelectLevel={setSelectedLevel}
      />

      {/* 3. Overview Cards: Streak & Progress */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Task Completion Progress */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Task Completion Rate
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black text-slate-900 dark:text-white">
                {completedCount} / {tasks.length}
              </span>
              <span className="text-xs text-indigo-600 dark:text-indigo-400 font-bold">
                {progressPercent}%
              </span>
            </div>
          </div>
          <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 mt-4">
            <div
              className="bg-indigo-600 h-2 rounded-full transition-all"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Consistency Streak */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-amber-500 mb-1">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Study Consistency
              </span>
              <Flame className="w-4 h-4" />
            </div>
            <div className="text-3xl font-black text-slate-900 dark:text-white">
              {completedCount > 0 ? 'Active Streak' : '0 Days'}
            </div>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Check off daily tasks to maintain your study rhythm
          </p>
        </div>

        {/* Active Curriculum Scope */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Target Level Curriculum
            </span>
            <div className="text-lg font-bold text-slate-900 dark:text-white">
              {selectedLevel === 'All' ? 'Complete BS Program' : `${selectedLevel} Level`}
            </div>
          </div>
          <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold mt-2">
            {availableSubjects.length} Active Courses Monitored
          </p>
        </div>

      </div>

      {/* 4. Upcoming Deadlines Banner */}
      <div className="p-5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-indigo-950 dark:text-indigo-200 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span>Upcoming Exam & Assignment Deadlines</span>
          </h3>
          <span className="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold">Official Term Schedule</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {upcomingDeadlines.map((dl, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-900/50 shadow-xs space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950 px-1.5 py-0.5 rounded">
                  {dl.date}
                </span>
                <span className={`w-2 h-2 rounded-full ${dl.priority === 'high' ? 'bg-rose-500' : 'bg-amber-500'}`} />
              </div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                {dl.title}
              </h4>
              <span className="text-[10px] text-slate-400 block truncate">
                {dl.level}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 5. Syllabus Week-by-Week Progress Checklist */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <ListTodo className="w-4 h-4 text-indigo-600" />
            <span>Weekly Syllabus Completion Tracker ({selectedLevel === 'All' ? 'Foundation / Diploma / Degree' : `${selectedLevel} Level`})</span>
          </h3>
          <span className="text-xs text-slate-400 font-medium">Click items to mark completed</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {availableSubjects.map((subj) => {
            const weeks = [1, 2, 3, 4, 5, 6];
            return (
              <div
                key={subj.id}
                className="p-4 rounded-xl bg-slate-50/70 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {subj.name}
                  </span>
                  <Badge variant="primary" size="sm">
                    {subj.code}
                  </Badge>
                </div>

                <div className="space-y-1.5">
                  {weeks.map((wk) => {
                    const itemId = `${subj.id}-w${wk}`;
                    const isChecked = !!checkedSyllabusItems[itemId];

                    return (
                      <div
                        key={wk}
                        onClick={() => toggleSyllabusCheck(itemId)}
                        className={`p-2 rounded-lg text-xs cursor-pointer flex items-center justify-between transition-colors ${
                          isChecked
                            ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 font-medium'
                            : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200/70 dark:border-slate-800 hover:border-indigo-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {isChecked ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                          ) : (
                            <Circle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          )}
                          <span>Week {wk} Revision & Exercises</span>
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {isChecked ? 'Done' : 'Pending'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 6. Tasks List & Filters */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        
        {/* Filters Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-600" />
            <span>Scheduled Study Tasks ({filteredTasks.length})</span>
          </h3>

          <div className="flex items-center gap-2">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as 'all' | 'pending' | 'completed')}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>

            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 focus:outline-none"
            >
              <option value="All">All Priorities</option>
              <option value="high">High Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="low">Low Priority</option>
            </select>
          </div>
        </div>

        {/* Tasks List */}
        {filteredTasks.length === 0 ? (
          <EmptyState
            id="empty-tasks"
            icon={Calendar}
            title="No scheduled study tasks match this filter."
            description="Create daily revision blocks, assign weekly problem sets, and pace your preparation."
            actionText="Schedule a Task"
            onAction={() => setIsModalOpen(true)}
          />
        ) : (
          <div className="space-y-2.5">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                id={`task-item-${task.id}`}
                className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  task.completed
                    ? 'bg-slate-50/80 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-800 text-slate-400 opacity-75'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs'
                }`}
              >
                <div className="flex items-start sm:items-center gap-3">
                  <button
                    onClick={() => handleToggleComplete(task)}
                    className="mt-0.5 sm:mt-0 text-slate-400 hover:text-indigo-600 transition-colors"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    ) : (
                      <Circle className="w-5 h-5" />
                    )}
                  </button>

                  <div>
                    <h4 className={`text-xs sm:text-sm font-bold ${
                      task.completed 
                        ? 'line-through text-slate-400 dark:text-slate-500' 
                        : 'text-slate-900 dark:text-white'
                    }`}>
                      {task.title}
                    </h4>

                    <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-500">
                      <span>{task.courseId}</span>
                      {task.topic && (
                        <>
                          <span>•</span>
                          <span className="truncate max-w-xs">{task.topic}</span>
                        </>
                      )}
                      <span>•</span>
                      <span>{task.date}</span>
                      {task.startTime && (
                        <span>({task.startTime} - {task.endTime || 'end'})</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    task.priority === 'high'
                      ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                      : task.priority === 'medium'
                      ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}>
                    {task.priority.toUpperCase()}
                  </span>

                  <button
                    onClick={() => setTaskToDelete(task)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors"
                    title="Delete task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* 7. Task Creation Modal */}
      {isModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsModalOpen(false)}
          title="Schedule New Study Task"
          maxWidth="lg"
        >
          <form onSubmit={handleCreateTask} className="space-y-4">
            {error && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Task Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Practice Week 3 Derivative & Slopes PYQs"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Subject / Course
                </label>
                <select
                  value={taskCourseId}
                  onChange={(e) => setTaskCourseId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {availableSubjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} - {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Topic / Subheading
                </label>
                <input
                  type="text"
                  placeholder="e.g. Week 3 Normal Distribution"
                  value={taskTopic}
                  onChange={(e) => setTaskTopic(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Date *
                </label>
                <input
                  type="date"
                  required
                  value={taskDate}
                  onChange={(e) => setTaskDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Start Time
                </label>
                <input
                  type="time"
                  value={taskStartTime}
                  onChange={(e) => setTaskStartTime(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Priority
                </label>
                <select
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value as 'low' | 'medium' | 'high')}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
              <Button
                variant="outline"
                size="sm"
                type="button"
                onClick={() => setIsModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                type="submit"
              >
                Save Task
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* 8. Deletion Confirmation Dialog */}
      {taskToDelete && (
        <ConfirmDialog
          isOpen={true}
          title="Delete Scheduled Task"
          message={`Are you sure you want to remove the task "${taskToDelete.title}"?`}
          confirmLabel="Delete Task"
          isDestructive={true}
          onConfirm={handleConfirmDelete}
          onCancel={() => setTaskToDelete(null)}
        />
      )}

    </div>
  );
};

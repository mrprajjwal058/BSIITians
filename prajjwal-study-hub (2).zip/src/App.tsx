import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { ThemeProvider } from './context/ThemeContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { StudentSidebar } from './components/layout/StudentSidebar';
import { AdminSidebar } from './components/layout/AdminSidebar';

// Public Pages
import { LandingPage } from './pages/public/LandingPage';
import { AboutPage } from './pages/public/AboutPage';
import { CoursesPage } from './pages/public/CoursesPage';
import { FeaturesPage } from './pages/public/FeaturesPage';
import { ContactPage } from './pages/public/ContactPage';
import { LoginPage } from './pages/public/LoginPage';
import { SignupPage } from './pages/public/SignupPage';
import { PrivacyPage } from './pages/public/PrivacyPage';
import { TermsPage } from './pages/public/TermsPage';

// Student Pages
import { DashboardPage } from './pages/student/DashboardPage';
import { MyCoursesPage } from './pages/student/MyCoursesPage';
import { NotesPage } from './pages/student/NotesPage';
import { FormulasPage } from './pages/student/FormulasPage';
import { PracticePage } from './pages/student/PracticePage';
import { MockTestsPage } from './pages/student/MockTestsPage';
import { PerformancePage } from './pages/student/PerformancePage';
import { StudyPlannerPage } from './pages/student/StudyPlannerPage';
import { BookmarksPage } from './pages/student/BookmarksPage';
import { ProfilePage } from './pages/student/ProfilePage';

// Admin Pages
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminCoursesPage } from './pages/admin/AdminCoursesPage';
import { AdminNotesPage } from './pages/admin/AdminNotesPage';
import { AdminFormulasPage } from './pages/admin/AdminFormulasPage';
import { AdminQuestionsPage } from './pages/admin/AdminQuestionsPage';
import { AdminMockTestsPage } from './pages/admin/AdminMockTestsPage';
import { AdminMessagesPage } from './pages/admin/AdminMessagesPage';

// Common
import { Button } from './components/common/Button';
import { ShieldAlert, LogIn, ArrowRight } from 'lucide-react';

const AppRouter: React.FC = () => {
  const { user, isAdmin, loginAsDemoStudent, loginAsDemoAdmin } = useAuth();
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    window.history.pushState({}, '', path);
    setCurrentPath(path);
  };

  const isAuthPage = ['/login', '/signup'].includes(currentPath);
  const isPublicRoute = [
    '/',
    '/about',
    '/courses',
    '/features',
    '/contact',
    '/login',
    '/signup',
    '/privacy',
    '/terms',
  ].includes(currentPath);

  const isAdminRoute = currentPath.startsWith('/admin');
  const isStudentRoute = !isPublicRoute && !isAdminRoute;

  // Render content based on currentPath
  const renderContent = () => {
    // 1. Public Pages
    switch (currentPath) {
      case '/':
        return <LandingPage navigate={navigate} />;
      case '/about':
        return <AboutPage navigate={navigate} />;
      case '/courses':
        return <CoursesPage navigate={navigate} />;
      case '/features':
        return <FeaturesPage navigate={navigate} />;
      case '/contact':
        return <ContactPage navigate={navigate} />;
      case '/login':
        return <LoginPage navigate={navigate} />;
      case '/signup':
        return <SignupPage navigate={navigate} />;
      case '/privacy':
        return <PrivacyPage navigate={navigate} />;
      case '/terms':
        return <TermsPage navigate={navigate} />;
    }

    // 2. Admin Routes Guard
    if (isAdminRoute) {
      if (!user) {
        return (
          <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center shadow-lg space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Admin Privileges Required</h2>
            <p className="text-xs text-slate-500">Sign in with an administrator account to access curriculum management tools.</p>
            <div className="pt-2 flex flex-col gap-2">
              <Button
                id="unauth-admin-demo-btn"
                variant="primary"
                onClick={() => {
                  loginAsDemoAdmin();
                  navigate('/admin');
                }}
              >
                Log In as Demo Admin
              </Button>
              <Button
                id="unauth-admin-login-btn"
                variant="outline"
                onClick={() => navigate('/login')}
              >
                Go to Sign In
              </Button>
            </div>
          </div>
        );
      }

      if (!isAdmin) {
        return (
          <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center shadow-lg space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Student Account Detected</h2>
            <p className="text-xs text-slate-500">This management area is restricted to curriculum administrators.</p>
            <div className="pt-2 flex flex-col gap-2">
              <Button
                id="switch-to-demo-admin-btn"
                variant="primary"
                onClick={() => {
                  loginAsDemoAdmin();
                  navigate('/admin');
                }}
              >
                Switch to Demo Admin
              </Button>
              <Button
                id="back-to-student-dashboard-btn"
                variant="outline"
                onClick={() => navigate('/dashboard')}
              >
                Back to Student Dashboard
              </Button>
            </div>
          </div>
        );
      }

      // Admin Pages
      switch (currentPath) {
        case '/admin':
          return <AdminDashboardPage navigate={navigate} />;
        case '/admin/courses':
          return <AdminCoursesPage />;
        case '/admin/notes':
          return <AdminNotesPage />;
        case '/admin/formulas':
          return <AdminFormulasPage />;
        case '/admin/questions':
          return <AdminQuestionsPage />;
        case '/admin/mock-tests':
          return <AdminMockTestsPage />;
        case '/admin/messages':
          return <AdminMessagesPage />;
        default:
          return <AdminDashboardPage navigate={navigate} />;
      }
    }

    // 3. Student Routes Guard
    if (isStudentRoute) {
      if (!user) {
        return (
          <div className="max-w-md mx-auto my-16 p-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-center shadow-lg space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 flex items-center justify-center mx-auto">
              <LogIn className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">Sign In to Continue</h2>
            <p className="text-xs text-slate-500">Access your revision notes, formula sheets, mock tests, and personalized study planner.</p>
            <div className="pt-2 flex flex-col gap-2">
              <Button
                id="unauth-student-demo-btn"
                variant="primary"
                onClick={() => {
                  loginAsDemoStudent();
                  navigate('/dashboard');
                }}
              >
                Explore as Demo Student
              </Button>
              <Button
                id="unauth-student-login-btn"
                variant="outline"
                onClick={() => navigate('/login')}
              >
                Go to Sign In
              </Button>
            </div>
          </div>
        );
      }

      // Student Pages
      switch (currentPath) {
        case '/dashboard':
          return <DashboardPage navigate={navigate} />;
        case '/my-courses':
          return <MyCoursesPage navigate={navigate} />;
        case '/notes':
          return <NotesPage navigate={navigate} />;
        case '/formulas':
          return <FormulasPage navigate={navigate} />;
        case '/practice':
          return <PracticePage navigate={navigate} />;
        case '/mock-tests':
          return <MockTestsPage navigate={navigate} />;
        case '/performance':
          return <PerformancePage navigate={navigate} />;
        case '/study-planner':
          return <StudyPlannerPage navigate={navigate} />;
        case '/bookmarks':
          return <BookmarksPage navigate={navigate} />;
        case '/profile':
          return <ProfilePage navigate={navigate} />;
        default:
          return <DashboardPage navigate={navigate} />;
      }
    }

    return <LandingPage navigate={navigate} />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 antialiased font-sans transition-colors">
      {!isAuthPage && <Navbar currentPath={currentPath} navigate={navigate} />}

      <div className="flex-1 flex w-full">
        {/* Render Sidebar on Authenticated Pages */}
        {user && isStudentRoute && (
          <StudentSidebar currentPath={currentPath} navigate={navigate} />
        )}

        {user && isAdminRoute && (
          <AdminSidebar currentPath={currentPath} navigate={navigate} />
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 w-full overflow-x-hidden min-h-[calc(100vh-4rem)]">
          {renderContent()}
        </main>
      </div>

      {/* Render Footer on Public Pages (except auth pages) or bottom of screen */}
      {isPublicRoute && !isAuthPage && <Footer navigate={navigate} />}
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <DataProvider>
          <AppRouter />
        </DataProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  role: UserRole | null;
  isAdmin: boolean;
  isStudent: boolean;
  signup: (name: string, email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  login: (email: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  updateUserProfile: (updates: Partial<UserProfile>) => Promise<void>;
  loginAsDemoStudent: () => void;
  loginAsDemoAdmin: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEMO_STUDENT: UserProfile = {
  uid: 'usr-demo-student-01',
  name: 'Prajjwal Student',
  email: 'student@prajjwalhub.edu',
  role: 'student',
  programEnrolled: 'IIT Madras BS Degree — Independent Preparation',
  currentTerm: 'Term 1 (Foundation)',
  targetExam: 'Term 1 Quiz 1 & 2',
  dailyGoalMinutes: 90,
  bio: 'Independent learner preparing for Foundational Mathematics, Statistics, and Python courses.',
  createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
  updatedAt: new Date().toISOString(),
};

const DEMO_ADMIN: UserProfile = {
  uid: 'usr-admin-prajjwal',
  name: 'Prajjwal Pandey (Admin)',
  email: 'prajjwalpandey225@gmail.com',
  role: 'admin',
  programEnrolled: 'Platform Administrator',
  currentTerm: 'Administrator',
  targetExam: 'Curriculum Management',
  dailyGoalMinutes: 120,
  bio: 'Platform founder and chief curriculum organizer.',
  createdAt: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000).toISOString(),
  updatedAt: new Date().toISOString(),
};

const REGISTERED_USERS_KEY = 'psh_registered_users';
const CURRENT_USER_KEY = 'psh_current_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Check saved session
    try {
      const saved = localStorage.getItem(CURRENT_USER_KEY);
      if (saved) {
        setUser(JSON.parse(saved));
      } else {
        // Default to logged-out public state
        setUser(null);
      }
    } catch (e) {
      console.error('Error reading session:', e);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const persistUser = (u: UserProfile | null) => {
    setUser(u);
    if (u) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(u));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  };

  const signup = async (name: string, email: string, _password?: string): Promise<{ success: boolean; error?: string }> => {
    setLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      const cleanName = name.trim();

      if (!cleanName) {
        return { success: false, error: 'Full name is required.' };
      }
      if (!cleanEmail || !cleanEmail.includes('@')) {
        return { success: false, error: 'Please provide a valid email address.' };
      }

      // Check existing users in storage
      const existingUsersRaw = localStorage.getItem(REGISTERED_USERS_KEY);
      const existingUsers: UserProfile[] = existingUsersRaw ? JSON.parse(existingUsersRaw) : [];

      if (existingUsers.some(u => u.email.toLowerCase() === cleanEmail)) {
        return { success: false, error: 'An account with this email address already exists. Please log in.' };
      }

      // Requirement 9 & 10: Default role MUST strictly be 'student', never admin from signup form
      const newUser: UserProfile = {
        uid: `usr-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        name: cleanName,
        email: cleanEmail,
        role: 'student',
        programEnrolled: 'IIT Madras BS Degree — Independent Preparation',
        currentTerm: 'Term 1 (Foundation)',
        targetExam: 'Upcoming Quiz 1',
        dailyGoalMinutes: 60,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      existingUsers.push(newUser);
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(existingUsers));
      persistUser(newUser);

      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Signup failed. Please try again.';
      return { success: false, error: msg };
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, _password?: string): Promise<{ success: boolean; error?: string }> => {
    setLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      if (!cleanEmail) {
        return { success: false, error: 'Please enter your email.' };
      }

      // Check predefined accounts
      if (cleanEmail === DEMO_ADMIN.email.toLowerCase() || cleanEmail === 'admin@prajjwalhub.edu') {
        persistUser(DEMO_ADMIN);
        return { success: true };
      }
      if (cleanEmail === DEMO_STUDENT.email.toLowerCase()) {
        persistUser(DEMO_STUDENT);
        return { success: true };
      }

      // Check registered users
      const existingUsersRaw = localStorage.getItem(REGISTERED_USERS_KEY);
      const existingUsers: UserProfile[] = existingUsersRaw ? JSON.parse(existingUsersRaw) : [];
      const found = existingUsers.find(u => u.email.toLowerCase() === cleanEmail);

      if (found) {
        persistUser(found);
        return { success: true };
      }

      // If not registered yet, automatically create standard student profile
      const newUser: UserProfile = {
        uid: `usr-${Date.now()}`,
        name: cleanEmail.split('@')[0],
        email: cleanEmail,
        role: 'student',
        programEnrolled: 'IIT Madras BS Degree — Independent Preparation',
        currentTerm: 'Term 1 (Foundation)',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      existingUsers.push(newUser);
      localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(existingUsers));
      persistUser(newUser);

      return { success: true };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Login failed.';
      return { success: false, error: msg };
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    persistUser(null);
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; message?: string; error?: string }> => {
    if (!email || !email.includes('@')) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    // Simulate real security token transmission
    return {
      success: true,
      message: `Password reset instructions have been sent to ${email}. Please check your inbox and spam folder.`
    };
  };

  const updateUserProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      ...updates,
      // Security protection: Prevent privilege escalation from profile update
      role: user.role === 'admin' ? (updates.role || 'admin') : 'student',
      updatedAt: new Date().toISOString(),
    };
    persistUser(updated);

    // Update in registered list too
    const existingUsersRaw = localStorage.getItem(REGISTERED_USERS_KEY);
    if (existingUsersRaw) {
      const existingUsers: UserProfile[] = JSON.parse(existingUsersRaw);
      const idx = existingUsers.findIndex(u => u.uid === user.uid);
      if (idx >= 0) {
        existingUsers[idx] = updated;
        localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(existingUsers));
      }
    }
  };

  const loginAsDemoStudent = () => {
    persistUser(DEMO_STUDENT);
  };

  const loginAsDemoAdmin = () => {
    persistUser(DEMO_ADMIN);
  };

  const role = user?.role || null;
  const isAdmin = role === 'admin';
  const isStudent = role === 'student';

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        role,
        isAdmin,
        isStudent,
        signup,
        login,
        logout,
        resetPassword,
        updateUserProfile,
        loginAsDemoStudent,
        loginAsDemoAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

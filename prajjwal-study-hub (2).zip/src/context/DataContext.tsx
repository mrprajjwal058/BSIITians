import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  Program, 
  Course, 
  Module, 
  Topic, 
  Note, 
  FormulaSheet, 
  Question, 
  MockTest, 
  StudyPlanTask, 
  BookmarkItem,
  TestAttempt,
  ContactMessage
} from '../types';
import { dbService } from '../services/db';
import { useAuth } from './AuthContext';

export interface DataContextType {
  programs: Program[];
  courses: Course[];
  modules: Module[];
  topics: Topic[];
  notes: Note[];
  formulas: FormulaSheet[];
  questions: Question[];
  mockTests: MockTest[];
  tasks: StudyPlanTask[];
  bookmarks: BookmarkItem[];
  attempts: TestAttempt[];
  contactMessages: ContactMessage[];
  refreshData: () => void;

  // Course operations
  saveCourse: (course: Course) => void;
  addCourse: (course: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateCourse: (id: string, course: Partial<Course>) => void;
  deleteCourse: (id: string) => void;

  // Module & Topic operations
  saveModule: (module: Module) => void;
  addModule: (module: Omit<Module, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deleteModule: (id: string) => void;
  saveTopic: (topic: Topic) => void;
  deleteTopic: (id: string) => void;

  // Note operations
  saveNote: (note: Note) => void;
  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateNote: (id: string, note: Partial<Note>) => void;
  deleteNote: (id: string) => void;

  // Formula operations
  saveFormula: (formula: FormulaSheet) => void;
  addFormula: (formula: Omit<FormulaSheet, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateFormula: (id: string, formula: Partial<FormulaSheet>) => void;
  deleteFormula: (id: string) => void;

  // Question operations
  saveQuestion: (question: Question) => void;
  addQuestion: (question: Omit<Question, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateQuestion: (id: string, question: Partial<Question>) => void;
  deleteQuestion: (id: string) => void;

  // Mock Test operations
  saveMockTest: (test: MockTest) => void;
  addMockTest: (test: Omit<MockTest, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMockTest: (id: string, test: Partial<MockTest>) => void;
  deleteMockTest: (id: string) => void;

  // Program operations
  saveProgram: (program: Program) => void;
  deleteProgram: (id: string) => void;

  // User tasks & bookmarks
  addTask: (task: Omit<StudyPlanTask, 'id' | 'userId' | 'createdAt' | 'updatedAt'> | StudyPlanTask) => void;
  updateTask: (task: StudyPlanTask) => void;
  deleteTask: (id: string) => void;
  toggleTaskCompletion: (id: string) => void;
  toggleBookmark: (itemType: 'note' | 'formula' | 'question' | 'course' | string, itemId: string, title?: string, courseName?: string) => boolean;
  removeBookmark: (id: string) => void;
  isBookmarked: (itemType: string, itemId: string) => boolean;
  recordTestAttempt: (attempt: Omit<TestAttempt, 'id' | 'userId' | 'completedAt'>) => void;

  // Contact Messages & Feedback
  sendContactMessage: (msg: Omit<ContactMessage, 'id' | 'createdAt' | 'status'>) => void;
  updateMessageStatus: (id: string, status: 'pending' | 'reviewed' | 'replied') => void;
  deleteContactMessage: (id: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  const [programs, setPrograms] = useState<Program[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [modules, setModules] = useState<Module[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [formulas, setFormulas] = useState<FormulaSheet[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [mockTests, setMockTests] = useState<MockTest[]>([]);
  const [tasks, setTasks] = useState<StudyPlanTask[]>([]);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [attempts, setAttempts] = useState<TestAttempt[]>([]);
  const [contactMessages, setContactMessages] = useState<ContactMessage[]>([]);

  const refreshData = useCallback(() => {
    setPrograms(dbService.getPrograms());
    setCourses(dbService.getCourses());
    setModules(dbService.getModules());
    setTopics(dbService.getTopics());
    setNotes(dbService.getNotes());
    setFormulas(dbService.getFormulas());
    setQuestions(dbService.getQuestions());
    setMockTests(dbService.getMockTests());
    setContactMessages(dbService.getContactMessages());

    if (user?.uid) {
      setTasks(dbService.getStudyTasks(user.uid));
      setBookmarks(dbService.getBookmarks(user.uid));
      setAttempts(dbService.getTestAttempts(user.uid));
    } else {
      setTasks([]);
      setBookmarks([]);
      setAttempts([]);
    }
  }, [user?.uid]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Program Handlers
  const saveProgram = (p: Program) => {
    dbService.saveProgram(p);
    refreshData();
  };
  const deleteProgram = (id: string) => {
    dbService.deleteProgram(id);
    refreshData();
  };

  // Course Handlers
  const saveCourse = (c: Course) => {
    dbService.saveCourse(c);
    refreshData();
  };
  const addCourse = (courseData: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newCourse: Course = {
      ...courseData,
      id: `course-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveCourse(newCourse);
    refreshData();
  };
  const updateCourse = (id: string, updates: Partial<Course>) => {
    const existing = courses.find(c => c.id === id);
    if (existing) {
      dbService.saveCourse({ ...existing, ...updates, updatedAt: new Date().toISOString() });
      refreshData();
    }
  };
  const deleteCourse = (id: string) => {
    dbService.deleteCourse(id);
    refreshData();
  };

  // Module Handlers
  const saveModule = (m: Module) => {
    dbService.saveModule(m);
    refreshData();
  };
  const addModule = (moduleData: Omit<Module, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newModule: Module = {
      ...moduleData,
      id: `mod-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveModule(newModule);
    refreshData();
  };
  const deleteModule = (id: string) => {
    dbService.deleteModule(id);
    refreshData();
  };

  // Topic Handlers
  const saveTopic = (t: Topic) => {
    dbService.saveTopic(t);
    refreshData();
  };
  const deleteTopic = (id: string) => {
    dbService.deleteTopic(id);
    refreshData();
  };

  // Note Handlers
  const saveNote = (n: Note) => {
    dbService.saveNote(n);
    refreshData();
  };
  const addNote = (noteData: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newNote: Note = {
      ...noteData,
      id: `note-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveNote(newNote);
    refreshData();
  };
  const updateNote = (id: string, updates: Partial<Note>) => {
    const existing = notes.find(n => n.id === id);
    if (existing) {
      dbService.saveNote({ ...existing, ...updates, updatedAt: new Date().toISOString() });
      refreshData();
    }
  };
  const deleteNote = (id: string) => {
    dbService.deleteNote(id);
    refreshData();
  };

  // Formula Handlers
  const saveFormula = (f: FormulaSheet) => {
    dbService.saveFormula(f);
    refreshData();
  };
  const addFormula = (formulaData: Omit<FormulaSheet, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newFormula: FormulaSheet = {
      ...formulaData,
      id: `form-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveFormula(newFormula);
    refreshData();
  };
  const updateFormula = (id: string, updates: Partial<FormulaSheet>) => {
    const existing = formulas.find(f => f.id === id);
    if (existing) {
      dbService.saveFormula({ ...existing, ...updates, updatedAt: new Date().toISOString() });
      refreshData();
    }
  };
  const deleteFormula = (id: string) => {
    dbService.deleteFormula(id);
    refreshData();
  };

  // Question Handlers
  const saveQuestion = (q: Question) => {
    dbService.saveQuestion(q);
    refreshData();
  };
  const addQuestion = (questionData: Omit<Question, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newQuestion: Question = {
      ...questionData,
      id: `q-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveQuestion(newQuestion);
    refreshData();
  };
  const updateQuestion = (id: string, updates: Partial<Question>) => {
    const existing = questions.find(q => q.id === id);
    if (existing) {
      dbService.saveQuestion({ ...existing, ...updates, updatedAt: new Date().toISOString() });
      refreshData();
    }
  };
  const deleteQuestion = (id: string) => {
    dbService.deleteQuestion(id);
    refreshData();
  };

  // MockTest Handlers
  const saveMockTest = (m: MockTest) => {
    dbService.saveMockTest(m);
    refreshData();
  };
  const addMockTest = (testData: Omit<MockTest, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newMockTest: MockTest = {
      ...testData,
      id: `test-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveMockTest(newMockTest);
    refreshData();
  };
  const updateMockTest = (id: string, updates: Partial<MockTest>) => {
    const existing = mockTests.find(t => t.id === id);
    if (existing) {
      dbService.saveMockTest({ ...existing, ...updates, updatedAt: new Date().toISOString() });
      refreshData();
    }
  };
  const deleteMockTest = (id: string) => {
    dbService.deleteMockTest(id);
    refreshData();
  };

  // Task Handlers
  const addTask = (taskData: Omit<StudyPlanTask, 'id' | 'userId' | 'createdAt' | 'updatedAt'> | StudyPlanTask) => {
    if (!user) return;
    const newTask: StudyPlanTask = {
      ...taskData,
      id: 'id' in taskData && taskData.id ? taskData.id : `task-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      userId: user.uid,
      createdAt: 'createdAt' in taskData && taskData.createdAt ? taskData.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    dbService.saveStudyTask(newTask);
    refreshData();
  };

  const updateTask = (task: StudyPlanTask) => {
    dbService.saveStudyTask(task);
    refreshData();
  };

  const deleteTask = (id: string) => {
    dbService.deleteStudyTask(id);
    refreshData();
  };

  const toggleTaskCompletion = (id: string) => {
    const target = tasks.find(t => t.id === id);
    if (!target) return;
    const updated: StudyPlanTask = {
      ...target,
      completed: !target.completed,
      completedAt: !target.completed ? new Date().toISOString() : undefined,
      updatedAt: new Date().toISOString(),
    };
    dbService.saveStudyTask(updated);
    refreshData();
  };

  // Bookmark Handlers
  const toggleBookmark = (itemType: 'note' | 'formula' | 'question' | 'course' | string, itemId: string, title?: string, courseName?: string) => {
    if (!user) return false;
    const result = dbService.toggleBookmark({
      userId: user.uid,
      itemType,
      itemId,
      title: title || 'Bookmark',
      courseName
    });
    refreshData();
    return result;
  };

  const removeBookmark = (id: string) => {
    dbService.removeBookmark(id);
    refreshData();
  };

  const isBookmarked = (itemType: string, itemId: string): boolean => {
    if (!user) return false;
    return dbService.isBookmarked(user.uid, itemType, itemId);
  };

  // Test Attempt Handlers
  const recordTestAttempt = (attemptData: Omit<TestAttempt, 'id' | 'userId' | 'completedAt'>) => {
    if (!user) return;
    const newAttempt: TestAttempt = {
      ...attemptData,
      id: `att-${Date.now()}`,
      userId: user.uid,
      completedAt: new Date().toISOString(),
    };
    dbService.saveTestAttempt(newAttempt);
    refreshData();
  };

  // Contact Messages Handlers
  const sendContactMessage = (msg: Omit<ContactMessage, 'id' | 'createdAt' | 'status'>) => {
    dbService.saveContactMessage(msg);
    refreshData();
  };

  const updateMessageStatus = (id: string, status: 'pending' | 'reviewed' | 'replied') => {
    dbService.updateContactMessageStatus(id, status);
    refreshData();
  };

  const deleteContactMessage = (id: string) => {
    dbService.deleteContactMessage(id);
    refreshData();
  };

  return (
    <DataContext.Provider
      value={{
        programs,
        courses,
        modules,
        topics,
        notes,
        formulas,
        questions,
        mockTests,
        tasks,
        bookmarks,
        attempts,
        contactMessages,
        refreshData,
        saveProgram,
        deleteProgram,
        saveCourse,
        addCourse,
        updateCourse,
        deleteCourse,
        saveModule,
        addModule,
        deleteModule,
        saveTopic,
        deleteTopic,
        saveNote,
        addNote,
        updateNote,
        deleteNote,
        saveFormula,
        addFormula,
        updateFormula,
        deleteFormula,
        saveQuestion,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        saveMockTest,
        addMockTest,
        updateMockTest,
        deleteMockTest,
        addTask,
        updateTask,
        deleteTask,
        toggleTaskCompletion,
        toggleBookmark,
        removeBookmark,
        isBookmarked,
        recordTestAttempt,
        sendContactMessage,
        updateMessageStatus,
        deleteContactMessage,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
